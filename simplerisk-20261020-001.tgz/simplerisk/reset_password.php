<?php
    /* This Source Code Form is subject to the terms of the Mozilla Public
    * License, v. 2.0. If a copy of the MPL was not distributed with this
    * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

    // Include required functions file
    require_once(realpath(__DIR__ . '/includes/functions.php'));
    require_once(realpath(__DIR__ . '/includes/authenticate.php'));
    require_once(realpath(__DIR__ . '/includes/display.php'));
    require_once(realpath(__DIR__ . '/includes/alerts.php'));
    require_once(realpath(__DIR__ . '/vendor/autoload.php'));

    // Add various security headers
    add_security_headers();

    if (!isset($_SESSION)) {

        // Session handler is database
        if (use_database_for_sessions()) {
            SimpleRiskSessionHandler::register();
        }

        // Start session
        $parameters = [
            "lifetime" => 0,
            "path" => "/",
            "domain" => "",
            "secure" => isset($_SERVER["HTTPS"]),
            "httponly" => true,
            "samesite" => "Strict",
        ];
        session_set_cookie_params($parameters);

        session_name('SimpleRisk');
        session_start();
    }

    // Include the CSRF Magic library
    include_csrf_magic();

    // Include the language file
    require_once(language_file());
	
    // Set a global variable for the current app version, so we don't have to call a function every time
	$current_app_version = current_version("app");

    if(empty($_SESSION['first_login_uid'])) {

        header('Location: index.php');
        exit;

    }

    // Generate a per-session CSRF nonce for this form if one does not already exist.
    // This is an explicit, server-side defence independent of the csrf-magic library.
    if (empty($_SESSION['reset_pwd_csrf_token'])) {
        $_SESSION['reset_pwd_csrf_token'] = bin2hex(random_bytes(32));
    }

    // Check if a password reset was requested
    if (isset($_POST['password_reset'])) {

        // Validate the explicit CSRF nonce before any state change.
        // hash_equals prevents timing-based side-channel attacks.
        $submitted_token = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['reset_pwd_csrf_token'], $submitted_token)) {
            set_alert(true, "bad", $lang['AccessDenied']);
            header('Location: reset_password.php');
            exit;
        }

        // Rotate the nonce after a valid submission so it cannot be replayed.
        $_SESSION['reset_pwd_csrf_token'] = bin2hex(random_bytes(32));

        $user_id            = $_SESSION['first_login_uid'];
        $current_password   = $_SESSION['first_login_pass'];
        $new_password       = $_POST['new_password'];
        $confirm_password    = $_POST['confirm_password'];

        // Remove the current password from the session
        unset($_SESSION['first_login_pass']);

        // If a password reset was submitted
        if (reset_password($user_id, $current_password, $new_password, $confirm_password)) {

            // Belt and braces. reset_password() has already cleared
            // first_login_uid — deliberately, because on the no-MFA branch
            // login() can exit(0) inside registration_redirect() and never
            // return here at all. This repeats it for the paths that DO return,
            // so the guard at the top of this file cannot be left holding a
            // marker for a change that is already done.
            unset($_SESSION['first_login_uid']);

            // Hand off to index.php rather than picking a destination here.
            // reset_password() ends by calling login(), which sets
            // $_SESSION['access'] and — ONLY on the no-MFA branch — issues its
            // own redirect. With MFA enabled it just sets the access value and
            // returns, so before this we fell through and re-rendered this very
            // form: the password had been changed, the success alert was shown,
            // and the visitor was handed back the change-password page with no
            // way forward. index.php already routes on $_SESSION['access'] to
            // MFA enrolment, MFA verification, or the landing page, which is
            // exactly what an ordinary login does in-request.
            header('Location: index.php');
            exit;

        }

    }

?>
<!doctype html>
<html>
    <head>
        <title>SimpleRisk: Enterprise Risk Management Simplified</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
        <meta http-equiv="X-UA-Compatible" content="IE=10,9,7,8">
        
        <!-- Favicon icon -->
        <?php setup_favicon();?>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/style.min.css?<?= $current_app_version ?>" />

        <!-- extra css -->
        <link rel="stylesheet" href="vendor/components/font-awesome/css/fontawesome.min.css?<?= $current_app_version ?>">

        <!-- jQuery Javascript -->
        <script src="vendor/node_modules/jquery/dist/jquery.min.js?<?= $current_app_version ?>" id="script_jquery"></script>

        <!-- Bootstrap tether Core JavaScript -->
        <script src="vendor/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js" defer></script> 

    </head>
    <body class="sr-auth-page">
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <div class="sr-auth">
<?php display_auth_brand_panel(); ?>
            <main class="sr-auth-main">
                <div class="sr-auth-col">
                    <div class="sr-auth-card">
                        <div class="sr-auth-card-head">
                            <h2><?= $escaper->escapeHtml($lang['PasswordChangeRequired']);?></h2>
                            <p><?= $escaper->escapeHtml($lang['ChooseANewPasswordToContinue']);?></p>
                        </div>
                        <form name="password_reset" method="post" autocomplete="off" action="" class="password_reset">
                            <input type="hidden" name="csrf_token" value="<?= $escaper->escapeHtmlAttr($_SESSION['reset_pwd_csrf_token']) ?>">
                            <div class="sr-auth-card-body">
    <?php
        $resetRequestMessages = getPasswordReqeustMessages();
        if(count($resetRequestMessages)) {
            // Each message already came back from _lang(), which escapes its
            // params -- so they are emitted as-is rather than escaped a second
            // time (see the double-escaping rule in CLAUDE.md).
            echo "
                                <div class='sr-auth-requirements'>
                                    <p>" . $escaper->escapeHtml($lang['PasswordRequirements']) . "</p>
                                    <ul>
            ";
            foreach($resetRequestMessages as $resetRequestMessage) {
                echo "
                                        <li>{$resetRequestMessage}</li>
                ";
            }
            echo "
                                    </ul>
                                </div>
            ";
        }
    ?>
                                <div class="sr-auth-field">
                                    <label for="new_password"><?= $escaper->escapeHtml($lang['NewPassword']);?></label>
                                    <input class="form-control" name="new_password" id="new_password" type="password" maxlength="50" autocomplete="off" />
                                </div>
                                <div class="sr-auth-field">
                                    <label for="confirm_password"><?= $escaper->escapeHtml($lang['ConfirmPassword']);?></label>
                                    <input class="form-control" name="confirm_password" id="confirm_password" type="password" maxlength="50" autocomplete="off" />
                                </div>
                                <div class="sr-auth-actions">
                                    <button type="reset" class="btn btn-dark"><?= $escaper->escapeHtml($lang['Reset']);?></button>
                                    <button type="submit" class="btn btn-submit" name="password_reset"><?= $escaper->escapeHtml($lang['Submit']);?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
        <!-- End Wrapper -->
    <?php
        get_alert();
        setup_alert_requirements("");
    ?>
    	<script>
        	$(function() {
        		// Fading out the preloader once everything is done rendering
        		$(".preloader").fadeOut();
            });
    	</script>
    </body>
</html>