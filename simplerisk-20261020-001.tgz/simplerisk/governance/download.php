<?php
    /* This Source Code Form is subject to the terms of the Mozilla Public
    * License, v. 2.0. If a copy of the MPL was not distributed with this
    * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

    // Include required functions file
    require_once(realpath(__DIR__ . '/../includes/functions.php'));
    require_once(realpath(__DIR__ . '/../includes/authenticate.php'));
    require_once(realpath(__DIR__ . '/../includes/display.php'));
    require_once(realpath(__DIR__ . '/../includes/permissions.php'));
    require_once(realpath(__DIR__ . '/../includes/governance.php'));
    require_once(realpath(__DIR__ . '/../includes/compliance.php'));
    require_once(realpath(__DIR__ . '/../vendor/autoload.php'));

// Add various security headers
add_security_headers();

// Add the session — flagged is_action because this is a file
// download, not a viewable page that should anchor navigation.
$permissions = array(
        "check_access" => true,
        "check_governance" => true,
        "is_action" => true,
);
add_session_check($permissions);

// Include the CSRF Magic library
include_csrf_magic();

// Include the SimpleRisk language file
require_once(language_file());

    // Check if a file id was sent
    if (isset($_GET['id']) || isset($_POST['id']))
    {
        if (isset($_GET['id']))
        {
            // Set the id to the get parameter
            $id = $_GET['id'];
        }
        else if (isset($_POST['id']))
        {
            // Set the id to the post parameter
            $id = $_POST['id'];
        }

        // Same team-separation gate compliance/download.php applies. Without
        // this guard, governance/download.php served any compliance_file by
        // id even with the team separation extra enabled. download_compliance_file()
        // enforces the per-ref_type granular permission at the sink (e.g.
        // view_exception for exception attachments, SR-1694) but not team
        // separation, so this entry-point check remains necessary.
        if (team_separation_extra()) {

            require_once(realpath(__DIR__ . '/../extras/separation/index.php'));

            if (!should_skip_test_and_audit_permission_check()) {
                if (!check_permission_for_compliance_file($id)) {
                    redirect_permission_denied('DownloadFilePermissionMessage', "governance file id={$id}");
                }
            }
        }

        // Get the file for the submitted file id
        download_compliance_file($id);
    }

?>
