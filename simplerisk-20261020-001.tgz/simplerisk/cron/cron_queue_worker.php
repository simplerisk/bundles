<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. You can obtain one at http://mozilla.org/MPL/2.0/. */

declare(strict_types=1);

if (php_sapi_name() !== "cli") {
    exit("This script must be run via the command line.\n");
}

require_once(realpath(__DIR__ . '/../includes/functions.php'));
require_once(realpath(__DIR__ . '/../includes/mail.php'));
require_once(realpath(__DIR__ . '/../includes/queues.php'));
require_once(realpath(__DIR__ . '/../includes/promises.php'));
require_once(realpath(__DIR__ . '/../includes/workers.php'));
require_once(realpath(__DIR__ . '/../includes/files.php'));
require_once(realpath(__DIR__ . '/../includes/Components/DocumentTextHandler.php'));
require_once(realpath(__DIR__ . '/../includes/Components/CsvHandler.php'));
require_once(realpath(__DIR__ . '/../includes/Components/PdfHandler.php'));
require_once(realpath(__DIR__ . '/../includes/Components/SpreadsheetHandler.php'));
require_once(realpath(__DIR__ . '/../includes/Components/WordHandler.php'));

// === CONFIGURATION ===
$workerName = 'cron_queue_worker';
$stalePidThreshold = 24 * 3600; // 24 hours
$loopDelaySeconds = 3;
$maxRuntimeMinutes = 60;
$maxIdleMinutes = 60;
$memoryLimitBytes = 400 * 1024 * 1024;
$stuckThresholdMinutes = 30;

$startTime = time();
$lastWorkTime = time();
// config.php, watched so an edit recycles the worker (see the main loop).
$configPath = __DIR__ . '/../includes/config.php';

// === SESSION IDENTITY FOR AUDIT LOGS ===
// Functions that write audit log entries read $_SESSION['user'] and $_SESSION['uid'].
// There is no HTTP session in CLI context, so seed these with a system identity.
$_SESSION['user'] = 'System User';
$_SESSION['uid']  = -1;

// === SYSTEM SETTINGS ===
ini_set('max_execution_time', 0);
set_time_limit(0);
ini_set('memory_limit', '512M');
ob_implicit_flush(true);

write_debug_log("Queue worker started (PID " . getmypid() . ")", "info");

// === CHECK FOR ZOMBIE WORKERS ===
$zombies = list_zombie_workers($workerName, $stalePidThreshold);
foreach ($zombies as $zombie) {
    write_debug_log(
        "Zombie worker detected: PID {$zombie['pid']} on host {$zombie['host']}, last heartbeat {$zombie['last_heartbeat']}",
        "warning"
    );
}

// === ACQUIRE LOCK ===
if (!acquire_worker_lock($workerName, $stalePidThreshold)) {
    write_debug_log("$workerName lock not acquired, exiting.", "info");
    exit(0);
}

// === REGISTER SIGNAL HANDLERS ===
register_worker_signal_handlers($workerName);

// === SHUTDOWN FUNCTION ===
register_shutdown_function(function () use ($workerName) {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
        write_debug_log("Fatal worker error: {$error['message']} in {$error['file']}:{$error['line']}", "error");
        record_worker_restart($workerName, 'fatal_error: ' . $error['message']);
    }
    release_worker_lock($workerName);
});

// === OPEN DB CONNECTION ===
$db = db_open();
if (!$db) {
    write_debug_log("Failed to open database connection, exiting.", "error");
    exit(1);
}

// === MAIN WORKER LOOP ===
while (true) {
    // Dispatch signals
    if (function_exists('pcntl_signal_dispatch')) {
        pcntl_signal_dispatch();
    }

    $now = time();

    // === SHUTDOWN & RELOAD CHECKS ===
    if (worker_should_shutdown()) {
        write_debug_log("Shutdown requested, exiting main loop...", "info");
        break;
    }

    // SIGHUP means "recycle with fresh code". An in-process reload is
    // impossible (require_once is a no-op once a file is loaded), so exit
    // gracefully and let cron respawn the worker with the new code.
    if (worker_should_reload()) {
        record_worker_restart($workerName, 'reload_signal');
        break;
    }

    // A deploy/upgrade requested a restart after this worker started, so
    // the code on disk is newer than the code in memory. Exit gracefully —
    // the current task already finished — and let cron respawn with fresh
    // code. Workers started after the request keep running.
    if (worker_restart_requested_since($startTime, worker_restart_flag_timestamp())) {
        record_worker_restart($workerName, 'restart_requested');
        break;
    }

    // config.php is read once, at start. When a system administrator edits it
    // (for example the asset discovery allowlist), exit between tasks so cron
    // respawns the worker with the new configuration. Fail-safe: a stat
    // failure or a future mtime never triggers this, and the respawned worker
    // starts after the edit, so it does not loop (worker_config_changed_since()).
    clearstatcache(true, $configPath);
    if (worker_config_changed_since($startTime, @filemtime($configPath), $now)) {
        record_worker_restart($workerName, 'config_changed');
        break;
    }

    // === METRICS: memory usage ===
    worker_metric_set($workerName, 'memory_bytes', memory_get_usage(true));
    worker_metric_set($workerName, 'peak_memory_bytes', memory_get_peak_usage(true));

    // === RESOURCE / TIME CHECKS ===
    if (($now - $startTime) > ($maxRuntimeMinutes * 60)) {
        record_worker_restart($workerName, 'max_runtime_exceeded');
        break;
    }

    if (($now - $lastWorkTime) > ($maxIdleMinutes * 60)) {
        record_worker_restart($workerName, 'max_idle_exceeded');
        break;
    }

    if (memory_get_usage(true) > $memoryLimitBytes) {
        record_worker_restart($workerName, 'memory_limit_exceeded');
        break;
    }

    // === ENSURE DB CONNECTION ===
    try {
        $db->query("SELECT 1");
    } catch (\Throwable $t) {
        write_debug_log("Reconnecting to DB after connection loss...", "warning");
        db_close($db);
        $db = db_open();
        if (!$db) {
            write_debug_log("Failed to reconnect to database, exiting.", "error");
            break;
        }
    }

    // === RECOVER STUCK TASKS ===
    // Only tasks with NO live promise chain are recovered — a task whose chain
    // is still being resolved is legitimately 'in_progress' and re-running its
    // queue_check would re-create the whole chain (the re-chaining runaway).
    // See recover_stuck_queue_tasks() in queues.php for the full rationale and
    // the liveness predicate (kept in sync with promise_chain_exists()).
    try {
        $recovered = recover_stuck_queue_tasks($db, $stuckThresholdMinutes);
        if ($recovered > 0) {
            // 'notice': reclaiming a stale/abandoned task (in_progress past the
            // threshold with no live chain) is an infrequent, operator-relevant
            // event — the "stale lock killed" analog — not a routine info event.
            write_debug_log("Recovered {$recovered} stuck tasks (no live promise chain).", "notice");
        }
    } catch (\Throwable $t) {
        write_debug_log("Error recovering stuck tasks: " . $t->getMessage(), "error");
    }

    // === FETCH NEXT PENDING TASK ===
    $task = null;
    try {
        $db->beginTransaction();
        // Skips tasks still waiting out a retry back-off (SR-2307) so a failing
        // high-priority task cannot stall the rest of the queue.
        $task = queue_pick_next_runnable_task($db, $now);
        if ($db->inTransaction()) {
            $db->commit();
        }
    } catch (\Throwable $t) {
        if ($db->inTransaction()) $db->rollBack();
        write_debug_log("Error fetching tasks: " . $t->getMessage(), "error");
        worker_interruptible_sleep($loopDelaySeconds);
        continue;
    }

    if (!$task) {
        worker_interruptible_sleep($loopDelaySeconds);
        continue;
    }

    $taskType = $task['task_type'];
    write_debug_log("Fetched task #{$task['id']} with type '{$taskType}'", "info");

    // === TASK LOOKUP USING KEYED JOB MAP ===
    $job_def = worker_get_job_definition($taskType);
    if (!$job_def) {
        // Counts every failed attempt, retried or not, like failed_promises. Each
        // increment comes before the failure handler so a throwing terminal hook
        // cannot skip it.
        worker_metric_inc($workerName, 'failed_queue_tasks');
        handle_queue_task_failure($db, $task, "No job definition");
        worker_interruptible_sleep($loopDelaySeconds);
        continue;
    }

    // === TASK HANDLER EXECUTION ===
    try {
        $handler = $job_def['queue_check'] ?? $job_def['task_check'] ?? null;
        if (!is_callable($handler)) throw new \RuntimeException("No valid handler for task #{$task['id']}");

        $result = $handler($task, $db);
        write_debug_log("Task #{$task['id']} handler returned: " . var_export($result, true), "debug");

        if ($result === false) {
            // worker_handle_task_failure() only surfaces the failure to a user
            // once retries are exhausted — handle_queue_task_failure() (which it
            // calls) returns true exactly then.
            worker_metric_inc($workerName, 'failed_queue_tasks');
            worker_handle_task_failure($job_def, $db, $task, "Handler returned false");
        } else {
            if (!empty($job_def['stages']) && is_array($job_def['stages'])) {
                queue_update_status($task['id'], 'in_progress', $db);
            } else {
                queue_update_status($task['id'], 'completed', $db);
            }
        }
    } catch (\Throwable $t) {
        write_debug_log("Unexpected error processing task #{$task['id']}: " . $t->getMessage(), "error");
        // Same retry/backoff policy as the false-return path above — left to the
        // function's defaults on both so the two can't drift.
        worker_metric_inc($workerName, 'failed_queue_tasks');
        worker_handle_task_failure($job_def, $db, $task, $t->getMessage());
    }

    $lastWorkTime = time();

    // === WORKER TICK ===
    worker_tick($workerName, $db);

    worker_interruptible_sleep($loopDelaySeconds);
}

// === CLEANUP ===
db_close($db);
write_debug_log("Queue worker exited.", "info");
?>