<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

return [
    'core_ai_context_update' => true,
    'core_asset_discovery' => true,
    'core_audit_initiate' => true,
    'core_control_update' => true,
    'core_countries_update' => true,
    'core_data_integrity_scan' => true,
    'core_document_update' => true,
    'core_email_send' => true,
    'core_kpi_snapshot' => true,
    'core_license_check' => true,
    'core_notifications_purge' => true,
    'core_notifications_remote_feed' => true,
    'core_promises_purge' => true,
    'core_version_check' => true,
    'core_workflow_action_execute' => true,
    'core_workflow_execute' => true,
    'governance_review_due' => true,
];

?>