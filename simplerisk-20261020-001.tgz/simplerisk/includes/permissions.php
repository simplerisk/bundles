<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Include required configuration files
require_once(realpath(__DIR__ . '/bootstrap.php'));
require_once(realpath(__DIR__ . '/alerts.php'));

// enforce_permission() answers API callers with a JSON envelope instead of a
// redirect, so it needs json_response() and current_request_expects_json_
// response(), which sit together in services.php. functions.php is for the
// write_debug_log() / build_url() / get_base_url() calls further down. Both
// are reachable transitively from every current caller, but the reachability
// rule wants each consumer to declare the file that defines what it calls.
require_once(realpath(__DIR__ . '/services.php'));
require_once(realpath(__DIR__ . '/functions.php'));

// Include the language file
require_once(language_file());
require_once(realpath(__DIR__ . '/../vendor/autoload.php'));

if (!function_exists('table_exists')) {
    // @phan-suppress-next-line PhanRedefineFunction -- guarded by function_exists() check above; alternate definition in includes/functions.php
    function table_exists($table) {
        
        // Open the database connection
        $db = db_open();
        
        // Query the schema for the table
        $database = DB_DATABASE; //Have to make a variable as bindParam can't take parameter by reference
        $stmt = $db->prepare("SELECT table_name FROM information_schema.tables WHERE table_schema = :database AND table_name = :table;");
        $stmt->bindParam(":database", $database, PDO::PARAM_STR);
        $stmt->bindParam(":table", $table, PDO::PARAM_STR);
        $stmt->execute();
        
        // Fetch the results
        $results = $stmt->fetchAll();
        
        // Close the database connection
        db_close($db);
        
        return count($results) > 0;
    }
}

// The list of currently existing permissions.
// Leaving here for backwards compatibility
global $possible_permissions;
$possible_permissions = get_possible_permissions();

global $exception_permissions;
$exception_permissions = ['view' ,'create' ,'update' ,'delete' ,'approve'];

/******************************
 * FUNCTION: CHECK PERMISSION *
 ******************************/
function check_permission($permission) {

	// If we have a valid session
	if (isset($_SESSION['user']) && $_SESSION['user'] != "") {

		$message = "The currently authenticated session for username '{$_SESSION['user']}'";

	} else {

        $message = "The currently unauthenticated session";

    }

	// Check if the permission is authorized
	if (!isset($_SESSION[$permission]) || $_SESSION[$permission] != 1) {

		write_debug_log("{$message} does not have the '{$permission}' permission.", "info");
		return false;

	} else {

		write_debug_log("{$message} has the '{$permission}' permission.", "debug");
		return true;

	}
}	

/*******************************************************************************
 * FUNCTION: ENFORCE PERMISSION DENY STATUS                                     *
 * The HTTP status an API/XHR caller is refused with when check_permission()    *
 * says no.                                                                     *
 *                                                                              *
 * "access" is the authentication gate rather than an authorization one, so it  *
 * answers 401 to match unauthenticated_access(); every other permission is a   *
 * genuine authorization refusal and answers 403. A client that distinguishes   *
 * "log in again" from "you may not do this" branches on exactly this, so it    *
 * is pulled out of enforce_permission() -- which exits and cannot be called    *
 * from a test -- and pinned by its own cases.                                  *
 *******************************************************************************/
function enforce_permission_deny_status($permission) {

	return $permission === "access" ? 401 : 403;
}

/********************************
 * FUNCTION: ENFORCE PERMISSION *
 ********************************/
function enforce_permission($permission)
{
	global $lang, $escaper;

	// If the permission is not authorized
	if (!check_permission($permission)) {

		// An API or XHR caller cannot act on a redirect to the login page: it
		// reads the 302 with its empty body as a success, and page JavaScript
		// renders the returned login HTML into a tab container. Answer those
		// callers with the JSON envelope the rest of the v2 API uses.
		//
		// json_response() exits, so the redirect below is unreachable here.
		if (current_request_expects_json_response()) {

			// See drain_output_buffers() in services.php for why a half-rendered
			// partial must not be flushed ahead of the JSON body.
			drain_output_buffers();

			// An API refusal halts the caller's whole workflow, so it is worth
			// an operator's attention; the page branch below is the routine
			// low-stakes redirect and stays at info.
			write_debug_log("User doesn't have the '{$permission}' permission. Refusing the API request.", 'notice');

			json_response(enforce_permission_deny_status($permission), $escaper->escapeHtml($lang['NoPermissionForThisAction']), NULL);
		}

		// Past the JSON branch this request really is being redirected, so the
		// message below is accurate. Logging it above the branch would have
		// asserted a redirect that never happens for every API caller.
	    write_debug_log("Redirecting back to the login page. User doesn't have the '{$permission}' permission.", 'info');

		// Different actions for different permissions
		switch ($permission) {
			// If this is the access permission
			case "access":
				// Store the requested URL in the session so we can redirect the user back to it after authentication
				set_unauthenticated_redirect();

				// Redirect the user to the login page
				header("Location: ../index.php");

				// Stop any further processing
				exit(0);
			default:
				// Redirect the user to the login page
				header("Location: ../index.php");

				// Stop any further processing
				exit(0);
		}
	}
}

/*************************************
 * FUNCTION: CHECK PERMISSION ASSET *
 *************************************/
function check_permission_exception($function)
{
    global $exception_permissions;
    return in_array($function, $exception_permissions)
            && isset($_SESSION["{$function}_exception"])
            && $_SESSION["{$function}_exception"] == 1;
}

function enforce_permission_exception($function)
{
    // If exception is not authorized
    if (!check_permission_exception($function))
    {
        header("Location: ../index.php");
        exit(0);
    }
}

/********************************************************************************
 * FUNCTION: GET QUESTIONNAIRE REQUEST TOKEN                                    *
 * The questionnaire token the caller presented, or '' when they presented      *
 * none. GET 'token' is what the respondent's links carry and POST              *
 * 'questionnaire_token' is what the response form posts; GET wins when both    *
 * are present.                                                                 *
 *                                                                              *
 * Extracted so the two consumers cannot drift: this file's                     *
 * check_questionnaire_get_token(), and download_questionnaire_file() in the     *
 * Assessments Extra, which needs the token itself rather than a yes/no.        *
 ********************************************************************************/
function get_questionnaire_request_token() {

    if (isset($_GET['token'])) {
        return (string)$_GET['token'];
    }

    if (isset($_POST['questionnaire_token'])) {
        return (string)$_POST['questionnaire_token'];
    }

    return '';
}

/********************************************************************************
 * FUNCTION: CHECK QUESTIONNAIRE GET TOKEN                                      *
 * Checks if the 'GET' parameter 'token' is a valid questionnaire token.        *
 * The function is built in a way to only check the database once per request   *
 * to reduce response time.                                                     *
 ********************************************************************************/
function check_questionnaire_get_token() {

    $token = get_questionnaire_request_token();

    // No token was provided so fail the token check
    if ($token === '') return false;

    $global_var_name = 'is_valid_questionnaire_token_' . $token;

    if (isset($GLOBALS[$global_var_name]))
        return $GLOBALS[$global_var_name];

    if (assessments_extra()) {
        require_once(realpath(__DIR__ . '/../extras/assessments/index.php'));

        $GLOBALS[$global_var_name] = is_valid_questionnaire_token($token, true);
        return $GLOBALS[$global_var_name];
    }

    $GLOBALS[$global_var_name] = false;
    return false;
}

/****************************************
 * FUNCTION: HAS PERMISSION             *
 * Checks if the user has $permission.  *
 ****************************************/
function has_permission($permission) {
    return $permission && isset($_SESSION[$permission]) && $_SESSION[$permission] == 1;
}

/*************************************************
 * FUNCTION: ASSET USER CAN                      *
 * Granular asset-management permission gate.    *
 * $action: edit | delete | verify | discovery | *
 *          group_create | group_edit |          *
 *          group_delete                         *
 * Any other action is denied. Read-only: only   *
 * reads $_SESSION via has_permission().         *
 *************************************************/
function asset_user_can(string $action): bool
{
    static $allowed_actions = ['edit', 'delete', 'verify', 'discovery', 'group_create', 'group_edit', 'group_delete'];

    if (!in_array($action, $allowed_actions, true)) {
        return false;
    }

    return has_permission('asset_' . $action);
}

/**************************************
 * FUNCTION: GET POSSIBLE PERMISSIONS *
 **************************************/
function get_possible_permissions() {
    
    // For backwards compatibility
    if (!table_exists('permissions')) {
        return [
            'governance',
            'riskmanagement',
            'compliance',
            'assessments',
            'asset',
            'asset_edit',
            'asset_delete',
            'asset_verify',
            'asset_discovery',
            'asset_group_create',
            'asset_group_edit',
            'asset_group_delete',
            'admin',
            'review_veryhigh',
            'accept_mitigation',
            'review_high',
            'review_medium',
            'review_low',
            'review_insignificant',
            'submit_risks',
            'modify_risks',
            'plan_mitigations',
            'close_risks',
            'add_new_frameworks',
            'modify_frameworks',
            'delete_frameworks',
            'add_new_controls',
            'modify_controls',
            'delete_controls',
            'add_documentation',
            'modify_documentation',
            'delete_documentation',
            'comment_risk_management',
            'comment_compliance',
            'view_exception',
            'create_exception',
            'update_exception',
            'delete_exception',
            'approve_exception',
            'add_projects',
            'delete_projects',
            'manage_projects',
            'define_tests',
            'edit_tests',
            'delete_tests',
            'approve_tests',
            'initiate_audits',
            'modify_audits',
            'reopen_audits',
            'delete_audits'
        ];
    }
    
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("SELECT `key` FROM `permissions`;");
    $stmt->execute();
    $perms = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Close the database connection
    db_close($db);
    
    return $perms;
}

function get_possible_permission_ids() {
    
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("SELECT `id` FROM `permissions`;");
    $stmt->execute();
    $perms = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Close the database connection
    db_close($db);
    
    return $perms;
}

function set_default_role($role_id) {
    // Open the database connection
    $db = db_open();
    
    // To update in a single db call to prevent having no default or having two defaults at the same time
    $stmt = $db->prepare("UPDATE `role` r SET `r`.`default` = CASE WHEN `r`.`value` = :role_id THEN 1 ELSE NULL END ORDER BY `r`.`default` DESC;");
    $stmt->bindParam(":role_id", $role_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Close the database connection
    db_close($db);
}

function get_default_role() {
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("SELECT * FROM `role` WHERE `default` IS NOT NULL;");
    $stmt->execute();
    $role = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Close the database connection
    db_close($db);
    
    return $role;
}

function get_default_role_id() {
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("SELECT `value` FROM `role` WHERE `default` IS NOT NULL;");
    $stmt->execute();
    $role = $stmt->fetchColumn();
    
    // Close the database connection
    db_close($db);
    
    return $role;
}

/*************************************
 * FUNCTION: GET PERMISSIONS OF USER *
 *************************************/
function get_grouped_permissions($user_id = false) {
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("
        SELECT
        	`pg`.`name` as permission_group_name,
            `pg`.`id` as permission_group_id,
            `pg`.`description` as permission_group_description,
            `p`.`id` as permission_id,
          	`p`.`name` as permission_name,
            `p`.`description` as permission_description,
        	`p`.`key`" . ($user_id ? ",(`p2u`.`user_id` IS NOT NULL) as selected" : "") . "
        FROM
        	`permission_groups` pg
        INNER JOIN 
                `permission_to_permission_group` p2pg 
            ON 
                `p2pg`.`permission_group_id` = `pg`.`id`
        INNER JOIN 
                `permissions` p 
            ON 
                `p2pg`.`permission_id` = `p`.`id` " .
        ($user_id ? "
        LEFT JOIN 
                `permission_to_user` p2u 
            ON 
                `p`.`id` = `p2u`.`permission_id` 
            AND 
                `p2u`.`user_id` = :user_id" : "") . "
        GROUP BY
        	`pg`.`id`, `p`.`id`
        ORDER BY
        	`pg`.`order`, `p`.`order`;
    ");
    if ($user_id) {
        $stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
    }
    $stmt->execute();
    $perms = $stmt->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_ASSOC);
    
    // Close the database connection
    db_close($db);
    
    return $perms;
}

/********************************
 * FUNCTION: UPDATE PERMISSIONS *
 ********************************/
function update_permissions($user_id, $permissions) {
    $current_permissions = get_permission_ids_of_user($user_id);
    
    if (save_junction_values('permission_to_user', 'user_id', $user_id, 'permission_id', $permissions)) {
        
        // Calculate what permissions are removed from the user and what permissions are added
        $permissions_to_remove = array_diff($current_permissions, $permissions);
        $permissions_to_add = array_diff($permissions, $current_permissions);
        
        // No audit logging is needed if nothing changed
        if ($permissions_to_add || $permissions_to_remove) {
            
            $permission_changes = [];
            if ($permissions_to_add) {
                $permission_changes[] = _lang_raw('PermissionUpdateAuditLogAdded', array('permissions_added' => get_names_by_multi_values('permissions', $permissions_to_add, false, ', ', true)));
            }
            if ($permissions_to_remove) {
                $permission_changes[] = _lang_raw('PermissionUpdateAuditLogRemoved', array('permissions_removed' => get_names_by_multi_values('permissions', $permissions_to_remove, false, ', ', true)));
            }
            
            $message = _lang_raw('UserPermissionUpdateAuditLog',
                array(
                    'user' => isset($_SESSION['user']) ? $_SESSION['user'] : '', // because it can happen that this function is used by the custom authentication logic when there's no session yet
                    'username' => get_name_by_value("user", $user_id),
                    'permissions_from' => get_names_by_multi_values('permissions', $current_permissions, false, ', ', true),
                    'permissions_to' => get_names_by_multi_values('permissions', $permissions, false, ', ', true),
                    'permission_changes' => implode(", ", $permission_changes)
                ));
            
            write_log((int)$user_id + 1000, isset($_SESSION['uid']) ? $_SESSION['uid'] : 0, $message, 'user');
        }
    }
}

/*************************************
 * FUNCTION: GET PERMISSIONS OF USER *
 *************************************/
function get_permissions_of_user($user_id) {
    // Open the database connection
    $db = db_open();
    
    // For backwards compatibility
    if (!table_exists('permissions')) {
        global $possible_permissions;
        
        $permission_selects = [];
        foreach ($possible_permissions as $permission) {
            // We can only do this because it only happens when we get back permission keys we defined from code
            $permission_selects[] = "SELECT `value` as user_id, '$permission' AS name FROM `user` WHERE `$permission` = 1 OR `admin` = 1";
        }
        
        $permissions_from_part = implode(" UNION ALL ", $permission_selects);
        
        $stmt = $db->prepare("
            SELECT
                DISTINCT `perms`.`name`
            FROM
                `user` u
                LEFT JOIN ($permissions_from_part) perms ON `u`.`value` = `perms`.`user_id`
            WHERE
                `u`.`value` = :user_id;
        ");
    } else {
        $stmt = $db->prepare("
            SELECT
                `key`
            FROM
                `permissions` p
                INNER JOIN `permission_to_user` p2u ON `p`.`id` = `p2u`.`permission_id`
            WHERE
                `p2u`.`user_id` = :user_id;
        ");
    }
    $stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $perms = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Close the database connection
    db_close($db);
    
    return $perms;
}

/****************************************
 * FUNCTION: GET PERMISSION IDS OF USER *
 ****************************************/
function get_permission_ids_of_user($user_id) {
    
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("
        SELECT
            `p`.`id`
        FROM
            `permissions` p
            INNER JOIN `permission_to_user` p2u ON `p`.`id` = `p2u`.`permission_id`
        WHERE
            `p2u`.`user_id` = :user_id;
    ");
    $stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $perms = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Close the database connection
    db_close($db);
    
    return $perms;
}

/*********************************
 * FUNCTION: USER HAS PERMISSION *
 *********************************/
function user_has_permission($user_id, $permission_key) {

    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("
        SELECT
            5
        FROM
            `permissions` p
            INNER JOIN `permission_to_user` p2u ON `p`.`id` = `p2u`.`permission_id`
        WHERE
            `p2u`.`user_id` = :user_id
            AND `p`.`key` = :permission_key;
    ");
    $stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
    $stmt->bindParam(":permission_key", $permission_key, PDO::PARAM_STR);
    
    $stmt->execute();

    $result = $stmt->fetchColumn();

    // Close the database connection
    db_close($db);

    return isset($result) && (int)$result === 5;
    
}

/*********************************
 * FUNCTION: ADD NEW PERMISSIONS *
 *********************************/
function add_new_permissions($permission_groups_and_permissions)
{
	// Open the database connection
	$db = db_open();

	// Create an array for the new permissions
	$new_permissions = [];

	// For each of the permission groups provided
	foreach ($permission_groups_and_permissions as $_ => $group)
	{
		// Pull out the group information
		$group_name = $group['name'];
		$group_description = $group['description'];
		$group_order = $group['order'];
		$permissions = $group['permissions'];

		// Create the permission group
		$stmt = $db->prepare("INSERT IGNORE INTO `permission_groups` (`name`, `description`, `order`) VALUES (:name, :description, :order);");
		$stmt->bindParam(":name", $group_name, PDO::PARAM_STR);
		$stmt->bindParam(":description", $group_description, PDO::PARAM_STR);
		$stmt->bindParam(":order", $group_order, PDO::PARAM_INT);
		$stmt->execute();

        // Get the permission group id
        $stmt = $db->prepare("SELECT `id` FROM `permission_groups` WHERE `name` = :name;");
        $stmt->bindParam(":name", $group_name, PDO::PARAM_STR);
        $stmt->execute();
        $group_row = $stmt->fetch(PDO::FETCH_ASSOC);
        $group_id = $group_row !== false ? $group_row['id'] : null;

        if ($group_id === null) {
            write_debug_log("[add_new_permissions] Could not resolve group id for name '{$group_name}'", 'error');
            continue;
        }

		// Write debug log
		write_debug_log("Added new permission group with the following values:", 'info');
		write_debug_log("GROUP ID: " . $group_id, 'info');
		write_debug_log("NAME: " . $group_name, 'info');
		write_debug_log("DESCRIPTION: " . $group_description, 'info');
		write_debug_log("ORDER: " . $group_order, 'info');

		// Write audit log
		$message = "A new permission group named \"" . $group_name . "\" was added to the system.";
		write_log(1000, $_SESSION['uid'] ?? 0, $message, "user");

		// For each of the permissions in this permission group
		foreach ($permissions as $key => $permission)
		{
			// Pull out the permission information
			$permission_name = $permission['name'];
			$permission_description = $permission['description'];
			$permission_order = $permission['order'];

            // If the permission is supported by system default, it is not add.
            $no_remove_permission = isset($permission['no_remove'])?$permission['no_remove']:0;
            if($no_remove_permission) continue;

			// Create the permission
			$stmt = $db->prepare("INSERT IGNORE INTO `permissions` (`key`, `name`, `description`, `order`) VALUES (:key, :name, :description, :order);");
			$stmt->bindParam(":key", $key, PDO::PARAM_STR);
			$stmt->bindParam(":name", $permission_name, PDO::PARAM_STR);
			$stmt->bindParam(":description", $permission_description, PDO::PARAM_STR);
			$stmt->bindParam(":order", $permission_order, PDO::PARAM_INT);
			$stmt->execute();

			// Get the permission id by key (the unique field used in INSERT IGNORE),
			// not name — so we always resolve the row even when the key already
			// existed under a different name and INSERT IGNORE was a no-op.
			$stmt = $db->prepare("SELECT `id` FROM `permissions` WHERE `key` = :key;");
			$stmt->bindParam(":key", $key, PDO::PARAM_STR);
			$stmt->execute();
			$permission_row = $stmt->fetch(PDO::FETCH_ASSOC);
			$permission_id = $permission_row !== false ? $permission_row['id'] : null;

			if ($permission_id === null) {
				write_debug_log("[add_new_permissions] Could not resolve permission id for key '{$key}'", 'error');
				continue;
			}

			// Add the new permission to the new permissions array
			$new_permissions[] = $permission_id;

			// Write debug log
			write_debug_log("Added new permission with the following values:", 'info');
			write_debug_log("PERMISSION ID: " . $permission_id, 'info');
			write_debug_log("KEY: " . $key, 'info');
			write_debug_log("NAME: " . $permission_name, 'info');
			write_debug_log("DESCRIPTION: " . $permission_description, 'info');
			write_debug_log("ORDER: " . $permission_order, 'info');

			// Write audit log
			$message = "A new permission named \"" . $permission_name . "\" was added to the system.";
			write_log(1000, $_SESSION['uid'] ?? 0, $message, "user");

			// Add the permission to the permission group
			$stmt = $db->prepare("INSERT IGNORE INTO `permission_to_permission_group` (`permission_id`, `permission_group_id`) VALUES (:permission_id, :permission_group_id);");
			$stmt->bindParam(":permission_id", $permission_id);
			$stmt->bindParam(":permission_group_id", $group_id);
			$stmt->execute();

			// Write debug log
			write_debug_log("Added permission id \"" . $permission_id . "\" to group id \"" . $group_id . "\".", 'info');

			// Write audit log
			$message = "The \"" . $permission_name . "\" permission was added to the \"" . $group_name . "\" permission group.";
			write_log(1000, $_SESSION['uid'] ?? 0, $message, "user");
		}
	}

	// For each admin user
	$admin_users = get_admin_users();
	foreach ($admin_users as $user)
	{
		// Get the user values
		$user_id = (int)$user['value'];
		$username = $user['username'];

		// Additively grant each new permission ID to this admin user.
		// The previous flow used update_permissions(), which destructively
		// rewrote permission_to_user (DELETE all rows for the user, then
		// INSERT the merged set). For an admin whose direct permissions
		// were empty at this moment — for example, a role-based admin
		// whose access lives in role_responsibilities and not in
		// permission_to_user — that flow read get_permission_ids_of_user()
		// as [], merged it with the new Extra's perms, then wiped every
		// other direct row in the rewrite. The admin's session, rebuilt
		// from permission_to_user via set_user_permissions() below, lost
		// every sidebar gate and the user appeared to "lose access" the
		// moment they activated the Extra. INSERT IGNORE preserves the
		// user's existing direct permission rows and only adds the new
		// ones idempotently. Issued as a single multi-VALUES statement
		// so the cost stays O(admins), not O(admins × perms).
		if (!empty($new_permissions)) {
			$placeholders = [];
			$params = [':user_id' => $user_id];
			foreach ($new_permissions as $i => $new_perm_id) {
				$placeholders[] = "(:user_id, :pid_{$i})";
				$params[":pid_{$i}"] = (int)$new_perm_id;
			}
			$stmt = $db->prepare(
				"INSERT IGNORE INTO `permission_to_user` (`user_id`, `permission_id`) VALUES "
				. implode(',', $placeholders) . ";"
			);
			$stmt->execute($params);

			// Audit log: record which permissions were granted to this
			// admin user as part of the add_new_permissions() call. The
			// pre-fix path emitted an audit entry via save_junction_values()
			// for every user the destructive rewrite touched; the additive
			// INSERT IGNORE path does not, so emit one explicitly here.
			$perm_names = get_names_by_multi_values('permissions', $new_permissions, false, ', ', true);
			$target_name = get_name_by_value('user', $user_id);
			$message = "Permissions \"" . $perm_names . "\" granted to user \"" . $target_name . "\" as part of permission group addition.";
			write_log((int)$user_id + 1000, $_SESSION['uid'] ?? 0, $message, 'user');
		}

		// If the update affects the current logged in user
		if (($_SESSION['uid'] ?? 0) == $user_id)
		{
			// Update the current user's permissions
			set_user_permissions($username);
		}

		// Refresh the permissions in the active sessions of the user
		refresh_permissions_in_sessions_of_user($user_id);

		// Write debug log
		write_debug_log("The new permissions were added to the \"" . $username . "\" user.", 'info');
	}

	// Automatically grant all permissions to roles granted admin
	$stmt = $db->prepare("
            INSERT IGNORE INTO
                `role_responsibilities`(`role_id`, `permission_id`)
            SELECT
                `r`.`value`,
                `p`.`id`
            FROM
                `role` r, `permissions` p
            WHERE
                `r`.`admin` = 1;
	");
	$stmt->execute();

	// Close the database connection
	db_close($db);
}

/********************************
 * FUNCTION: REMOVE PERMISSIONS *
 ********************************/
function remove_permissions($permission_groups_and_permissions)
{
	// Open the database connection
	$db = db_open();

        // Create an array for the removed permissions
        $removed_permissions = [];

	// For each of the permission groups provided
	foreach ($permission_groups_and_permissions as $_ => $group)
	{
		// Pull out the group information
		$group_name = $group['name'];
		$permissions = $group['permissions'];
        $no_remove_group = isset($group['no_remove'])?$group['no_remove']:0;

		// For each of the permissions in this permission group
		foreach ($permissions as $key => $permission)
		{
			// Pull out the permission information
			$permission_name = $permission['name'];

            // If the permission is supported by system default, it is not remove.
            $no_remove_permission = isset($permission['no_remove'])?$permission['no_remove']:0;
            if($no_remove_permission) continue;

			write_debug_log("Deleting permission named \"" . $permission_name . "\".", 'info');

            // Get the permission id
            $stmt = $db->prepare("SELECT `id` FROM `permissions` WHERE `name` = :name;");
            $stmt->bindParam(":name", $permission_name, PDO::PARAM_STR);
            $stmt->execute();
            $permission_id = $stmt->fetch(PDO::FETCH_ASSOC);
            if($permission_id) {
                $permission_id = $permission_id['id'];

                // Add the new permission to the removed permissions array
                $removed_permissions[] = $permission_id;

                // Delete the permission from the permission group
                $stmt = $db->prepare("
                    DELETE FROM `permission_to_permission_group` WHERE `permission_id` = :permission_id;
                ");
                $stmt->bindParam(":permission_id", $permission_id, PDO::PARAM_INT);
                $stmt->execute();

                // Delete the permission
                $stmt = $db->prepare("
                    DELETE FROM `permissions` WHERE `name` = :name;
                ");
                $stmt->bindParam(":name", $permission_name, PDO::PARAM_STR);
                $stmt->execute();

                // Write audit log
                $message = "The \"" . $permission_name . "\" permission was removed from the system.";
                write_log(1000, $_SESSION['uid'] ?? 0, $message, "user");
            }
		}
        if(!$no_remove_group) {
            // After all permissions have been deleted, delete the permission group
            write_debug_log("Deleting permission group named \"" . $group_name . "\".", 'info');
            $stmt = $db->prepare("
                DELETE FROM `permission_groups`  WHERE `name` = :name;
            ");
            $stmt->bindParam(":name", $group_name, PDO::PARAM_STR);
            $stmt->execute();

            // Write audit log
            $message = "The \"" . $group_name . "\" permission group was removed from the system.";
            write_log(1000, $_SESSION['uid'] ?? 0, $message, "user");
        }

	}

	// Cleanup the permissions after the deletion
	cleanup_after_delete('permissions');
	cleanup_after_delete('permission_groups');

        // For each user
	$all_users = get_all_users();
        foreach ($all_users as $user)
        {
                // Get the user values
                $user_id = (int)$user['value'];
                $username = $user['username'];

                // Get the current permissions of this user
                //$current_permissions = get_permission_ids_of_user($user_id);

		// Remove the removed permissions from the current permissions
		//$updated_permissions = array_diff($current_permissions, $removed_permissions);

                // Remove the removed permissions from the user
                //update_permissions($user_id, $updated_permissions);

                // If the update affects the current logged in user
                if (($_SESSION['uid'] ?? 0) == $user_id)
                {
                        // Update the current user's permissions
                        set_user_permissions($username);
                }

                // Refresh the permissions in the active sessions of the user
                refresh_permissions_in_sessions_of_user($user_id);

                // Write debug log
                write_debug_log("The new permissions were added to the \"" . $username . "\" user.", 'info');
        }

	// Close the database connection
	db_close($db);
}

/*****************************
 * FUNCTION: GET ADMIN USERS *
 *****************************/
function get_admin_users()
{
	// Open the database connection
	$db = db_open();

	// Get all users with an admin role
	$stmt = $db->prepare("
		SELECT `value`, `username` FROM `user` WHERE admin = 1;
	");
	$stmt->execute();
	$admin_users = $stmt->fetchAll(PDO::FETCH_ASSOC);

	// Close the database connection
	db_close($db);

	// Return the list of admin users
	return $admin_users;
}

/************************************************
 * FUNCTION: CHECK REVIEW PERMISSION BY RISK ID *
 ************************************************/
function check_review_permission_by_risk_id($risk_id)
{
	// Get the calcualted risk for this risk id
	$calculated_risk = get_calculated_risk_by_id($risk_id);

	// Get the risk level name for this calculated risk
	$level = get_risk_level_name($calculated_risk);

	// Get the risk level display names
	$very_high_display_name = get_risk_level_display_name('Very High');
	$high_display_name      = get_risk_level_display_name('High');
	$medium_display_name    = get_risk_level_display_name('Medium');
	$low_display_name       = get_risk_level_display_name('Low');
	$insignificant_display_name = get_risk_level_display_name('Insignificant');

	// If the user has permission to review the current level
	if (($level == $very_high_display_name && has_permission("review_veryhigh")) || ($level == $high_display_name && has_permission("review_high")) || ($level == $medium_display_name && has_permission("review_medium")) || ($level == $low_display_name && has_permission("review_low")) || ($level == $insignificant_display_name && has_permission("review_insignificant")))
	{
		// Review is approved
		$approved = true;
	}
	// Otherwise the review is not approved
	else $approved = false;

	// Return the approved status
	return $approved;
}

/**********************************************************************
 * FUNCTION: COMPUTE WORKFLOW REDIRECT TARGET                          *
 *                                                                     *
 * Pure decision logic for redirect_permission_denied(): pick the URL  *
 * the user should be sent to after a permission denial. Pulled out of *
 * the helper itself so it can be unit-tested without exercising       *
 * header()/exit() side effects.                                       *
 *                                                                     *
 * Returns $workflow_start when it is non-empty AND different from the *
 * current request URL. Otherwise returns $fallback. The same-URL      *
 * check is defense-in-depth: an action page that forgot to declare    *
 * 'is_action' => true would have anchored workflow_start at its own   *
 * URL, and bouncing to itself produces a redirect loop.               *
 **********************************************************************/
function compute_workflow_redirect_target($workflow_start, $current_url, $fallback) {
	if (empty($workflow_start) || $workflow_start === $current_url) {
		return $fallback;
	}
	return $workflow_start;
}

/**********************************************************************
 * FUNCTION: SANITIZE LOG CONTEXT                                      *
 *                                                                     *
 * Flattens control characters in a value bound for a log line.        *
 *                                                                     *
 * Callers build denial context out of request data (risk ids,         *
 * unique_names, ref_types), and write_debug_log()'s formatter runs    *
 * with $allowInlineLineBreaks = true, so a CR/LF in that value lands  *
 * in the log verbatim. The authorization-denial record is what an     *
 * incident responder reads after a suspected access-control probe, so *
 * a caller able to inject newlines there could forge whole denial     *
 * lines attributed to other users.                                    *
 *                                                                     *
 * Replaces rather than deletes, so two tokens either side of a        *
 * stripped newline cannot silently fuse into one.                     *
 *                                                                     *
 * Pure: no session, no database, no $lang.                            *
 **********************************************************************/
function sanitize_log_context($context) {
	return preg_replace('/[[:cntrl:]]/', ' ', (string)$context);
}

/**********************************************************************
 * FUNCTION: REDIRECT PERMISSION DENIED                                *
 *                                                                     *
 * Called when a permission/access check inside a page denies. Logs a  *
 * warning, queues a toast for the next page render, and redirects     *
 * the user back to the most recent legitimate page they visited       *
 * (recorded by add_session_check() into $_SESSION['workflow_start']). *
 *                                                                     *
 * The captured URL is server-derived (SCRIPT_FILENAME-based) and only *
 * written for GET requests on non-action pages, so it is safe to      *
 * reflect into a Location: header.                                    *
 *                                                                     *
 * $message_lang_key — language key for the toast message              *
 * $log_context      — extra context for the debug log                 *
 **********************************************************************/
function redirect_permission_denied($message_lang_key = 'NoPermissionForThisAction', $log_context = '') {
	global $lang, $escaper;

	// Both interpolated values are flattened, not just the caller-supplied one:
	// a username is attacker-influenced wherever self-registration or an
	// external identity provider supplies it, and one CR/LF in it forges log
	// lines just as effectively as one in $log_context. $_SERVER['SCRIPT_NAME']
	// is deliberately left alone -- it is the resolved script path, set by the
	// server rather than taken from the request.
	$user = sanitize_log_context(isset($_SESSION['user']) ? $_SESSION['user'] : '(unauthenticated)');

	// $log_context is request-derived -- see sanitize_log_context() above for the
	// forged-denial-line threat this closes. Applied centrally here, so it also
	// covers the call sites that were already interpolating request data.
	$detail = $log_context !== '' ? ' (' . sanitize_log_context($log_context) . ')' : '';

	write_debug_log("Permission denied for user '{$user}' on " . $_SERVER['SCRIPT_NAME'] . $detail, 'warning');

	$message = isset($lang[$message_lang_key]) ? $lang[$message_lang_key] : 'You do not have permission to perform that action.';

	// Several of these call sites sit in management/partials/*.php, which the
	// api/v2 risk handlers include to render a tab. A redirect is useless to an
	// API caller -- it reads as an empty 302 -- so answer one with the same JSON
	// envelope the rest of the v2 API uses.
	//
	// No set_alert() on this branch: the toast is queued for the NEXT page
	// render, and an API caller has none. The message goes in the response.
	// json_response() exits, so the redirect below is unreachable here.
	if (current_request_expects_json_response()) {

		// Several of these call sites are reached from inside an ob_start()'d
		// partial render, so drop anything already buffered rather than let it
		// be flushed ahead of the JSON body.
		drain_output_buffers();

		json_response(403, $escaper->escapeHtml($message), NULL);
	}

	set_alert(true, "bad", $message);

	$base_url       = !empty($_SESSION['base_url']) ? $_SESSION['base_url'] : get_base_url();
	$current_url    = rtrim($base_url, '/') . get_encoded_request_uri();
	$workflow_start = !empty($_SESSION['workflow_start']) ? $_SESSION['workflow_start'] : '';

	$target = compute_workflow_redirect_target($workflow_start, $current_url, build_url(''));

	header("Location: " . $target);
	exit();
}

?>