<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Include required configuration files
require_once(realpath(__DIR__ . '/functions.php'));

// Include the language file
require_once(language_file());
require_once(realpath(__DIR__ . '/../vendor/autoload.php'));

/*******************************************
 * FUNCTION: POSSIBLE FORMATS              *
 * Calculates what formats the input       *
 * (formatted date string) can be in       *
 *******************************************/
function possibleFormats($date) {

    if (!(preg_match("(\d{2}[ \.\/-]{1}\d{2}[ \.\/-]{1}\d{4})", $date) || preg_match("(\d{4}[ \.\/-]{1}\d{2}[ \.\/-]{1}\d{2})", $date)))
        return array();

    $separator = preg_replace("/([0-9]*)/", "", $date)[0];
    $parts = explode($separator, $date);

    if ((int)$parts[0] > 31) { //starts with Y
        if ((int)$parts[1] === (int)$parts[2]) { // month and day are the same, just return something
            return array("Y{$separator}m{$separator}d");
        } elseif ((int)$parts[1] > 12) { //it's Ydm
            return array("Y{$separator}d{$separator}m");
        } elseif((int)$parts[2] > 12) { //it's Ymd
            return array("Y{$separator}m{$separator}d");
        } else { //can be both
            return array("Y{$separator}d{$separator}m", "Y{$separator}m{$separator}d");
        }
    } elseif((int)$parts[2] > 31) { //ends with Y
        if ((int)$parts[0] === (int)$parts[1]) { // month and day are the same, just return something
            return array("d{$separator}m{$separator}Y");
        } elseif ((int)$parts[0] > 12) { //it's dmY
            return array("d{$separator}m{$separator}Y");
        } elseif((int)$parts[1] > 12) { //it's mdY
            return array("m{$separator}d{$separator}Y");
        } else { //can be both
            return array("d{$separator}m{$separator}Y", "m{$separator}d{$separator}Y");
        }
    } else return array();
}

/******************************************
 * FUNCTION: GET REVIEWS WITH DATE ISSUES *
 ******************************************/
function getReviewsWithDateIssues($order_column = 0, $order_dir = "asc", $offset = 0, $page_size = -1) {

    if ($order_column == 1)
        $order_column = 'ri.subject';
    else $order_column = 'ri.id';

    $db = db_open();

    // Team Separation (SR-2098) has to filter the full malformed-review set
    // BEFORE pagination is applied, or an off-team row could be pushed onto
    // a page the caller shouldn't be able to reach while recordsTotal still
    // reflects the unfiltered count. So the LIMIT/SQL_CALC_FOUND_ROWS pair
    // that used to paginate in SQL is gone: fetch every matching row here,
    // filter, then slice to the requested page below.
    $stmt = $db->prepare("
        select re.id as review_id, ri.id as risk_id, re.next_review, ri.subject
            from `mgmt_reviews` re
            left join `risks` ri on re.risk_id = ri.id
            where re.next_review not REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}'
            order by {$order_column} {$order_dir}, re.id;");
    $stmt->execute();

    $reviews = $stmt->fetchAll();

    db_close($db);

    // Strip rows for risks the caller isn't allowed to see. Without this, a
    // user holding only the broad `riskmanagement` permission could read
    // off-team risk subjects and review dates through this maintenance
    // listing, which the canonical risk API denies (SR-2098).
    if (team_separation_extra()) {
        require_once(realpath(__DIR__ . '/../extras/separation/index.php'));
        $reviews = strip_no_access_risks($reviews, null, 'risk_id');
    }

    $recordsTotal = count($reviews);

    if ($page_size > 0) {
        $reviews = array_slice($reviews, $offset, $page_size);
    }

    return array($recordsTotal, $reviews);
}

/**********************************************
 * FUNCTION: GET ALL REVIEWS WITH DATE ISSUES *
 **********************************************/
function getAllReviewsWithDateIssues() {

    $db = db_open();

    $stmt = $db->prepare("select `id` review_id, `next_review` from `mgmt_reviews` where `next_review` not REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}' order by `id`;");
    $stmt->execute();

    $array = $stmt->fetchAll();

    db_close($db);

    return $array;    
}

/*********************************************
 * FUNCTION: CHANGE NEXT_REVIEW TO DATE TYPE *
 *********************************************/
function changeNextReviewToDateType() {
    $db = db_open();

    $stmt = $db->prepare("ALTER TABLE `mgmt_reviews` CHANGE `next_review` `next_review` DATE NOT NULL DEFAULT '0000-00-00';");
    $stmt->execute();

    db_close($db);

    return getTypeOfColumn('mgmt_reviews', 'next_review') == 'date';
}

/*******************************************************
 * FUNCTION: GET MGMT REVIEW RISK ID                    *
 * Resolves the risk_id a mgmt_reviews row belongs to,  *
 * so a caller can run its normal per-risk access check *
 * before writing to a review by id. Returns null if no *
 * such review exists.                                  *
 *******************************************************/
function get_mgmt_review_risk_id($id) {

    $db = db_open();

    $stmt = $db->prepare("select `risk_id` from `mgmt_reviews` where `id`=:id;");
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();

    $risk_id = $stmt->fetch();

    db_close($db);

    // mgmt_reviews.risk_id stores the raw risks.id (see the INSERT in
    // add_management_review()), but extra_grant_access() -- and every
    // existing caller of it, e.g. reopenForm()'s $id -- expects the
    // +1000 display/API id and subtracts 1000 itself. Add it back so this
    // resolves to the same risk extra_grant_access() will check, instead
    // of silently checking access against a different (or negative) id.
    return $risk_id ? (int)$risk_id[0] + 1000 : null;
}

/*****************************************
 * FUNCTION: FIX NEXT REVIEW DATE FORMAT *
 *****************************************/
function fixNextReviewDateFormat($id, $format) {

    $db = db_open();

    $stmt = $db->prepare("select `next_review`, `risk_id` from `mgmt_reviews` where `id`=:id;");
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();

    $review = $stmt->fetch();

    // Resolve the review's parent risk and enforce access to it before
    // allowing the caller to reschedule it (SR-2030). The API handler that
    // calls this function only checks broad riskmanagement/modify_risks
    // permissions, not whether the caller may access THIS risk, so without
    // this check any holder of those permissions could reschedule a
    // cross-team review by guessing/incrementing its review id.
    //
    // check_access_for_risk() (and get_risk_by_id()) key off the public/API
    // risk id, which is the internal `risks`.`id` plus 1000 -- mgmt_reviews's
    // risk_id column stores the internal id, so it has to be offset here.
    if (!$review || !check_access_for_risk((int)$review['risk_id'] + 1000)) {
        db_close($db);
        return false;
    }

    if (strlen($review['next_review']) == 10) {

        $next_review = $review['next_review'];

        $d = DateTime::createFromFormat($format, $next_review);
        $standard_date = $d ? $d->format('Y-m-d') : false;

        if ($standard_date) {
            //save the date
            $stmt = $db->prepare("update `mgmt_reviews` set `next_review`=:standard_date where `id`=:id;");
            $stmt->bindParam(":standard_date", $standard_date, PDO::PARAM_STR);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->execute();

            db_close($db);
            return true;
        }
    }

    db_close($db);
    return false;
}


/************************************
 * FUNCTION: RESET NEXT REVIEW DATE *
 ************************************/
function resetNextReviewDate($id) {

    $db = db_open();

    $stmt = $db->prepare("update `mgmt_reviews` set `next_review`='0000-00-00' where `id`=:id;");
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();

    db_close($db);
}

/******************************************
 * FUNCTION: CONVERT DATE FORMAT FROM PHP *
 ******************************************/
function convertDateFormatFromPHP($format) {
    $disp_format = str_replace('Y', 'YYYY', $format);
    $disp_format = str_replace('m', 'MM', $disp_format);
    $disp_format = str_replace('d', 'DD', $disp_format);

    return $disp_format;
}

/****************************************
 * FUNCTION: CONVERT DATE FORMAT TO PHP *
 ****************************************/
function convertDateFormatToPHP($disp_format) {
    $format = str_replace('YYYY', 'Y', $disp_format);
    $format = str_replace('MM', 'm', $format);
    $format = str_replace('DD', 'd', $format);

    return $format;
}

?>