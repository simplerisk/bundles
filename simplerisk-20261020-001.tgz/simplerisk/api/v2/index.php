<?php
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Include required functions file
require_once(realpath(__DIR__ . '/includes/api.php'));
require_once(realpath(__DIR__ . '/includes/simplerisk.php'));
require_once(realpath(__DIR__ . '/includes/assets.php'));
require_once(realpath(__DIR__ . '/includes/assets_discovery.php'));
require_once(realpath(__DIR__ . '/includes/governance.php'));
require_once(realpath(__DIR__ . '/includes/governance_controls.php'));
require_once(realpath(__DIR__ . '/includes/applicability.php'));
require_once(realpath(__DIR__ . '/includes/soa.php'));
require_once(realpath(__DIR__ . '/includes/risks.php'));
require_once(realpath(__DIR__ . '/includes/compliance.php'));
require_once(realpath(__DIR__ . '/includes/artificial_intelligence.php'));
require_once(realpath(__DIR__ . '/includes/reporting.php'));
require_once(realpath(__DIR__ . '/includes/self_assessments.php'));
require_once(realpath(__DIR__ . '/includes/data_integrity.php'));
require_once(realpath(__DIR__ . '/includes/profile.php'));
require_once(realpath(__DIR__ . '/../../includes/functions.php'));
require_once(realpath(__DIR__ . '/../../includes/authenticate.php'));
require_once(realpath(__DIR__ . '/../../includes/governance.php'));
require_once(realpath(__DIR__ . '/../../includes/compliance.php'));
require_once(realpath(__DIR__ . '/../../includes/compliance_grid.php'));
require_once(realpath(__DIR__ . '/../../includes/reporting.php'));
require_once(realpath(__DIR__ . '/../../includes/api.php'));
require_once(realpath(__DIR__ . '/../../includes/services.php'));
require_once(realpath(__DIR__ . '/../../vendor/autoload.php'));
require_once(realpath(__DIR__ . '/../../includes/Components/SimpleriskApiExceptionHandler.php'));

// Add various security headers except CSP
add_security_headers(true, true, true, true, false);

// Include the language file
require_once(language_file());

// If access is authenticated via session or API key
if (api_v2_is_authenticated())
{
    write_debug_log("[APIv2] Using session-based or API key-based authentication.", "debug");

    // SimpleRisk Admin Routes
    app()->get('/admin/version', 'api_v2_admin_version');
    app()->get('/admin/version/app', 'api_v2_admin_version_app');
    app()->get('/admin/version/db', 'api_v2_admin_version_db');
    app()->post('/admin/upgrade/db', 'api_v2_admin_upgrade_db');
    app()->post('/admin/write_debug_log', 'api_v2_admin_write_debug_log');
    app()->post('/admin/reset_registration', 'api_v2_admin_reset_registration');
    app()->delete('/admin/tag', 'api_v2_admin_tag_delete');
    app()->delete('/admin/tag/all', 'api_v2_admin_tag_delete_all');
    app()->post('/admin/governance/documents/maptocontrols', 'api_v2_update_all_document_control_mappings');
    app()->get('/admin/queue', 'api_v2_admin_queue');
    app()->get('/admin/queue/promises', 'api_v2_admin_queue_promises');

    // Data Integrity Framework
    app()->get('/admin/data-integrity/issues', 'api_v2_data_integrity_issues_list');
    app()->patch('/admin/data-integrity/issues/{id}', 'api_v2_data_integrity_issue_apply');
    app()->post('/admin/data-integrity/issues/bulk-repair', 'api_v2_data_integrity_issues_bulk_repair');
    app()->post('/admin/data-integrity/scan', 'api_v2_data_integrity_scan_trigger');

    // Encryption Extra HTTP handlers. Registered in Core because the four
    // endpoints (status, restore, algorithm-check/trigger, backup/delete) must be
    // reachable even when encryption_extra() is false — failed or partial
    // activation states need the failure-recovery routes. The handlers
    // themselves live with the Extra; the require_once below is gated on
    // the Extra directory existing.
    if (is_dir(realpath(__DIR__ . '/../../extras/encryption'))) {
        require_once realpath(__DIR__ . '/../../extras/encryption/includes/api.php');
        app()->get('/encryption/activation/status', 'api_v2_encryption_activation_status');
        app()->post('/encryption/restore', 'api_v2_encryption_restore');
        app()->post('/encryption/algorithm-check/trigger', 'api_v2_encryption_algorithm_check_trigger');
        app()->post('/encryption/frameworks-consistency/repair', 'api_v2_encryption_frameworks_consistency_repair');
        app()->delete('/encryption/backup', 'api_v2_encryption_backup_delete');
        app()->get('/encryption/backup/download', 'api_v2_encryption_backup_download');
    }

    // SimpleRisk Assets Routes
    app()->get('/assets', 'api_v2_assets');
    app()->get('/assets/associations', 'api_v2_assets_associations');
    app()->get('/assets/tags', 'api_v2_assets_tags_get');
    // Literal /assets/<word> GETs must be registered before the /assets/{id}
    // CRUD wildcard below — Leaf matches in registration order, so a wildcard
    // registered first will swallow GET /assets/options as id="options" and
    // 400 from getAssetById's non-integer-id check. Same constraint applies
    // to any future literal GET /assets/<word> route.
    app()->get('/assets/options', 'get_asset_options');
    app()->get('/assets/column-settings', 'assets_column_settings_get');
    app()->put('/assets/column-settings', 'assets_column_settings_put');
    // POST /assets/bulk must stay ahead of any /assets/{id} route.
    app()->post('/assets/bulk', 'assets_bulk_API');
    // Background discovery runs -- also ahead of the /assets/{id} wildcard.
    app()->post('/assets/discovery-runs', 'assets_discovery_runs_create_API');
    app()->get('/assets/discovery-runs', 'assets_discovery_runs_list_API');
    // Literal segment ahead of the /assets/discovery-runs/{id} wildcard.
    app()->get('/assets/discovery-runs/capabilities', 'assets_discovery_capabilities_API');
    app()->get('/assets/discovery-runs/{id}', 'assets_discovery_run_get_API');
    app()->delete('/assets/discovery-runs/{id}', 'assets_discovery_run_cancel_API');

    /************************** ASSETS CRUD API *******************************/
    app()->get('/assets/{id}', 'getAssetById');
    app()->post('/assets', 'createAsset');
    app()->patch('/assets/{id}', 'updateAssetById');
    app()->delete('/assets/{id}', 'deleteAssetById');
    app()->get('/assets/{id}/associations', 'getAssetAssociations');
    app()->get('/assets/{id}/audit-trail', 'getAssetAuditTrail');
    app()->get('/asset-groups', 'listAssetGroups');
    // Literal /asset-groups/<word> routes must be registered before the
    // /asset-groups/{id} wildcard below (Leaf matches in registration order).
    app()->get('/asset-groups/column-settings', 'asset_groups_column_settings_get');
    app()->put('/asset-groups/column-settings', 'asset_groups_column_settings_put');
    app()->post('/asset-groups/bulk', 'asset_groups_bulk_API');
    app()->post('/asset-groups', 'createAssetGroupCrud');
    app()->get('/asset-groups/{id}', 'getAssetGroupById');
    app()->patch('/asset-groups/{id}', 'updateAssetGroupById');
    app()->delete('/asset-groups/{id}', 'deleteAssetGroupById');
    app()->get('/asset-groups/{id}/assets', 'getAssetGroupAssets');
    app()->post('/asset-groups/{id}/assets', 'addAssetsToAssetGroup');
    app()->delete('/asset-groups/{id}/assets/{asset_id}', 'removeAssetFromAssetGroupById');
    /************************* END ASSETS CRUD API ****************************/

    // SimpleRisk Governance Routes

    app()->get('/governance/frameworks', 'api_v2_governance_frameworks');
    app()->get('/governance/frameworks/treegrid', 'api_v2_governance_frameworks_treegrid');
    // Client-rendered framework rail (Define Control Frameworks redesign, Task 22).
    // Returns value/name/depth/control_count -- not the treegrid's easyui shape --
    // and must stay a literal path registered before the /governance/frameworks/{id}
    // CRUD wildcard below, matching the /governance/controls/table convention above.
    app()->get('/governance/frameworks/rail', 'api_v2_governance_frameworks_rail');
    app()->get('/governance/frameworks/associations', 'api_v2_governance_frameworks_associations');
    app()->get('/governance/controls', 'api_v2_governance_controls');
    // Full cross-framework control roster (id, control_number, short_name,
    // family, description, frameworks[]) for the sr-faceted-picker.js control
    // pickers on Document Program and Define Exceptions -- same shape as
    // api_v2_compliance_control_roster() (api/v2/includes/compliance.php),
    // gated on governance instead of compliance permission since those two
    // pages don't require the Compliance module. Registered as a literal
    // path before the /governance/controls/{id} CRUD wildcard below, same
    // reasoning as /governance/controls/table just below.
    app()->get('/governance/controls/roster', 'api_v2_governance_control_roster');
    // Client-rendered controls table (Define Control Frameworks redesign). Returns
    // shaped row data, not HTML -- see api/v2/includes/governance_controls.php.
    // Registered as a literal path before the /governance/controls/{id} CRUD
    // wildcard below, matching the /assets/options ordering convention above.
    app()->get('/governance/controls/table', 'api_v2_governance_controls_table');
    app()->get('/governance/controls/mapped-frameworks', 'api_v2_get_control_mapped_frameworks');
    app()->get('/governance/controls/mapped-frameworks/count', 'api_v2_get_control_mapped_frameworks_count');
    app()->get('/governance/controls/associations', 'api_v2_governance_controls_associations');
    // Bulk control delete (Task 54). POST rather than DELETE because the request
    // names either a list of ids or a FILTER the server resolves -- there is no
    // addressable resource, and a nested filter map cannot ride in a DELETE body.
    // Literal path, registered before the /governance/controls/{id} wildcards
    // below, matching the /governance/controls/table convention above. The
    // `confirm` flag in the body is the interlock: without it the endpoint
    // resolves the set and reports the soft/hard split without writing anything.
    app()->post('/governance/controls/bulk-delete', 'api_v2_governance_controls_bulk_delete');
    // Columns picker persistence (Task: Columns picker + saved layout/
    // filters) -- same {"columns":[...], "filters":{...}} shape and RPC
    // framing as /management/projects/display_settings below; there is no
    // addressable resource, only the requesting user's own display
    // preferences. Literal path, registered before the /governance/controls/
    // {id} wildcards below, same reasoning as /governance/controls/table above.
    app()->post('/governance/controls/display_settings', 'saveControlFrameworksDisplaySettingsApi');
    // /governance/documents is the v2-native flat-list endpoint. The legacy
    // treegrid view (used by the Document Hierarchy tab) lives at
    // /governance/documents/treegrid further down in this file — the two
    // are separate routes by design so the same path doesn't try to serve
    // two different response shapes.
    app()->get('/governance/documents', 'api_v2_governance_documents');
    app()->delete('/governance/documents', 'api_v2_governance_documents_delete');
    app()->get('/governance/documents/controls', 'api_v2_governance_documents_to_controls');
    app()->post('/governance/documents/controls', 'getDocumentsToControlsDatatableResponse');
    app()->get('/governance/documents/associations', 'api_v2_governance_documents_associations');
    app()->get('/governance/documents/terms', 'api_v2_governance_documents_significant_terms');
    // Control applicability -- the Statement of Applicability's one new fact
    // (spec section 5). Reads are gated on `governance`, the write on
    // `modify_frameworks`: scoping a control out of a framework is a
    // framework-scoping decision (spec D10).
    //
    // /reasons is a literal path registered before the collection routes,
    // matching the /governance/controls/table and /assets/options ordering
    // convention above -- Leaf matches in registration order.
    app()->get('/governance/applicability/reasons', 'api_v2_governance_applicability_reasons');
    app()->get('/governance/applicability', 'api_v2_governance_applicability_get');
    // POST rather than PATCH/DELETE: one call sets a whole SELECTION, and the
    // same call inserts, updates, or -- for state 'applicable', which is the
    // default and is never stored -- deletes rows. There is no addressable
    // /applicability/{id} for a bulk decision to PATCH.
    app()->post('/governance/applicability', 'api_v2_governance_applicability_set');
    // The Statement of Applicability itself -- the document every applicability
    // decision above exists to produce (ISO/IEC 27001:2022 clause 6.1.3(d)).
    // Gated on `governance` only: the REPORT is Core, and only its export is
    // Extra-gated. Per-framework by definition, so a request naming no framework
    // is a 400 rather than a cross-framework roll-up that the data model cannot
    // honestly answer.
    //
    // The /export sibling is the SAME document as a file, and is registered
    // FIRST -- the literal-before-general ordering this file uses throughout,
    // because Leaf matches in registration order. It refuses the same
    // frameworks for the same reasons, and adds the ONE thing the report does
    // not have: an Import/Export Extra check, enforced HERE rather than only by
    // the page declining to render a button.
    app()->get('/governance/soa/export', 'api_v2_governance_soa_export');
    app()->get('/governance/soa', 'api_v2_governance_soa');
    app()->get('/governance/keywords', 'api_v2_governance_keywords');
    app()->post('/governance/save_custom_documents_to_controls_display_settings', 'saveCustomDocumentsToControlsDisplaySettingsAPI');

    /************************** GOVERNANCE CRUD API *******************************/
    app()->get('/governance/frameworks/{id}', 'getFrameworkById');
    app()->post('/governance/frameworks', 'createFrameworkCrud');
    app()->patch('/governance/frameworks/{id}', 'updateFrameworkById');
    app()->delete('/governance/frameworks/{id}', 'deleteFrameworkById');
    app()->get('/governance/controls/{id}', 'getControlById');
    app()->post('/governance/controls', 'createControlCrud');
    app()->patch('/governance/controls/{id}', 'updateControlById');
    app()->delete('/governance/controls/{id}', 'deleteControlById');
    /************************* END GOVERNANCE CRUD API ****************************/

    /************************** SELF-ASSESSMENTS API (core, SCF-based) ************/
    // Literal paths registered before the /self-assessments/{id} wildcard so
    // Leaf's registration-order matching doesn't swallow them as an id value.
    app()->get('/self-assessments/frameworks', 'api_v2_self_assessment_frameworks');
    app()->get('/self-assessments/control-results', 'api_v2_self_assessment_control_results');
    app()->get('/self-assessments/pending-risks', 'api_v2_self_assessment_pending_risks');
    app()->post('/self-assessments/pending-risks/{id}/push', 'api_v2_self_assessment_push_risk');
    app()->delete('/self-assessments/pending-risks/{id}', 'api_v2_self_assessment_delete_pending_risk');
    app()->get('/self-assessments', 'api_v2_self_assessments_list');
    app()->post('/self-assessments', 'api_v2_self_assessment_create');
    app()->get('/self-assessments/{id}', 'api_v2_self_assessment_get');
    app()->patch('/self-assessments/{id}/responses', 'api_v2_self_assessment_save_responses');
    app()->post('/self-assessments/{id}/complete', 'api_v2_self_assessment_complete');
    app()->delete('/self-assessments/{id}', 'api_v2_self_assessment_delete');
    /************************ END SELF-ASSESSMENTS API *****************************/

    // SimpleRisk Risk Routes
    app()->get('/risks', 'api_v2_risks');
    app()->get('/risks/associations', 'api_v2_risks_associations');
    app()->get('/risks/tags', 'api_v2_risks_tags_get');
    app()->post('/risks/submit', 'api_v2_risk_submit');

    //SimpleRisk Compliance Routes
    app()->get('/compliance/tests', 'api_v2_compliance_tests');
    app()->get('/compliance/tests/associations', 'api_v2_compliance_tests_associations');
    app()->get('/compliance/tests/tags', 'api_v2_compliance_tests_tags_get');
    app()->get('/compliance/audits/tags', 'api_v2_compliance_audits_tags_get');

    // Define Tests redesign (Phase 1, Task 4) -- grid data feed + control-mappings lookup
    app()->post('/compliance/tests_grid', 'api_v2_compliance_tests_grid');
    app()->post('/compliance/tests_grid/filtered_ids', 'api_v2_compliance_tests_grid_filtered_ids');
    // "Select all N" bulk actions -- ONE request carrying every selected id
    // instead of the client looping one POST/DELETE per id (see
    // api_v2_compliance_tests_batch_retire()/_batch_delete()'s docblocks,
    // api/v2/includes/compliance.php). Hyphenated, matching every other
    // batch-route in this file (/risks/batch-*, /documents/batch-delete,
    // /exceptions/batch-delete-ids, /compliance/audits/batch-delete below).
    app()->post('/compliance/tests/batch-retire', 'api_v2_compliance_tests_batch_retire');
    app()->post('/compliance/tests/batch-delete', 'api_v2_compliance_tests_batch_delete');
    app()->get('/compliance/control_mappings', 'api_v2_compliance_control_mappings');
    // Define Tests redesign -- lightweight control roster (id/control_number/short_name
    // only, no test/last-result/tag enrichment) for the Add-Test modal's control <select>,
    // so populating it no longer requires a full tests_grid(length=-1) fetch of every control.
    app()->get('/compliance/control_roster', 'api_v2_compliance_control_roster');

    /************************** COMPLIANCE CRUD API *******************************/
    app()->get('/compliance/tests/{id}', 'getTestById');
    app()->post('/compliance/tests', 'createTest');
    app()->patch('/compliance/tests/{id}', 'updateTestById');
    app()->delete('/compliance/tests/{id}', 'deleteTestById');
    // Define Tests redesign (Phase 1, Task 8) -- retire/restore lifecycle actions,
    // gated by can_retire_tests() (edit_tests OR delete_tests) rather than a single
    // fixed permission, since either grants the softer "hide it" action.
    app()->post('/compliance/tests/{id}/retire', 'retireTestById');
    app()->post('/compliance/tests/{id}/restore', 'restoreTestById');
    // The test's audit history (every run, newest first) -- the Define Tests
    // grid's History row action. Read-only, so it's gated on compliance
    // permission + the same per-test access check the write routes use, not on
    // any of the edit/delete permissions.
    app()->get('/compliance/tests/{id}/audits', 'getTestAuditHistoryById');
    // Remove ONE (test, control) pairing -- the grid's unlink row action. The
    // test itself survives on its other controls; removing the last one is
    // refused (409) rather than orphaning it.
    app()->delete('/compliance/tests/{id}/controls/{control_id}', 'detachTestFromControl');
    app()->get('/compliance/audits/{id}', 'getAuditById');
    app()->post('/compliance/audits', 'createAudit');
    app()->patch('/compliance/audits/{id}', 'updateAuditById');
    app()->delete('/compliance/audits/{id}', 'deleteAuditById');
    // Define Tests redesign (Phase 3b, Task 5) -- approver sign-off actions on a
    // closed-but-pending audit, gated by approve_tests + user_is_approver_of_audit()
    // + segregation-of-duties (approver cannot be the audit's own tester).
    app()->post('/compliance/audits/{id}/approve', 'approveAuditById');
    app()->post('/compliance/audits/{id}/reject', 'rejectAuditById');
    /************************* END COMPLIANCE CRUD API ****************************/

    // SimpleRisk Artificial Intelligence Routes
    app()->get('/ai/recommendations', 'api_v2_ai_recommendations');
    app()->get('/ai/capabilities', 'api_v2_ai_capabilities_get');
    app()->patch('/ai/capabilities/{id}', 'api_v2_ai_capability_patch');
    app()->get('/ai/provider-url-check', 'api_v2_ai_provider_url_check');
    app()->patch('/ai/context', 'api_v2_ai_context_patch');
    app()->get('/ai/context', 'api_v2_ai_context_questions_get');
    // Registered ABOVE /ai/context/{type}/{id}: 'search' is one literal
    // segment where the {type}/{id} pattern needs two, so there is no true
    // routing collision today -- but the ordering makes the intent explicit
    // so a future router change can't silently swallow 'search' as a {type}.
    app()->get('/ai/context/search', 'api_v2_ai_context_search_get');
    // Same "registered above the {type}/{id} pattern" convention as
    // 'search' above: the canvas launchpad's tile-counts and entity-list
    // endpoints (Task 23).
    app()->get('/ai/context/entity-counts', 'api_v2_ai_context_entity_counts_get');
    app()->get('/ai/context/entities', 'api_v2_ai_context_entities_get');
    app()->get('/ai/context/{type}/{id}', 'api_v2_ai_context_get');
    app()->get('/ai/proposals', 'api_v2_ai_proposals_get');
    app()->patch('/ai/proposals/{id}', 'api_v2_ai_proposal_patch');

    // SimpleRisk Reports Routes
    app()->get('/reports/risk/average', 'api_v2_reports_risk_average');
    app()->get('/reports/risk/opencount', 'api_v2_reports_risk_open_count');

    // Reports Hub + Settings Hub — catalog endpoints, per-user favorites,
    // and Settings Hub license enrichment for uninstalled Extras tiles
    app()->get('/reports/catalog', 'api_v2_reports_catalog');
    app()->get('/admin/settings/catalog', 'api_v2_admin_settings_catalog');
    app()->get('/admin/settings/extras/licenses', 'api_v2_admin_settings_extras_licenses');
    app()->post('/admin/license/refresh',          'api_v2_admin_license_refresh');
    app()->get('/admin/licenses',                  'api_v2_admin_licenses');
    app()->post('/admin/extras/install',           'api_v2_admin_extras_install');
    app()->post('/admin/settings/favorites',          'api_v2_admin_settings_favorite_add');
    app()->delete('/admin/settings/favorites/{key}',  'api_v2_admin_settings_favorite_remove');
    app()->get('/reports/favorites', 'api_v2_reports_favorites_list');
    app()->post('/reports/favorites', 'api_v2_reports_favorites_add');
    app()->delete('/reports/favorites/{report_key}', 'api_v2_reports_favorites_delete');

    // Notifications
    require_once(realpath(__DIR__ . '/../../includes/notifications.php'));
    app()->get('/notifications/counts', 'api_v2_notifications_counts');
    app()->get('/notifications',        'api_v2_notifications_list');
    app()->post('/notifications/mark-read', 'api_v2_notifications_mark_read');
    app()->post('/notifications/trash',    'api_v2_notifications_trash');
    app()->post('/notifications/restore',  'api_v2_notifications_restore');

    // RISK API from external app
    // Define the normal routes
    //app()->get('/', 'api_v2_documentation_redirect');
    app()->get('/whoami', 'whoami');
    app()->get('/management', 'show_management');
    app()->get('/management/risk/view', 'viewrisk');
    app()->post('/management/risk/add', 'addRisk');
    app()->post('/management/risk/update', 'updateRisk');
    app()->post('/management/mitigation/add', 'saveMitigation');
    app()->get('/management/mitigation/view', 'viewmitigation');
    app()->post('/management/review/add', 'saveReview');
    app()->get('/management/review/view', 'viewreview');

    /************************** RISKS CRUD API *******************************/
    app()->get('/risks/{id}', 'viewrisk');
    app()->post('/risks', 'addRisk');
    app()->patch('/risks/{id}', 'updateRisk');
    app()->get('/risks/{id}/mitigations', 'viewmitigation');
    app()->post('/risks/{id}/mitigations', 'saveMitigation');
    app()->patch('/risks/{id}/mitigations', 'saveMitigation');
    app()->get('/risks/{id}/mitigations/controls', 'getMitigationControlsList');
    app()->get('/risks/{id}/mitigations/controls/{control_id}/validation', 'getMitigationControlValidation');
    app()->post('/risks/{id}/mitigations/controls/{control_id}/validation', 'saveMitigationControlValidation');
    app()->get('/risks/{id}/supporting-documentation', 'getSupportingDocumentation');
    app()->post('/risks/{id}/supporting-documentation', 'saveSupportingDocumentation');
    app()->get('/risks/{id}/mitigations/supporting-documentation', 'getMitigationSupportingDocumentation');
    app()->post('/risks/{id}/mitigations/supporting-documentation', 'saveMitigationSupportingDocumentation');
    app()->get('/risks/{id}/reviews', 'viewreview');
    app()->post('/risks/{id}/reviews', 'saveReview');
    app()->get('/risks/{id}/scoring-history', 'scoringHistory');
    app()->get('/risks/{id}/residual-scoring-history', 'residualScoringHistory');
    app()->post('/risks/{id}/reopen', 'reopenForm');
    app()->get('/risks/{id}/comments', 'getRiskComments');
    app()->post('/risks/{id}/comments', 'saveCommentForm');
    app()->post('/risks/{id}/accept-mitigation', 'acceptMitigationForm');

    // Review Risk "Select all N" bulk actions -- one request for up to
    // REVIEW_RISK_SELECT_ALL_MAX ids (includes/api.php), replacing
    // review-risk.js's previous "loop the single-risk endpoint above once
    // per id" client behavior for these five actions.
    app()->post('/risks/batch-comment', 'saveCommentBatch');
    app()->post('/risks/batch-reassign-owner', 'updateRiskOwnerBatch');
    app()->post('/risks/batch-reassign-mitigation-owner', 'saveMitigationOwnerBatch');
    app()->post('/risks/batch-update-status', 'updateStatusBatch');
    app()->post('/risks/batch-close', 'closeRiskBatch');
    /************************* END RISKS CRUD API ****************************/
    app()->get('/admin', 'show_admin');
    app()->get('/admin/users/all', 'allusers');
    app()->get('/admin/users/enabled', 'enabledusers');
    app()->get('/admin/users/disabled', 'disabledusers');
    app()->get('/reports', 'show_reports');
    app()->get('/reports/dynamic', 'dynamicrisk');
    app()->get('/risk_levels', 'risk_levels');

    // RISK API from form
    app()->get('/reports/appetite', 'appetite_report_api');
    app()->post('/reports/high_risk', 'high_risk_report_datatable');
    app()->post('/reports/user_management_reports', 'user_management_reports_api');
    app()->get('/reports/user_management_reports_unique_column_data', 'user_management_reports_unique_column_data_api');

    app()->post('/management/risk/reopen', 'reopenForm');
    app()->get('/management/risk/overview', 'overviewForm');

    app()->post('/reports/dynamic', 'dynamicriskForm');
    app()->post('/reports/dynamic_unique_column_data', 'dynamicriskUniqueColumnDataAPI');
    app()->post('/reports/save-dynamic-selections', 'saveDynamicSelectionsForm');
    app()->post('/reports/delete-dynamic-selection', 'deleteDynamicSelectionForm');
    app()->post('/reports/my_open_risk', 'my_open_risk_datatable');
    app()->post('/reports/recent_commented_risk', 'recent_commented_risk_datatable');
    app()->get('/reports/governance/control_gap_analysis', 'controlGapAnalysisResponse');

    app()->post('/reports/save-graphical-selections', 'saveGraphicalSelectionsForm');
    app()->post('/reports/delete-graphical-selection', 'deleteGraphicalSelectionForm');

    app()->get('/management/risk/viewhtml', 'viewriskHtmlForm');

    app()->get('/management/risk/closerisk', 'closeriskHtmlForm');
    app()->post('/management/risk/closerisk', 'closeriskForm');

    app()->get('/management/risk/view_all_reviews', 'viewAllReviewsForm');
    app()->get('/management/risk/editdetails', 'editdetailsForm');
    app()->post('/management/risk/saveDetails', 'saveDetailsForm');
    app()->post('/management/risk/saveMitigation', 'saveMitigationForm');
    app()->post('/management/risk/saveReview', 'saveReviewForm');

    app()->get('/management/risk/changestatus', 'changestatusForm');
    app()->post('/management/risk/updateStatus', 'updateStatusForm');

    app()->get('/management/risk/mark-unmitigation', 'markUnmitigationForm');
    app()->post('/management/risk/saveMarkUnmitigation', 'saveMarkUnmitigationForm');
    app()->get('/management/risk/mark-unreview', 'markUnreviewForm');
    app()->post('/management/risk/saveMarkUnreview', 'saveMarkUnreviewForm');

    app()->get('/management/risk/scoreaction', 'scoreactionForm');
    app()->post('/management/risk/scoring-method', 'updateScoringMethodForm');
    app()->post('/management/risk/saveScore', 'saveScoreForm');

    app()->post('/management/risk/saveSubject', 'saveSubjectForm');
    app()->get('/management/risk/auditLog', 'get_risk_audit_log_api');

    app()->post('/management/risk/saveComment', 'saveCommentForm');
    app()->post('/management/risk/accept_mitigation', 'acceptMitigationForm');
    app()->post('/management/risk/fix_review_date_format', 'fixReviewDateFormat');
    app()->post('/management/risk/setProjectToRisk', 'setProjectToRiskForm');

    app()->post('/management/impportexport/deleteMapping', 'deleteMapping');

    app()->post('/assessment/update', 'updateAssessment');

    app()->post('/datatable/framework_controls', 'getFrameworkControlsDatatable');
    app()->post('/datatable/mitigation_controls', 'getMitigationControlsDatatable');
    app()->get('/role_responsibilities/get_responsibilities', 'getResponsibilitiesByRoleIdForm');

    /******************** Risk Management Datatatable API **********************/
    // SR: the plan_mitigation/managment_review/review_risks routes and the three
    // matching save_custom_*_display_settings routes were removed here (Task 22)
    // -- their handlers were deleted from includes/api.php when the three legacy
    // pages they served (plan_mitigations.php/management_review.php/review_risks.php)
    // were retired in favor of review_risk.php.
    app()->post('/risk_management/review_risk', 'getReviewRiskDatatableResponse');
    app()->get('/risk_management/review_risk/filter_options', 'getReviewRiskFilterOptions');
    app()->post('/risk_management/review_risk/filtered_ids', 'getReviewRiskFilteredIdsResponse');
    app()->get('/risk_management/review_date_issues', 'getReviewsWithDateIssuesDatatableResponse');

    /******************** Custom Display Settings API **********************/
    app()->post('/risk_management/save_custom_review_risk_display_settings', 'saveCustomReviewRiskDisplaySettingsAPI');

    /******************** Governance and Compliance API **********************/
    //app()->get('/governance/frameworks', 'getFrameworksResponse');
    app()->get('/governance/tabular_documents', 'getTabularDocumentsResponse');

    app()->post('/governance/update_framework_status', 'updateFrameworkStatusResponse');
    app()->post('/governance/update_framework_parent', 'updateFrameworkParentResponse');
    app()->get('/governance/parent_frameworks_dropdown', 'getParentFrameworksDropdownResponse');
    app()->get('/governance/selected_parent_frameworks_dropdown', 'getSelectedParentFrameworksDropdownResponse');
    app()->get('/governance/control', 'getControlResponse');
    app()->get('/governance/framework', 'getFrameworkResponse');
    app()->post('/governance/update_framework', 'updateFrameworkResponse');
    app()->get('/governance/parent_documents_dropdown', 'getParentDocumentsDropdownResponse');
    // Treegrid view of documents grouped by type. Used by governance.js:134's
    // documentation-tab loader. Distinct from /governance/documents above
    // (the v2-native flat list); they were previously colliding on the same
    // path.
    app()->get('/governance/documents/treegrid', 'getDocumentsResponse');
    app()->get('/governance/documents/audit_log', 'get_documents_audit_log_api');
    // Row-expander version history (Document Program grid): every historical
    // compliance_files row for a document, not just the current file_id --
    // get_document_versions_by_id() (includes/governance.php) already existed
    // for the pre-redesign EasyUI treegrid's drilldown; this is its first v2
    // exposure. See get_document_versions_api() in includes/api.php.
    app()->get('/governance/documents/versions', 'get_document_versions_api');
    app()->get('/governance/document', 'getDocumentResponse');
    // Document Program category tab strip (Task 10): read-only list backing the
    // dynamic tabs + quick-add "+" affordance in governance-documents.js.
    app()->get('/governance/document_types', 'get_document_types_api');
    app()->get('/governance/selected_parent_documents_dropdown', 'getSelectedParentDocumentsDropdownResponse');
    app()->get('/governance/related_controls_by_framework_ids', 'getRelatedControlsByFrameworkIdsResponse');
    app()->post('/governance/rebuild_control_filters', 'getControlFiltersByFrameworksResponse');

    app()->post('/governance/add_control', 'addControlResponse');
    app()->post('/governance/update_control', 'updateControlResponse');

    app()->post('/compliance/define_tests', 'getDefineTestsResponse');
    app()->post('/compliance/update_test', 'updateTestResponse');
    app()->get('/compliance/test', 'getTestResponse');
    app()->get('/compliance/approver_roster', 'get_compliance_approver_roster');
    app()->post('/compliance/schedule_preview', 'getSchedulePreviewResponse');
    app()->get('/compliance/initiate_audits', 'getInitiateTestAuditsResponse');
    app()->post('/compliance/active_audits', 'getActiveTestAuditsResponse');
    app()->post('/compliance/save_audit_comment', 'saveTestAuditCommentResponse');
    app()->post('/compliance/past_audits', 'getPastTestAuditsResponse');
    app()->post('/compliance/reopen_audit', 'reopenTestAuditResponse');
    app()->post('/compliance/audit_initiation/initiate', 'initiateFrameworkControlTestsResponse');
    app()->post('/compliance/audit_initiation/initiate_bulk', 'initiateTestsBulkResponse');
    app()->post('/compliance/audit_initiation/eligible_tests', 'getInitiateEligibleTestsResponse');
    app()->get('/compliance/audit_timeline', 'auditTimelineResponse');
    app()->post('/compliance/delete_audit', 'deleteTestAuditResponse');
    /*************************************************************************/

    /******************************* Audit Log API **********************************/
    app()->get('/audit_logs', 'get_audit_logs_api');
    /****************************************** *************************************/

    /******************************* Assets API *************************************/
    app()->post('/assets/update_asset', 'assets_update_asset_API');
    app()->post('/assets/create_asset', 'assets_create_asset_API');
    app()->post('/assets/view/asset_data', 'assets_for_view_API');
    app()->post('/assets/view/action', 'assets_view_action_API');
    app()->post('/asset-group/create', 'asset_group_create');
    app()->post('/asset-group/update', 'asset_group_update');
    app()->post('/asset-group/delete', 'asset_group_delete');
    app()->post('/asset-group/remove_asset', 'asset_group_remove_asset');
    app()->get('/asset-group/tree', 'asset_group_tree');
    app()->get('/asset-group/info', 'asset_group_info');
    app()->get('/asset-group/options', 'get_asset_group_options');
    app()->get('/asset-group/options_by_control', 'get_asset_group_options_by_control');
    app()->post('/assets/create', 'create_asset_api');
    app()->post('/assets/delete', 'delete_asset_api');
    /********************************************************************************/

    /********************* CVE LOOKUP API (to avoid CORS) **********************/
    app()->get('/cve/lookup', 'cve_lookup_api');
    /********************************************************************************/

    /********************* RISK FORMULA API ***************************/
    app()->post('/riskformula/add_impact', 'add_impact_api');
    app()->post('/riskformula/delete_impact', 'delete_impact_api');
    app()->post('/riskformula/add_likelihood', 'add_likelihood_api');
    app()->post('/riskformula/delete_likelihood', 'delete_likelihood_api');
    app()->post('/riskformula/update_impact_or_likelihood_name', 'update_impact_or_likelihood_name_api');
    app()->post('/riskformula/update_custom_score', 'update_custom_score_api');
    app()->get('/riskformula/config', 'api_get_risk_formula_config');
    /******************************************************************/

    /********************* RISK LEVEL API **************************/
    app()->post('/risklevel/update', 'update_risk_level_API');
    /***************************************************************/

    /********************* CONTRIBUTING RISKS API ***************************/
    app()->post('/contributing_risks/add', 'add_contributing_risks_api');
    app()->post('/contributing_risks/update/likelihood', 'update_contributing_risks_likelihood_api');
    app()->post('/contributing_risks/update/impact', 'update_contributing_risks_impact_api');
    app()->post('/contributing_risks/delete/likelihood', 'delete_contributing_risks_likelihood_api');
    app()->post('/contributing_risks/delete/impact', 'delete_contributing_risks_impact_api');
    app()->post('/contributing_risks/table_list', 'contributing_risks_table_list_api');
    /******************************************************************/

    /***************** DOCUMENTS API *****************/
    app()->post('/documents/create', 'create_document_api');
    app()->post('/documents/update', 'update_document_api');
    app()->post('/documents/delete', 'delete_document_api');
    app()->post('/documents/approve', 'approve_document_api');
    app()->post('/documents/unapprove', 'unapprove_document_api');
    app()->post('/documents/batch-approve', 'batch_approve_document_api');
    app()->post('/documents/batch-delete', 'batch_delete_document_api');
    // Deleting exactly ONE historical version (never the document itself)
    // is /documents/delete above with `version` set -- delete_document_api()
    // already forwards it straight through to delete_document()'s existing
    // $version branch (includes/governance.php), so the version-history row
    // expander's delete-this-version action (governance-documents.js) reuses
    // the SAME #document-delete-modal/delete-document-form the row's main
    // delete action uses, just with a real version number in the hidden
    // field instead of an empty one. No separate route needed.
    /***********************************************************/

    /***************** DOCUMENT EXCEPTIONS API *****************/
    app()->post('/exceptions/create', 'create_exception_api');
    app()->post('/exceptions/update', 'update_exception_api');
    app()->post('/exceptions/delete', 'delete_exception_api');
    app()->post('/exceptions/approve', 'approve_exception_api');
    app()->post('/exceptions/unapprove', 'unapprove_exception_api');
    app()->post('/exceptions/batch-approve', 'batch_approve_exception_api');
    app()->post('/exceptions/batch-delete', 'batch_delete_exception_api');
    app()->post('/exceptions/batch-delete-ids', 'batch_delete_exceptions_by_ids_api');
    app()->get('/exceptions/tree', 'get_exceptions_as_treegrid_api');
    app()->get('/exceptions/exception', 'get_exception_api');
    app()->get('/exceptions/info', 'get_exception_for_display_api');
    app()->get('/exceptions/audit_log', 'get_exceptions_audit_log_api');
    app()->get('/exceptions/status', 'get_exceptions_status_api');
    app()->get('/associated-exceptions/tree', 'get_associated_exceptions_as_treegrid_api');
    /***********************************************************/

    app()->get('/management/tag_options_of_type', 'getTagOptionsOfType');
    app()->get('/management/tag_options_of_types', 'getTagOptionsOfTypes');

    // Return scoring histories
    app()->get('/management/risk/scoring_history', 'scoringHistory');
    app()->get('/management/risk/residual_scoring_history', 'residualScoringHistory');

    // Get manager by owner
    app()->get('/user/manager', 'getManagerByUserAPI');

    // Interal api for ajax
    app()->post('/set_custom_display', 'setCustomDisplay');
    app()->post('/set_custom_audits_column', 'setCustomAuditsColumn');

    // Get unfiltered table data
    app()->get('/admin/tables/fullData', 'getTableData');

    // Get Mitigation Control Info (governance-gated via wrapper — see api_v2_get_mitigation_control_info())
    app()->get('/mitigation_controls/get_mitigation_control_info', 'api_v2_get_mitigation_control_info');

    // Get Tooltip Info
    app()->post('/likelihood_impact_chart/tooltip', 'get_tooltip_api');

    app()->post('/one_click_upgrade', 'one_click_upgrade');

    /**************************** PROJECT API ******************************/
    app()->post('/management/project/add', 'add_project_api');
    app()->post('/management/project/delete', 'delete_project_api');
    app()->post('/management/project/update', 'update_project_api');
    app()->post('/management/project/edit', 'edit_project_api');
    app()->post('/management/project/update_status', 'update_project_status_api');
    app()->post('/management/project/update_order', 'update_project_order_api');
    app()->get('/management/project/detail', 'detail_project_api');

    // Plan Projects grid (SR-2229) -- the rebuilt management/prioritize_planning.php
    // is API-backed; these are its read/mutation routes. The seven routes above
    // (add/edit/detail/delete/update_status/update_order/update) are kept and
    // still called by the page.
    app()->get('/management/projects', 'getPlanProjectsGridApi');
    app()->get('/management/projects/unassigned_risks', 'getPlanProjectsUnassignedRisksApi');
    app()->get('/management/project/{id}/risks', 'getPlanProjectRisksApi');
    app()->post('/management/projects/assign_risks', 'assignRisksToProjectApi');
    app()->post('/management/projects/reorder', 'reorderPlanProjectsApi');
    app()->post('/management/projects/display_settings', 'savePlanProjectsDisplaySettingsApi');

    // Get risk catalog table data
    app()->get('/admin/risk_catalog/datatable', 'getRiskCatalogDatatableAPI');
    app()->get('/admin/risk_catalog/detail', 'getRiskCatalogAPI');
    app()->post('/admin/risk_catalog/update_order', 'updateRiskCatalogOrderAPI');
    app()->post('/admin/risk_catalog/add_risk_catalog', 'addRiskCatalogAPI');
    app()->post('/admin/risk_catalog/update_risk_catalog', 'updateRiskCatalogAPI');
    app()->post('/admin/risk_catalog/delete_risk_catalog', 'deleteRiskCatalogAPI');
    app()->post('/admin/risk_catalog/swap_groups', 'swapGroupCatalogAPI');

    // Get threat catalog table data
    app()->get('/admin/threat_catalog/datatable', 'getThreatCatalogDatatableAPI');
    app()->get('/admin/threat_catalog/detail', 'getThreatCatalogAPI');
    app()->post('/admin/threat_catalog/update_order', 'updateThreatCatalogOrderAPI');
    app()->post('/admin/threat_catalog/add_threat_catalog', 'addThreatCatalogAPI');
    app()->post('/admin/threat_catalog/update_threat_catalog', 'updateThreatCatalogAPI');
    app()->post('/admin/threat_catalog/delete_threat_catalog', 'deleteThreatCatalogAPI');

    // This status call needs to be available with ComplianceForge SCF disabled
    // Enable/disable are state-changing and must be POST-only (GET is CSRF-able).
    app()->post('/complianceforgescf/enable', 'api_complianceforgescf_enable');
    app()->post('/complianceforgescf/disable', 'api_complianceforgescf_disable');
    app()->get('/complianceforgescf/status', 'api_complianceforgescf_status');

    //**************************** ACTIVATE/DEACTIVATE EXTRA BEGIN****************************//
    app()->post('/admin/activate_deactivate_extra', 'activateDeactivateExtraApi');
    //***************************** ACTIVATE/DEACTIVATE EXTRA END*****************************//

    /************************** DATATABLE API BEGIN *******************************/
    // SR-1721: resource-scoped, permission-gated DataTables feeds. The old generic
    // POST /get/datatable (getDatatableAPI) was removed — it enforced only session
    // auth, letting any logged-in user pull any module's datatable data. Each route
    // gates on its module permission first, then serves a fixed view.
    app()->post('/compliance/audits/active/datatable', 'api_v2_compliance_active_audits_datatable');
    app()->post('/compliance/audits/past/datatable', 'api_v2_compliance_past_audits_datatable');
    app()->post('/compliance/audits/all/datatable', 'api_v2_compliance_all_audits_datatable');
    app()->post('/compliance/audits/filtered_ids', 'api_v2_compliance_audits_filtered_ids');
    app()->post('/compliance/audits/batch-delete', 'api_v2_compliance_audits_batch_delete');
    app()->get('/compliance/audits/filter_counts', 'api_v2_compliance_audits_filter_counts');
    app()->post('/compliance/audits/report/datatable', 'api_v2_compliance_dynamic_audit_report_datatable');
    app()->post('/compliance/audits/timeline/datatable', 'api_v2_compliance_audit_timeline_datatable');
    app()->post('/governance/documents/datatable', 'api_v2_governance_documents_datatable');
    app()->post('/exceptions/datatable', 'api_v2_exceptions_datatable');
    /*************************** DATATABLE API END ********************************/

    /************************** UI API BEGIN *******************************/
    app()->post('/ui/layout', 'api_save_ui_layout');
    app()->get('/ui/layout', 'api_get_ui_layout');
    app()->get('/ui/widget', 'api_get_ui_widget');
    app()->post('/ui/default_layout', 'api_update_default_status');
    app()->post('/ui/column_settings', 'saveColumnSelectionSettingsAPI');
    app()->get('/ui/risk/template_groups', 'api_get_ui_risk_template_groups');
    app()->get('/ui/risk/fields', 'api_get_ui_risk_fields');
    app()->get('/ui/risk/layout', 'api_get_ui_risk_layout');
    app()->get('/ui/risk/{id}/values', 'api_get_ui_risk_values');
    app()->get('/ui/risk/{id}/mitigation-values', 'api_get_ui_risk_mitigation_values');
    app()->get('/ui/risk/{id}/review-values', 'api_get_ui_risk_review_values');
    app()->get('/ui/risk/{id}/review-history', 'api_get_ui_risk_review_history');
    // Asset record modal (Cards). Literal segments ahead of the {id} route.
    app()->get('/ui/asset/template_groups', 'api_get_ui_asset_template_groups');
    app()->get('/ui/asset/fields', 'api_get_ui_asset_fields');
    app()->get('/ui/asset/layout', 'api_get_ui_asset_layout');
    app()->get('/ui/asset/{id}/values', 'api_get_ui_asset_values');
    // Getting Started widget — per-user step dismissals (dismissal is a resource,
    // so CRUD: PUT create / DELETE restore / GET list).
    app()->put('/ui/getting_started/dismissals/{step_key}', 'api_getting_started_dismiss');
    app()->delete('/ui/getting_started/dismissals/{step_key}', 'api_getting_started_restore');
    app()->get('/ui/getting_started/dismissals', 'api_getting_started_dismissals');
    /*************************** UI API END ********************************/

    // SimpleRisk My Profile Routes -- every handler here is self-scoped to
    // $_SESSION['uid']; none of them accept a target user id.
    app()->get('/account/profile', 'api_v2_profile_get');
    app()->patch('/account/profile', 'api_v2_profile_patch');
    app()->post('/account/reset-display-settings', 'api_v2_profile_reset_display_settings');
    app()->put('/account/password', 'api_v2_profile_password_update');

    /************************** SIMPLERISK EXTRAS APIS ************************************/

    // If the Advanced Search Extra is enabled
    if (advanced_search_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/advanced_search/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the advanced search routes
            get_advanced_search_routes();
        }
    }

    // If the API Extra is enabled
    if (api_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/api/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the api routes
            get_api_routes();

            // Self-service API key management for the caller's own profile.
            // v2-only by design -- api/v1/index.php's matching api_extra()
            // block does not call this. Guarded on function_exists(): the
            // API Extra is versioned and distributed separately from Core
            // (see the maintaining-simplerisk-upgrades skill), so a Core
            // that has been upgraded ahead of its installed API Extra build
            // (core_upgrade_extras() can fail and return 0, or the customer
            // did a manual/tarball Core upgrade) must not fatal on EVERY
            // authenticated v2 request just because this function doesn't
            // exist yet in that older Extra code.
            if (function_exists('get_api_key_routes'))
            {
                get_api_key_routes();
            }
        }
    }

    // If the Artificial Intelligence Extra is enabled
    if (artificial_intelligence_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/artificial_intelligence/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the artificial intelligence routes
            get_artificial_intelligence_routes();
        }
    }

    // If the Assessments Extra is enabled
    if (assessments_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/assessments/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the assessments routes
            get_assessments_routes();
        }
    }

    // If the Authentication Extra is enabled
    if (custom_authentication_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/authentication/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the authentication routes
            get_authentication_routes();
        }
    }

    // If the Secure Controls Framework (SCF) Extra is installed (not enabled like the others)
    if (is_extra_installed("complianceforgescf"))
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/complianceforgescf/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the complianceforge scf routes
            get_complianceforge_scf_routes();
        }
    }

    // If the Customization Extra is enabled
    if (customization_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/customization/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the customization routes
            get_customization_routes();

            // Get the customization v2-only routes (custom fields, document
            // types, template groups). Registered here (v2 only) rather than
            // inside get_customization_routes() -- see that function's
            // neighboring get_customization_v2_routes() docblock in
            // extras/customization/includes/api.php for why:
            // get_customization_routes() is also called from
            // api/v1/index.php's own Customization Extra block, and none of
            // these endpoints belong on the frozen v1 surface.
            get_customization_v2_routes();
        }
    }

    // If the Encryption Extra is enabled
    if (encryption_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/encryption/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the encryption routes
            get_encryption_routes();
        }
    }

    // If the Import Export Extra is enabled
    if (import_export_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/import-export/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the import-export routes
            get_import_export_routes();
        }
    }

    // If the Incident Management Extra is enabled
    if (incident_management_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/incident_management/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the incident management routes
            get_incident_management_routes();
        }
    }

    // If the Jira Extra is enabled
    if (jira_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/jira/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the jira routes
            get_jira_routes();
        }
    }

    // If the Notification Extra is enabled
    if (notification_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/notification/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the notification routes
            get_notification_routes();
        }
    }

    // If the Organizational Hierarchy Extra is enabled
    if (organizational_hierarchy_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/organizational_hierarchy/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the organizational hierarchy routes
            get_organizational_hierarchy_routes();
        }
    }

    // If the Separation Extra is enabled
    if (team_separation_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/separation/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the separation routes
            get_separation_routes();
        }
    }

    // If the UCF Extra is enabled
    if (ucf_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/ucf/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the ucf routes
            get_ucf_routes();
        }
    }

    // If the Vulnerability Management Extra is enabled
    if (vulnmgmt_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/vulnmgmt/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the vulnmgmt routes
            get_vulnmgmt_routes();
        }
    }

    // If the Workflows Extra is enabled
    if (workflows_extra())
    {
        // Required file
        $required_file = realpath(__DIR__ . '/../../extras/workflows/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the workflows routes
            get_workflows_routes();
        }
    }

    // If the instance is registered
    if (get_setting('registration_registered') != 0)
    {
        // Require file
        $required_file = realpath(__DIR__ . '/../../extras/upgrade/includes/api.php');

        // If the file exists
        if (file_exists($required_file))
        {
            // Include the required file
            require_once($required_file);

            // Get the upgrade routes
            get_upgrade_routes();
        }
    }

    /**************************************************************************************/

}
// If this request uses the risk assessment questionnaire token
else if (check_questionnaire_get_token()) {
        write_debug_log("[APIv2] Using token-based authentication.", "debug");

        // Here's a separate section for when the request is not authenticated,
        // but has a valid questionnaire token.
        // This won't create an authenticated session, but allows questionnaires to
        // serve some data to unauthenticated contacts

        app()->get('/asset-group/options', 'get_asset_group_options_noauth');

        // If the Risk Assessment Extra is enabled
        if (assessments_extra())
        {
            // Load the required file
            require_once(realpath(__DIR__ . '/../../extras/assessments/includes/api.php'));

            // This registration serves the token-only (check_questionnaire_get_token()) code path,
            // which does not call get_assessments_routes(). It is NOT redundant with the registration
            // in get_assessments_routes() — removing it would silently break draft saves for external
            // (unauthenticated) contacts who authenticate via questionnaire token only.
            app()->post('/assessments/questionnaire/draft/save', 'api_v2_assessment_questionnaire_draft_save');
        }
    }
// If we are unauthenticated
else
{
    write_debug_log("[APIv2] Unable to authenticate.", "info");

    // Set the error message
    $status_code = "401";
    $status_message = "Unauthorized";
    $data = null;

    // Return the json result
    api_v2_json_result($status_code, $status_message, $data);
}

// Set the error handling if the page is not found
app()->set404(function ()
{
    $response = [];
    $response['status'] = 404;
    $response['status_message'] = "The Requested API Endpoint Was Not Found";
    $response['data'] = null;
    response()->json($response, 404);
});

// Configure leaf logging to the error log
/*
Leaf\Config::set([
    'log.enabled' => true,
    'log.dir' => sys_get_temp_dir(),
    'log.file' => 'simplerisk.log',
]);
*/

// Enable the debugging if needed. Default is false.
app()->config('debug', false);

// Add the custom Simplerisk API Exception Handler
app()->setErrorHandler(new SimpleriskApiExceptionHandler());

// Run the leaf route
app()->run();

?>
