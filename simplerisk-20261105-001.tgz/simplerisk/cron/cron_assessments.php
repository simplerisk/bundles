<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Only run this script if called via the command line
if (php_sapi_name() == "cli")
{
        // Include required functions file
	require_once(realpath(__DIR__ . '/../includes/functions.php'));
	require_once(realpath(__DIR__ . '/../includes/bootstrap.php'));
	require_once(realpath(__DIR__ . '/../vendor/autoload.php'));

	// If the notification extra is enabled
	if (assessments_extra())
	{
	    $message = "Looking for email assessments to send.";
	    write_debug_log($message, "info");
	    //write_log(0, 0, $message, 'notification');

	    // Load the Email Notification Extra
	    require_once(realpath(__DIR__ . '/../extras/assessments/index.php'));

		// Run the email assessments crons
		run_assessments_crons();
	}
}

?>
