<?php
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Include required functions file
require_once(realpath(__DIR__ . '/api.php'));
require_once(realpath(__DIR__ . '/../../../includes/functions.php'));
require_once(realpath(__DIR__ . '/../../../includes/api.php')); // datatable_response_for_view()
require_once(realpath(__DIR__ . '/../../../includes/governance.php'));
require_once (realpath(__DIR__ . '/../../../includes/Components/WordHandler.php'));
require_once (realpath(__DIR__ . '/../../../includes/tf_idf_enrichment.php'));
// entity_graph.php defines the get_*_connectivity_for_*() walkers called
// directly below (api_v2_governance_controls_associations() etc.); declared
// explicitly per CLAUDE.md's function-reachability rule even though it is
// also reachable transitively today via includes/reporting.php.
require_once(realpath(__DIR__ . '/../../../includes/entity_graph.php'));
// ai_context_search_visible_ids() (the L4/Team-Separation record filter
// applied to the walker results below) is defined here.
require_once(realpath(__DIR__ . '/../../../includes/ai_context_graph.php'));
// shape_control_roster() (api_v2_governance_control_roster() below) is
// defined here -- a pure, unit-tested grouping/dedupe helper with no
// Compliance-specific coupling, otherwise only reachable via compliance.php.
require_once(realpath(__DIR__ . '/../../../includes/compliance_grid.php'));

load_language_file();

/******************************************
 * FUNCTION: API V2 GOVERNANCE FRAMEWORKS *
 ******************************************/
function api_v2_governance_frameworks()
{
    // Check that this user has the ability to view governance
    api_v2_check_permission("governance");

    // Get the framework id
    $id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($id))
    {
        // Get just the framework with that id
        $framework = get_framework($id);

        // If the framework value returned is empty then we are unable to find a framework with that id
        if (empty($framework))
        {
            // Set the status
            $status_code = 204;
            $status_message = "NO CONTENT: Unable to find a framework with the specified id.";
            $data = null;
        }
        else
        {
            // Set the status
            $status_code = 200;
            $status_message = "SUCCESS";

            // Purify the rich-text description at this output boundary (defense-in-depth
            // against any stored value that bypassed on-write purification).
            $framework['description'] = purify_rich_text_output($framework['description'] ?? '');

            // Create the data array
            $data = [
                "framework" => $framework,
            ];
        }
    }
    // Otherwise, return all frameworks
    else
    {
        // Get the requested status defaulted to 1
        $status = get_param("GET", "status", 1);

        // Get the frameworks array
        $frameworks = get_frameworks($status, true, true, "name");

        // Purify each rich-text description at this output boundary (defense-in-depth
        // against any stored value that bypassed on-write purification).
        foreach ($frameworks as &$framework) {
            $framework['description'] = purify_rich_text_output($framework['description'] ?? '');
        }
        unset($framework);

        // Create the data array
        $data = [
            "frameworks" => $frameworks,
        ];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/***************************************************
 * FUNCTION: API V2 GOVERNANCE FRAMEWORKS TREEGRID *
 ***************************************************/
function api_v2_governance_frameworks_treegrid()
{
    global $lang, $escaper;

    // If the user has governance permissions
    if (check_permission("governance"))
    {
        // The rail's "All" option (Task 2) sends status='' -- that must mean
        // "no status filter", which get_frameworks()/get_frameworks_as_treegrid()
        // already support via $status === false. Blindly (int)-casting '' produces
        // 0, and no framework has status 0 (status is only ever 1 or 2), so "All"
        // silently returned zero frameworks instead of everything. An omitted
        // status defaults to 1 (Active), matching api_v2_governance_frameworks()
        // just above.
        $status = get_param("GET", "status", 1);
        $status = ($status === '' || $status === null) ? false : (int)$status;
        $result = get_frameworks_as_treegrid($status);
        echo json_encode($result, JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
    else
    {
        json_response(400, $escaper->escapeHtml($lang['NoPermissionForGovernance']), NULL);
    }
}

/*******************************************************************
 * FUNCTION: API V2 GOVERNANCE FRAMEWORKS RAIL                     *
 * Purpose-built payload for the Define Control Frameworks page's  *
 * framework rail (Task 22) -- replaces that page's former reliance *
 * on GET /governance/frameworks/treegrid above, which is shaped     *
 * for the easyui treegrid js/simplerisk/pages/governance.js's       *
 * Document Program / Exceptions treegrids still use (left            *
 * untouched: this is a new, separate route, not a change to that    *
 * one). The rail consumed only 3 of that endpoint's 10 fields and    *
 * discarded its server-rendered `actions` HTML column entirely --    *
 * this returns exactly what the rail renders: `value`, `name`,       *
 * `depth` (tree indentation, build_framework_rail_rows()), a         *
 * real per-framework `control_count` (get_framework_control_counts(), *
 * one query for every framework in the response, not N+1), and       *
 * `is_scf` (Task 27, get_scf_origin_framework_ids()) -- whether the   *
 * framework was created from the ComplianceForge SCF Extra's import.  *
 *******************************************************************/
function api_v2_governance_frameworks_rail()
{
    // Check that this user has the ability to view governance
    api_v2_check_permission("governance");

    // Same "no status filter" semantics as the treegrid endpoint above
    // (Task 9's '' -> false fix): an omitted status defaults to Active (1);
    // an explicit empty string means "every status".
    $status = get_param("GET", "status", 1);
    $status = ($status === '' || $status === null) ? false : (int)$status;

    $frameworks = get_frameworks($status);

    // Task 27: the rail's own ordering, not get_frameworks()'s `order` column.
    // "All frameworks" is pinned first client-side (governance-frameworks.js's
    // renderRail() always prepends it); everything else sorts alphabetically
    // by name via sort_frameworks_by_name() (includes/governance.php -- see
    // its docblock for why sorting the flat list here is sufficient to sort
    // siblings without flattening the tree).
    $frameworks = sort_frameworks_by_name($frameworks);

    $rows = build_framework_rail_rows($frameworks);

    $counts = get_framework_control_counts(array_column($rows, 'value'));

    // Task 27: SCF-origin chip. get_scf_origin_framework_ids() degrades to an
    // empty list (no chips for anyone) when the ComplianceForge SCF Extra
    // isn't installed or its schema hasn't been created -- see that function's
    // docblock (includes/governance.php) for the Core/Extra boundary guard.
    $scfFrameworkIds = get_scf_origin_framework_ids();

    foreach ($rows as &$row) {
        $row['control_count'] = $counts[$row['value']] ?? 0;
        $row['is_scf'] = in_array($row['value'], $scfFrameworkIds, true);
    }
    unset($row);

    // The count behind the rail's synthetic "Unassigned controls" row: live
    // controls mapped to NO framework at all.
    //
    // NOT scoped by ?status=. A control that belongs to no framework is outside
    // every framework, so no filter over framework STATUS can change how many
    // there are -- returning a status-scoped number would make the row's chip
    // move when the rail's Active/Inactive/All switch is thrown, describing a
    // set that did not change.
    //
    // get_control_scope_totals([-1]) rather than a COUNT of its own: that is
    // the SAME aggregate the insights band's Controls tile reads
    // (get_ui_widget_define_frameworks_insights()), and its -1 handling is
    // control_framework_scope_sql()'s `m.control_id is NULL` -- the identical
    // spelling get_framework_controls_by_filter() uses for the controls table's
    // own framework facet. So the rail chip, the tile and the table's row count
    // under that scope are one computation rather than three that ought to
    // agree, which is the rule Tasks 37/40 spent a day establishing on this page.
    $unmapped = get_control_scope_totals([-1]);

    api_v2_json_result(200, "SUCCESS", [
        'rows'           => $rows,
        'unmapped_count' => $unmapped['total'],
    ]);
}

/*********************************************************
 * FUNCTION: API V2 GET MITIGATION CONTROL INFO          *
 * Permission-gated wrapper around the shared            *
 * get_mitigation_control_info() helper. The permission  *
 * check lives here at the v2 route level because the    *
 * shared function is also invoked from the v1 API.      *
 *                                                       *
 * Access requires governance OR riskmanagement:         *
 * - riskmanagement users need control details to make   *
 *   informed selections on the mitigation planning tab  *
 * - governance users need them for the Risks & Controls *
 *   report                                              *
 * - users with neither have no legitimate need for this *
 *   data                                                *
 *********************************************************/
function api_v2_get_mitigation_control_info()
{
    // Allow access if the user has governance or riskmanagement permission
    if (!check_permission("governance") && !check_permission("riskmanagement"))
    {
        api_v2_json_result(403, "FORBIDDEN: The user does not have the required permission to perform this action.", null);
        exit;
    }

    // Delegate to the shared implementation
    get_mitigation_control_info();
}

/****************************************
 * FUNCTION: API V2 GOVERNANCE CONTROLS *
 ****************************************/
function api_v2_governance_controls()
{
    // Check that this user has the ability to view governance
    api_v2_check_permission("governance");

    // Get the control id
    $id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($id))
    {
        // Get just the control with that id
        $control = get_framework_control($id);

        // If the control value returned is empty then we are unable to find a control with that id
        if (empty($control))
        {
            // Set the status
            $status_code = 204;
            $status_message = "NO CONTENT: Unable to find a control with the specified id.";
            $data = null;
        }
        else
        {
            // Set the status
            $status_code = 200;
            $status_message = "SUCCESS";

            // Create the data array
            $data = [
                "control" => $control,
            ];
        }
    }
    // Otherwise, return all controls
    else
    {
        // Get the controls array
        $controls = get_framework_controls();

        // Create the data array
        $data = [
            "controls" => $controls,
        ];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/**********************************************
 * FUNCTION: API V2 GOVERNANCE CONTROL ROSTER *
 **********************************************/
// Full cross-framework control roster for sr-faceted-picker.js (design-system.md
// §14b) -- see the route registration comment in api/v2/index.php. Same SQL/
// shaping as api_v2_compliance_control_roster() (api/v2/includes/compliance.php),
// deliberately duplicated rather than shared across the two files: the two
// endpoints differ only in which permission they gate on, and a shared helper
// spanning api/v2/includes/compliance.php and governance.php would invert which
// file owns which permission domain for no real savings over ~15 lines of SQL.
//
// The Mitigation Controls picker (risk-mitigation-controls.js) also gates on
// `governance` (see this function's own permission check -- the roster is
// pure control-CATALOG data, owned by Governance, not risk-management), so it
// calls this SAME endpoint rather than maintaining its own duplicate query --
// with `include_facets=1` to additionally receive the framework/family facet
// lists its faceted-picker columns need (governance/documentation.php's and
// document_exceptions.php's callers don't ask for those and keep getting the
// original flat-array response, so neither breaks).
function api_v2_governance_control_roster()
{
    // Check that this user has the ability to view governance
    api_v2_check_permission("governance");

    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("
        SELECT `id`, `control_number`, `short_name`, `family`, `description`
        FROM `framework_controls`
        WHERE `deleted` = 0
        ORDER BY `control_number`, `id`
    ");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Framework membership, gathered in one pass -- see
    // api_v2_compliance_control_roster()'s identical comment on why this is
    // joined to `frameworks` (a mapping pointing at a deleted/inactive
    // framework can't put a facet in the picker the page's own framework
    // list doesn't offer).
    $stmt = $db->prepare("
        SELECT m.`control_id`, m.`framework`
        FROM `framework_control_mappings` m
            INNER JOIN `frameworks` f ON f.`value` = m.`framework`
        ORDER BY m.`control_id`
    ");
    $stmt->execute();
    $mapping_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Close the database connection
    db_close($db);

    // Grouping/dedupe is pure -- see shape_control_roster()
    // (includes/compliance_grid.php), unit-tested without a DB.
    $controls = shape_control_roster($rows, $mapping_rows);

    // Opt-in only: governance/documentation.php's and document_exceptions.php's
    // roster callers expect `data` to be the flat controls array itself (see
    // their own loadDocumentControlsRoster()/loadExceptionControlsRoster()),
    // so the default response shape is unchanged. Only a caller that asks for
    // the facet lists (risk-mitigation-controls.js's faceted picker) pays for
    // computing them and receives the wrapped {controls, frameworks, families}
    // shape instead.
    if (get_param("GET", "include_facets", "0") === "1") {
        $frameworks = array_map(function ($row) {
            return array('value' => (int)$row['value'], 'name' => (string)$row['name']);
        }, getAvailableControlFrameworkList(true));
        $families = array_map(function ($row) {
            return array('value' => (int)$row['value'], 'name' => (string)$row['name']);
        }, getAvailableControlFamilyList());

        api_v2_json_result(200, "SUCCESS", array(
            'controls' => $controls,
            'frameworks' => $frameworks,
            'families' => $families,
        ));
        return;
    }

    // Return the result
    api_v2_json_result(200, "SUCCESS", $controls);
}

/*****************************************
 * FUNCTION: API V2 GOVERNANCE DOCUMENTS *
 *****************************************/
function api_v2_governance_documents()
{
    // Check that this user has the ability to view governance
    api_v2_check_permission("governance");

    // Get the document id
    $id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($id))
    {
        // Get just the document with that id
        $document = get_document_by_id($id);

        // If the document value returned is empty then we are unable to find a document with that id
        if (empty($document))
        {
            // Set the status
            $status_code = 204;
            $status_message = "NO CONTENT: Unable to find a document with the specified id.";
            $data = null;
        }
        else
        {
            // Set the status
            $status_code = 200;
            $status_message = "SUCCESS";

            // Create the data array
            $data = [
                "document" => $document,
            ];
        }
    }
    // Otherwise, return all documents
    else
    {
        // Get the documents array
        $documents = get_documents();

        // Create the data array
        $data = [
            "documents" => $documents,
        ];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/************************************************
 * FUNCTION: API V2 GOVERNANCE DOCUMENTS DELETE *
 ************************************************/
function api_v2_governance_documents_delete()
{
    global $lang;

    // Check that this user has the proper permissions
    api_v2_check_permission("governance");
    api_v2_check_permission("delete_documentation");

    // Get the document id and version
    $id = get_param("GET", "document_id", null);
    $version = get_param("GET", "version", null);

    // If we received an id
    if (!empty($id))
    {
        // If the user has the permission to access this document
        if (check_access_for_document($id))
        {
            // Get just the document with that id
            $document = get_document_by_id($id);

            // If the document value returned is empty then we are unable to find a document with that id
            if (empty($document))
            {
                // Set the status
                $status_code = 204;
                $status_message = "NO CONTENT: Unable to find a document with the specified id.";
                $data = [];
            }
            else
            {
                // Attempt to delete the document
                if ($result = delete_document($id, $version))
                {
                    $status_code = 200;
                    $status_message = "Document was deleted successfully.";

                    // Create the data array
                    $data = [
                        "document_id" => $id,
                        "document_name" => $document['document_name'],
                        "document_type" => $document['document_type'],
                    ];
                }
                else
                {
                    $status_code = 400;
                    $status_message = "BAD REQUEST: " . $lang['ErrorDeletingDocument'];
                    $data = [];
                }
            }
        }
        else
        {
            $status_code = 204;
            $status_message = "NO CONTENT: Unable to find a document with the specified id.";
            $data = [];
        }
    }
    else
    {
        $status_code = 204;
        $status_message = "NO CONTENT: Unable to find a document with the specified id.";
        $data = [];
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/******************************************
 * FUNCTION: API V2 CONTROLS ASSOCIATIONS *
 ******************************************/
function api_v2_governance_controls_associations()
{
    // Check that this user has the ability to view risks
    api_v2_check_permission("governance");

    // Get the control id
    $id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($id))
    {
        // Get the connectivity for the control
        $framework_associations = get_framework_connectivity_for_control($id);

        // The "tests" bucket additionally requires the compliance domain
        // permission -- holding "governance" alone does not grant test
        // visibility (mirrors ai_context_type_permission()'s
        // 'test' => 'compliance' mapping used by the /ai/context bundle).
        // Omit the bucket rather than 403 the whole endpoint: every other
        // bucket here is governance-gated and still valid.
        $test_associations = graph_bucket_if_permitted("compliance", fn() => get_test_connectivity_for_control($id));

        $document_associations = get_document_connectivity_for_control($id);

        // The "risks" bucket additionally requires the riskmanagement domain
        // permission -- holding "governance" alone does not grant Risk
        // Management visibility (SR-2094 / HackerOne #3960918: a
        // governance-only caller could read another team's Risk Management
        // subjects through this bucket). Mirrors the "tests" bucket's
        // compliance gate immediately above. Omit the bucket rather than
        // 403 the whole endpoint: every other bucket here is governance-gated
        // and still valid.
        $risk_associations = graph_bucket_if_permitted("riskmanagement", fn() => get_risk_connectivity_for_control($id));

        // L4 (Team Separation) record filter. get_risk_connectivity_for_control()
        // already strips team-inaccessible risks internally (via
        // graph_risk_edge_rows()), but get_test_connectivity_for_control() and
        // get_document_connectivity_for_control() are plain graph_edge_rows()
        // walkers with no L4 awareness of their own. This endpoint calls the
        // walkers directly rather than through the /ai/context orchestrator
        // (which applies its own L4 pass over the assembled node set), so
        // without this the tests/documents buckets leak off-team records to
        // any caller holding "governance" (see l4-audit.md Finding 3a).
        if (!empty($test_associations)) {
            $visibleTestIds = ai_context_search_visible_ids('test', array_column($test_associations, 'test_id'));
            $test_associations = graph_filter_rows_by_visible_ids($test_associations, 'test_id', $visibleTestIds);
        }
        if (!empty($document_associations)) {
            $visibleDocumentIds = ai_context_search_visible_ids('document', array_column($document_associations, 'document_id'));
            $document_associations = graph_filter_rows_by_visible_ids($document_associations, 'document_id', $visibleDocumentIds);
        }

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";

        // Create the data array
        $data = [
            "frameworks" => $framework_associations,
            "tests" => $test_associations,
            "documents" => $document_associations,
            "risks" => $risk_associations,
        ];
    }
    // Otherwise, return an empty data array
    else
    {
        // Create the data array
        $data = [];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/********************************************
 * FUNCTION: API V2 FRAMEWORKS ASSOCIATIONS *
 ********************************************/
function api_v2_governance_frameworks_associations()
{
    // Check that this user has the ability to view risks
    api_v2_check_permission("governance");

    // Get the risk id
    $id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($id))
    {
        // Get the connectivity for the control
        $control_associations = get_control_connectivity_for_framework($id);

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";

        // Create the data array
        $data = [
            "controls" => $control_associations,
        ];
    }
    // Otherwise, return an empty data array
    else
    {
        // Create the data array
        $data = [];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/*******************************************
 * FUNCTION: API V2 DOCUMENTS ASSOCIATIONS *
 *******************************************/
function api_v2_governance_documents_associations()
{
    // Check that this user has the ability to view risks
    api_v2_check_permission("governance");

    // Get the document id
    $id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($id))
    {
        // If the user should have access to this document id
        if (check_access_for_document($id))
        {
            // Get the connectivity for the control
            $control_associations = get_control_connectivity_for_document($id);

            // Set the status
            $status_code = 200;
            $status_message = "SUCCESS";

            // Create the data array
            $data = [
                "controls" => $control_associations,
            ];
        }
        // If the user should not have access to this document id
        else
        {
            // Set the status
            $status_code = 403;
            $status_message = "FORBIDDEN: The user does not have the required permission to perform this action.";
            $data = null;
        }
    }
    // Otherwise, return an empty data array
    else
    {
        // Create the data array
        $data = [];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/************************************************
 * FUNCTION: API V2 DOCUMENTS SIGNIFICANT TERMS *
 ************************************************/
function api_v2_governance_documents_significant_terms()
{
    write_debug_log("FUNCTION: API V2 GOVERNANCE DOCUMENTS SIGNIFICANT TERMS", "debug");

    // Check that this user has the ability to view risks
    api_v2_check_permission("governance");

    // Get the document id
    $document_id = get_param("GET", "id", null);

    // If we received an id
    if (!empty($document_id))
    {
        // If the user should have access to this document id
        if (check_access_for_document($document_id))
        {
            try
            {
                // Get the document
                $document = get_document_by_id($document_id);

                // If the document doesn't exist, return;
                if (empty($document))
                {
                    // Return a 204 response
                    $status_code = 204;
                    $status_message = "NOT FOUND: The requested document was not found.";
                    $data = [];
                    api_v2_json_result($status_code, $status_message, $data);
                }
                // If the document exists
                else
                {
                    // Open the database connection
                    $db = db_open();

                    // Get the file from the database
                    $unique_name = $document['unique_name'];
                    $stmt = $db->prepare("SELECT * FROM compliance_files WHERE BINARY unique_name=:unique_name");
                    $stmt->bindParam(":unique_name", $unique_name, PDO::PARAM_STR, 30);
                    $stmt->execute();

                    // Store the results in an array
                    $array = $stmt->fetch();

                    // Close the database connection
                    db_close($db);

                    // If the array is empty
                    if (empty($array))
                    {
                        // Set the content to null
                        $content = null;
                    }
                    else
                    {
                        // Set the file contents
                        $content = $array['content'];

                        // Write the content to a temporary file
                        $temp_file = tempnam(sys_get_temp_dir(), 'doc_');
                        file_put_contents($temp_file, $content);

                        // Read the Word document
                        $phpWord = PhpOffice\PhpWord\IOFactory::load($temp_file, 'Word2007');

                        // Delete the temporary file
                        unlink($temp_file);

                        // Extract the text from the Word document
                        // @phan-suppress-next-line PhanUndeclaredFunction -- extract_text_content() is a runtime-loaded helper for PHPWord text extraction
                        $document_text = extract_text_content($phpWord);
                        write_debug_log("Extracted text: " . strlen((string)$document_text) . " bytes.", "debug");

                        // Get the significant terms for the document
                        $significant_terms = extractSignificantTerms($document_text);
                        write_debug_log("Significant Terms: " . json_encode($significant_terms), "debug");

                        // Set the status
                        $status_code = 200;
                        $status_message = "SUCCESS";

                        // Create the data array
                        $data = [
                            "terms" => $significant_terms,
                        ];
                    }

                }
            } catch (\Exception $e) {
                write_debug_log("Error processing document: " . $e->getMessage(), "error");
                // Return a 500 response
                $status_code = 500;
                $status_message = "Error processing document.";
                $data = [];
                api_v2_json_result($status_code, $status_message, $data);
            }
        }
        // If the user should not have access to this document id
        else
        {
            // Set the status
            $status_code = 403;
            $status_message = "FORBIDDEN: The user does not have the required permission to perform this action.";
            $data = null;
        }
    }
    // Otherwise, return an empty data array
    else
    {
        // Create the data array
        $data = [];

        // Set the status
        $status_code = 200;
        $status_message = "SUCCESS";
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/****************************************
 * FUNCTION: API V2 GOVERNANCE KEYWORDS *
 ****************************************/
function api_v2_governance_keywords()
{
    write_debug_log("FUNCTION: API V2 GOVERNANCE KEYWORDS", "debug");

    // Check that this user has the ability to view risks
    api_v2_check_permission("governance");

    // Get the governance type
    $type = get_param("GET", "type", null);

    // Get the governance id
    $id = get_param("GET", "id", null);

    // Switch based on the type provided
    switch ($type)
    {
        case "document":
            $result = get_keywords_for_document($id);
            break;
        case "control":
            $result = get_keywords_for_control($id);
            break;
        default:
            $result = [
                'status_code' => 400,
                'status_message' => "BAD REQUEST: The type provided is not valid.",
                'data' => []
            ];
            // Set the status
            $status_code = 400;
            $status_message = "BAD REQUEST: The type provided is not valid.";
            $data = [];
            api_v2_json_result($status_code, $status_message, $data);
            break;
    }

    // Get the result values
    $status_code = $result['status_code'];
    $status_message = $result['status_message'];
    $data = $result['data'];

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/*****************************************************
 * FUNCTION: API V2 GOVERNANCE DOCUMENTS TO CONTROLS *
 *****************************************************/
function api_v2_governance_documents_to_controls()
{
    write_debug_log("FUNCTION: API V2 GOVERNANCE DOCUMENTS TO CONTROLS", "debug");

    // Check that this user has the ability to view risks
    api_v2_check_permission("governance");

    // Get the document id
    $document_id = get_param("GET", "document_id", null);

    // Get the documents to controls array
    $documents_to_controls = get_documents_to_controls(0, false, false, false, false, [], $document_id);

    // If documents were found
    if (!empty($documents_to_controls['data']))
    {
        // Get the result values
        $status_code = 200;
        $status_message = "SUCCESS";
        $data = $documents_to_controls['data'];
    }
    // If no documents were found
    else
    {
        $status_code = 204;
        $status_message = "NO CONTENT: Unable to find a document with the specified id.";
        $data = [];
    }

    // Return the result
    api_v2_json_result($status_code, $status_message, $data);
}

/**********************************************
 * FUNCTION: SAVE CUSTOM DISPLAY SETTINGS API *
 *********************************************/
function saveCustomDocumentsToControlsDisplaySettingsAPI(){
    global $escaper, $lang;
    if (!check_permission("governance")){
        json_response(400, $escaper->escapeHtml($lang['NoPermissionForGovernance']), NULL);
        return;
    }
    if(isset($_POST["document_columns"]) && isset($_POST["control_columns"]) && isset($_POST["matching_columns"])){
        // SR-1870: reject any column name that isn't a plain [A-Za-z0-9_] token
        // before storing it (it is later echoed into a data-name attribute / JS).
        if (!custom_display_columns_are_valid([$_POST["document_columns"], $_POST["control_columns"], $_POST["matching_columns"]])) {
            set_alert(true, "bad", $lang['NoDataAvailable']);
            json_response(400, get_alert(true), NULL);
            return;
        }
        $data = array(
            "document_columns" => $_POST["document_columns"],
            "control_columns" => $_POST["control_columns"],
            "matching_columns" => $_POST["matching_columns"],
        );
        save_custom_risk_display_settings("custom_documents_to_controls_display_settings", $data);
        set_alert(true, "good", $lang['SavedSuccess']);
        json_response(200, get_alert(true), null);
    } else {
        set_alert(true, "bad", $lang['NoDataAvailable']);
        json_response(400, get_alert(true), NULL);
    }
    return;
}

/******************************************************************
 * FUNCTION: RETURN JSON DATA FOR DOCUMENTS TO CONTROLS DATATABLE *
 ******************************************************************/
function getDocumentsToControlsDatatableResponse()
{
    // SD-804: a datatable request that arrives without its DataTables parameters must not 500.
    datatable_request_defaults();

    global $lang;
    global $escaper;

    // If the user has governance permissions
    if (check_permission("governance")) {

        $user = get_user_by_id($_SESSION['uid']);
        $settings = json_decode($user["custom_documents_to_controls_display_settings"] ?? '', true);
        $document_columns_setting = isset($settings["document_columns"])?$settings["document_columns"]:[];
        $control_columns_setting = isset($settings["control_columns"])?$settings["control_columns"]:[];
        $matching_columns_setting = isset($settings["matching_columns"])?$settings["matching_columns"]:[];
        $columns_setting = array_merge($document_columns_setting, $control_columns_setting, $matching_columns_setting);
        $columns = [];

        foreach($columns_setting as $column) {
            if(stripos($column[0], "custom_field_") !== false) {
                if(customization_extra() && $column[1] == 1) $columns[] = $column[0];
            } else if($column[1] == 1) {
                $columns[] = $column[0];
            }
        }
        if(!count($columns)){
            $columns = ["document","control_number","selected","matching","recommendation"];
        }

        $draw = $escaper->escapeHtml($_POST['draw']);

        $start  = $_POST['start'] ? (int)$_POST['start'] : 0;
        $length = $_POST['length'] ? (int)$_POST['length'] : 10;
        /** @var array[] $post_order */
        $post_order = $_POST['order'];
        /** @var array[] $post_columns */
        $post_columns = $_POST['columns'];
        // @phan-suppress-next-line PhanTypeMismatchDimFetch
        $orderColumn = isset($post_order[0]['column']) ? $post_order[0]['column'] : "";
        // @phan-suppress-next-line PhanTypeMismatchDimFetch
        $orderColumnName = isset($post_columns[$orderColumn]['name']) ? $post_columns[$orderColumn]['name'] : null;;
        // @phan-suppress-next-line PhanTypeMismatchDimFetch
        $orderDir = !empty($post_order[0]['dir']) && strtolower($post_order[0]['dir']) === 'asc'? 'asc' : 'desc';

        $column_filters = [];
        for ($i=0; $i<count($post_columns); $i++) {
            // @phan-suppress-next-line PhanTypeMismatchDimFetch
            if (isset($post_columns[$i]) && $post_columns[$i]['searchable'] == "true" && $post_columns[$i]['search']['value'] != '') {
                // @phan-suppress-next-line PhanTypeMismatchDimFetch
                $column_filters[$post_columns[$i]['name']] = $post_columns[$i]['search']['value'];
            }
        }

        // Pass column filters to the get_documents_to_controls function
        $documents_to_controls = get_documents_to_controls(1, $orderColumnName, $orderDir, $start, $length, $column_filters, null);
        $recordsTotal = $documents_to_controls['total'];

        // Now $recordsTotal already accounts for the filters
        $recordsFiltered = $recordsTotal;

        $documents_data = [];
        foreach ($documents_to_controls['data'] as $key=>$document)
        {
            $data_row = [];
            foreach($columns as $column){
                switch ($column) {
                    default :
                        $data_row[] = $escaper->escapeHtml($document[$column]);
                        break;
                    case "document_id":
                        $document_id = $document['document_id'];
                        $data_row[] = "<div data-document_id='{$document_id}'>{$document_id}</div>";
                        break;
                    case "document":
                        $data_row[] = "<div class=\"file-name\"><a href=\"".$_SESSION['base_url']."/compliance/download.php?id=".$escaper->escapeHtml($document['unique_name'])."\">".$escaper->escapeHtml($document['document_name'])."</a></div>";
                        break;
                    case "control_id":
                        $control_id = $document['control_id'];
                        $data_row[] = "<div data-control_id='{$control_id}'>{$control_id}</div>";
                        break;
                    case "selected":
                        $data_row[] = ($document['selected'] === 1 ? "Yes" : "No");
                        break;
                    case "tfidf_match":
                        $data_row[] = ($document['tfidf_match'] === 1 ? "Yes" : "No");
                        break;
                    case "ai_match":
                        $data_row[] = ($document['ai_match'] === 1 ? "Yes" : "No");
                        break;
                    case "ai_confidence":
                        $data_row[] = "{$document['ai_confidence']}%";
                        break;
                    case "ai_reasoning":
                        $data_row[] = (!empty($document['ai_reasoning']) ? $escaper->escapeHtml($document['ai_reasoning']) : $escaper->escapeHtml($lang['ToBeDetermined']));
                        break;
                    case "matching":
                        $matching = $document['matching'];
                        $data_row[] = "<div class=\"matching\">" . $escaper->escapeHtml($lang[$matching]) . "</div>";
                        break;
                    case "recommendation":
                        $recommendation = $document['recommendation'];
                        $data_row[] = "<div class=\"recommendation\">" . $escaper->escapeHtml($lang[$recommendation]) . "</div>";
                        break;
                }
            }
            $documents_data[] = $data_row;
        }

        // The filtered data is already properly handled by the database query
        $documents_by_page = $documents_data;

        $result = [
            'draw' => $draw,
            'data' => $documents_data,
            'recordsTotal' => $recordsTotal,
            'recordsFiltered' => $recordsFiltered,
        ];
        // @phan-suppress-next-line SecurityCheck-XSS -- JSON response consumed by JavaScript/DataTables, not rendered as HTML; values are pre-escaped
        echo json_encode($result, JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
    else
    {
        json_response(400, $escaper->escapeHtml($lang['NoPermissionForGovernance']), NULL);
    }
}

function api_v2_get_control_mapped_frameworks()
{
    global $lang;
    global $escaper;

    // If the user has governance permissions
    if (check_permission("governance"))
    {
        // Get the control ID
        $control_id = (int) $_GET['control_id'];

        // Get the mappings for this framework control ID
        $data = get_mapping_control_frameworks($control_id);

        // Return the successful response
        json_response(200, "Successfully retreived mapped controls.", $data);
    }
    else
    {
        json_response(400, $escaper->escapeHtml($lang['NoPermissionForGovernance']), NULL);
    }
}

function api_v2_get_control_mapped_frameworks_count()
{
    global $lang;
    global $escaper;

    if (!check_permission("governance")) {
        json_response(400, $escaper->escapeHtml($lang['NoPermissionForGovernance']), NULL);
        return;
    }

    $control_id = isset($_GET['control_id']) ? (int) $_GET['control_id'] : 0;
    if (!$control_id) {
        json_response(400, "Invalid control ID.", NULL);
        return;
    }

    // Get the count for the specified control ID
    $data = get_control_framework_mappings_counts($control_id);

    json_response(200, "Successfully retrieved mapped frameworks count.", $data);
}

/*******************************************************************************
 * FUNCTIONS: GOVERNANCE DATATABLE FEEDS                                         *
 * Server-side DataTables feeds for the document-program and exception views    *
 * (SR-1721). The document-program feed is gated on the `governance` module     *
 * permission. Exceptions have their own granular permission set (view/create/  *
 * update/delete/approve_exception) independent of `governance` -- `governance` *
 * only ever gated the wider module, from before those granular exception       *
 * permissions existed -- so their feed lives at the top-level /exceptions      *
 * (alongside the other /exceptions/* endpoints) and is gated on the exception  *
 * 'view' permission alone (HackerOne #3960658 / SR-2091, SR-2103: this used to *
 * additionally require `governance`, which let a `governance` holder without  *
 * `view_exception` read exception data through other surfaces -- e.g. the AI   *
 * context graph -- that only ever checked `view_exception`; dropping the      *
 * `governance` requirement here, rather than adding it everywhere else, makes *
 * `view_exception` the single source of truth for exception read access).      *
 *******************************************************************************/
function api_v2_governance_documents_datatable() {
    api_v2_check_permission("governance");
    datatable_response_for_view('document_program');
}

function api_v2_exceptions_datatable() {
    if (!check_permission_exception('view')) {
        api_v2_json_result(403, "FORBIDDEN: The user does not have the required permission to perform this action.", null);
        exit;
    }
    datatable_response_for_view('document_exception');
}

?>