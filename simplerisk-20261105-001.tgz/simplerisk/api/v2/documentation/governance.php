<?php
// @phan-file-suppress PhanDeprecatedClass -- swagger-php 7 deprecates the OpenApi\Attributes classes (removed in 8.0); move these to OpenApi\Spec before upgrading to swagger-php 8

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// GOVERNANCE (CRUD)

use OpenApi\Attributes as OA;

#[OA\Get(
    path: '/governance/frameworks/{id}',
    summary: 'Get a framework by ID',
    operationId: 'getFrameworkById',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the framework to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Framework retrieved successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'Framework retrieved successfully.'),
                    new OA\Property(property: 'data', type: 'object', additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have governance permission.'),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a framework with the specified id.'),
    ],
)]
class OpenApiGetFrameworkById {}

#[OA\Post(
    path: '/governance/frameworks',
    summary: 'Create a new framework',
    operationId: 'createFramework',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    required: ['name'],
                    properties: [
                        new OA\Property(property: 'name', type: 'string', description: 'The name of the framework.'),
                        new OA\Property(
                            property: 'description',
                            type: 'string',
                            description: 'A description of the framework.',
                        ),
                        new OA\Property(
                            property: 'parent',
                            type: 'integer',
                            description: 'The parent framework ID (0 for no parent).',
                            example: 0,
                        ),
                        new OA\Property(
                            property: 'status',
                            type: 'integer',
                            enum: [1, 2],
                            description: 'Status: 1=active, 2=inactive. Defaults to 1.',
                            example: 1,
                        ),
                        new OA\Property(
                            property: 'scope_statement',
                            type: 'string',
                            description: "Statement of Applicability: the scope this framework is certified against. RICH TEXT (HTML) — purified with HTMLPurifier on write, stored and returned as purified HTML. Render it raw; escaping it prints tags to the reader. Markup that renders as nothing (an emptied editor's `<p><br></p>`) is stored as an empty string.",
                        ),
                        new OA\Property(
                            property: 'default_inclusion_justification',
                            type: 'string',
                            description: 'Statement of Applicability: how inclusion was determined for controls that are applicable. Stored and returned as RAW PLAIN TEXT — escape it at your own rendering sink. Deliberately NOT rich text, unlike scope_statement: this sentence fills a table cell once per applicable control.',
                        ),
                        new OA\Property(
                            property: 'clone_from',
                            type: 'integer',
                            description: "Clone: an existing framework whose control mappings (control, reference name, reference text and reference subject) the new framework is given. Applicability decisions are NOT copied — the clone starts with every control applicable, which is what makes it a fresh scoping canvas over the same control set. Every other field is an ordinary create parameter, so the caller decides the clone's name, description, parent, status and default inclusion justification.",
                            example: 0,
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 201,
            description: 'Framework created successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 201),
                    new OA\Property(property: 'message', type: 'string', example: 'Framework created successfully.'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(property: 'id', type: 'integer', example: 5),
                            new OA\Property(
                                property: 'mappings_copied',
                                type: 'integer',
                                description: 'How many control mappings were copied from clone_from. Always 0 when clone_from was not supplied.',
                                example: 0,
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have permission to add frameworks.'),
        new OA\Response(
            response: 404,
            description: 'NOT FOUND: The clone_from framework does not exist. Nothing was created.',
        ),
        new OA\Response(response: 409, description: 'CONFLICT: A framework with that name already exists.'),
        new OA\Response(
            response: 500,
            description: "The framework was created, but its control mappings could not be copied. The new framework's id is returned in data.",
        ),
    ],
)]
class OpenApiCreateFramework {}

#[OA\Patch(
    path: '/governance/frameworks/{id}',
    summary: 'Update a framework by ID',
    operationId: 'updateFrameworkById',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the framework to update.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    requestBody: new OA\RequestBody(
        required: false,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    properties: [
                        new OA\Property(
                            property: 'name',
                            type: 'string',
                            description: 'The new name for the framework.',
                        ),
                        new OA\Property(
                            property: 'description',
                            type: 'string',
                            description: 'The new description for the framework.',
                        ),
                        new OA\Property(
                            property: 'parent',
                            type: 'integer',
                            description: 'The new parent framework ID.',
                        ),
                        new OA\Property(
                            property: 'status',
                            type: 'integer',
                            enum: [1, 2],
                            description: 'Status: 1=active, 2=inactive. Deactivating cascades to every descendant framework; activating also activates the ancestor chain. Omit the key to leave the status alone.',
                            example: 1,
                        ),
                        new OA\Property(
                            property: 'scope_statement',
                            type: 'string',
                            description: 'Statement of Applicability scope. Omit the key to leave the stored value alone; send an empty string to clear it. RICH TEXT (HTML) — purified on write and returned as purified HTML; render it raw.',
                        ),
                        new OA\Property(
                            property: 'default_inclusion_justification',
                            type: 'string',
                            description: 'Statement of Applicability inclusion justification. Omit the key to leave the stored value alone; send an empty string to clear it. RAW PLAIN TEXT — escape at your rendering sink.',
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(response: 200, description: 'Framework updated successfully.'),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: No updatable fields were provided, a status other than 1 or 2 was sent, or a Statement of Applicability field exceeded 65535 bytes.',
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to modify frameworks.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a framework with the specified id.'),
    ],
)]
class OpenApiUpdateFrameworkById {}

#[OA\Delete(
    path: '/governance/frameworks/{id}',
    summary: 'Delete a framework by ID',
    operationId: 'deleteFrameworkById',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the framework to delete.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Framework deleted successfully.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to delete frameworks.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a framework with the specified id.'),
    ],
)]
class OpenApiDeleteFrameworkById {}

#[OA\Get(
    path: '/governance/controls/{id}',
    summary: 'Get a control by ID',
    operationId: 'getControlById',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the control to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Control retrieved successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'Control retrieved successfully.'),
                    new OA\Property(property: 'data', type: 'object', additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have governance permission.'),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a control with the specified id.'),
    ],
)]
class OpenApiGetControlById {}

#[OA\Post(
    path: '/governance/controls',
    summary: 'Create a new control',
    operationId: 'createControl',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    required: ['short_name'],
                    properties: [
                        new OA\Property(
                            property: 'short_name',
                            type: 'string',
                            description: 'The short name (required).',
                        ),
                        new OA\Property(
                            property: 'long_name',
                            type: 'string',
                            description: 'The long name of the control.',
                        ),
                        new OA\Property(
                            property: 'description',
                            type: 'string',
                            description: 'A description of the control.',
                        ),
                        new OA\Property(property: 'supplemental_guidance', type: 'string'),
                        new OA\Property(property: 'control_owner', type: 'integer', example: 0),
                        new OA\Property(property: 'control_class', type: 'integer', example: 0),
                        new OA\Property(property: 'control_phase', type: 'integer', example: 0),
                        new OA\Property(property: 'control_number', type: 'string'),
                        new OA\Property(property: 'control_current_maturity', type: 'integer', example: 0),
                        new OA\Property(property: 'control_desired_maturity', type: 'integer', example: 0),
                        new OA\Property(property: 'control_priority', type: 'integer', example: 0),
                        new OA\Property(
                            property: 'control_status',
                            type: 'integer',
                            example: 1,
                            description: '0 = Fail, 1 = Pass, 2 = Not Tested',
                        ),
                        new OA\Property(property: 'family', type: 'integer', example: 0),
                        new OA\Property(property: 'mitigation_percent', type: 'integer', example: 0),
                        new OA\Property(
                            property: 'map_framework_id[]',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Parallel to reference_name[]/reference_text[]/reference_subject[] -- one framework id per mapping row. A row with no framework id is skipped.',
                        ),
                        new OA\Property(
                            property: 'reference_name[]',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            description: "The reference (clause number) this framework cites the control under. Parallel to map_framework_id[]. Part of the mapping's unique key, so a row's reference identifies which mapping is written. An element absent at a row's index is treated as an empty reference.",
                        ),
                        new OA\Property(
                            property: 'reference_text[]',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            nullable: true,
                            description: 'The clause text. Parallel to map_framework_id[]. An element that is ABSENT (a shorter array, or the array omitted entirely) leaves the column unset for that row rather than storing an empty string.',
                        ),
                        new OA\Property(
                            property: 'reference_subject[]',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            nullable: true,
                            description: "The framework's own title for the control, as the Statement of Applicability prints it. Parallel to map_framework_id[]. An element that is ABSENT leaves the column unset for that row, and the Statement of Applicability falls back to the SimpleRisk control name.",
                        ),
                        new OA\Property(
                            property: 'asset_maturity[]',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Parallel to assets_asset_groups[] -- one maturity level per mapping row.',
                        ),
                        new OA\Property(
                            property: 'assets_asset_groups[]',
                            type: 'array',
                            items: new OA\Items(type: 'array', items: new OA\Items(type: 'string')),
                            description: "Parallel to asset_maturity[] -- each row is an array of '<id>_asset'/'<id>_group' values.",
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 201,
            description: 'Control created successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 201),
                    new OA\Property(property: 'message', type: 'string', example: 'Control created successfully.'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [new OA\Property(property: 'id', type: 'integer', example: 10)],
                    ),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have permission to add controls.'),
    ],
)]
class OpenApiCreateControl {}

#[OA\Patch(
    path: '/governance/controls/{id}',
    summary: 'Update a control by ID',
    operationId: 'updateControlById',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the control to update.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    requestBody: new OA\RequestBody(
        required: false,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    properties: [
                        new OA\Property(property: 'short_name', type: 'string'),
                        new OA\Property(property: 'long_name', type: 'string'),
                        new OA\Property(property: 'description', type: 'string'),
                        new OA\Property(property: 'supplemental_guidance', type: 'string'),
                        new OA\Property(property: 'control_owner', type: 'integer'),
                        new OA\Property(property: 'control_class', type: 'integer'),
                        new OA\Property(property: 'control_phase', type: 'integer'),
                        new OA\Property(property: 'control_number', type: 'string'),
                        new OA\Property(property: 'control_current_maturity', type: 'integer'),
                        new OA\Property(property: 'control_desired_maturity', type: 'integer'),
                        new OA\Property(property: 'control_priority', type: 'integer'),
                        new OA\Property(
                            property: 'control_status',
                            type: 'integer',
                            description: '0 = Fail, 1 = Pass, 2 = Not Tested',
                        ),
                        new OA\Property(property: 'family', type: 'integer'),
                        new OA\Property(property: 'mitigation_percent', type: 'integer'),
                        new OA\Property(
                            property: 'control_type[]',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: "The control's type IDs. PRESERVE VS CLEAR: if this key is omitted from the request AND control_type_submitted is not sent, the control's existing types are left alone. Sending control_type[] -- with one or more values -- always replaces the existing set, marker or not. To CLEAR every type (the multiselect-deselect-all case, which submits no control_type[] key at all), you must send control_type_submitted with a truthy value; without it, omitting control_type[] is indistinguishable from 'not mentioned' and preserves the existing types.",
                        ),
                        new OA\Property(
                            property: 'control_type_submitted',
                            type: 'string',
                            description: "Marker: send a truthy value alongside an omitted/empty control_type[] to explicitly clear all of the control's types. Only needed for the clear case -- see control_type[] above. Ignored otherwise.",
                        ),
                        new OA\Property(
                            property: 'map_framework_id[]',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: "Parallel to reference_name[]/reference_text[]/reference_subject[] -- one framework id per mapping row. PRESERVE VS CLEAR: this entire group (map_framework_id[], reference_name[], reference_text[], reference_subject[]) is read ONLY when map_frameworks_submitted is sent with a truthy value. Without that marker, the group is ignored outright and the control's existing framework mappings are left alone -- even if map_framework_id[] itself is present in the request. With the marker, the submitted rows become the complete set, replacing every existing mapping; sending the marker with no rows clears all framework mappings.",
                        ),
                        new OA\Property(
                            property: 'reference_name[]',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            description: "Parallel to map_framework_id[]. See map_framework_id[] for the map_frameworks_submitted preserve/clear rule. Part of the mapping's unique key, so a row's reference identifies which mapping is written -- a different reference addresses a different mapping rather than renaming an existing one. An element absent at a row's index is treated as an empty reference.",
                        ),
                        new OA\Property(
                            property: 'reference_text[]',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            nullable: true,
                            description: 'The clause text. Parallel to map_framework_id[]. See map_framework_id[] for the map_frameworks_submitted preserve/clear rule. PER-ELEMENT PRESERVE VS CLEAR: for a row that survives that rule, an element that is present but empty CLEARS the stored clause text, while an element that is ABSENT (a shorter array, or the array omitted entirely while map_framework_id[] is sent) leaves the stored clause text untouched.',
                        ),
                        new OA\Property(
                            property: 'reference_subject[]',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            nullable: true,
                            description: "The framework's own title for the control, as the Statement of Applicability prints it. Parallel to map_framework_id[]. See map_framework_id[] for the map_frameworks_submitted preserve/clear rule. PER-ELEMENT PRESERVE VS CLEAR: an element that is present but empty CLEARS the stored subject; an element that is ABSENT leaves it untouched.",
                        ),
                        new OA\Property(
                            property: 'map_frameworks_submitted',
                            type: 'string',
                            description: "Marker: send a truthy value to have this request's map_framework_id[]/reference_name[]/reference_text[]/reference_subject[] group replace the control's framework mappings -- including replacing them with none if the group is empty. Omit it (or send it falsy) to leave existing framework mappings untouched regardless of what those fields contain.",
                        ),
                        new OA\Property(
                            property: 'asset_maturity[]',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: "Parallel to assets_asset_groups[] -- one maturity level per mapping row. PRESERVE VS CLEAR: this group is read ONLY when mapped_assets_submitted is sent with a truthy value. Without that marker, the group is ignored and the control's existing asset mappings are left alone -- even if asset_maturity[] itself is present in the request. With the marker, the submitted rows become the complete set, replacing every existing mapping; sending the marker with no rows clears all asset mappings.",
                        ),
                        new OA\Property(
                            property: 'assets_asset_groups[]',
                            type: 'array',
                            items: new OA\Items(type: 'array', items: new OA\Items(type: 'string')),
                            description: "Parallel to asset_maturity[] -- each row is an array of '<id>_asset'/'<id>_group' values. See asset_maturity[] for the mapped_assets_submitted preserve/clear rule.",
                        ),
                        new OA\Property(
                            property: 'mapped_assets_submitted',
                            type: 'string',
                            description: "Marker: send a truthy value to have this request's asset_maturity[]/assets_asset_groups[] group replace the control's asset mappings -- including replacing them with none if the group is empty. Omit it (or send it falsy) to leave existing asset mappings untouched regardless of what those fields contain.",
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(response: 200, description: 'Control updated successfully.'),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have permission to modify controls.'),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a control with the specified id.'),
    ],
)]
class OpenApiUpdateControlById {}

#[OA\Delete(
    path: '/governance/controls/{id}',
    summary: 'Delete a control by ID',
    operationId: 'deleteControlById',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the control to delete.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Control deleted successfully.'),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have permission to delete controls.'),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a control with the specified id.'),
    ],
)]
class OpenApiDeleteControlById {}

// GOVERNANCE (LEGACY)

#[OA\Get(
    path: '/governance/frameworks',
    summary: 'List control frameworks in SimpleRisk',
    operationId: 'governanceFrameworks',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the control framework you would like to retrieve details for. Will return all control frameworks if no id is specified.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
        new OA\Parameter(
            parameter: 'status',
            in: 'query',
            name: 'status',
            description: 'Use a status of 1 for enabled or 2 for disabled. Will default to enabled.',
            required: false,
            schema: new OA\Schema(type: 'integer', enum: ['1', '2']),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk control frameworks',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'Success'),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(type: 'object', additionalProperties: true),
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 204,
            description: 'NO CONTENT: Unable to find a control framework with the specified id.',
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceFrameworks {}

#[OA\Get(
    path: '/governance/frameworks/associations',
    summary: 'List framework associations in SimpleRisk',
    operationId: 'frameworksAssociations',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the framework you would like to retrieve associations for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk framework associations. A row whose join target was missing (e.g. a mapping pointing at a deleted record) or whose display name resolved empty is silently dropped rather than returned with a null/blank name.',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a framework with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiFrameworksAssociations {}

#[OA\Get(
    path: '/governance/controls',
    summary: 'List controls in SimpleRisk',
    operationId: 'governanceControls',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the control you would like to retrieve details for. Will return all controls if no id is specified.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk controls',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a control with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceControls {}

#[OA\Get(
    path: '/governance/controls/roster',
    summary: 'Get the lightweight control roster (id/number/name/description, plus family and framework ids)',
    description: "Returns id, control_number, short_name, family and framework ids for every non-deleted control, with no test/last-result/tag enrichment. Backs Document Program's and Define Exceptions' control pickers (design-system.md §14b), whose framework and family columns filter client-side from these ids, AND the Mitigation Controls field's faceted picker (risk-mitigation-controls.js), which passes include_facets=1 to additionally receive resolved framework/family name lists (see that parameter's own description). Same shape as GET /compliance/control_roster, gated on governance instead of compliance permission -- these pages don't require the Compliance module. Without include_facets, framework and family NAMES are not included; each non-Mitigation-Controls caller renders both lists for its own picker facets separately.",
    operationId: 'governanceControlRoster',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'include_facets',
            in: 'query',
            required: false,
            description: "When '1', wraps the response as {controls, frameworks, families} instead of returning the controls array directly -- frameworks/families are each {value, name} pairs resolved server-side, for a caller (the Mitigation Controls picker) that needs facet NAMES, not just ids. Omit for the default flat-array response.",
            schema: new OA\Schema(type: 'string', enum: ['0', '1'], default: '0'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: "Every non-deleted control's id/control_number/short_name, with its family id and the ids of the frameworks it maps into.",
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(
                            type: 'object',
                            properties: [
                                new OA\Property(property: 'id', type: 'integer'),
                                new OA\Property(property: 'control_number', type: 'string', nullable: true),
                                new OA\Property(property: 'short_name', type: 'string'),
                                new OA\Property(
                                    property: 'description',
                                    type: 'string',
                                    description: "The control's description as one line of plain text (tags stripped, whitespace collapsed, capped at 300 characters) for the picker's hover.",
                                ),
                                new OA\Property(
                                    property: 'family',
                                    type: 'integer',
                                    description: 'Family id, or 0 when the control has no family.',
                                ),
                                new OA\Property(
                                    property: 'frameworks',
                                    type: 'array',
                                    description: 'Ids of the frameworks this control maps into; empty when it maps to none.',
                                    items: new OA\Items(type: 'integer'),
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have governance permission.'),
    ],
)]
class OpenApiGovernanceControlRoster {}

#[OA\Get(
    path: '/governance/controls/table',
    summary: 'List controls for the client-rendered controls table',
    description: 'Returns shaped, filtered, sorted, and paginated control rows for the Define Control Frameworks page. Unlike GET /governance/controls, this endpoint never renders HTML -- every field is data.',
    operationId: 'governanceControlsTable',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'start',
            in: 'query',
            description: 'Zero-based offset of the first row to return. An offset past the end of the filtered result set is clamped onto the last page that exists; the offset actually used comes back as data.start.',
            required: false,
            schema: new OA\Schema(type: 'integer', default: 0),
        ),
        new OA\Parameter(
            name: 'length',
            in: 'query',
            description: 'Page size, clamped to 1-200.',
            required: false,
            schema: new OA\Schema(type: 'integer', default: 25),
        ),
        new OA\Parameter(
            name: 'sort',
            in: 'query',
            description: 'Sort column. One of: control_number, short_name, family_name, control_owner_name, control_maturity, control_status. Falls back to control_number.',
            required: false,
            schema: new OA\Schema(type: 'string', default: 'control_number'),
        ),
        new OA\Parameter(
            name: 'dir',
            in: 'query',
            description: 'Sort direction.',
            required: false,
            schema: new OA\Schema(type: 'string', enum: ['asc', 'desc'], default: 'asc'),
        ),
        new OA\Parameter(
            name: 'framework',
            in: 'query',
            description: 'Comma-separated framework IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'family',
            in: 'query',
            description: 'Comma-separated family IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'owner',
            in: 'query',
            description: 'Comma-separated control-owner user IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'class',
            in: 'query',
            description: 'Comma-separated control-class IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'phase',
            in: 'query',
            description: 'Comma-separated control-phase IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'priority',
            in: 'query',
            description: 'Comma-separated control-priority IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'type',
            in: 'query',
            description: 'Comma-separated control-type IDs to filter by. -1 means Unassigned.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'status',
            in: 'query',
            description: 'Comma-separated test-status tokens to filter by: pass, fail, not_tested.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'maturity',
            in: 'query',
            description: 'Comma-separated maturity-bucket tokens to filter by: below, at, above. The legacy spelling below_target is accepted as an alias for below.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
        new OA\Parameter(
            name: 'applicability',
            in: 'query',
            description: "Comma-separated applicability states to filter by: applicable, not_applicable, inherited. The legacy token `excluded` is accepted as an alias for `not_applicable,inherited`. IGNORED unless exactly one real framework is scoped -- applicability is per-framework, so outside one framework's scope there is no state to filter on.",
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Controls table page',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'total',
                                type: 'integer',
                                description: 'Total non-deleted controls, unfiltered.',
                            ),
                            new OA\Property(
                                property: 'filtered',
                                type: 'integer',
                                description: 'Row count after filters, before pagination.',
                            ),
                            new OA\Property(
                                property: 'start',
                                type: 'integer',
                                description: 'The offset the rows below were actually sliced at. Equals the requested start unless that offset is past the end of the filtered result set, in which case it is clamped onto the last page that exists.',
                            ),
                            new OA\Property(
                                property: 'length',
                                type: 'integer',
                                description: 'The page size actually applied, after the 1-200 clamp.',
                            ),
                            new OA\Property(
                                property: 'applicability_scoped',
                                type: 'boolean',
                                description: "Whether applicability is answerable for this request -- true only when exactly one real framework is scoped. The applicability_* row fields below are present only when this is true; outside one framework's scope there is no single honest answer, so they are omitted rather than sent as null.",
                            ),
                            new OA\Property(
                                property: 'rows',
                                type: 'array',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(property: 'id', type: 'integer'),
                                        new OA\Property(property: 'control_number', type: 'string'),
                                        new OA\Property(property: 'short_name', type: 'string'),
                                        new OA\Property(property: 'long_name', type: 'string'),
                                        new OA\Property(property: 'family', type: 'integer'),
                                        new OA\Property(property: 'control_class', type: 'integer'),
                                        new OA\Property(property: 'control_phase', type: 'integer'),
                                        new OA\Property(property: 'control_priority', type: 'integer'),
                                        new OA\Property(property: 'control_owner', type: 'integer'),
                                        new OA\Property(
                                            property: 'control_type_ids',
                                            type: 'array',
                                            items: new OA\Items(type: 'string'),
                                        ),
                                        new OA\Property(
                                            property: 'frameworks',
                                            type: 'array',
                                            items: new OA\Items(type: 'string'),
                                        ),
                                        new OA\Property(
                                            property: 'mapped_frameworks_count',
                                            type: 'integer',
                                            description: "Distinct frameworks this control is mapped into. Same length as `frameworks`; sent as a count so the client doesn't have to re-derive it.",
                                        ),
                                        new OA\Property(
                                            property: 'mapped_controls_count',
                                            type: 'integer',
                                            description: "Distinct reference names (the OTHER frameworks' own control identifiers) this control is mapped to. May differ from mapped_frameworks_count when a control maps into one framework under several reference names.",
                                        ),
                                        new OA\Property(property: 'family_name', type: 'string'),
                                        new OA\Property(property: 'control_class_name', type: 'string'),
                                        new OA\Property(property: 'control_phase_name', type: 'string'),
                                        new OA\Property(property: 'control_priority_name', type: 'string'),
                                        new OA\Property(property: 'control_owner_name', type: 'string'),
                                        new OA\Property(
                                            property: 'control_type_names',
                                            type: 'array',
                                            items: new OA\Items(type: 'string'),
                                        ),
                                        new OA\Property(
                                            property: 'control_status',
                                            type: 'integer',
                                            description: '0 = Fail, 1 = Pass, 2 = Not Tested',
                                        ),
                                        new OA\Property(property: 'control_maturity', type: 'integer'),
                                        new OA\Property(property: 'desired_maturity', type: 'integer'),
                                        new OA\Property(
                                            property: 'control_maturity_name',
                                            type: 'string',
                                            description: 'Display label for control_maturity. Admin-renameable; falls back to the numeric level when the value is outside the 0-5 scale.',
                                        ),
                                        new OA\Property(
                                            property: 'desired_maturity_name',
                                            type: 'string',
                                            description: 'Display label for desired_maturity. Admin-renameable; falls back to the numeric level when the value is outside the 0-5 scale.',
                                        ),
                                        new OA\Property(property: 'mitigation_percent', type: 'integer'),
                                        new OA\Property(
                                            property: 'description_purified',
                                            type: 'string',
                                            description: 'HTML-purified description, safe to insert with .html().',
                                        ),
                                        new OA\Property(
                                            property: 'supplemental_guidance_purified',
                                            type: 'string',
                                            description: 'HTML-purified supplemental guidance, safe to insert with .html().',
                                        ),
                                        new OA\Property(
                                            property: 'custom_field_{id}',
                                            type: 'string',
                                            description: "Present once per ACTIVE Customization Extra custom 'control' field, keyed by the field's numeric id. The active-field catalog itself (key/label/custom) is not served by this endpoint -- the Define Control Frameworks page renders it inline at page load, alongside its other server-resolved state. Each value is resolved to its display text (dropdown/multidropdown option names, decrypted where the field is encrypted) and HTML-escaped -- render with .text()/textContent or insert as-is into an already-trusted sink, never re-escape.",
                                        ),
                                        new OA\Property(
                                            property: 'applicability',
                                            type: 'string',
                                            enum: ['applicable', 'not_applicable', 'inherited'],
                                            description: "The control's applicability within the scoped framework. Only present when applicability_scoped is true. `applicable` is the DEFAULT and is never stored -- a control with no decision row resolves to it.",
                                        ),
                                        new OA\Property(
                                            property: 'applicability_reason',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Name of the configurable reason on the decision, or null. PLAIN TEXT, returned raw -- render with .text()/textContent, never .html().',
                                        ),
                                        new OA\Property(
                                            property: 'applicability_narrative',
                                            type: 'string',
                                            nullable: true,
                                            description: 'The justification recorded with the deviation, or null for an applicable control. PLAIN TEXT, returned raw -- render with .text()/textContent, never .html().',
                                        ),
                                        new OA\Property(
                                            property: 'applicability_provider',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Who performs an inherited control. Empty for a not_applicable decision, null when there is no decision. PLAIN TEXT, returned raw -- render with .text()/textContent, never .html().',
                                        ),
                                        new OA\Property(
                                            property: 'applicability_by',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Username the decision is attributed to, or null when there is no decision.',
                                        ),
                                        new OA\Property(
                                            property: 'applicability_at',
                                            type: 'string',
                                            nullable: true,
                                            description: 'When the decision was recorded, or null when there is no decision.',
                                        ),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceControlsTable {}

#[OA\Post(
    path: '/governance/controls/display_settings',
    summary: "Save the requesting user's Define Control Frameworks Columns picker state",
    description: "Persists the Columns picker's column visibility as one JSON blob on the requesting user's own record, read back on the next page load (rendered inline at page load, not served by any GET endpoint). There is no addressable resource -- only the caller's own display preferences -- hence POST rather than PATCH, matching POST /management/projects/display_settings' identical framing. The filter sheet's facet state is deliberately not accepted here: it is search state, not layout, and is never persisted.",
    operationId: 'saveGovernanceControlsDisplaySettings',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(
                    property: 'columns',
                    type: 'array',
                    description: "Column visibility pairs. Each entry is [key, '0'|'1']. `key` is a standard column id (family, owner, class, phase, priority, control_type, maturity, status) or custom_field_{id}; anything else is rejected with a 400.",
                    items: new OA\Items(type: 'array', items: new OA\Items()),
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(response: 200, description: 'Saved'),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: columns was not sent, or a value failed validation.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'message', type: 'string'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have governance permission.'),
    ],
)]
class OpenApiSaveGovernanceControlsDisplaySettings {}

#[OA\Get(
    path: '/governance/controls/associations',
    summary: 'List control associations in SimpleRisk',
    operationId: 'controlsAssociations',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the control you would like to retrieve associations for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk control associations (frameworks, tests, documents, risks). Every bucket now consistently returns control_id as an integer. A row whose join target was missing or whose display name resolved empty is silently dropped rather than returned with a null/blank name.',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a control with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiControlsAssociations {}

#[OA\Get(
    path: '/governance/controls/mapped-frameworks',
    summary: 'Get mapped framework controls for a governance control',
    description: 'Returns a list of framework control references mapped to a given governance control ID.',
    operationId: 'getControlMappedFrameworks',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'control_id',
            in: 'query',
            description: 'The ID of the governance control',
            required: true,
            schema: new OA\Schema(type: 'integer', example: 42),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Successfully retrieved mapped controls',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'message',
                        type: 'string',
                        example: 'Successfully retrieved mapped controls.',
                    ),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(
                            type: 'object',
                            properties: [
                                new OA\Property(property: 'framework_name', type: 'string', example: 'NIST CSF'),
                                new OA\Property(property: 'reference_name', type: 'string', example: 'ID.AM-1'),
                                new OA\Property(
                                    property: 'reference_text',
                                    type: 'string',
                                    example: 'Physical devices and systems within the organization are inventoried',
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceControlsMappings {}

#[OA\Get(
    path: '/governance/controls/mapped-frameworks/count',
    summary: 'Get the count of mapped frameworks for a specific control',
    operationId: 'governanceControlsMappingsCount',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'control_id',
            in: 'query',
            description: 'ID of the control to retrieve the mapped frameworks count for',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Successfully retrieved mapped frameworks count',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'control_id', type: 'integer', example: 123),
                    new OA\Property(property: 'count', type: 'integer', example: 12),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions or invalid input',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceControlsMappingsCount {}

#[OA\Get(
    path: '/governance/documents',
    summary: 'List documents in SimpleRisk',
    operationId: 'governanceDocuments',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the document you would like to retrieve details for. Will return all documents if no id is specified.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk documents',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a document with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceDocuments {}

#[OA\Delete(
    path: '/governance/documents',
    summary: 'Delete documents in SimpleRisk',
    operationId: 'governanceDocumentsDelete',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'document_id',
            in: 'query',
            name: 'document_id',
            description: 'The id of the document you would like to delete.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
        new OA\Parameter(
            parameter: 'version',
            in: 'query',
            name: 'version',
            description: 'The version of the document you would like to delete.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk documents delete successful',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Document deleted successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a document with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGovernanceDocumentsDelete {}

#[OA\Get(
    path: '/governance/documents/controls',
    summary: 'Get the document to control mappings in SimpleRisk',
    operationId: 'documentsToControls',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'document_id',
            in: 'query',
            name: 'document_id',
            description: 'The id of the document you would like to retrieve the controls mappings for.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk document controls',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a document with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiDocumentsToControls {}

#[OA\Get(
    path: '/governance/documents/associations',
    summary: 'List document associations in SimpleRisk',
    operationId: 'documentsAssociations',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the document you would like to retrieve associations for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk document associations. A row whose join target was missing or whose display name resolved empty is silently dropped rather than returned with a null/blank name.',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a document with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiDocumentsAssociations {}

#[OA\Get(
    path: '/governance/documents/terms',
    summary: 'Get significant terms for a document in SimpleRisk',
    operationId: 'documentsTerms',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the document you would like to retrieve terms for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk document terms',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a document with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiDocumentsTerms {}

#[OA\Get(
    path: '/governance/keywords',
    summary: 'Get keywords for Governance in SimpleRisk',
    operationId: 'keywords',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'type',
            in: 'query',
            name: 'type',
            description: 'The type of Governance keywords you would like to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'string', enum: ['document', 'control']),
        ),
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id you would like to retrieve keywords for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk Governance keywords retrieved',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a document with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiKeywords {}

#[OA\Get(
    path: '/governance/frameworks/treegrid',
    summary: 'Get control frameworks as a treegrid structure',
    description: 'Get control frameworks as a treegrid structure with parent-child relationships.',
    operationId: 'frameworksTreegrid',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'status',
            in: 'query',
            description: 'Use a status of 1 for enabled or 2 for disabled. Omit, or send an empty value, to return frameworks of every status.',
            required: false,
            schema: new OA\Schema(type: 'integer', enum: [1, 2]),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Array of treegrid row objects representing the framework hierarchy',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiFrameworksTreegrid {}

#[OA\Get(
    path: '/governance/frameworks/rail',
    summary: 'List frameworks for the client-rendered framework rail',
    description: "Returns a flat, depth-annotated list of frameworks with a real per-framework control count, for the Define Control Frameworks page's rail. Unlike GET /governance/frameworks/treegrid (which stays reserved for the legacy easyui treegrids on the Document Program / Exceptions tabs), this endpoint carries only the fields the rail renders and never serializes HTML.",
    operationId: 'governanceFrameworksRail',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'status',
            in: 'query',
            description: 'Use a status of 1 for enabled (default) or 2 for disabled. Send an empty value to return frameworks of every status.',
            required: false,
            schema: new OA\Schema(type: 'integer', enum: [1, 2]),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Framework rail rows',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'rows',
                                type: 'array',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(
                                            property: 'value',
                                            type: 'integer',
                                            description: 'Framework id.',
                                        ),
                                        new OA\Property(property: 'name', type: 'string'),
                                        new OA\Property(
                                            property: 'depth',
                                            type: 'integer',
                                            description: 'Tree depth for rail indentation; 0 = top-level.',
                                        ),
                                        new OA\Property(
                                            property: 'control_count',
                                            type: 'integer',
                                            description: 'Distinct non-deleted controls mapped to this framework.',
                                        ),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 403),
                    new OA\Property(property: 'message', type: 'string', example: 'Forbidden'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiFrameworksRail {}

#[OA\Post(
    path: '/governance/documents/controls',
    summary: 'Get document-to-control mappings in DataTables format',
    description: 'Get document-to-control mappings in DataTables format.',
    operationId: 'documentsToControlsDatatable',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(property: 'draw', type: 'integer', description: 'DataTables draw counter', example: 1),
                new OA\Property(
                    property: 'start',
                    type: 'integer',
                    description: 'Paging first record indicator',
                    example: 0,
                ),
                new OA\Property(
                    property: 'length',
                    type: 'integer',
                    description: 'Number of records to display',
                    example: 10,
                ),
                new OA\Property(
                    property: 'columns',
                    type: 'array',
                    description: 'Column definitions',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
                new OA\Property(
                    property: 'order',
                    type: 'array',
                    description: 'Column ordering',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
                new OA\Property(
                    property: 'search',
                    type: 'object',
                    description: 'Global search value',
                    additionalProperties: true,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'DataTables response with document-to-control mapping data',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 100),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 100),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(type: 'object', additionalProperties: true),
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiDocumentsToControlsDatatable {}

#[OA\Post(
    path: '/governance/save_custom_documents_to_controls_display_settings',
    summary: 'Save custom column display settings for the documents-to-controls view',
    description: 'Save custom column display settings for the documents-to-controls view.',
    operationId: 'saveCustomDocumentsToControlsDisplaySettings',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(
                    property: 'document_columns',
                    type: 'array',
                    description: 'List of document column identifiers to display',
                    items: new OA\Items(type: 'string'),
                ),
                new OA\Property(
                    property: 'control_columns',
                    type: 'array',
                    description: 'List of control column identifiers to display',
                    items: new OA\Items(type: 'string'),
                ),
                new OA\Property(
                    property: 'matching_columns',
                    type: 'array',
                    description: 'List of matching column identifiers to display',
                    items: new OA\Items(type: 'string'),
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Display settings saved successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'message',
                        type: 'string',
                        example: 'Display settings saved successfully',
                    ),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error saving display settings',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to save display settings'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiSaveCustomDocumentsToControlsDisplaySettings {}

#[OA\Get(
    path: '/governance/tabular_documents',
    summary: 'Get governance documents in a tabular format',
    description: 'Get governance documents in a tabular format.',
    operationId: 'tabularDocuments',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Array of document objects in tabular format',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiTabularDocuments {}

#[OA\Post(
    path: '/governance/update_framework_status',
    summary: 'Enable or disable a control framework',
    description: 'Enable or disable a control framework.',
    operationId: 'updateFrameworkStatus',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['framework_id', 'status'],
            properties: [
                new OA\Property(
                    property: 'framework_id',
                    type: 'integer',
                    description: 'The ID of the framework to update',
                    example: 1,
                ),
                new OA\Property(
                    property: 'status',
                    type: 'integer',
                    description: 'Use 1 for enabled or 2 for disabled',
                    enum: [1, 2],
                    example: 1,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Framework status updated successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'message',
                        type: 'string',
                        example: 'Framework status updated successfully',
                    ),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error updating framework status',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to update framework status'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiUpdateFrameworkStatus {}

#[OA\Post(
    path: '/governance/update_framework_parent',
    summary: 'Set the parent framework of a control framework',
    description: 'Set the parent framework of a control framework.',
    operationId: 'updateFrameworkParent',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['framework_id', 'parent_id'],
            properties: [
                new OA\Property(
                    property: 'framework_id',
                    type: 'integer',
                    description: 'The ID of the framework to update',
                    example: 1,
                ),
                new OA\Property(
                    property: 'parent_id',
                    type: 'integer',
                    description: 'The ID of the parent framework. Use 0 for no parent.',
                    example: 0,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Framework parent updated successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'message',
                        type: 'string',
                        example: 'Framework parent updated successfully',
                    ),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error updating framework parent',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to update framework parent'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiUpdateFrameworkParent {}

#[OA\Get(
    path: '/governance/parent_frameworks_dropdown',
    summary: 'Get a list of frameworks for use as parent framework options in a dropdown',
    description: 'Get a list of frameworks for use as parent framework options in a dropdown.',
    operationId: 'parentFrameworksDropdown',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: 'HTML select options or array of framework options for the parent dropdown',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
    ],
)]
class OpenApiParentFrameworksDropdown {}

#[OA\Get(
    path: '/governance/selected_parent_frameworks_dropdown',
    summary: 'Get the currently selected parent framework dropdown option for a given framework',
    description: 'Get the currently selected parent framework dropdown option for a given framework.',
    operationId: 'selectedParentFrameworksDropdown',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework_id',
            in: 'query',
            description: 'The ID of the framework to retrieve the selected parent option for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'HTML option element representing the currently selected parent framework',
            content: new OA\JsonContent(type: 'object', additionalProperties: true),
        ),
    ],
)]
class OpenApiSelectedParentFrameworksDropdown {}

#[OA\Get(
    path: '/governance/control',
    summary: 'Get details for a single control',
    description: 'Get details for a single control.',
    operationId: 'getControl',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'control_id',
            in: 'query',
            description: 'The ID of the control to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Control object with all fields',
            content: new OA\JsonContent(type: 'object', additionalProperties: true),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGetControl {}

#[OA\Get(
    path: '/governance/framework',
    summary: 'Get details for a single framework',
    description: 'Get details for a single framework.',
    operationId: 'getFramework',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework_id',
            in: 'query',
            description: 'The ID of the framework to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Framework object',
            content: new OA\JsonContent(type: 'object', additionalProperties: true),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGetFramework {}

#[OA\Post(
    path: '/governance/update_framework',
    summary: 'Update an existing control framework',
    description: 'Update an existing control framework.',
    operationId: 'updateFramework',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['framework_id'],
            properties: [
                new OA\Property(
                    property: 'framework_id',
                    type: 'integer',
                    description: 'The ID of the framework to update',
                    example: 1,
                ),
                new OA\Property(
                    property: 'name',
                    type: 'string',
                    description: 'The name of the framework',
                    example: 'NIST CSF',
                ),
                new OA\Property(property: 'description', type: 'string', description: 'A description of the framework'),
                new OA\Property(
                    property: 'status',
                    type: 'integer',
                    description: 'Use 1 for enabled or 2 for disabled',
                    enum: [1, 2],
                    example: 1,
                ),
                new OA\Property(
                    property: 'parent',
                    type: 'integer',
                    description: 'The ID of the parent framework. Use 0 for no parent.',
                    example: 0,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Framework updated successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Framework updated successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error updating framework',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to update framework'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiUpdateFramework {}

#[OA\Get(
    path: '/governance/parent_documents_dropdown',
    summary: 'Get a list of documents for use as parent document options in a dropdown',
    description: 'Get a list of documents for use as parent document options in a dropdown.',
    operationId: 'parentDocumentsDropdown',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: 'HTML select options for the parent document dropdown',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
    ],
)]
class OpenApiParentDocumentsDropdown {}

#[OA\Get(
    path: '/governance/document',
    summary: 'Get details for a single document',
    description: 'Get details for a single document.',
    operationId: 'getDocument',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'document_id',
            in: 'query',
            description: 'The ID of the document to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Document object',
            content: new OA\JsonContent(type: 'object', additionalProperties: true),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have governance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for governance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGetDocument {}

#[OA\Get(
    path: '/governance/document_types',
    summary: 'Get the document category lookup used by the Document Program tab strip',
    description: 'Get every document category ({value, name}) a document can be filed under, in display order. Backs the Document Program tab strip and its quick-add affordance (Task 10); categories are created via Admin > Add/Remove Values.',
    operationId: 'getDocumentTypes',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: 'List of document categories',
            content: new OA\JsonContent(
                type: 'array',
                items: new OA\Items(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'value', type: 'integer', example: 1),
                        new OA\Property(property: 'name', type: 'string', example: 'policies'),
                        new OA\Property(property: 'label', type: 'string', example: 'Policies'),
                    ],
                ),
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have the view_documentation permission',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(
                        property: 'message',
                        type: 'string',
                        example: "You don't have permission to view Documentation",
                    ),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGetDocumentTypes {}

#[OA\Post(
    path: '/governance/document_types',
    summary: 'Add a document category',
    description: 'Admin-only. Requires the Customization Extra to be active. Creates a new document category; duplicate names resolve to the existing row rather than erroring.',
    operationId: 'addDocumentType',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['name'],
            properties: [new OA\Property(property: 'name', type: 'string', maxLength: 100, example: 'Runbooks')],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'The refreshed list of document categories',
            content: new OA\JsonContent(
                type: 'array',
                items: new OA\Items(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'value', type: 'integer', example: 5),
                        new OA\Property(property: 'name', type: 'string', example: 'Runbooks'),
                        new OA\Property(property: 'label', type: 'string', example: 'Runbooks'),
                    ],
                ),
            ),
        ),
        new OA\Response(response: 400, description: 'Missing/too-long name'),
        new OA\Response(response: 403, description: 'Caller is not an admin, or the Customization Extra is not active'),
    ],
)]
class OpenApiAddDocumentType {}

#[OA\Patch(
    path: '/governance/document_types/{id}',
    summary: 'Rename a document category',
    description: 'Admin-only. Requires the Customization Extra to be active. Refuses to rename Policies/Guidelines/Standards/Procedures — those slugs are matched literally throughout the codebase.',
    operationId: 'updateDocumentType',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [new OA\Parameter(name: 'id', in: 'path', required: true, schema: new OA\Schema(type: 'integer'))],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['name'],
            properties: [new OA\Property(property: 'name', type: 'string', maxLength: 100)],
        ),
    ),
    responses: [
        new OA\Response(response: 200, description: 'The refreshed list of document categories'),
        new OA\Response(response: 400, description: 'Missing/too-long name, or the id is a seeded slug'),
        new OA\Response(response: 403, description: 'Caller is not an admin, or the Customization Extra is not active'),
        new OA\Response(response: 404, description: 'No document category with that id'),
    ],
)]
class OpenApiUpdateDocumentType {}

#[OA\Delete(
    path: '/governance/document_types/{id}',
    summary: 'Delete a document category',
    description: 'Admin-only. Requires the Customization Extra to be active. Refuses to delete Policies/Guidelines/Standards/Procedures — those slugs are matched literally throughout the codebase — or a category that still has documents filed under it.',
    operationId: 'deleteDocumentType',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [new OA\Parameter(name: 'id', in: 'path', required: true, schema: new OA\Schema(type: 'integer'))],
    responses: [
        new OA\Response(response: 200, description: 'The refreshed list of document categories'),
        new OA\Response(
            response: 400,
            description: 'The category is a seeded slug, or still has documents filed under it',
        ),
        new OA\Response(response: 403, description: 'Caller is not an admin, or the Customization Extra is not active'),
        new OA\Response(response: 404, description: 'No document category with that id'),
    ],
)]
class OpenApiDeleteDocumentType {}

#[OA\Get(
    path: '/governance/selected_parent_documents_dropdown',
    summary: 'Get the currently selected parent document dropdown for a given document',
    description: 'Get the currently selected parent document dropdown for a given document.',
    operationId: 'selectedParentDocumentsDropdown',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'document_id',
            in: 'query',
            description: 'The ID of the document to retrieve the selected parent option for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'HTML option element representing the currently selected parent document',
            content: new OA\JsonContent(type: 'object', additionalProperties: true),
        ),
    ],
)]
class OpenApiSelectedParentDocumentsDropdown {}

#[OA\Get(
    path: '/governance/related_controls_by_framework_ids',
    summary: 'Get controls related to one or more frameworks',
    description: 'Get controls related to one or more frameworks.',
    operationId: 'relatedControlsByFrameworkIds',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework_ids',
            in: 'query',
            description: 'One or more framework IDs to retrieve related controls for.',
            required: true,
            schema: new OA\Schema(type: 'array', items: new OA\Items(type: 'integer')),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Array of control objects related to the specified frameworks',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
    ],
)]
class OpenApiRelatedControlsByFrameworkIds {}

#[OA\Get(
    path: '/governance/rebuild_control_filters',
    summary: 'Get control filter options based on selected frameworks',
    description: 'Get control filter options based on selected frameworks.',
    operationId: 'rebuildControlFilters',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework_ids',
            in: 'query',
            description: 'One or more framework IDs to build filter options for.',
            required: false,
            schema: new OA\Schema(type: 'array', items: new OA\Items(type: 'integer')),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Filter HTML or JSON options based on selected frameworks',
            content: new OA\JsonContent(type: 'object', additionalProperties: true),
        ),
    ],
)]
class OpenApiRebuildControlFilters {}

#[OA\Post(
    path: '/governance/add_control',
    summary: 'Add a new control',
    description: 'Add a new control.',
    operationId: 'addControl',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['short_name'],
            properties: [
                new OA\Property(
                    property: 'short_name',
                    type: 'string',
                    description: 'Short name for the control',
                    example: 'AC-1',
                ),
                new OA\Property(
                    property: 'long_name',
                    type: 'string',
                    description: 'Full descriptive name for the control',
                ),
                new OA\Property(property: 'description', type: 'string', description: 'Description of the control'),
                new OA\Property(
                    property: 'supplemental_guidance',
                    type: 'string',
                    description: 'Supplemental guidance for implementing the control',
                ),
                new OA\Property(
                    property: 'framework_ids',
                    type: 'array',
                    description: 'IDs of frameworks this control belongs to. Used ONLY when no map_framework_id[] rows are sent; the control is added to each framework under its own control_number as the reference.',
                    items: new OA\Items(type: 'integer'),
                ),
                new OA\Property(
                    property: 'map_framework_id[]',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'One framework id per mapping row. Parallel to reference_name[] and reference_text[] -- the three arrays are paired BY INDEX. Takes precedence over framework_ids.',
                ),
                new OA\Property(
                    property: 'reference_name[]',
                    type: 'array',
                    items: new OA\Items(type: 'string'),
                    description: "The reference (clause number) this framework cites the control under. Parallel to map_framework_id[]. Part of the mapping's unique key, so a row's reference identifies which mapping is being written.",
                ),
                new OA\Property(
                    property: 'reference_text[]',
                    type: 'array',
                    items: new OA\Items(type: 'string'),
                    description: 'The clause text. Parallel to map_framework_id[]. An element that is present but empty CLEARS the stored text; an element that is ABSENT (a shorter array, or the array omitted entirely) leaves the stored text untouched.',
                ),
                new OA\Property(
                    property: 'control_number',
                    type: 'string',
                    description: 'Control reference number',
                    example: 'AC-1',
                ),
                new OA\Property(property: 'control_class', type: 'integer', description: 'ID of the control class'),
                new OA\Property(property: 'control_phase', type: 'integer', description: 'ID of the control phase'),
                new OA\Property(
                    property: 'control_owner',
                    type: 'integer',
                    description: 'User ID of the control owner',
                ),
                new OA\Property(
                    property: 'control_priority',
                    type: 'integer',
                    description: 'ID of the control priority',
                ),
                new OA\Property(property: 'family', type: 'integer', description: 'ID of the control family'),
                new OA\Property(
                    property: 'mitigation_percent',
                    type: 'integer',
                    description: 'Mitigation percentage (0-100)',
                    example: 50,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Control added successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Control added successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error adding control',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to add control'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiAddControl {}

#[OA\Post(
    path: '/governance/update_control',
    summary: 'Update an existing control',
    description: 'Update an existing control.',
    operationId: 'updateControl',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['control_id'],
            properties: [
                new OA\Property(
                    property: 'control_id',
                    type: 'integer',
                    description: 'The ID of the control to update',
                    example: 1,
                ),
                new OA\Property(
                    property: 'short_name',
                    type: 'string',
                    description: 'Short name for the control',
                    example: 'AC-1',
                ),
                new OA\Property(
                    property: 'long_name',
                    type: 'string',
                    description: 'Full descriptive name for the control',
                ),
                new OA\Property(property: 'description', type: 'string', description: 'Description of the control'),
                new OA\Property(
                    property: 'supplemental_guidance',
                    type: 'string',
                    description: 'Supplemental guidance for implementing the control',
                ),
                new OA\Property(
                    property: 'framework_ids',
                    type: 'array',
                    description: "IDs of frameworks this control belongs to. Used ONLY when no map_framework_id[] rows are sent. It asserts MEMBERSHIP and nothing more: a framework the control is already mapped to is left exactly as it is (its reference and clause text are not rewritten), and a framework it is not yet in gains a mapping under the control's own control_number.",
                    items: new OA\Items(type: 'integer'),
                ),
                new OA\Property(
                    property: 'map_framework_id[]',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'One framework id per mapping row. Parallel to reference_name[] and reference_text[] -- the three arrays are paired BY INDEX. Takes precedence over framework_ids. Without map_frameworks_submitted this group only ADDS and UPDATES mappings and never removes one. A request carrying map_frameworks_submitted replaces the control\'s mapping set with the submitted rows, matched by (framework, reference_name); mappings to inactive frameworks, which the form cannot represent, are preserved.',
                ),
                new OA\Property(
                    property: 'map_frameworks_submitted',
                    type: 'string',
                    description: "Marker: send a truthy value to have this request's map_framework_id[]/reference_name[]/reference_text[] group replace the control's framework mappings, matched by (framework, reference_name); mappings to inactive frameworks are preserved. Sending the marker with no rows removes every mapping to an active framework. Omit it to leave existing framework mappings untouched (nothing is removed).",
                ),
                new OA\Property(
                    property: 'reference_name[]',
                    type: 'array',
                    items: new OA\Items(type: 'string'),
                    description: "The reference (clause number) this framework cites the control under. Parallel to map_framework_id[]. Part of the mapping's unique key, so a row's reference identifies which mapping is being written -- a different reference addresses a different mapping rather than renaming an existing one.",
                ),
                new OA\Property(
                    property: 'reference_text[]',
                    type: 'array',
                    items: new OA\Items(type: 'string'),
                    description: 'The clause text. Parallel to map_framework_id[]. An element that is present but empty CLEARS the stored text; an element that is ABSENT (a shorter array, or the array omitted entirely) leaves the stored text untouched.',
                ),
                new OA\Property(
                    property: 'control_number',
                    type: 'string',
                    description: 'Control reference number',
                    example: 'AC-1',
                ),
                new OA\Property(property: 'control_class', type: 'integer', description: 'ID of the control class'),
                new OA\Property(property: 'control_phase', type: 'integer', description: 'ID of the control phase'),
                new OA\Property(
                    property: 'control_owner',
                    type: 'integer',
                    description: 'User ID of the control owner',
                ),
                new OA\Property(
                    property: 'control_priority',
                    type: 'integer',
                    description: 'ID of the control priority',
                ),
                new OA\Property(property: 'family', type: 'integer', description: 'ID of the control family'),
                new OA\Property(
                    property: 'mitigation_percent',
                    type: 'integer',
                    description: 'Mitigation percentage (0-100)',
                    example: 50,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Control updated successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Control updated successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error updating control',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to update control'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiUpdateControl {}

#[OA\Post(
    path: '/governance/documents/datatable',
    summary: 'Server-side DataTables feed for the Document Program report',
    description: 'Returns Document Program rows in DataTables server-side format. Gated on the governance permission (SR-1721).',
    operationId: 'governanceDocumentsDatatable',
    tags: ['governance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: 'Standard DataTables server-side request parameters (draw, start, length, order, columns, search).',
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 10),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: DataTables server-side response.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 42),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 42),
                    new OA\Property(property: 'data', type: 'array', items: new OA\Items(type: 'object')),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiGovernanceDocumentsDatatable {}

#[OA\Get(
    path: '/governance/applicability/reasons',
    summary: 'List the configurable control-applicability reasons',
    description: "Returns the customer-extendable reason picklist behind the Statement of Applicability. `applies_to` scopes a reason to the state it is offered for -- 'Performed by a third party' is an INHERITED reason, not an exclusion, because a cloud-hosted organisation does not exclude the controls its provider performs. An unrecognised applies_to value returns the full list rather than an error.",
    operationId: 'governanceApplicabilityReasons',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'applies_to',
            in: 'query',
            description: 'Scope the list to one state.',
            required: false,
            schema: new OA\Schema(type: 'string', enum: ['not_applicable', 'inherited']),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'The applicability reason list',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'reasons',
                                type: 'array',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(property: 'value', type: 'integer'),
                                        new OA\Property(property: 'name', type: 'string'),
                                        new OA\Property(
                                            property: 'applies_to',
                                            type: 'string',
                                            enum: ['not_applicable', 'inherited'],
                                        ),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiGovernanceApplicabilityReasons {}

#[OA\Get(
    path: '/governance/applicability',
    summary: 'Read the stored control-applicability decisions for a framework',
    description: "Applicable is the DEFAULT and is never stored, so this returns DEVIATIONS ONLY -- a control with no entry in `decisions` is applicable. The payload echoes `default_state` so a client resolves an absent control the same way the server does. Omit control_ids to read every decision in the framework; that is cheap because only deviations are stored. Decisions whose control is no longer mapped into the framework are included: a decision goes dormant rather than being deleted, since an auditor may still ask about last year's exclusion. `narrative` and `provider` are plain text returned raw and must be rendered as text, never inserted as HTML.",
    operationId: 'governanceApplicabilityGet',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework',
            in: 'query',
            description: 'Framework id the decisions are scoped to.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
        new OA\Parameter(
            name: 'control_ids',
            in: 'query',
            description: 'Comma-separated control ids to scope the read to, e.g. the page currently on screen. Omit for the whole framework.',
            required: false,
            schema: new OA\Schema(type: 'string'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: "The framework's applicability deviations",
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(property: 'framework', type: 'integer'),
                            new OA\Property(
                                property: 'default_state',
                                type: 'string',
                                example: 'applicable',
                                description: 'The state of every control NOT listed in decisions.',
                            ),
                            new OA\Property(
                                property: 'decisions',
                                type: 'array',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(property: 'id', type: 'integer'),
                                        new OA\Property(property: 'framework', type: 'integer'),
                                        new OA\Property(property: 'control_id', type: 'integer'),
                                        new OA\Property(
                                            property: 'state',
                                            type: 'string',
                                            enum: ['applicable', 'not_applicable', 'inherited'],
                                            description: "'applicable' appears only for a control that stored its OWN justification; a control with no row at all is applicable too, and is absent from this list.",
                                        ),
                                        new OA\Property(
                                            property: 'reason_ids',
                                            type: 'array',
                                            items: new OA\Items(type: 'integer'),
                                            description: 'The taxonomy reasons attached to this decision. Multi-select; empty when none.',
                                        ),
                                        new OA\Property(
                                            property: 'reason_names',
                                            type: 'array',
                                            items: new OA\Items(type: 'string'),
                                            description: 'The names of reason_ids, in the same order.',
                                        ),
                                        new OA\Property(
                                            property: 'narrative',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Plain text, returned raw. Render as text, never as HTML. NULL means no narrative was ever given -- deliberately distinct from an empty string.',
                                        ),
                                        new OA\Property(
                                            property: 'provider',
                                            type: 'string',
                                            description: 'Plain text, returned raw. Empty unless state is inherited.',
                                        ),
                                        new OA\Property(property: 'decided_by', type: 'integer'),
                                        new OA\Property(property: 'decided_by_name', type: 'string'),
                                        new OA\Property(property: 'decided_at', type: 'string', format: 'date-time'),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: A framework id is required, or the selection is too large.',
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiGovernanceApplicabilityGet {}

#[OA\Post(
    path: '/governance/applicability',
    summary: 'Set or clear control applicability across a selection',
    description: "Bulk-set is the primary interaction, not a convenience -- nobody decides 1,535 SCF controls one row at a time. state 'not_applicable' requires at least one reason_id AND a narrative; 'inherited' requires a provider AND a narrative; 'applicable' requires neither -- it may carry its own reasons and/or narrative, and with NEITHER it CLEARS the row back to the framework default. ABSENT IS NOT EMPTY: a field the body omits (or sends as null) PRESERVES what is stored, while an explicit empty array or empty string CLEARS it -- so resetting a control to the framework default is {state:'applicable', narrative:'', reason_ids:[]}, and a bare {state:'applicable'} leaves a stored justification alone. A reason may only be used for the state its applies_to names. The write is all-or-nothing: every argument and every framework/control id is validated before anything is written, so a partly-invalid selection writes nothing. The selection is named EITHER as control_ids OR as all_filtered+filters -- never both -- because the control table pages, so a client holding one page cannot enumerate the whole filtered set it just asked to act on. Requires the modify_frameworks permission (spec D10) -- scoping a control out of a framework is a framework-scoping decision.",
    operationId: 'governanceApplicabilitySet',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['framework', 'state'],
            properties: [
                new OA\Property(
                    property: 'framework',
                    type: 'integer',
                    description: 'Framework the decision is scoped to. The same control excluded from ISO 27001 is not thereby excluded from PCI DSS.',
                ),
                new OA\Property(
                    property: 'control_ids',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'Controls in the selection. Duplicates collapse. At most 5000. Required unless all_filtered is true; sending both is a 400.',
                ),
                new OA\Property(
                    property: 'all_filtered',
                    type: 'boolean',
                    description: "Act on every control the `filters` below match, instead of on a list of ids. Resolved server-side through the SAME pipeline GET /governance/controls/table uses, so the set written is exactly the set that endpoint's `filtered` count reported. Still capped at 5000 resolved controls.",
                ),
                new OA\Property(
                    property: 'filters',
                    type: 'object',
                    description: 'Only read when all_filtered is true. The same query-parameter map GET /governance/controls/table takes (family, owner, class, phase, priority, type, status, maturity, applicability, text) as comma-separated strings. Any `framework` key here is OVERWRITTEN with the framework above, so ids can never be resolved out of one framework and recorded against another.',
                ),
                new OA\Property(property: 'state', type: 'string', enum: ['applicable', 'not_applicable', 'inherited']),
                new OA\Property(
                    property: 'reason_ids',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    nullable: true,
                    description: 'Taxonomy reasons, MULTI-select. At least one is required for not_applicable; optional for inherited and applicable. Every id must be a reason whose applies_to matches state -- a mismatched one is refused, not dropped. Omit (or send null) to leave the stored reasons alone; send [] to remove them all. A scalar is a 400.',
                ),
                new OA\Property(
                    property: 'narrative',
                    type: 'string',
                    nullable: true,
                    description: "Required for both deviations, optional for applicable. Plain text, max 65535 bytes. Omit (or send null) to leave the stored narrative alone; send '' to remove it.",
                ),
                new OA\Property(
                    property: 'provider',
                    type: 'string',
                    nullable: true,
                    description: "Required for inherited; forced empty otherwise. Max 200 bytes. Omit (or send null) to leave the stored provider alone; send '' to remove it.",
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'The decision was recorded (or cleared)',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(property: 'framework', type: 'integer'),
                            new OA\Property(property: 'state', type: 'string'),
                            new OA\Property(
                                property: 'selected',
                                type: 'integer',
                                description: 'How many controls the decision was applied to. For an all_filtered request this is the RESOLVED count, not the size of anything the client sent.',
                            ),
                            new OA\Property(
                                property: 'updated',
                                type: 'integer',
                                description: 'Controls whose decision was written, plus rows removed. Equals `selected` for a deviation; for a reset it counts only the controls that actually held a decision. One call can do both, because the reset decision is made per control.',
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: the request or the deviation is not well formed (missing narrative, missing reason or provider, unknown framework or control, reason offered for a different state, both control_ids and all_filtered named, or an all_filtered selection that matches nothing).',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [new OA\Property(property: 'error', type: 'string', example: 'invalid_request')],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiGovernanceApplicabilitySet {}

#[OA\Post(
    path: '/governance/controls/bulk-delete',
    summary: 'Delete controls in bulk, by id list or by filter',
    description: "POST rather than DELETE because there is no addressable resource: the request names EITHER an explicit control_ids list OR all_filtered+filters, which the server resolves through the same pipeline GET /governance/controls/table uses -- so the set deleted is exactly the set that endpoint's `filtered` count reported. Naming both is a 400; they are two different populations and silently discarding one is the difference between deleting 25 controls and deleting 1,535. DELETING A CONTROL IS TWO OUTCOMES, NOT ONE: a control that carries any test history is retained in a deleted state (framework_controls.deleted = 1), a control with no tests is removed permanently along with its type / asset / asset-group mappings. Both counts are reported so a caller can state honestly what is about to happen. `confirm` IS THE INTERLOCK -- without it the endpoint resolves the set, reports the split, and writes NOTHING; only an explicit confirm:true deletes. The default is the safe direction on purpose, so a client that drops the flag previews instead of destroying. Deleting a control removes it from EVERY framework it is mapped to, so unlike POST /governance/applicability this endpoint does not require a framework. Requires BOTH the governance permission (which gates reading the controls a filtered selection resolves over) and delete_controls (which gates deleting a control at all).",
    operationId: 'governanceControlsBulkDelete',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(
                    property: 'control_ids',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'Controls to delete. Duplicates collapse. At most 2000. Required unless all_filtered is true; sending both is a 400.',
                ),
                new OA\Property(
                    property: 'all_filtered',
                    type: 'boolean',
                    description: 'Delete every control the `filters` below match, instead of a list of ids. Resolved server-side. Still capped at 2000 resolved controls, and a filter matching nothing is a 400 rather than a cheerful 0.',
                ),
                new OA\Property(
                    property: 'filters',
                    type: 'object',
                    description: 'Only read when all_filtered is true. The same query-parameter map GET /governance/controls/table takes (family, owner, class, phase, priority, type, status, maturity, applicability, text) as comma-separated strings.',
                ),
                new OA\Property(
                    property: 'framework',
                    type: 'integer',
                    nullable: true,
                    description: 'Optional. When a positive id is given it OVERWRITES any `framework` key in `filters`, so ids cannot be resolved out of a framework the caller did not scope. Omit it to resolve over the unscoped All-frameworks view -- deleting a control removes it from every framework anyway.',
                ),
                new OA\Property(
                    property: 'confirm',
                    type: 'boolean',
                    description: "Absent or false: PREVIEW. The set is resolved and the split reported; nothing is written, and the response's `deleted` is false. Only true performs the delete.",
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'The resolved set and its soft/hard split. Whether anything was written is reported by `deleted`.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(property: 'framework', type: 'integer', nullable: true),
                            new OA\Property(property: 'all_filtered', type: 'boolean'),
                            new OA\Property(
                                property: 'resolved',
                                type: 'integer',
                                description: 'Distinct control ids named, or resolved from the filter. Never the size of anything the client sent for an all_filtered request.',
                            ),
                            new OA\Property(
                                property: 'found',
                                type: 'integer',
                                description: 'Of those, the ones that name a control that actually exists. Equals soft_delete + hard_delete.',
                            ),
                            new OA\Property(
                                property: 'soft_delete',
                                type: 'integer',
                                description: 'Controls carrying test history. These are RETAINED in a deleted state rather than removed.',
                            ),
                            new OA\Property(
                                property: 'hard_delete',
                                type: 'integer',
                                description: 'Controls with no test history. These are removed PERMANENTLY.',
                            ),
                            new OA\Property(
                                property: 'missing',
                                type: 'integer',
                                description: 'Ids naming no control -- a stale client selection, or one another session already removed. Neither retained nor removed, because there is nothing there.',
                            ),
                            new OA\Property(
                                property: 'deleted',
                                type: 'boolean',
                                description: 'false for a preview, true when the delete was performed.',
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: both control_ids and all_filtered named, an empty control_ids list, more than 2000 controls named or resolved, or an all_filtered selection that matches nothing.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [new OA\Property(property: 'error', type: 'string', example: 'invalid_request')],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiGovernanceControlsBulkDelete {}

#[OA\Get(
    path: '/governance/soa',
    summary: 'The Statement of Applicability for one framework',
    description: "The document ISO/IEC 27001:2022 clause 6.1.3(d) asks for: every control in the framework, whether it is applicable, the justification for its inclusion or exclusion, and its implementation status. PER-FRAMEWORK BY DEFINITION -- applicability is stored per (framework, control_id), the same control excluded from ISO 27001 is not thereby excluded from PCI DSS, and there is no Applicable-in-N-of-M roll-up across frameworks; a request naming no framework is a 400 rather than an invented cross-framework answer. APPLICABLE IS THE DEFAULT AND IS NEVER STORED, so this iterates the framework's CONTROLS and resolves each one's state -- it does not iterate the applicability table, which holds deviations only and would yield a document listing nothing but the exclusions. THE POPULATION IS THE CONTROLS PAGE'S: rows resolve through the same pipeline GET /governance/controls/table uses, so the count on this cover equals the count on that grid for the same framework, and the cover's totals are counted from the printed rows rather than by a separate aggregate. `implemented` is DERIVED on every read from the control's LIVE (non-retired) tests and their latest results -- never stored, and never from maturity, which measures ambition rather than effectiveness. Six values: `yes` (every live test passed), `partial` (mixed), `no` (nothing passed and at least one failed), `no_test_defined` (a governance gap -- no live test exists), `never_run` (an operational gap -- tests exist, none has produced a verdict), and `not_applicable`. A separate boolean `implemented_overdue` COMPOSES with `yes`/`partial`/`no` when a contributing test is past its own scheduled date; it is not a seventh value. The rule is deliberately ASYMMETRIC: unresolved evidence blocks `yes` but does not rescue a control from `no`, because missing evidence must never improve the reported position. Soft-deleted controls are absent, as they are from the controls page. Text fields -- control names, narratives, justifications, provider and evidence -- are PLAIN TEXT returned RAW and must be rendered as text, never inserted as HTML. TWO FIELDS IN THIS RESPONSE ARE STORED AS RICH TEXT, and they are delivered differently from each other, deliberately. The cover's `scope_statement` is returned AS purified HTML and must be rendered raw. `evidence_items[].required_evidence` is a rich-text column too, but is PROJECTED TO PLAIN TEXT before it leaves the server (soa_plain_text_or_null(), includes/soa.php): what you receive is newline-separated lines, with each list item already prefixed `&#8226; `, and never markup -- so it is rendered as text like every other field here, and a client that inserted it as HTML would be inserting escaped entities. The projection is not cosmetic: this value lands in a dense table cell that three sinks render, one of them a spreadsheet, and the PDF writer joins the cell with `&lt;br&gt;` precisely to avoid an element per line. On the two cover statements, null means the field was never set and '' means it was deliberately cleared; the report prompts on either, but the distinction is preserved rather than coerced. Requires the governance permission. The REPORT IS CORE and is not Extra-gated; only its export is, which is what `can_export` advertises.",
    operationId: 'governanceSoa',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework',
            in: 'query',
            description: 'Framework the statement is made about. Required, and must be an ACTIVE framework.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'The Statement of Applicability',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'cover',
                                type: 'object',
                                description: "The document's cover block. Its counts are derived from the rows below, so they cannot contradict the table they introduce.",
                                properties: [
                                    new OA\Property(property: 'framework', type: 'integer'),
                                    new OA\Property(
                                        property: 'framework_name',
                                        type: 'string',
                                        description: 'Plain text, returned raw. Decrypted where the Encrypted Database Extra is active.',
                                    ),
                                    new OA\Property(
                                        property: 'framework_status',
                                        type: 'integer',
                                        example: 1,
                                        description: 'Always 1 (active) on a successful response; an inactive framework is refused with a 409.',
                                    ),
                                    new OA\Property(
                                        property: 'scope_statement',
                                        type: 'string',
                                        nullable: true,
                                        description: "The scope the framework is certified against. RICH TEXT (HTML), purified on the way out as well as on write — render it raw. null = never set (the report prompts); '' = deliberately cleared, which also covers markup that renders as nothing.",
                                    ),
                                    new OA\Property(
                                        property: 'default_inclusion_justification',
                                        type: 'string',
                                        nullable: true,
                                        description: "Fills the Justification column for every plainly-applicable control. Plain text, returned raw. null = never set; '' = deliberately cleared.",
                                    ),
                                    new OA\Property(
                                        property: 'total',
                                        type: 'integer',
                                        description: "Controls in the framework. Equals the controls page's `filtered` count for the same framework with no filters applied.",
                                    ),
                                    new OA\Property(property: 'applicable', type: 'integer'),
                                    new OA\Property(property: 'not_applicable', type: 'integer'),
                                    new OA\Property(property: 'inherited', type: 'integer'),
                                    new OA\Property(
                                        property: 'excluded',
                                        type: 'integer',
                                        description: "not_applicable + inherited -- both stored deviations, matching what the controls page's Excluded insight tile counts. The two are also reported separately, because folding them together would make the statement factually wrong: an organization does not EXCLUDE the controls a provider performs for it.",
                                    ),
                                    new OA\Property(
                                        property: 'generated_at',
                                        type: 'string',
                                        format: 'date-time',
                                        description: 'When this response was assembled. The document is built on every read, so this is the only honest timestamp.',
                                    ),
                                ],
                            ),
                            new OA\Property(
                                property: 'rows',
                                type: 'array',
                                description: 'One row per control, in natural control-number order.',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(property: 'control_id', type: 'integer'),
                                        new OA\Property(
                                            property: 'ref',
                                            type: 'string',
                                            description: 'The control number, e.g. A.5.1. Plain text, returned raw.',
                                        ),
                                        new OA\Property(
                                            property: 'name',
                                            type: 'string',
                                            description: "The control's short name. Plain text, returned raw.",
                                        ),
                                        new OA\Property(
                                            property: 'applicable',
                                            type: 'string',
                                            enum: ['applicable', 'not_applicable', 'inherited'],
                                            description: '`applicable` is the DEFAULT and is never stored -- a control with no decision row resolves to it.',
                                        ),
                                        new OA\Property(
                                            property: 'justification',
                                            type: 'string',
                                            description: "Never blank by construction: a deviation carries its own mandatory narrative; an applicable control cites its linked risks if it has any; otherwise the framework's default inclusion justification fills the cell. Plain text, returned raw.",
                                        ),
                                        new OA\Property(
                                            property: 'implemented',
                                            type: 'string',
                                            enum: ['yes', 'partial', 'no', 'not_applicable'],
                                            description: 'DERIVED on every read, never stored. A failed test yields `no` and outranks maturity; an UNTESTED control does not, because absence of evidence is not evidence of absence. Below a set target yields `partial`; a desired maturity of 0 means no target. `not_applicable` only for an excluded control -- an inherited control is applicable and does have an implementation status.',
                                        ),
                                        new OA\Property(
                                            property: 'evidence',
                                            type: 'string',
                                            description: "Governing documents mapped to the control, comma-joined. CONFIRMED mappings only (selected=1) -- unreviewed TF-IDF and AI candidate matches are excluded, because presenting a machine's guesses to an auditor as the organization's governing documentation would be a misstatement. Plain text, returned raw.",
                                        ),
                                        new OA\Property(
                                            property: 'reason',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Name of the configurable reason on the decision. null for an applicable control.',
                                        ),
                                        new OA\Property(
                                            property: 'provider',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Who performs an inherited control. Plain text, returned raw.',
                                        ),
                                        new OA\Property(
                                            property: 'decided_by',
                                            type: 'string',
                                            nullable: true,
                                            description: 'Username the deviation is attributed to. A justification an auditor cannot attribute is an assertion, not a record.',
                                        ),
                                        new OA\Property(
                                            property: 'decided_at',
                                            type: 'string',
                                            nullable: true,
                                            format: 'date-time',
                                        ),
                                    ],
                                ),
                            ),
                            new OA\Property(
                                property: 'can_export',
                                type: 'boolean',
                                description: 'Whether the Import/Export Extra is active. ADVISORY -- it exists so the page renders the export button only where it would work. The export endpoint enforces the same check independently, so ignoring this flag gains a caller nothing.',
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: A framework is required. A Statement of Applicability is a per-framework document.',
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: That framework does not exist.'),
        new OA\Response(
            response: 409,
            description: 'CONFLICT: That framework is inactive. A Statement of Applicability states the scope an organization currently operates under, and a deactivated framework has been withdrawn from the program.',
        ),
    ],
)]
class OpenApiGovernanceSoa {}

#[OA\Get(
    path: '/governance/soa/export',
    summary: 'Download the Statement of Applicability as a file',
    description: "The SAME document GET /governance/soa returns, rendered as a file: an XLSX spreadsheet or a PDF. Streams a binary body -- on success the response is the file, not JSON. THE POPULATION AND THE COUNTS ARE THE ENDPOINT ABOVE'S, from the same single build: the export does not run a query of its own, so the spreadsheet, the PDF and the document on screen cannot disagree about how many controls a framework has or what any of them says. Columns are the document's, in its order: Reference, Control Name, Applicability, Justification, Implementation Status, Evidence -- six, always, followed by Appendix A (every control's justification in full) and Appendix R (the remediation plan behind every failing control). The Risk Register, Control Owner and Review Cadence columns a `detailed` variant used to append are gone; the risk traceability survives inside Appendix R's entries, which name the risk id, the planning date, the mitigation owner and the percentage. With the decision's attribution (decided by, reason, provider) folded into the Justification cell exactly as the screen folds it, so an auditor holding the download and the page can reconcile them line for line. REQUIRES THE IMPORT/EXPORT EXTRA, enforced here and not only by the page declining to render the button: a caller who knows the URL gets a 403, not a document. The report itself is Core and is not Extra-gated. Requires the governance permission -- an export is a READ of the document, so it does not additionally require modify_frameworks.",
    operationId: 'governanceSoaExport',
    tags: ['governance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'framework',
            in: 'query',
            description: 'Framework the statement is made about. Required, and must be an ACTIVE framework.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
        new OA\Parameter(
            name: 'format',
            in: 'query',
            description: 'Rendering to produce. An unrecognized value is a 400 rather than a silent fallback to xlsx.',
            required: false,
            schema: new OA\Schema(type: 'string', enum: ['xlsx', 'pdf'], default: 'xlsx'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'The Statement of Applicability as a file. Content-Disposition is an attachment whose filename is built from the framework name; the name is sanitized before it reaches the header.',
            content: [
                new OA\MediaType(
                    mediaType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    schema: new OA\Schema(type: 'string', format: 'binary'),
                ),
                new OA\MediaType(mediaType: 'application/pdf', schema: new OA\Schema(type: 'string', format: 'binary')),
            ],
        ),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: no framework was named (a Statement of Applicability is a per-framework document), or `format` is not one of xlsx, pdf. The rejected value is never echoed back.',
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: the user lacks the governance permission, or the Import/Export Extra -- which this export requires -- is not active.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: That framework does not exist.'),
        new OA\Response(
            response: 409,
            description: 'CONFLICT: That framework is inactive. A Statement of Applicability states the scope an organization currently operates under, and a deactivated framework has been withdrawn from the program.',
        ),
        new OA\Response(
            response: 500,
            description: 'INTERNAL SERVER ERROR: the Import/Export Extra is active but predates this export and does not provide it.',
        ),
    ],
)]
class OpenApiGovernanceSoaExport {}

?>
