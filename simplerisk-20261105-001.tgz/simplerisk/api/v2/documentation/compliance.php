<?php
// @phan-file-suppress PhanDeprecatedClass -- swagger-php 7 deprecates the OpenApi\Attributes classes (removed in 8.0); move these to OpenApi\Spec before upgrading to swagger-php 8

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// COMPLIANCE (CRUD)

use OpenApi\Attributes as OA;

#[OA\Get(
    path: '/compliance/tests/{id}',
    summary: 'Get a test by ID',
    description: 'Returns the test, including controls (array of mapped control IDs, via the test_control_map junction -- a test maps to N controls) and control_names (control ID => short_name map for every mapped control).',
    operationId: 'getTestById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Test retrieved successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'Test retrieved successfully.'),
                    new OA\Property(property: 'data', type: 'object', additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have compliance permission or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiGetTestById {}

#[OA\Post(
    path: '/compliance/tests',
    summary: 'Create a new test',
    description: "Create a compliance test. Accepts the legacy interval fields (test_frequency, last_date, next_date) as well as the calendar-cadence schedule fields (schedule_type, cadence_unit, cadence_interval, cadence_anchor_date, schedule_exceptions) -- see updateTestSchedule (POST /compliance/update_test) for the same fields on an existing test. schedule_type may be omitted entirely (no cadence validation is applied and the legacy interval fields drive scheduling, same as before these fields existed); when supplied it must be one of manual/interval/calendar, and calendar requires a complete cadence with an anchor date that is today or later. A test maps to one or more controls via controls[]; a lone framework_control_id (no controls[] submitted) is accepted as a back-compat single-element set. At least one of controls[]/framework_control_id is required. The response's data.controls/data.control_names reflect the resolved set (framework_control_id is kept in sync as min(controls)).",
    operationId: 'createTest',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    required: ['name'],
                    properties: [
                        new OA\Property(property: 'name', type: 'string', description: 'The name of the test.'),
                        new OA\Property(
                            property: 'framework_control_id',
                            type: 'integer',
                            description: 'Back-compat: the ID of a single associated framework control. Accepted when controls[] is omitted (normalized to a one-element controls set); ignored if controls[] is also submitted.',
                        ),
                        new OA\Property(
                            property: 'controls',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Control IDs this test covers (1+). Replaces the single framework_control_id; a lone framework_control_id is still accepted as a single-element set when controls[] is omitted. At least one of controls[]/framework_control_id is required.',
                        ),
                        new OA\Property(
                            property: 'tester',
                            type: 'integer',
                            description: 'User ID of the tester.',
                            example: 0,
                        ),
                        new OA\Property(
                            property: 'test_frequency',
                            type: 'integer',
                            description: 'Legacy interval test frequency in days.',
                            example: 0,
                        ),
                        new OA\Property(property: 'objective', type: 'string', description: 'The test objective.'),
                        new OA\Property(
                            property: 'test_steps',
                            type: 'string',
                            description: 'Steps to perform the test.',
                        ),
                        new OA\Property(
                            property: 'approximate_time',
                            type: 'integer',
                            description: 'Approximate time to complete in minutes.',
                            example: 0,
                        ),
                        new OA\Property(
                            property: 'expected_results',
                            type: 'string',
                            description: 'Expected results of the test.',
                        ),
                        new OA\Property(
                            property: 'additional_stakeholders',
                            type: 'string',
                            description: 'Comma-separated user IDs of additional stakeholders.',
                        ),
                        new OA\Property(
                            property: 'teams',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Team IDs assigned to the test.',
                        ),
                        new OA\Property(
                            property: 'tags',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            description: 'Tags assigned to the test.',
                        ),
                        new OA\Property(
                            property: 'last_date',
                            type: 'string',
                            format: 'date',
                            description: "Last test date. Accepted as ISO YYYY-MM-DD or in this instance's configured display date format (Admin > Settings > Default Date Format, e.g. MM/DD/YYYY); stored as YYYY-MM-DD either way. A value that is neither is rejected with 400 rather than stored as a zero date.",
                        ),
                        new OA\Property(
                            property: 'next_date',
                            type: 'string',
                            format: 'date',
                            description: "Next scheduled test date; ignored (computed by the cadence engine) when schedule_type is calendar. Accepted as ISO YYYY-MM-DD or in this instance's configured display date format; a value that is neither is rejected with 400.",
                        ),
                        new OA\Property(
                            property: 'audit_initiation_offset',
                            type: 'integer',
                            description: 'Days before next_date to initiate the audit. Optional for Interval and Calendar schedule_type; ignored (forced to null) when schedule_type is manual.',
                        ),
                        new OA\Property(
                            property: 'schedule_type',
                            type: 'string',
                            enum: ['manual', 'interval', 'calendar'],
                            description: 'The scheduling mode for this test. Omit to skip cadence validation entirely (legacy interval-only behavior).',
                        ),
                        new OA\Property(
                            property: 'cadence_unit',
                            type: 'string',
                            enum: ['day', 'week', 'month', 'year'],
                            description: 'Calendar cadence recurrence unit. Required when schedule_type is calendar.',
                        ),
                        new OA\Property(
                            property: 'cadence_interval',
                            type: 'integer',
                            description: 'Calendar cadence recurrence interval. Required when schedule_type is calendar.',
                        ),
                        new OA\Property(
                            property: 'cadence_anchor_date',
                            type: 'string',
                            format: 'date',
                            description: "Calendar cadence anchor date, must be today or later. Accepts ISO (YYYY-MM-DD) or this instance's configured display format. Required when schedule_type is calendar.",
                        ),
                        new OA\Property(
                            property: 'schedule_exceptions',
                            type: 'array',
                            description: 'Per-occurrence overrides/skips for the calendar schedule. May be supplied as a JSON-encoded string or a native array.',
                            items: new OA\Items(
                                type: 'object',
                                required: ['occurrence_date'],
                                properties: [
                                    new OA\Property(
                                        property: 'occurrence_date',
                                        type: 'string',
                                        format: 'date',
                                        description: 'The natural (un-overridden) occurrence date this exception applies to.',
                                    ),
                                    new OA\Property(
                                        property: 'override_date',
                                        type: 'string',
                                        format: 'date',
                                        nullable: true,
                                        description: 'Replacement date for this occurrence, or null to keep the natural date.',
                                    ),
                                    new OA\Property(
                                        property: 'skipped',
                                        type: 'boolean',
                                        description: 'True to skip this occurrence entirely.',
                                    ),
                                ],
                            ),
                        ),
                        new OA\Property(
                            property: 'test_method',
                            type: 'string',
                            enum: ['inquiry', 'observation', 'inspection', 'reperformance'],
                            nullable: true,
                            description: 'How the test evidence is gathered.',
                        ),
                        new OA\Property(
                            property: 'sample',
                            type: 'string',
                            description: 'The sample selection/methodology used for the test.',
                        ),
                        new OA\Property(
                            property: 'required_evidence',
                            type: 'string',
                            description: 'The evidence required to satisfy the test.',
                        ),
                        new OA\Property(
                            property: 'approvers',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'User IDs authorized to approve results of this test. Segregation-of-duties: the tester may not also be listed as an approver.',
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 201,
            description: 'Test created successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 201),
                    new OA\Property(property: 'message', type: 'string', example: 'Test created successfully.'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [new OA\Property(property: 'id', type: 'integer', example: 5)],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: Validation failed (missing name, no controls[]/framework_control_id resolving to at least one control, invalid schedule_type, incomplete calendar cadence, a past anchor date, an invalid test_method, an unparseable last_date/next_date/cadence_anchor_date, or the tester listed among approvers).',
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have permission to define tests.'),
    ],
)]
class OpenApiCreateTest {}

#[OA\Patch(
    path: '/compliance/tests/{id}',
    summary: 'Update a test by ID',
    operationId: 'updateTestById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test to update.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    requestBody: new OA\RequestBody(
        required: false,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    properties: [
                        new OA\Property(property: 'name', type: 'string'),
                        new OA\Property(
                            property: 'framework_control_id',
                            type: 'integer',
                            description: "Ignored on update: controls[] is the only way to change a test's control mapping on a PATCH. Omit controls[] to leave the currently-persisted control set untouched; a lone framework_control_id here does NOT change it (this prevents a GET->PATCH round-trip, which returns the scalar but not controls[], from silently collapsing a multi-control test to its min control).",
                        ),
                        new OA\Property(
                            property: 'controls',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Control IDs this test covers (1+). Omit entirely to leave the currently-persisted controls untouched (a partial PATCH never silently clears them); supply to replace the full set. framework_control_id is kept in sync as min(controls).',
                        ),
                        new OA\Property(property: 'tester', type: 'integer'),
                        new OA\Property(property: 'test_frequency', type: 'integer'),
                        new OA\Property(property: 'objective', type: 'string'),
                        new OA\Property(property: 'test_steps', type: 'string'),
                        new OA\Property(property: 'approximate_time', type: 'integer'),
                        new OA\Property(property: 'expected_results', type: 'string'),
                        new OA\Property(property: 'additional_stakeholders', type: 'string'),
                        new OA\Property(
                            property: 'last_date',
                            type: 'string',
                            format: 'date',
                            description: "Accepted as ISO YYYY-MM-DD or in this instance's configured display date format (e.g. MM/DD/YYYY); stored as YYYY-MM-DD either way. Omit to leave the existing value untouched; submit empty to clear it. A value that is neither format is rejected with 400 rather than stored as a zero date.",
                        ),
                        new OA\Property(
                            property: 'next_date',
                            type: 'string',
                            format: 'date',
                            description: "Accepted as ISO YYYY-MM-DD or in this instance's configured display date format; stored as YYYY-MM-DD either way. Omit to leave the existing value untouched (or, for a calendar schedule, to let the cadence engine recompute it); submit empty to clear it. A value that is neither format is rejected with 400.",
                        ),
                        new OA\Property(property: 'audit_initiation_offset', type: 'integer'),
                        new OA\Property(
                            property: 'test_method',
                            type: 'string',
                            enum: ['inquiry', 'observation', 'inspection', 'reperformance'],
                            nullable: true,
                            description: 'How the test evidence is gathered. Omit to leave the existing value untouched.',
                        ),
                        new OA\Property(
                            property: 'sample',
                            type: 'string',
                            description: 'The sample selection/methodology used for the test. Omit to leave the existing value untouched.',
                        ),
                        new OA\Property(
                            property: 'required_evidence',
                            type: 'string',
                            description: 'The evidence required to satisfy the test. Omit to leave the existing value untouched.',
                        ),
                        new OA\Property(
                            property: 'approvers',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'User IDs authorized to approve results of this test. Omit entirely to leave the currently-persisted approvers untouched (a partial PATCH never silently clears them); supply (including []) to replace the full list. Segregation-of-duties: the effective tester (submitted, or currently-persisted if tester is omitted) may not also be listed as an approver.',
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(response: 200, description: 'Test updated successfully.'),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: Invalid test_method, an unparseable last_date/next_date, a freshly-submitted controls[] resolving to zero controls, or the effective tester is listed among approvers.',
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to edit tests or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiUpdateTestById {}

#[OA\Delete(
    path: '/compliance/tests/{id}',
    summary: 'Delete a test by ID',
    operationId: 'deleteTestById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test to delete.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Test deleted successfully.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to delete tests or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiDeleteTestById {}

#[OA\Post(
    path: '/compliance/tests/{id}/retire',
    summary: 'Retire a test (soft-hide without deleting it or its audit history)',
    operationId: 'retireTestById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test to retire.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Test retired successfully.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have edit_tests or delete_tests permission, or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiRetireTestById {}

#[OA\Post(
    path: '/compliance/tests/{id}/restore',
    summary: 'Restore a retired test to the active list',
    operationId: 'restoreTestById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test to restore.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Test restored successfully.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have edit_tests or delete_tests permission, or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiRestoreTestById {}

#[OA\Get(
    path: '/compliance/tests/{id}/audits',
    summary: 'Get the audit history (every run, newest first) for one test',
    operationId: 'getTestAuditHistoryById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test whose audit history to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Test audit history retrieved successfully.',
            content: new OA\JsonContent(
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(
                        property: 'status_message',
                        type: 'string',
                        example: 'Test audit history retrieved successfully.',
                    ),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(property: 'test_id', type: 'integer', example: 34),
                            new OA\Property(
                                property: 'test_name',
                                type: 'string',
                                example: 'Quarterly backup restore test',
                            ),
                            new OA\Property(
                                property: 'audits',
                                type: 'array',
                                description: 'Every audit for the test, newest first, including any currently-open run.',
                                items: new OA\Items(
                                    properties: [
                                        new OA\Property(property: 'audit_id', type: 'integer', example: 812),
                                        new OA\Property(
                                            property: 'date',
                                            type: 'string',
                                            description: "The date the run happened, in the instance's date format.",
                                            example: '06/30/2026',
                                        ),
                                        new OA\Property(
                                            property: 'result',
                                            type: 'string',
                                            nullable: true,
                                            description: 'The recorded result, or null when the run has none yet.',
                                            example: 'Pass',
                                        ),
                                        new OA\Property(
                                            property: 'result_family',
                                            type: 'string',
                                            enum: ['success', 'danger', 'warning', 'neutral'],
                                            example: 'success',
                                        ),
                                        new OA\Property(property: 'tester_name', type: 'string', example: 'Josh Sokol'),
                                        new OA\Property(property: 'status_name', type: 'string', example: 'Closed'),
                                        new OA\Property(
                                            property: 'approval_state',
                                            type: 'string',
                                            enum: ['none', 'pending', 'approved', 'rejected'],
                                            example: 'approved',
                                        ),
                                        new OA\Property(
                                            property: 'link',
                                            type: 'string',
                                            description: 'Deep link to the audit: the read-only view for a truly-closed audit, the editor otherwise.',
                                            example: '../compliance/view_test.php?id=812',
                                        ),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(response: 400, description: 'BAD REQUEST: You need to specify an id parameter.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have compliance permission, or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiGetTestAuditHistoryById {}

#[OA\Delete(
    path: '/compliance/tests/{id}/controls/{control_id}',
    summary: 'Remove a test from one control, without deleting the test',
    description: "Deletes a single (test, control) mapping. A test shared across several controls stays on the others. Removing the test's last control is refused with a 409 -- a test must belong to at least one control, so retire or delete is the correct action there.",
    operationId: 'detachTestFromControl',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the test to remove from the control.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
        new OA\Parameter(
            name: 'control_id',
            in: 'path',
            description: 'The ID of the control to remove the test from.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Test removed from the control successfully.',
            content: new OA\JsonContent(
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(
                        property: 'status_message',
                        type: 'string',
                        example: 'Test removed from the control successfully.',
                    ),
                ],
            ),
        ),
        new OA\Response(response: 400, description: 'BAD REQUEST: You need to specify an id parameter.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have edit_tests permission, or does not have access to this test.',
        ),
        new OA\Response(
            response: 404,
            description: 'NOT FOUND: No such test, or the test is not mapped to that control.',
        ),
        new OA\Response(response: 409, description: 'CONFLICT: A test must belong to at least one control.'),
    ],
)]
class OpenApiDetachTestFromControl {}

#[OA\Get(
    path: '/compliance/audits/{id}',
    summary: 'Get an audit by ID',
    operationId: 'getAuditById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the audit to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Audit retrieved successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'Audit retrieved successfully.'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        additionalProperties: true,
                        properties: [
                            new OA\Property(
                                property: 'audit',
                                type: 'object',
                                additionalProperties: true,
                                description: 'The audit record.',
                                properties: [
                                    new OA\Property(
                                        property: 'controls',
                                        type: 'array',
                                        items: new OA\Items(type: 'integer'),
                                        description: "IDs of every control this audit belongs to. A common test can map to multiple controls; the set is frozen from the snapshot taken when the audit was initiated, so it does not change even if the source test's controls[] is edited afterward. audits.framework_control_id (kept for back-compat) is the minimum id in this set.",
                                    ),
                                    new OA\Property(
                                        property: 'control_names',
                                        type: 'object',
                                        description: 'Map of control ID to its short_name, for each control in controls.',
                                        additionalProperties: new OA\AdditionalProperties(type: 'string'),
                                    ),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have compliance permission or does not have access to this audit.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find an audit with the specified id.'),
    ],
)]
class OpenApiGetAuditById {}

#[OA\Post(
    path: '/compliance/audits',
    summary: 'Initiate a new audit from a test',
    operationId: 'createAudit',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    required: ['test_id'],
                    properties: [
                        new OA\Property(
                            property: 'test_id',
                            type: 'integer',
                            description: 'The ID of the test to initiate an audit for.',
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 201,
            description: 'Audit initiated successfully.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 201),
                    new OA\Property(property: 'message', type: 'string', example: 'Audit initiated successfully.'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'audit_id',
                                type: 'integer',
                                nullable: true,
                                description: 'The id of the newly initiated audit when a single test is initiated; null for framework/control initiation.',
                                example: 42,
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to initiate audits or does not have access to this test.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a test with the specified id.'),
    ],
)]
class OpenApiCreateAudit {}

#[OA\Patch(
    path: '/compliance/audits/{id}',
    summary: 'Update an audit result by ID',
    operationId: 'updateAuditById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the audit to update.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    requestBody: new OA\RequestBody(
        required: false,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    properties: [
                        new OA\Property(property: 'status', type: 'integer', description: 'The audit status ID.'),
                        new OA\Property(
                            property: 'test_result',
                            type: 'string',
                            description: 'The test result (e.g. Pass, Fail).',
                        ),
                        new OA\Property(property: 'tester', type: 'integer', description: 'User ID of the tester.'),
                        new OA\Property(
                            property: 'test_date',
                            type: 'string',
                            format: 'date',
                            description: "Date the test was performed. Accepted as ISO YYYY-MM-DD or in this instance's configured display date format (Admin > Settings > Default Date Format, e.g. MM/DD/YYYY); stored as YYYY-MM-DD either way. Omit to leave the stored value untouched. A value that is neither format is rejected with 400 rather than stored as a zero date.",
                        ),
                        new OA\Property(property: 'summary', type: 'string', description: 'Summary of findings.'),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(response: 200, description: 'Audit updated successfully.'),
        new OA\Response(response: 400, description: 'BAD REQUEST: Invalid test_result, or an unparseable test_date.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to modify audits or does not have access to this audit.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find an audit with the specified id.'),
    ],
)]
class OpenApiUpdateAuditById {}

#[OA\Post(
    path: '/compliance/audits/{id}/approve',
    summary: 'Approve a closed-but-pending audit (Phase 3b approval workflow)',
    description: "Approves an audit that is being held awaiting sign-off (approval_state='pending') because its parent test has one or more configured approvers. Requires the approve_tests permission, that the caller is listed as an approver of the audit's test, that the caller is not also the audit's tester (segregation of duties), and that the audit is currently pending approval.",
    operationId: 'approveAuditById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the audit to approve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Audit approved successfully.'),
        new OA\Response(response: 400, description: 'BAD REQUEST: No id parameter was specified.'),
        new OA\Response(
            response: 403,
            description: "FORBIDDEN: The user does not have approve_tests permission, does not have access to this audit, is not a configured approver of this audit's test, or is the audit's own tester.",
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find an audit with the specified id.'),
        new OA\Response(response: 409, description: 'CONFLICT: The audit is not currently awaiting approval.'),
    ],
)]
class OpenApiApproveAuditById {}

#[OA\Post(
    path: '/compliance/audits/{id}/reject',
    summary: 'Reject a closed-but-pending audit (Phase 3b approval workflow)',
    description: "Rejects an audit that is being held awaiting sign-off, reopening it (status reset to in-progress, approval_state='rejected') and notifying the tester with the required rejection comment. Same gates as approve: approve_tests permission, team access, configured approver, not the tester, and the audit must be currently pending approval.",
    operationId: 'rejectAuditById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the audit to reject.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    required: ['comment'],
                    properties: [
                        new OA\Property(
                            property: 'comment',
                            type: 'string',
                            description: "Required explanation of why the audit close is being rejected. Stored in the approval history and mirrored to the audit's comment thread.",
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(response: 200, description: 'Audit rejected successfully.'),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: No id parameter was specified, or the comment field was missing/empty.',
        ),
        new OA\Response(
            response: 403,
            description: "FORBIDDEN: The user does not have approve_tests permission, does not have access to this audit, is not a configured approver of this audit's test, or is the audit's own tester.",
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find an audit with the specified id.'),
        new OA\Response(response: 409, description: 'CONFLICT: The audit is not currently awaiting approval.'),
    ],
)]
class OpenApiRejectAuditById {}

#[OA\Delete(
    path: '/compliance/audits/{id}',
    summary: 'Delete an audit by ID',
    operationId: 'deleteAuditById',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'path',
            description: 'The ID of the audit to delete.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'Audit deleted successfully.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have permission to delete audits or does not have access to this audit.',
        ),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find an audit with the specified id.'),
    ],
)]
class OpenApiDeleteAuditById {}

// COMPLIANCE (LEGACY)

#[OA\Get(
    path: '/compliance/tests',
    summary: 'List audit tests in SimpleRisk',
    operationId: 'complianceTests',
    tags: ['compliance_crud'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the test you would like to retrieve details for. Will return all tests if no id is specified.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'SimpleRisk audit tests'),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find an audit test with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceTests {}

#[OA\Get(
    path: '/compliance/tests/associations',
    summary: 'List test associations in SimpleRisk',
    operationId: 'testssAssociations',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the test you would like to retrieve associations for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'SimpleRisk test associations. controls[].test_id is now consistently an integer (previously a string echoing the raw request id). A row whose join target was missing or whose display name resolved empty is silently dropped rather than returned with a null/blank name.',
        ),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a test with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiTestsAssociations {}

#[OA\Get(
    path: '/compliance/tests/tags',
    summary: 'List compliance test tags',
    operationId: 'complianceTestTagsGet',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the tag you would like to retrieve details for. Will return all tags if no id is specified.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'SimpleRisk compliance test tags'),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a tag with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceTestTagsGet {}

#[OA\Get(
    path: '/compliance/audits/tags',
    summary: 'List compliance audit tags',
    operationId: 'complianceAuditTagsGet',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            parameter: 'id',
            in: 'query',
            name: 'id',
            description: 'The id of the tag you would like to retrieve details for. Will return all tags if no id is specified.',
            required: false,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(response: 200, description: 'SimpleRisk compliance audit tags'),
        new OA\Response(response: 204, description: 'NO CONTENT: Unable to find a tag with the specified id.'),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceAuditTagsGet {}

#[OA\Post(
    path: '/compliance/tests_grid',
    summary: 'Get the Define Tests grid data feed (controls + nested tests)',
    description: 'Returns a page of framework controls (filtered by framework/family/search/coverage/schedule/tag/quick flags), each with its nested list of tests enriched with schedule summary, overdue status, and last audit result. Backs the Define Tests redesign grid.',
    operationId: 'complianceTestsGrid',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: false,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(
                    property: 'framework',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'Framework ids to filter controls by (a control matches if mapped to any of these).',
                ),
                new OA\Property(
                    property: 'family',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'Control family ids to filter by.',
                ),
                new OA\Property(
                    property: 'search',
                    type: 'string',
                    description: 'Free-text search across test name, control number/short name/long name, and mapped framework reference name/text.',
                ),
                new OA\Property(
                    property: 'coverage',
                    type: 'string',
                    enum: ['with', 'all', 'gaps'],
                    description: "'with' = only controls that have at least one active test; 'gaps' = only controls with zero active tests; 'all' (default) = no coverage filter.",
                ),
                new OA\Property(
                    property: 'schedule',
                    type: 'string',
                    enum: ['manual', 'interval', 'calendar'],
                    description: 'Filter tests to a single schedule_type.',
                ),
                new OA\Property(
                    property: 'tag',
                    type: 'string',
                    description: 'Filter tests to those carrying this tag.',
                ),
                new OA\Property(
                    property: 'quick',
                    type: 'object',
                    description: 'Quick-filter toggles.',
                    properties: [
                        new OA\Property(
                            property: 'mine',
                            type: 'boolean',
                            description: 'Only tests where the current user is the tester.',
                        ),
                        new OA\Property(
                            property: 'overdue',
                            type: 'boolean',
                            description: 'Only tests whose next_date has passed.',
                        ),
                        new OA\Property(
                            property: 'due_soon',
                            type: 'boolean',
                            description: 'Only automated (interval/calendar) tests that are not overdue and whose audit-initiation lead-in window is open (today falls within [next_date - audit_initiation_offset, next_date]).',
                        ),
                        new OA\Property(
                            property: 'failing',
                            type: 'boolean',
                            description: "Only tests whose most recent audit result is 'Fail'.",
                        ),
                        new OA\Property(
                            property: 'manual',
                            type: 'boolean',
                            description: "Only tests with schedule_type='manual'.",
                        ),
                        new OA\Property(
                            property: 'untested',
                            type: 'boolean',
                            description: "Only controls with zero active tests (equivalent to coverage='gaps').",
                        ),
                        new OA\Property(
                            property: 'show_retired',
                            type: 'boolean',
                            description: 'Include retired tests (excluded by default).',
                        ),
                    ],
                ),
                new OA\Property(
                    property: 'start',
                    type: 'integer',
                    description: 'Paging offset into the filtered control list.',
                    example: 0,
                ),
                new OA\Property(
                    property: 'length',
                    type: 'integer',
                    description: 'Page size; -1 returns every matching control.',
                    example: 10,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Paged grid data.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'recordsTotal',
                                type: 'integer',
                                description: 'All non-deleted controls, ignoring every filter.',
                            ),
                            new OA\Property(
                                property: 'recordsFiltered',
                                type: 'integer',
                                description: 'Controls matching every filter, before pagination.',
                            ),
                            new OA\Property(
                                property: 'controls',
                                type: 'array',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(property: 'id', type: 'integer'),
                                        new OA\Property(property: 'control_number', type: 'string', nullable: true),
                                        new OA\Property(property: 'short_name', type: 'string'),
                                        new OA\Property(
                                            property: 'long_name',
                                            type: 'string',
                                            nullable: true,
                                            description: "Added for the Define Tests grid (Task 6) so the control's full display name is still findable/visible via the toolbar search now that the legacy page's dedicated long-name filter field is gone.",
                                        ),
                                        new OA\Property(property: 'owner_name', type: 'string', nullable: true),
                                        new OA\Property(property: 'framework_count', type: 'integer'),
                                        new OA\Property(property: 'test_count', type: 'integer'),
                                        new OA\Property(
                                            property: 'tests',
                                            type: 'array',
                                            items: new OA\Items(
                                                type: 'object',
                                                properties: [
                                                    new OA\Property(property: 'id', type: 'integer'),
                                                    new OA\Property(property: 'name', type: 'string'),
                                                    new OA\Property(
                                                        property: 'tester_name',
                                                        type: 'string',
                                                        nullable: true,
                                                    ),
                                                    new OA\Property(
                                                        property: 'schedule_type',
                                                        type: 'string',
                                                        enum: ['manual', 'interval', 'calendar'],
                                                        description: "Added for the Define Tests grid (Task 6) so the client can render a distinct 'Manual' next-due pill state -- a manual test still carries a next_date, so overdue/due-soon math alone can't distinguish it.",
                                                    ),
                                                    new OA\Property(
                                                        property: 'schedule_summary',
                                                        type: 'string',
                                                        example: 'Every 3 Months',
                                                    ),
                                                    new OA\Property(
                                                        property: 'next_date',
                                                        type: 'string',
                                                        format: 'date',
                                                    ),
                                                    new OA\Property(property: 'overdue', type: 'boolean'),
                                                    new OA\Property(
                                                        property: 'due_soon',
                                                        type: 'boolean',
                                                        description: 'Automated test, not overdue, and inside its audit-initiation lead-in window.',
                                                    ),
                                                    new OA\Property(
                                                        property: 'last_result',
                                                        type: 'string',
                                                        nullable: true,
                                                        example: 'Pass',
                                                    ),
                                                    new OA\Property(
                                                        property: 'last_result_family',
                                                        type: 'string',
                                                        enum: ['success', 'danger', 'warning', 'neutral'],
                                                    ),
                                                    new OA\Property(property: 'retired', type: 'boolean'),
                                                    new OA\Property(property: 'approximate_time', type: 'integer'),
                                                    new OA\Property(
                                                        property: 'tags',
                                                        type: 'array',
                                                        items: new OA\Items(type: 'string'),
                                                    ),
                                                ],
                                            ),
                                        ),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have compliance permission.'),
    ],
)]
class OpenApiComplianceTestsGrid {}

#[OA\Post(
    path: '/compliance/tests_grid/filtered_ids',
    summary: "Resolve every real test id matching the Define Tests page's current filter set, across every page ('Select all N')",
    description: 'Unlike /compliance/tests_grid above, which returns one page, this applies the identical filter (parse_grid_request() + build_tests_grid() forced to length=-1, includes/compliance_grid.php) across the WHOLE matching set and flattens it to a plain list of real test ids (flatten_tests_grid_ids()) -- AI-suggestion rows are excluded, since they have no real id and are acted on by the separate proposal-approval flow, not Retire/Delete. Refused with 400 when the match count exceeds DEFINE_TESTS_SELECT_ALL_MAX (500, api/v2/includes/compliance.php) -- narrow the filter and retry, since every subsequent bulk action fires one request per selected id rather than a single atomic bulk write.',
    operationId: 'complianceTestsGridFilteredIds',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: false,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(property: 'framework', type: 'array', items: new OA\Items(type: 'integer')),
                new OA\Property(property: 'family', type: 'array', items: new OA\Items(type: 'integer')),
                new OA\Property(property: 'search', type: 'string'),
                new OA\Property(property: 'coverage', type: 'string', enum: ['with', 'all', 'gaps']),
                new OA\Property(property: 'schedule', type: 'string', enum: ['manual', 'interval', 'calendar']),
                new OA\Property(property: 'tag', type: 'string'),
                new OA\Property(property: 'tester', type: 'integer'),
                new OA\Property(property: 'retired', type: 'string', enum: ['active', 'all', 'retired_only']),
                new OA\Property(
                    property: 'quick',
                    type: 'object',
                    description: 'Same quick-filter toggles as /compliance/tests_grid.',
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Every matching real test id',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Real test ids (framework_control_tests.id) matching the given filters, across every page.',
                            ),
                            new OA\Property(property: 'total', type: 'integer', description: 'count(ids).'),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'The filter matches more tests than DEFINE_TESTS_SELECT_ALL_MAX allows',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(property: 'data', nullable: true),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have compliance permission.'),
    ],
)]
class OpenApiComplianceTestsGridFilteredIds {}

#[OA\Post(
    path: '/compliance/tests/batch-retire',
    summary: "Retire every test id in the given array in a single request ('Select all N')",
    description: 'Replaces looping POST /compliance/tests/{id}/retire once per selected id: the Define Tests bulk-retire bar sends every selected/resolved id (up to DEFINE_TESTS_SELECT_ALL_MAX = 500, api/v2/includes/compliance.php) in one call. Runs the exact same authorization retireTestById() (includes/api.php) runs for a single retire -- can_retire_tests() (edit_tests OR delete_tests) gates the whole request once, then check_access_for_test() (includes/functions.php) is re-evaluated individually for EVERY id -- when the Team Separation Extra is active this can deny a caller access to a specific test even though they hold edit_tests/delete_tests in general. An id that fails that per-id check is skipped and reported in denied_ids/denied rather than aborting the batch or being silently dropped; an id with no matching test (already deleted elsewhere) is likewise skipped and reported in failed_ids/failed.',
    operationId: 'complianceTestsBatchRetire',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['ids'],
            properties: [
                new OA\Property(
                    property: 'ids',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'Test ids (framework_control_tests.id) to retire.',
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Batch processed (individual ids may still have been denied or not found -- see denied/denied_ids and failed/failed_ids).',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'processed',
                                type: 'integer',
                                description: 'Count of ids actually retired.',
                            ),
                            new OA\Property(property: 'denied', type: 'integer', description: 'count(denied_ids).'),
                            new OA\Property(
                                property: 'denied_ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Ids skipped because the per-id check_access_for_test() check denied access to this user.',
                            ),
                            new OA\Property(property: 'failed', type: 'integer', description: 'count(failed_ids).'),
                            new OA\Property(
                                property: 'failed_ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Ids skipped because no matching test was found.',
                            ),
                            new OA\Property(
                                property: 'total',
                                type: 'integer',
                                description: 'count(ids) actually considered, after the cap.',
                            ),
                            new OA\Property(
                                property: 'truncated',
                                type: 'boolean',
                                description: 'True when more than `limit` valid ids were submitted -- only the first `limit` were processed.',
                            ),
                            new OA\Property(property: 'limit', type: 'integer', example: 500),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Missing/empty/non-array ids',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(property: 'data', nullable: true),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: missing both edit_tests and delete_tests.'),
    ],
)]
class OpenApiComplianceTestsBatchRetire {}

#[OA\Post(
    path: '/compliance/tests/batch-delete',
    summary: "Delete every test id in the given array in a single request ('Select all N')",
    description: 'Replaces looping DELETE /compliance/tests/{id} once per selected id: the Define Tests bulk-delete bar sends every selected/resolved id (up to DEFINE_TESTS_SELECT_ALL_MAX = 500, api/v2/includes/compliance.php) in one call. Runs the exact same authorization deleteTestById() (includes/api.php) runs for a single delete -- the delete_tests permission gates the whole request once, then check_access_for_test() (includes/functions.php) is re-evaluated individually for EVERY id -- when the Team Separation Extra is active this can deny a caller access to a specific test even though they hold delete_tests in general. An id that fails that per-id check is skipped and reported in denied_ids/denied rather than aborting the batch or being silently dropped; an id with no matching test (already deleted elsewhere) is likewise skipped and reported in failed_ids/failed.',
    operationId: 'complianceTestsBatchDelete',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['ids'],
            properties: [
                new OA\Property(
                    property: 'ids',
                    type: 'array',
                    items: new OA\Items(type: 'integer'),
                    description: 'Test ids (framework_control_tests.id) to delete.',
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Batch processed (individual ids may still have been denied or not found -- see denied/denied_ids and failed/failed_ids).',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'processed',
                                type: 'integer',
                                description: 'Count of ids actually deleted.',
                            ),
                            new OA\Property(property: 'denied', type: 'integer', description: 'count(denied_ids).'),
                            new OA\Property(
                                property: 'denied_ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Ids skipped because the per-id check_access_for_test() check denied access to this user.',
                            ),
                            new OA\Property(property: 'failed', type: 'integer', description: 'count(failed_ids).'),
                            new OA\Property(
                                property: 'failed_ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Ids skipped because no matching test was found.',
                            ),
                            new OA\Property(
                                property: 'total',
                                type: 'integer',
                                description: 'count(ids) actually considered, after the cap.',
                            ),
                            new OA\Property(
                                property: 'truncated',
                                type: 'boolean',
                                description: 'True when more than `limit` valid ids were submitted -- only the first `limit` were processed.',
                            ),
                            new OA\Property(property: 'limit', type: 'integer', example: 500),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Missing/empty/non-array ids',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(property: 'data', nullable: true),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: missing delete_tests.'),
    ],
)]
class OpenApiComplianceTestsBatchDelete {}

#[OA\Get(
    path: '/compliance/control_mappings',
    summary: 'Get the framework mappings for a single control',
    description: "Returns the control's description plus every framework mapping row (framework name, reference name/text) for the given control. Backs the Define Tests redesign's control-detail (SCF) expand.",
    operationId: 'complianceControlMappings',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'control_id',
            in: 'query',
            description: 'The ID of the control to retrieve mappings for.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Control description and its framework mappings.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'description',
                                type: 'string',
                                description: "The control's purified description.",
                            ),
                            new OA\Property(
                                property: 'mappings',
                                type: 'array',
                                items: new OA\Items(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(property: 'framework_name', type: 'string'),
                                        new OA\Property(property: 'reference_name', type: 'string'),
                                        new OA\Property(property: 'reference_text', type: 'string', nullable: true),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(response: 400, description: 'BAD REQUEST: control_id is required.'),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have compliance permission.'),
        new OA\Response(response: 404, description: 'NOT FOUND: Unable to find a control with the specified id.'),
    ],
)]
class OpenApiComplianceControlMappings {}

#[OA\Get(
    path: '/compliance/control_roster',
    summary: 'Get the lightweight control roster (id/number/name/description, plus family and framework ids)',
    description: "Returns id, control_number, short_name, family and framework ids for every non-deleted control, with no test/last-result/tag enrichment. Backs the Define Tests test modals' control picker, whose framework and family columns filter client-side from these ids -- deliberately cheap (a plain SELECT plus one mappings query) since it doesn't need the full grid's enrichment/pagination. Framework and family NAMES are not included; the page renders both lists for its own toolbar filters.",
    operationId: 'complianceControlRoster',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: "Every non-deleted control's id/control_number/short_name, with its family id and the ids of the frameworks it maps into.",
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(
                            type: 'object',
                            properties: [
                                new OA\Property(property: 'id', type: 'integer'),
                                new OA\Property(property: 'control_number', type: 'string', nullable: true),
                                new OA\Property(property: 'short_name', type: 'string'),
                                new OA\Property(
                                    property: 'description',
                                    type: 'string',
                                    description: "The control's description as one line of plain text (tags stripped, whitespace collapsed, capped at 300 characters) for the picker's hover.",
                                ),
                                new OA\Property(
                                    property: 'family',
                                    type: 'integer',
                                    description: 'Family id, or 0 when the control has no family.',
                                ),
                                new OA\Property(
                                    property: 'frameworks',
                                    type: 'array',
                                    description: 'Ids of the frameworks this control maps into; empty when it maps to none.',
                                    items: new OA\Items(type: 'integer'),
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have compliance permission.'),
    ],
)]
class OpenApiComplianceControlRoster {}

#[OA\Post(
    path: '/compliance/define_tests',
    summary: 'Get a DataTables-formatted list of defined tests for a control',
    description: 'Get a DataTables-formatted list of defined tests for a control.',
    operationId: 'defineTests',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['control_id'],
            properties: [
                new OA\Property(property: 'draw', type: 'integer', description: 'DataTables draw counter', example: 1),
                new OA\Property(
                    property: 'start',
                    type: 'integer',
                    description: 'Paging first record indicator',
                    example: 0,
                ),
                new OA\Property(
                    property: 'length',
                    type: 'integer',
                    description: 'Number of records to display',
                    example: 10,
                ),
                new OA\Property(
                    property: 'control_id',
                    type: 'integer',
                    description: 'The ID of the control to retrieve tests for',
                    example: 1,
                ),
                new OA\Property(
                    property: 'columns',
                    type: 'array',
                    description: 'Column definitions',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
                new OA\Property(
                    property: 'order',
                    type: 'array',
                    description: 'Column ordering',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'DataTables response with defined tests',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 100),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 100),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(type: 'object', additionalProperties: true),
                    ),
                ],
            ),
        ),
    ],
)]
class OpenApiDefineTests {}

#[OA\Post(
    path: '/compliance/update_test',
    summary: 'Update a compliance test, including its audit cadence schedule',
    description: 'Update a compliance test. Accepts the legacy interval fields (test_frequency, last_date, next_date) as well as the calendar-cadence schedule fields (schedule_type, cadence_unit, cadence_interval, cadence_anchor_date, schedule_exceptions). schedule_exceptions may be omitted (existing exceptions are left untouched) or supplied as a JSON-encoded array (including an empty array, which clears them).',
    operationId: 'updateTestSchedule',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    required: ['test_id', 'name', 'tester'],
                    properties: [
                        new OA\Property(
                            property: 'test_id',
                            type: 'integer',
                            description: 'The ID of the test to update.',
                        ),
                        new OA\Property(property: 'name', type: 'string', description: 'The name of the test.'),
                        new OA\Property(property: 'tester', type: 'integer', description: 'User ID of the tester.'),
                        new OA\Property(
                            property: 'test_frequency',
                            type: 'integer',
                            description: 'Legacy interval test frequency in days.',
                        ),
                        new OA\Property(property: 'objective', type: 'string', description: 'The test objective.'),
                        new OA\Property(
                            property: 'test_steps',
                            type: 'string',
                            description: 'Steps to perform the test.',
                        ),
                        new OA\Property(
                            property: 'approximate_time',
                            type: 'integer',
                            description: 'Approximate time to complete in minutes.',
                        ),
                        new OA\Property(
                            property: 'expected_results',
                            type: 'string',
                            description: 'Expected results of the test.',
                        ),
                        new OA\Property(
                            property: 'additional_stakeholders',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'User IDs of additional stakeholders.',
                        ),
                        new OA\Property(
                            property: 'team',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Team IDs assigned to the test.',
                        ),
                        new OA\Property(
                            property: 'tags',
                            type: 'array',
                            items: new OA\Items(type: 'string'),
                            description: 'Tags assigned to the test.',
                        ),
                        new OA\Property(
                            property: 'last_date',
                            type: 'string',
                            format: 'date',
                            description: "Last test date. Accepts ISO (YYYY-MM-DD) or this instance's configured display format. Omit to keep the stored value; submit an empty string to clear it.",
                        ),
                        new OA\Property(
                            property: 'next_date',
                            type: 'string',
                            format: 'date',
                            description: "Next scheduled test date. Accepts ISO (YYYY-MM-DD) or this instance's configured display format. Omitting it or submitting an empty string means 'do not set it explicitly' — but that does NOT guarantee the stored value survives, because this endpoint always resolves next_date from the schedule: when schedule_type is calendar the cadence engine recomputes it, and on the interval path it is recomputed as last_date + test_frequency days whenever this request supplies a non-empty last_date and a test_frequency above 0. The stored value is left alone only when there is nothing to project from (no last_date in this request, or test_frequency 0) and none was submitted.",
                        ),
                        new OA\Property(
                            property: 'audit_initiation_offset',
                            type: 'integer',
                            description: 'Days before next_date to initiate the audit. Optional for Interval and Calendar schedule_type; ignored (forced to null) when schedule_type is manual.',
                        ),
                        new OA\Property(
                            property: 'schedule_type',
                            type: 'string',
                            enum: ['manual', 'interval', 'calendar'],
                            description: 'The scheduling mode for this test.',
                        ),
                        new OA\Property(
                            property: 'cadence_unit',
                            type: 'string',
                            enum: ['day', 'week', 'month', 'year'],
                            description: 'Calendar cadence recurrence unit. Required when schedule_type is calendar.',
                        ),
                        new OA\Property(
                            property: 'cadence_interval',
                            type: 'integer',
                            description: 'Calendar cadence recurrence interval. Required when schedule_type is calendar.',
                        ),
                        new OA\Property(
                            property: 'cadence_anchor_date',
                            type: 'string',
                            format: 'date',
                            description: "Calendar cadence anchor date, must be today or later. Accepts ISO (YYYY-MM-DD) or this instance's configured display format. Required when schedule_type is calendar.",
                        ),
                        new OA\Property(
                            property: 'schedule_exceptions',
                            type: 'array',
                            description: 'Per-occurrence overrides/skips for the calendar schedule. Omit to leave existing exceptions untouched; supply (including []) to replace them.',
                            items: new OA\Items(
                                type: 'object',
                                required: ['occurrence_date'],
                                properties: [
                                    new OA\Property(
                                        property: 'occurrence_date',
                                        type: 'string',
                                        format: 'date',
                                        description: 'The natural (un-overridden) occurrence date this exception applies to.',
                                    ),
                                    new OA\Property(
                                        property: 'override_date',
                                        type: 'string',
                                        format: 'date',
                                        nullable: true,
                                        description: 'Replacement date for this occurrence, or null to keep the natural date.',
                                    ),
                                    new OA\Property(
                                        property: 'skipped',
                                        type: 'boolean',
                                        description: 'True to skip this occurrence entirely.',
                                    ),
                                ],
                            ),
                        ),
                        new OA\Property(
                            property: 'test_method',
                            type: 'string',
                            enum: ['inquiry', 'observation', 'inspection', 'reperformance'],
                            nullable: true,
                            description: 'How the test evidence is gathered.',
                        ),
                        new OA\Property(
                            property: 'sample',
                            type: 'string',
                            description: 'The sample selection/methodology used for the test.',
                        ),
                        new OA\Property(
                            property: 'required_evidence',
                            type: 'string',
                            description: 'The evidence required to satisfy the test.',
                        ),
                        new OA\Property(
                            property: 'approvers',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'User IDs authorized to approve results of this test. The edit form submits the full multi-select, so this always replaces the persisted list. Segregation-of-duties: the tester may not also be listed as an approver.',
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(response: 200, description: 'Test updated successfully.'),
        new OA\Response(
            response: 400,
            description: 'BAD REQUEST: Validation failed (including an invalid test_method, the tester listed among approvers, or a last_date / next_date / cadence_anchor_date that is not a real date in either accepted format), or the user does not have permission to edit tests / access this test.',
        ),
    ],
)]
class OpenApiUpdateTestSchedule {}

#[OA\Get(
    path: '/compliance/test',
    summary: 'Get details for a single compliance test, including its audit cadence schedule',
    description: 'Get details for a single compliance test, including the calendar-cadence schedule fields (schedule_type, cadence_unit, cadence_interval, cadence_anchor_date) and the persisted per-occurrence schedule_exceptions map, keyed by occurrence_date.',
    operationId: 'getTest',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'id',
            in: 'query',
            description: 'The ID of the test to retrieve.',
            required: true,
            schema: new OA\Schema(type: 'integer'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Test details object',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        additionalProperties: true,
                        properties: [
                            new OA\Property(
                                property: 'schedule_type',
                                type: 'string',
                                enum: ['manual', 'interval', 'calendar'],
                                nullable: true,
                            ),
                            new OA\Property(
                                property: 'cadence_unit',
                                type: 'string',
                                enum: ['day', 'week', 'month', 'year'],
                                nullable: true,
                            ),
                            new OA\Property(property: 'cadence_interval', type: 'integer', nullable: true),
                            new OA\Property(
                                property: 'cadence_anchor_date',
                                type: 'string',
                                format: 'date',
                                nullable: true,
                            ),
                            new OA\Property(
                                property: 'schedule_exceptions',
                                type: 'object',
                                description: 'Persisted per-occurrence exceptions, keyed by occurrence_date.',
                                additionalProperties: new OA\AdditionalProperties(
                                    type: 'object',
                                    properties: [
                                        new OA\Property(
                                            property: 'override_date',
                                            type: 'string',
                                            format: 'date',
                                            nullable: true,
                                        ),
                                        new OA\Property(property: 'skipped', type: 'boolean'),
                                    ],
                                ),
                            ),
                            new OA\Property(
                                property: 'test_method',
                                type: 'string',
                                enum: ['inquiry', 'observation', 'inspection', 'reperformance'],
                                nullable: true,
                            ),
                            new OA\Property(
                                property: 'sample',
                                type: 'string',
                                description: 'Purified rich-text sample selection/methodology.',
                            ),
                            new OA\Property(
                                property: 'required_evidence',
                                type: 'string',
                                description: 'Purified rich-text required evidence.',
                            ),
                            new OA\Property(
                                property: 'approvers',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'User IDs authorized to approve results of this test.',
                            ),
                            new OA\Property(
                                property: 'approver_names',
                                type: 'object',
                                description: 'Approver user IDs mapped to display names, keyed by user id.',
                                additionalProperties: new OA\AdditionalProperties(type: 'string'),
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have compliance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for compliance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiGetTest {}

#[OA\Get(
    path: '/compliance/approver_roster',
    summary: 'Get the compliance test approver roster (value/name)',
    description: "Returns value/name for every enabled user holding the approve_tests permission. Backs the Phase 3a test-definition form's approver multi-select. Gated on define_tests (not approve_tests) -- the caller building/editing a test needs to see who the eligible approvers are without needing to be one themselves.",
    operationId: 'complianceApproverRoster',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: "Every enabled approve_tests user's value/name.",
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(
                            type: 'object',
                            properties: [
                                new OA\Property(property: 'value', type: 'integer', description: "The user's id."),
                                new OA\Property(
                                    property: 'name',
                                    type: 'string',
                                    description: "The user's display name.",
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ),
        new OA\Response(response: 403, description: 'FORBIDDEN: The user does not have permission to define tests.'),
    ],
)]
class OpenApiComplianceApproverRoster {}

#[OA\Post(
    path: '/compliance/schedule_preview',
    summary: 'Preview the occurrence dates a calendar audit cadence schedule would produce',
    description: 'Computes the effective occurrence dates for a candidate calendar cadence schedule (cadence unit/interval/anchor plus optional per-occurrence exceptions) over a date range, without persisting anything. Backs the live preview in the test schedule editor.',
    operationId: 'getSchedulePreview',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['cadence_unit', 'cadence_interval', 'cadence_anchor_date'],
            properties: [
                new OA\Property(
                    property: 'cadence_unit',
                    type: 'string',
                    enum: ['day', 'week', 'month', 'year'],
                    description: 'Recurrence unit.',
                ),
                new OA\Property(
                    property: 'cadence_interval',
                    type: 'integer',
                    description: 'Recurrence interval, in units of cadence_unit.',
                ),
                new OA\Property(
                    property: 'cadence_anchor_date',
                    type: 'string',
                    format: 'date',
                    description: 'Anchor date (YYYY-MM-DD) the recurrence is computed from.',
                ),
                new OA\Property(
                    property: 'start',
                    type: 'string',
                    format: 'date',
                    description: 'Start of the preview range (YYYY-MM-DD). Defaults to today.',
                ),
                new OA\Property(
                    property: 'end',
                    type: 'string',
                    format: 'date',
                    description: 'End of the preview range (YYYY-MM-DD). Defaults to two years from today.',
                ),
                new OA\Property(
                    property: 'schedule_exceptions',
                    type: 'array',
                    description: 'Per-occurrence overrides/skips to apply before filtering to the preview range.',
                    items: new OA\Items(
                        type: 'object',
                        required: ['occurrence_date'],
                        properties: [
                            new OA\Property(property: 'occurrence_date', type: 'string', format: 'date'),
                            new OA\Property(property: 'override_date', type: 'string', format: 'date', nullable: true),
                            new OA\Property(property: 'skipped', type: 'boolean'),
                        ],
                    ),
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Computed occurrence dates within the preview range.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'message', type: 'string', example: 'success'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'occurrences',
                                type: 'array',
                                items: new OA\Items(type: 'string', format: 'date'),
                                example: ['2026-01-01', '2026-04-01', '2026-07-01', '2026-10-01'],
                            ),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(response: 400, description: 'BAD REQUEST: The user does not have compliance permission.'),
    ],
)]
class OpenApiGetSchedulePreview {}

#[OA\Get(
    path: '/compliance/initiate_audits',
    summary: 'Get a list of tests available to be initiated as audits',
    description: 'Get a list of tests available to be initiated as audits.',
    operationId: 'initiateAudits',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Array of test objects available for audit initiation',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have compliance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for compliance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiInitiateAudits {}

#[OA\Post(
    path: '/compliance/active_audits',
    summary: 'Get active test audits in DataTables format',
    description: 'Get active test audits in DataTables format.',
    operationId: 'activeAudits',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(property: 'draw', type: 'integer', description: 'DataTables draw counter', example: 1),
                new OA\Property(
                    property: 'start',
                    type: 'integer',
                    description: 'Paging first record indicator',
                    example: 0,
                ),
                new OA\Property(
                    property: 'length',
                    type: 'integer',
                    description: 'Number of records to display',
                    example: 10,
                ),
                new OA\Property(
                    property: 'columns',
                    type: 'array',
                    description: 'Column definitions',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
                new OA\Property(
                    property: 'order',
                    type: 'array',
                    description: 'Column ordering',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
                new OA\Property(
                    property: 'filter',
                    type: 'object',
                    description: 'Additional filter parameters',
                    additionalProperties: true,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'DataTables response with active audits',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 100),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 100),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(type: 'object', additionalProperties: true),
                    ),
                ],
            ),
        ),
    ],
)]
class OpenApiActiveAudits {}

#[OA\Post(
    path: '/compliance/save_audit_comment',
    summary: 'Save a comment on a test audit',
    description: 'Save a comment on a test audit.',
    operationId: 'saveAuditComment',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['audit_id', 'comment'],
            properties: [
                new OA\Property(
                    property: 'audit_id',
                    type: 'integer',
                    description: 'The ID of the audit to comment on',
                    example: 1,
                ),
                new OA\Property(property: 'comment', type: 'string', description: 'The comment text to save'),
                new OA\Property(
                    property: 'test_result',
                    type: 'string',
                    description: 'The result of the test (e.g. pass, fail)',
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Audit comment saved successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Audit comment saved successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error saving audit comment',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to save audit comment'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiSaveAuditComment {}

#[OA\Post(
    path: '/compliance/past_audits',
    summary: 'Get completed/past test audits in DataTables format',
    description: 'Get completed/past test audits in DataTables format.',
    operationId: 'pastAudits',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            properties: [
                new OA\Property(property: 'draw', type: 'integer', description: 'DataTables draw counter', example: 1),
                new OA\Property(
                    property: 'start',
                    type: 'integer',
                    description: 'Paging first record indicator',
                    example: 0,
                ),
                new OA\Property(
                    property: 'length',
                    type: 'integer',
                    description: 'Number of records to display',
                    example: 10,
                ),
                new OA\Property(
                    property: 'columns',
                    type: 'array',
                    description: 'Column definitions',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
                new OA\Property(
                    property: 'order',
                    type: 'array',
                    description: 'Column ordering',
                    items: new OA\Items(type: 'object', additionalProperties: true),
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'DataTables response with past audits',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 100),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 100),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(type: 'object', additionalProperties: true),
                    ),
                ],
            ),
        ),
    ],
)]
class OpenApiPastAudits {}

#[OA\Post(
    path: '/compliance/reopen_audit',
    summary: 'Reopen a closed test audit',
    description: 'Reopen a closed test audit.',
    operationId: 'reopenAudit',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['audit_id'],
            properties: [
                new OA\Property(
                    property: 'audit_id',
                    type: 'integer',
                    description: 'The ID of the audit to reopen',
                    example: 1,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Audit reopened successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Audit reopened successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error reopening audit',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to reopen audit'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiReopenAudit {}

#[OA\Post(
    path: '/compliance/audit_initiation/initiate',
    summary: 'Initiate audits for one or more framework control tests',
    description: 'Initiate audits for one or more framework control tests.',
    operationId: 'initiateAudit',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['test_ids'],
            properties: [
                new OA\Property(
                    property: 'test_ids',
                    type: 'array',
                    description: 'IDs of the tests to initiate audits for',
                    items: new OA\Items(type: 'integer'),
                ),
                new OA\Property(
                    property: 'frequency',
                    type: 'string',
                    description: 'Frequency at which the audit should recur',
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Audits initiated successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Audits initiated successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error initiating audits',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to initiate audits'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiInitiateAudit {}

#[OA\Post(
    path: '/compliance/audit_initiation/initiate_bulk',
    summary: 'Initiate audits for an arbitrary batch of individual tests',
    description: "Batch-initiates audits for a list of framework_control_test ids, applying one shared tag set. Backs the redesigned Initiate Audits page's 'Initiate selected' bulk action -- filtering the flat list to one framework/control and selecting all matching reproduces 'initiate whole framework/control' without a nested tree. A test that can't be initiated (retired, outside the viewer's team) is reported back as skipped rather than failing the whole batch. Gated on the compliance permission plus Initiate Audits (SR-1721).",
    operationId: 'initiateTestsBulk',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    required: ['ids'],
                    properties: [
                        new OA\Property(
                            property: 'ids',
                            type: 'array',
                            description: 'framework_control_test ids to initiate',
                            items: new OA\Items(type: 'integer'),
                        ),
                        new OA\Property(
                            property: 'tags',
                            type: 'array',
                            description: 'Tags applied to every initiated audit',
                            items: new OA\Items(type: 'string'),
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: at least one audit was initiated.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Initiated 3 tests.'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'initiated',
                                type: 'array',
                                items: new OA\Items(type: 'object', additionalProperties: true),
                            ),
                            new OA\Property(property: 'skipped', type: 'array', items: new OA\Items(type: 'integer')),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'No permission, no ids given, or every test in the batch was skipped.',
        ),
    ],
)]
class OpenApiInitiateTestsBulk {}

#[OA\Post(
    path: '/compliance/audit_initiation/eligible_tests',
    summary: 'Flat, filterable list of tests eligible for initiation',
    description: 'Server-side feed backing the redesigned, flat Initiate Audits page. Team-scoped via the same access check initiate_framework_control_tests() enforces at action time. Returns RAW field values (not pre-rendered HTML) -- the client renders each row. Gated on the compliance permission (SR-1721).',
    operationId: 'complianceInitiateEligibleTests',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: "Standard DataTables-style paging (draw, start, length) plus this page's own filters.",
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 25),
                        new OA\Property(property: 'filter_text', type: 'string'),
                        new OA\Property(
                            property: 'filter_framework',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                        ),
                        new OA\Property(
                            property: 'filter_control',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                        ),
                        new OA\Property(
                            property: 'filter_schedule_type',
                            type: 'array',
                            description: 'manual|interval|calendar',
                            items: new OA\Items(type: 'string'),
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: paginated list of eligible tests.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 47),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 47),
                    new OA\Property(
                        property: 'data',
                        type: 'array',
                        items: new OA\Items(type: 'object', additionalProperties: true),
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceInitiateEligibleTests {}

#[OA\Get(
    path: '/compliance/audit_timeline',
    summary: 'Get the audit timeline data for calendar display',
    description: 'Get the audit timeline data for calendar display.',
    operationId: 'auditTimeline',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    responses: [
        new OA\Response(
            response: 200,
            description: 'Array of audit timeline event objects',
            content: new OA\JsonContent(type: 'array', items: new OA\Items(type: 'object', additionalProperties: true)),
        ),
        new OA\Response(
            response: 400,
            description: 'User does not have compliance permissions',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'No permission for compliance'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiAuditTimeline {}

#[OA\Post(
    path: '/compliance/delete_audit',
    summary: 'Delete a test audit',
    description: 'Delete a test audit.',
    operationId: 'deleteAudit',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['audit_id'],
            properties: [
                new OA\Property(
                    property: 'audit_id',
                    type: 'integer',
                    description: 'The ID of the audit to delete',
                    example: 1,
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Audit deleted successfully',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'success'),
                    new OA\Property(property: 'message', type: 'string', example: 'Audit deleted successfully'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Error deleting audit',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'string', example: 'error'),
                    new OA\Property(property: 'message', type: 'string', example: 'Unable to delete audit'),
                    new OA\Property(property: 'data', type: 'object', nullable: true, additionalProperties: true),
                ],
            ),
        ),
    ],
)]
class OpenApiDeleteAudit {}

#[OA\Post(
    path: '/compliance/audits/active/datatable',
    summary: 'Server-side DataTables feed for the Active Audits view',
    description: 'Returns Active Audits rows in DataTables server-side format. Gated on the compliance permission (SR-1721).',
    operationId: 'complianceActiveAuditsDatatable',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: 'Standard DataTables server-side request parameters (draw, start, length, order, columns, search).',
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 10),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: DataTables server-side response.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 42),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 42),
                    new OA\Property(property: 'data', type: 'array', items: new OA\Items(type: 'object')),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceActiveAuditsDatatable {}

#[OA\Post(
    path: '/compliance/audits/past/datatable',
    summary: 'Server-side DataTables feed for the Past Audits view',
    description: 'Returns Past Audits rows in DataTables server-side format. Gated on the compliance permission (SR-1721).',
    operationId: 'compliancePastAuditsDatatable',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: 'Standard DataTables server-side request parameters (draw, start, length, order, columns, search).',
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 10),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: DataTables server-side response.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 42),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 42),
                    new OA\Property(property: 'data', type: 'array', items: new OA\Items(type: 'object')),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiCompliancePastAuditsDatatable {}

#[OA\Post(
    path: '/compliance/audits/all/datatable',
    summary: 'Server-side DataTables feed for the merged Audits view',
    description: 'Returns every non-deleted audit (open and closed together) in DataTables server-side format, backing the merged Compliance > Audits page that replaces the separate Active/Past Audits pages. Gated on the compliance permission (SR-1721).',
    operationId: 'complianceAllAuditsDatatable',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: 'Standard DataTables server-side request parameters (draw, start, length, order, columns, search).',
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 10),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: DataTables server-side response.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 42),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 42),
                    new OA\Property(property: 'data', type: 'array', items: new OA\Items(type: 'object')),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceAllAuditsDatatable {}

#[OA\Post(
    path: '/compliance/audits/filtered_ids',
    summary: "Resolve every audit id matching the Manage Audits page's current status chip + filters, across every page ('Select all N')",
    description: "Unlike the three status-chip datatable endpoints above, which each return one page, this applies the identical filter (get_data_for_datatable(), includes/functions.php, forced to length=-1) across the WHOLE matching set for the given status and returns just the ids. `status` selects which of the three views' SQL scope (active_audits/past_audits/all_audits) to resolve against -- it is validated strictly with no silent default, since resolving against the wrong scope could hand a bulk Delete more ids than the viewer ever saw. Refused with 400 when the match count exceeds MANAGE_AUDITS_SELECT_ALL_MAX (2000, api/v2/includes/compliance.php) -- narrow the filter and retry, since the page's only bulk action (Delete) fires one request per selected id rather than a single atomic bulk write.",
    operationId: 'complianceAuditsFilteredIds',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['status'],
            properties: [
                new OA\Property(
                    property: 'status',
                    type: 'string',
                    enum: ['active', 'past', 'all'],
                    description: "Which status chip's SQL scope to resolve ids against.",
                ),
                new OA\Property(
                    property: 'audits_column_filters',
                    type: 'string',
                    description: "JSON-encoded object of the toolbar quickfilter values (framework_name/test_name/tester/result/status/tags/teams), same shape the datatable endpoints' own audits_column_filters param takes.",
                ),
                new OA\Property(
                    property: 'search',
                    type: 'string',
                    description: "Global search term, matched the same way the toolbar search box's term is matched.",
                ),
                new OA\Property(
                    property: 'audits_test_date_range',
                    type: 'string',
                    description: "Manage Audits' Test Date range quickfilter, same start-minus-end format the datatable endpoints already expect.",
                ),
            ],
        ),
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Every matching audit id',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Audit ids matching the given status + filters, across every page.',
                            ),
                            new OA\Property(property: 'total', type: 'integer', description: 'count(ids).'),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Missing/invalid status, or the filter matches more audits than MANAGE_AUDITS_SELECT_ALL_MAX allows',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(property: 'data', nullable: true),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceAuditsFilteredIds {}

#[OA\Post(
    path: '/compliance/audits/batch-delete',
    summary: "Delete every audit id in the given array in a single request ('Select all N')",
    description: 'Replaces looping POST /compliance/delete_audit once per selected id: the Manage Audits bulk-delete bar sends every selected/resolved id (up to MANAGE_AUDITS_SELECT_ALL_MAX = 2000, api/v2/includes/compliance.php) in one call. Runs the exact same authorization deleteTestAuditResponse() runs for a single delete -- the compliance permission plus the delete_audits session flag gate the whole request once, then, when the Team Separation Extra is active, is_user_allowed_to_access() (extras/separation/index.php) is re-evaluated individually for EVERY id. An id that fails that per-id check is skipped and reported in denied_ids/denied rather than aborting the batch or being silently dropped.',
    operationId: 'complianceAuditsBatchDelete',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        required: true,
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    required: ['ids'],
                    properties: [
                        new OA\Property(
                            property: 'ids',
                            type: 'array',
                            items: new OA\Items(type: 'integer'),
                            description: 'Audit ids to delete.',
                        ),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'Batch processed (individual ids may still have been denied -- see denied/denied_ids).',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 200),
                    new OA\Property(property: 'status_message', type: 'string', example: 'SUCCESS'),
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(
                                property: 'deleted',
                                type: 'integer',
                                description: 'Count of ids actually deleted.',
                            ),
                            new OA\Property(property: 'denied', type: 'integer', description: 'count(denied_ids).'),
                            new OA\Property(
                                property: 'denied_ids',
                                type: 'array',
                                items: new OA\Items(type: 'integer'),
                                description: 'Ids skipped because the per-id Team Separation check denied access to this user.',
                            ),
                            new OA\Property(
                                property: 'truncated',
                                type: 'boolean',
                                description: 'True when more than `limit` valid ids were submitted -- only the first `limit` were processed.',
                            ),
                            new OA\Property(property: 'limit', type: 'integer', example: 2000),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 400,
            description: 'Missing/empty/non-array ids',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'status', type: 'integer', example: 400),
                    new OA\Property(property: 'status_message', type: 'string'),
                    new OA\Property(property: 'data', nullable: true),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: missing the compliance permission or the delete_audits flag.',
        ),
    ],
)]
class OpenApiComplianceAuditsBatchDelete {}

#[OA\Get(
    path: '/compliance/audits/filter_counts',
    summary: 'Per-option counts for the Manage Audits quickfilters',
    description: "Returns, for the requested status scope, how many audits match each option of the Framework/Test Name/Tester/Result/Tag/Team quickfilters -- keyed by the same raw id each filter's <option> value already uses. Backs the Manage Audits page's zero-count-option suppression. Gated on the compliance permission (SR-1721).",
    operationId: 'complianceAuditsFilterCounts',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    parameters: [
        new OA\Parameter(
            name: 'status',
            in: 'query',
            required: false,
            description: "Which status chip's scope to count against. Defaults to 'active' when omitted or invalid.",
            schema: new OA\Schema(type: 'string', enum: ['active', 'past', 'all'], default: 'active'),
        ),
    ],
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: counts per filter dimension, each a map of raw filter value to matching audit count.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(
                        property: 'data',
                        type: 'object',
                        properties: [
                            new OA\Property(property: 'framework_name', type: 'object', example: [1 => 4, 2 => 2]),
                            new OA\Property(property: 'test_name', type: 'object', example: [7 => 1]),
                            new OA\Property(property: 'tester', type: 'object', example: [3 => 5]),
                            new OA\Property(
                                property: 'test_result',
                                type: 'object',
                                example: ['pass' => 3, 'fail' => 1],
                            ),
                            new OA\Property(property: 'tags', type: 'object', example: [12 => 2]),
                            new OA\Property(property: 'teams', type: 'object', example: [1 => 6]),
                        ],
                    ),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceAuditsFilterCounts {}

#[OA\Post(
    path: '/compliance/audits/report/datatable',
    summary: 'Server-side DataTables feed for the Dynamic Audit Report',
    description: 'Returns Dynamic Audit Report rows in DataTables server-side format. Gated on the compliance permission (SR-1721).',
    operationId: 'complianceDynamicAuditReportDatatable',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: 'Standard DataTables server-side request parameters (draw, start, length, order, columns, search).',
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 10),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: DataTables server-side response.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 42),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 42),
                    new OA\Property(property: 'data', type: 'array', items: new OA\Items(type: 'object')),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceDynamicAuditReportDatatable {}

#[OA\Post(
    path: '/compliance/audits/timeline/datatable',
    summary: 'Server-side DataTables feed for the Audit Timeline report',
    description: 'Returns Audit Timeline rows in DataTables server-side format. Gated on the compliance permission (SR-1721).',
    operationId: 'complianceAuditTimelineDatatable',
    tags: ['compliance'],
    security: [['ApiKeyAuth' => []]],
    requestBody: new OA\RequestBody(
        description: 'Standard DataTables server-side request parameters (draw, start, length, order, columns, search).',
        content: [
            new OA\MediaType(
                mediaType: 'application/x-www-form-urlencoded',
                schema: new OA\Schema(
                    type: 'object',
                    properties: [
                        new OA\Property(property: 'draw', type: 'integer', example: 1),
                        new OA\Property(property: 'start', type: 'integer', example: 0),
                        new OA\Property(property: 'length', type: 'integer', example: 10),
                    ],
                ),
            ),
        ],
    ),
    responses: [
        new OA\Response(
            response: 200,
            description: 'OK: DataTables server-side response.',
            content: new OA\JsonContent(
                type: 'object',
                properties: [
                    new OA\Property(property: 'draw', type: 'integer', example: 1),
                    new OA\Property(property: 'recordsTotal', type: 'integer', example: 42),
                    new OA\Property(property: 'recordsFiltered', type: 'integer', example: 42),
                    new OA\Property(property: 'data', type: 'array', items: new OA\Items(type: 'object')),
                ],
            ),
        ),
        new OA\Response(
            response: 403,
            description: 'FORBIDDEN: The user does not have the required permission to perform this action.',
        ),
    ],
)]
class OpenApiComplianceAuditTimelineDatatable {}

?>
