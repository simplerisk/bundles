<?php
    /* This Source Code Form is subject to the terms of the Mozilla Public
    * License, v. 2.0. If a copy of the MPL was not distributed with this
    * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

    // Render the header and sidebar
    require_once(realpath(__DIR__ . '/../includes/renderutils.php'));

    render_header_and_sidebar(['multiselect', 'chart.js', 'UILayoutWidget'], ['check_riskmanagement' => true], active_sidebar_submenu: 'Reporting_Reports', active_sidebar_menu: 'Reporting', breadcrumb_title_key: 'RiskCharts');

    // Include required functions file
    require_once(realpath(__DIR__ . '/../includes/reporting.php'));
    // sanitize_requested_teams() is defined here -- require it directly
    // rather than relying on reporting.php's transitive include.
    require_once(realpath(__DIR__ . '/../includes/functions.php'));

    $teamOptions = get_teams_by_login_user();
    array_unshift($teamOptions, array(
        'value' => "0",
        'name' => $lang['Unassigned'],
    ));

    // Restrict any client-submitted team ids to the ones this user can
    // actually see -- otherwise a requester could name another team's id
    // and pull that team's risk data regardless of their own team access.
    $teams = sanitize_requested_teams($teamOptions, $_GET['teams'] ?? null);

?>
<div class="card-body border my-2">
    <div class="row">
        <div class="col-12">
            <h4><?= $escaper->escapeHtml($lang['OpenRisks']); ?> (<?= $escaper->escapeHtml(get_open_risks($teams)); ?>)</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-4">
            <label><strong><?= $escaper->escapeHtml($lang['Teams']); ?> :</strong></label>
    <?php 
            create_multiple_dropdown("teams", $teams, NULL, $teamOptions); 
    ?>
            <form id="risks_dashboard_form" method="GET">
                <input type="hidden" value="<?= $escaper->escapeHtml(implode(',', $teams)); ?>" name="teams" id="team_options">
            </form>
    <?php 
            get_report_dashboard_dropdown_script(); 
    ?>
        </div>
    </div>
    <div class="mt-2">
    <?php 
        // Render the 'dashboard_open' layout
        (new \includes\Widgets\UILayout('dashboard_open'))->render();
    ?>
    </div>
</div>
<div class="card-body border my-2">
    <div class="row">
        <div class="col-12">
            <h4><?= $escaper->escapeHtml($lang['ClosedRisks']); ?> (<?= $escaper->escapeHtml(get_closed_risks($teams)); ?>)</h4>
        </div>
    </div>
    <div class="mt-2">
    <?php 
        // Render the 'dashboard_close' layout
        (new \includes\Widgets\UILayout('dashboard_close'))->render();
    ?>
    </div>
</div>
<?php
    // Render the footer of the page. Please don't put code after this part.
    render_footer();
?>