<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0/. */
require_once(realpath(__DIR__ . '/../vendor/autoload.php'));
// Declared directly, not leaned on transitively. display_auth_brand_panel()
// below calls purify_html_login_notice(), get_custom_logo_src() and _lang(),
// all defined in functions.php, which this file otherwise reaches only through
// reporting.php. CLAUDE.md requires every direct consumer of a shared helper to
// require the defining file itself, because an include reorder or a split entry
// point can strip a transitive chain and turn the call into a fatal.
// require_once makes the duplicate load a no-op for callers that already have it.
require_once(realpath(__DIR__ . '/functions.php'));
require_once(realpath(__DIR__ . '/displayrisks.php'));
require_once(realpath(__DIR__ . '/assets.php'));
require_once(realpath(__DIR__ . '/assessments.php'));
require_once(realpath(__DIR__ . '/permissions.php'));
require_once(realpath(__DIR__ . '/governance.php'));
require_once(realpath(__DIR__ . '/reporting.php'));
require_once(realpath(__DIR__ . '/extras.php'));

/**********************************
* FUNCTION: DISPLAY AUTH BRAND PANEL *
***********************************/
/**
 * The charcoal brand panel on the left of the unauthenticated split-panel
 * screens -- index.php (login / MFA), reset.php (password reset request and
 * token redemption) and reset_password.php (forced password change).
 *
 * It lives here rather than being repeated in each of those three files
 * because it is identical on all of them; each caller already require_once's
 * this file directly, so the call is reachable without relying on a
 * transitive include.
 *
 * Styles are in scss/modules/_auth.scss, scoped to `.sr-auth`. The photograph
 * is decorative -- the wordmark beside it already names the product -- so both
 * backdrop layers are hidden from assistive technology.
 *
 * The panel carries the wordmark, a single tagline, and the copyright line.
 * The tagline is deliberately ONE short line rather than the value-proposition
 * paragraph this screen used to show: everyone who reaches it has already
 * obtained and installed SimpleRisk, so a sales argument addresses a reader who
 * is not here. A brand signature under the wordmark is a different thing from a
 * pitch, and it doubles as the visible hint that the slot is configurable.
 *
 * Both the mark and the tagline are the SimpleRisk defaults. The Customization
 * Extra replaces them with the customer's own, and adds a separate system-use
 * notice field; when that Extra is not active these defaults are what renders.
 *
 * The brandmark follows the same rule as the authenticated shell's
 * `.sr-wordmark` (header.php): the two-tone text at desktop widths, the logo
 * mark alone below `sm`. Showing both at once would make this a third brand
 * lockup that exists nowhere else in the product.
 */
function display_auth_brand_panel()
{
    global $lang, $escaper;

    // Customer branding is a Customization Extra feature. When that Extra is
    // inactive the stored values are ignored entirely rather than merely being
    // uneditable, so an instance that never had it -- or that let it lapse --
    // renders the SimpleRisk defaults. Reading the settings behind the gate
    // also means a value planted by any other route cannot reach this page
    // while the Extra is off.
    $customization_active = customization_extra();

    $tagline = $customization_active ? trim((string)get_setting('login_tagline')) : '';
    if ($tagline === '') {
        $tagline = $lang['FromZeroToGRCInMinutes'];
    }

    // Sanitized again here, not only on save. A row written by a restore, a
    // direct database edit or some future API has never been through the save
    // path, and this page is served to unauthenticated visitors -- so the
    // render boundary re-applies the allowlist rather than trusting storage.
    // purify_html_login_notice() is idempotent, so already-clean values are
    // unchanged.
    $notice = $customization_active ? (string)get_setting('login_notice') : '';
    $notice = $notice !== '' ? purify_html_login_notice($notice) : '';

    // One shared decision (functions.php) rather than a third copy of it: the
    // gate, the filename, the content version and the URL all resolve there.
    // Still a settings read, never a blob query -- the bytes are fetched by the
    // browser from the endpoint, so rendering this page pulls no image out of
    // the database.
    $custom_logo_src = get_custom_logo_src();

    // Pick the type size from the tagline's length.
    //
    // This is done here, in PHP, rather than in CSS because CSS cannot do it:
    // clamp() and container queries size text against the VIEWPORT, and nothing
    // sizes it against how much text there is. The alternative is a JavaScript
    // measure-and-shrink pass, which would put a reflow on the page that has to
    // load fastest and would make a customer's notice render correctly only
    // when scripting is available.
    //
    // Thresholds are in characters, which is an approximation of rendered width
    // -- good enough to choose between three sizes, and it degrades in the safe
    // direction because a wide string simply lands in a smaller bucket. The
    // Customization tagline field caps its own length as well; these buckets
    // absorb a reasonable range rather than making any length work.
    // The bucketing itself lives in functions.php as a pure function, so the
    // boundaries can be pinned by a test. Transposing two thresholds here would
    // otherwise only ever show up as a customer's tagline rendering at the wrong
    // size, which nothing asserts.
    $tagline_size_class = auth_tagline_size_class($tagline);

    echo "
        <aside class='sr-auth-brand'>
            <div class='sr-auth-brand-media' aria-hidden='true'></div>
            <div class='sr-auth-brand-scrim' aria-hidden='true'></div>
    ";

    // A configured logo REPLACES the wordmark rather than sitting beside it --
    // two marks in one lockup is exactly the third-variant problem the
    // brandmark rule exists to avoid. Neither branch is a link: this screen is
    // unauthenticated, and sending someone mid-sign-in out to simplerisk.com is
    // the wrong affordance -- more so when the mark is the customer's own.
    if ($custom_logo_src !== '') {
        echo "
            <span class='sr-auth-brandmark sr-auth-brandmark--custom'>
                <img class='sr-auth-customlogo' src='" . $escaper->escapeHtmlAttr($custom_logo_src) . "' alt='" . $escaper->escapeHtmlAttr($lang['OrganizationLogo']) . "' />
            </span>
        ";
    } else {
        echo "
            <span class='sr-auth-brandmark'>
                <img class='sr-auth-brandlogo' src='images/simplerisk-logo-icon.png' alt='SimpleRisk' />
                <span class='sr-auth-brandtext'><span class='s'>Simple</span><span class='r'>Risk</span></span>
            </span>
        ";
    }

    echo "
            <p class='sr-auth-tagline {$tagline_size_class}'>" . $escaper->escapeHtml($tagline) . "</p>
    ";

    // The notice sits between the tagline and the copyright line. Emitted as
    // raw HTML because it is restricted rich text -- purify_html_login_notice()
    // above is what makes that safe, and escaping here as well would show the
    // operator their own markup as literal text.
    if ($notice !== '') {
        echo "
            <div class='sr-auth-notice'>{$notice}</div>
        ";
    }

    echo "
            <p class='sr-auth-legal'>" . $escaper->escapeHtml(sprintf($lang['FooterCopyright'], date('Y'))) . "</p>
        </aside>
    ";
}

/*******************************************
* FUNCTION: CSS NAMED COLOR TO HEX *
*******************************************/
// Resolves a CSS3 extended-keyword color name (e.g. 'orange') to its hex
// equivalent, so risk_level_tile_is_light_color() below can compute a real
// luminance for it instead of treating every non-hex value as "not light".
// Mirrors admin/risk_configuration.php's own colourNameToHex() JS helper
// (same table, same source: the CSS Color Module Level 3 extended keyword
// list) -- PHP has no built-in equivalent, and the browser normally does
// this resolution for free (see risk_level_tile_is_light_color()'s own
// docblock). Returns $name unchanged (lowercased/trimmed) when it isn't a
// recognized keyword, so an already-hex value or genuine garbage input
// passes through for the caller's own validation.
function css_named_color_to_hex($name) {
    static $colors = [
        'aliceblue' => '#f0f8ff', 'antiquewhite' => '#faebd7', 'aqua' => '#00ffff', 'aquamarine' => '#7fffd4', 'azure' => '#f0ffff',
        'beige' => '#f5f5dc', 'bisque' => '#ffe4c4', 'black' => '#000000', 'blanchedalmond' => '#ffebcd', 'blue' => '#0000ff', 'blueviolet' => '#8a2be2', 'brown' => '#a52a2a', 'burlywood' => '#deb887',
        'cadetblue' => '#5f9ea0', 'chartreuse' => '#7fff00', 'chocolate' => '#d2691e', 'coral' => '#ff7f50', 'cornflowerblue' => '#6495ed', 'cornsilk' => '#fff8dc', 'crimson' => '#dc143c', 'cyan' => '#00ffff',
        'darkblue' => '#00008b', 'darkcyan' => '#008b8b', 'darkgoldenrod' => '#b8860b', 'darkgray' => '#a9a9a9', 'darkgreen' => '#006400', 'darkkhaki' => '#bdb76b', 'darkmagenta' => '#8b008b', 'darkolivegreen' => '#556b2f',
        'darkorange' => '#ff8c00', 'darkorchid' => '#9932cc', 'darkred' => '#8b0000', 'darksalmon' => '#e9967a', 'darkseagreen' => '#8fbc8f', 'darkslateblue' => '#483d8b', 'darkslategray' => '#2f4f4f', 'darkturquoise' => '#00ced1',
        'darkviolet' => '#9400d3', 'deeppink' => '#ff1493', 'deepskyblue' => '#00bfff', 'dimgray' => '#696969', 'dodgerblue' => '#1e90ff',
        'firebrick' => '#b22222', 'floralwhite' => '#fffaf0', 'forestgreen' => '#228b22', 'fuchsia' => '#ff00ff',
        'gainsboro' => '#dcdcdc', 'ghostwhite' => '#f8f8ff', 'gold' => '#ffd700', 'goldenrod' => '#daa520', 'gray' => '#808080', 'green' => '#008000', 'greenyellow' => '#adff2f',
        'honeydew' => '#f0fff0', 'hotpink' => '#ff69b4',
        'indianred' => '#cd5c5c', 'indigo' => '#4b0082', 'ivory' => '#fffff0', 'khaki' => '#f0e68c',
        'lavender' => '#e6e6fa', 'lavenderblush' => '#fff0f5', 'lawngreen' => '#7cfc00', 'lemonchiffon' => '#fffacd', 'lightblue' => '#add8e6', 'lightcoral' => '#f08080', 'lightcyan' => '#e0ffff', 'lightgoldenrodyellow' => '#fafad2',
        'lightgrey' => '#d3d3d3', 'lightgreen' => '#90ee90', 'lightpink' => '#ffb6c1', 'lightsalmon' => '#ffa07a', 'lightseagreen' => '#20b2aa', 'lightskyblue' => '#87cefa', 'lightslategray' => '#778899', 'lightsteelblue' => '#b0c4de',
        'lightyellow' => '#ffffe0', 'lime' => '#00ff00', 'limegreen' => '#32cd32', 'linen' => '#faf0e6',
        'magenta' => '#ff00ff', 'maroon' => '#800000', 'mediumaquamarine' => '#66cdaa', 'mediumblue' => '#0000cd', 'mediumorchid' => '#ba55d3', 'mediumpurple' => '#9370d8', 'mediumseagreen' => '#3cb371', 'mediumslateblue' => '#7b68ee',
        'mediumspringgreen' => '#00fa9a', 'mediumturquoise' => '#48d1cc', 'mediumvioletred' => '#c71585', 'midnightblue' => '#191970', 'mintcream' => '#f5fffa', 'mistyrose' => '#ffe4e1', 'moccasin' => '#ffe4b5',
        'navajowhite' => '#ffdead', 'navy' => '#000080',
        'oldlace' => '#fdf5e6', 'olive' => '#808000', 'olivedrab' => '#6b8e23', 'orange' => '#ffa500', 'orangered' => '#ff4500', 'orchid' => '#da70d6',
        'palegoldenrod' => '#eee8aa', 'palegreen' => '#98fb98', 'paleturquoise' => '#afeeee', 'palevioletred' => '#d87093', 'papayawhip' => '#ffefd5', 'peachpuff' => '#ffdab9', 'peru' => '#cd853f', 'pink' => '#ffc0cb', 'plum' => '#dda0dd', 'powderblue' => '#b0e0e6', 'purple' => '#800080',
        'rebeccapurple' => '#663399', 'red' => '#ff0000', 'rosybrown' => '#bc8f8f', 'royalblue' => '#4169e1',
        'saddlebrown' => '#8b4513', 'salmon' => '#fa8072', 'sandybrown' => '#f4a460', 'seagreen' => '#2e8b57', 'seashell' => '#fff5ee', 'sienna' => '#a0522d', 'silver' => '#c0c0c0', 'skyblue' => '#87ceeb', 'slateblue' => '#6a5acd', 'slategray' => '#708090', 'snow' => '#fffafa', 'springgreen' => '#00ff7f', 'steelblue' => '#4682b4',
        'tan' => '#d2b48c', 'teal' => '#008080', 'thistle' => '#d8bfd8', 'tomato' => '#ff6347', 'turquoise' => '#40e0d0',
        'violet' => '#ee82ee',
        'wheat' => '#f5deb3', 'white' => '#ffffff', 'whitesmoke' => '#f5f5f5',
        'yellow' => '#ffff00', 'yellowgreen' => '#9acd32',
    ];
    $key = strtolower(trim((string)$name));
    return $colors[$key] ?? $name;
}

/*********************************************
* FUNCTION: RISK LEVEL TILE IS LIGHT COLOR *
*********************************************/
// Decides whether a .sr-risk-level-tile needs the .on-light contrast
// modifier (charcoal text) instead of the default white -- the same
// luminance-based contrast pick risk-details-form.js's
// paintCvssRiskLevelTile() uses for the CVSS holder's own risk-level tile
// client-side (0.299/0.587/0.114 weights, >150 threshold), ported here
// because view_score_html() is plain server-rendered HTML with no client
// paint pass of its own. get_risk_color() can return a hex string OR a
// named CSS color -- risk_levels.color ships seeded with names (red/
// orangered/orange/yellow, includes/upgrade.php) and stays a name unless
// an admin later re-picks it via admin/risk_configuration.php's native
// <input type="color">, which always saves hex from then on.
//
// Every OTHER consumer of this same tile (risk-details-form.js's CVSS/
// DREAD/OWASP/Classic holders, risk-details-view.js's read-mode cards, and
// risk-view-details.js's post-load patchRiskSummaryTiles()) resolves the
// color through the BROWSER's own CSS engine first (assigning it to an
// element's style.color and reading back getComputedStyle()), so a named
// color already arrives here as real RGB and this exact bug never surfaces
// on any page that repaints client-side after load. management/
// print_view.php (no such repaint -- it renders once, server-side, on
// purpose) is what actually exposed it: "Medium"/orange read white text
// live (JS-repainted) vs. white-on-orange in print (server-rendered only),
// even though it's the SAME risk, the SAME color string, and the SAME
// 0.299/0.587/0.114/>150 formula on both sides -- css_named_color_to_hex()
// below is what the browser was doing for free that PHP wasn't.
function risk_level_tile_is_light_color($color)
{
    if (empty($color)) {
        return false;
    }
    if (strcasecmp($color, 'white') === 0) {
        return true;
    }
    if ($color[0] !== '#') {
        $color = css_named_color_to_hex($color);
    }
    if (empty($color) || $color[0] !== '#') {
        return false;
    }
    $hex = ltrim($color, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if (strlen($hex) !== 6 || !ctype_xdigit($hex)) {
        return false;
    }
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    $luminance = 0.299 * $r + 0.587 * $g + 0.114 * $b;
    return $luminance > 150;
}

/****************************
* FUNCTION: VIEW SCORE HTML *
****************************/
function view_score_html($risk_id, $calculated_risk, $mitigation_percent)
{
    global $lang, $escaper;

    // Inherent Risk
    // Stable ids -- the ONLY hook risk-view-details.js's saveDetailsForm()
    // success handler has to patch this tile's number/level/color after a
    // scoring save, since this whole block is plain server-rendered HTML
    // with no client-side render path of its own to refresh otherwise (see
    // api_get_ui_risk_values()'s 'risk_summary' key, api/v2/includes/api.php).
    // Markup/classes follow the .sr-risk-level-tile hero component
    // (scss/modules/_risks.scss) -- the same "solid, saturated, colored
    // chip" severity treatment as .sr-sev-pill/.sr-cvss-risk-level-tile
    // (design-system.md §7), sized for the record header. Fill color is
    // painted inline here (server-rendered, no client render pass of its
    // own) via escapeCssColor(), same mechanism those two components use.
    $inherent_color = get_risk_color($calculated_risk);
    echo "
                <div class='sr-risk-level-tile" . (risk_level_tile_is_light_color($inherent_color) ? " on-light" : "") . "' id='inherent-risk-tile' style='background-color: " . $escaper->escapeCssColor($inherent_color) . "'>
                    <div class='sr-risk-level-label'>" . $escaper->escapeHtml($lang['InherentRisk']) . "</div>
                    <div class='sr-risk-level-score' id='inherent-risk-score'>" . $escaper->escapeHtml($calculated_risk) . "</div>
                    <div class='sr-risk-level-name' id='inherent-risk-level'>" . $escaper->escapeHtml(get_risk_level_name($calculated_risk)) . "</div>
                </div>
    ";

    // Residual Risk
    if(!$calculated_risk || $calculated_risk == "0.0")
    {
        $residual_risk = "0";
    }
    else
    {
        $residual_risk = get_residual_risk($risk_id);
    }

    $residual_color = get_risk_color($residual_risk);
    echo "
                <div class='sr-risk-level-tile" . (risk_level_tile_is_light_color($residual_color) ? " on-light" : "") . "' id='residual-risk-tile' style='background-color: " . $escaper->escapeCssColor($residual_color) . "'>
                    <div class='sr-risk-level-label'>" . $escaper->escapeHtml($lang['ResidualRisk']) . "</div>
                    <div class='sr-risk-level-score' id='residual-risk-score'>" . $escaper->escapeHtml($residual_risk) . "</div>
                    <div class='sr-risk-level-name' id='residual-risk-level'>" . $escaper->escapeHtml(get_risk_level_name($residual_risk)) . "</div>
                </div>
    ";
}

/****************************
* FUNCTION: VIEW TOP TABLE *
****************************/
function view_top_table($risk_id, $calculated_risk, $subject, $status, $show_details = false, $mitigation_percent = 0, $display_risk = true)
{

    global $lang, $escaper;

    // Decrypt fields
    $subject = try_decrypt($subject);

    // Status -> the design-system.md §7 "state" pill family, by MEANING
    // rather than exact label -- `status` is free text on the `risks` table
    // (no enum), so an unrecognized/custom status still reads as a
    // reasonable in-progress state instead of falling back to plain,
    // unstyled text. The three values the workflow actually writes today
    // (see includes/functions.php's status assignments): New/Mitigation
    // Planned read as the spec's own "New, In Progress" info example;
    // Mgmt Reviewed as its "Reviewed" success example; Closed as its own
    // named neutral example.
    $status_pill_family = 'info';
    if ($status === 'Closed') {
        $status_pill_family = 'neutral';
    } elseif ($status === 'Mgmt Reviewed') {
        $status_pill_family = 'success';
    }

    echo "
        <div class='sr-risk-record-header'>
    ";
                view_score_html($risk_id, $calculated_risk, $mitigation_percent);
    echo "
            <div class='sr-qcard sr-risk-record-card'>
                <div class='sr-risk-record-top'>
                    <div class='sr-risk-record-meta'>
                        <div class='sr-qfield'>
                            <span class='sr-qlabel'>" . $escaper->escapeHtml($lang['IDNumber']) . "</span>
                            <span class='sr-qfield-value risk-id'>" . $escaper->escapeHtml($risk_id) . "</span>
                        </div>
                        <div class='sr-qfield sr-risk-record-status'>
                            <div id='static-status' class='static-status'>
                                <span class='sr-qlabel'>" . $escaper->escapeHtml($lang['Status']) . "</span>
                                <span class='sr-state-pill sr-state-" . $escaper->escapeHtmlAttr($status_pill_family) . " status-text'>" . $escaper->escapeHtml($status) . "</span>
    ";

    // Same gate as the Actions-menu "Change Status" item below (has_permission
    // check duplicated, not shared, since that item is inside the
    // $display_risk-only block further down and this one is not). Clicking
    // this swaps the pill for a <select> in place, same shape as Subject
    // below -- but it still submits through the EXISTING changestatus/
    // updateStatus flow (risk.js), not a parallel one: status changes are
    // not a simple text swap (closing/reopening carries real business logic
    // downstream, and a successful change re-renders the whole tab, unlike
    // Subject's narrower refresh), so only the PRESENTATION changed here,
    // not the underlying mechanism.
    if ($display_risk == true && has_permission("modify_risks")) {
        echo "
                                <button type='button' class='sr-row-action change-status' title='" . $escaper->escapeHtmlAttr($lang['ChangeStatus']) . "' aria-label='" . $escaper->escapeHtmlAttr($lang['ChangeStatus']) . "'>
                                    <i class='fa fa-edit' aria-hidden='true'></i>
                                </button>
        ";
    }

    echo "
                            </div>
                            <div class='edit-status d-none'></div>
                        </div>
                    </div>
    ";

    if($display_risk == true) {

        echo "
                    <div class='dropdown'>
                        <button type='button' class='sr-record-actions-trigger dropdown-toggle' data-bs-toggle='dropdown'>" . $escaper->escapeHtml($lang['RiskActions']) . "</button>
                        <ul class='dropdown-menu sr-record-actions-menu dropdown-menu-end'>
        ";

        // If the risk is closed, offer to reopen
        if ($status == "Closed") { 
            echo "
                                    <li><a class='reopen-risk dropdown-item' href='#'>" . $escaper->escapeHtml($lang['ReopenRisk']) . "</a></li>
            "; 
        }

        // Otherwise, offer to close
        else {
            // If the user has permission to close risks
            if (has_permission("close_risks")) {
                echo "
                                    <li><a class='close-risk dropdown-item' href='close.php?id=" . $escaper->escapeHtml($risk_id) . "'>" . $escaper->escapeHtml($lang['CloseRisk']) . "</a></li>
                ";
            }
        }

        // If the user has permission to modify risks
        if (has_permission("modify_risks"))
        {
            echo "
                                    <li><a class='edit-risk dropdown-item' href='view.php?action=editdetail&id=" . $escaper->escapeHtml($risk_id) . "'>" . $escaper->escapeHtml($lang['EditRisk']) . "</a></li>
            ";
        }

        // If the user has permission to plan mitigations
        if (has_permission("plan_mitigations"))
        {
            echo "
                                    <li><a class='edit-mitigation dropdown-item' href='#'>" . $escaper->escapeHtml($lang['PlanAMitigation']) . "</a></li>
            ";
        }

        // Check the review permissions for this risk id
        $approved = check_review_permission_by_risk_id($risk_id);

        // If the user has permission to review the current level
        if ($approved) {
            echo "
                                    <li><a class='risk-review-perform-from-actions dropdown-item' href='#'>" . $escaper->escapeHtml($lang['PerformAReview']) . "</a></li>
            ";
        }

        // Viewing review HISTORY is a read concern, not the (risk-level-
        // tiered) permission to submit a NEW one -- reaching this menu at
        // all already required riskmanagement + access to this risk, same
        // gate the modal's own endpoint enforces, so no extra check here.
        echo "
                                    <li><a class='risk-review-view-all-from-actions dropdown-item' href='#'>" . $escaper->escapeHtml($lang['ViewAllReviews']) . "</a></li>
        ";

        // Change Status moved out of this menu -- the Status pill's own
        // hover-revealed .sr-row-action.change-status icon (just above,
        // this same function) now does the same job in one fewer click,
        // and .change-status is still just a class-based delegate handler
        // (risk.js), so wiring stays with whichever element carries it.

        // If the user has permission to comment on risk management
        if (has_permission("comment_risk_management")) {
            echo "
                                    <li><a href='#comment' class='add-comment-menu dropdown-item'>" . $escaper->escapeHtml($lang['AddAComment']) . "</a></li>
            ";
        }
        // If the user has permission to plan mitigations
        if (has_permission("plan_mitigations")) {
            echo "
                                    <li><a class='mark-unmitigation dropdown-item' href='#'>" . $escaper->escapeHtml($lang['ResetMitigations']) . "</a></li>
            ";
        }

        // If the user has permission to plan mitigations
        if (has_permission("modify_risks")) {
            echo "
                                    <li><a class='mark-unreview dropdown-item' href='#'>" . $escaper->escapeHtml($lang['ResetReviews']) . "</a></li>
            ";
        }

        echo "
                                    <li><a class='printable-veiw dropdown-item' href='print_view.php?id=" . $escaper->escapeHtml($risk_id) . "' target='_blank'>" . $escaper->escapeHtml($lang['PrintableView']) . "</a></li>
                                </ul>
                            </div>
        ";
    }

    echo "
                    </div>
                    <div class='sr-risk-record-subject'>
                        <div id='static-subject' class='static-subject'>
                            <span class='sr-qlabel'>" . $escaper->escapeHtml($lang['Subject']) . "</span>
                            <span class='sr-qfield-value risk-subject'>" . $escaper->escapeHtml($subject) . "</span>
    ";

    // If we are displaying the risk and the user has modify risk permissions
    if($display_risk == true && has_permission("modify_risks")) {
        echo "
                            <button type='button' id='edit-subject' class='sr-row-action edit-subject-btn' title='" . $escaper->escapeHtmlAttr($lang['Edit']) . "' aria-label='" . $escaper->escapeHtmlAttr($lang['Edit']) . "'>
                                <i class='fa fa-edit' aria-hidden='true'></i>
                            </button>
        ";
    }

    echo "
                        </div>
                        <form name='details' method='post' action=''>
                            <input type='hidden' name='riskid' value='" . $escaper->escapeHtml($risk_id) . "'/>
                            <div class='edit-subject row d-none'>
                                <div class='d-flex align-items-center'>
                                    <input maxlength='" . (int)get_setting('maximum_risk_subject_length', 300) . "' class='form-control' type='text' name='subject' value='" . $escaper->escapeHtml($subject) . "' style='max-width:none;'/>
                                    <div class='sr-inline-edit-actions'>
                                        <button type='button' class='sr-row-action cancel-edit-subject' title='" . $escaper->escapeHtmlAttr($lang['Cancel']) . "' aria-label='" . $escaper->escapeHtmlAttr($lang['Cancel']) . "'>
                                            <i class='fa fa-xmark' aria-hidden='true'></i>
                                        </button>
                                        <button type='button' class='sr-row-action' name='update_subject' title='" . $escaper->escapeHtmlAttr($lang['Save']) . "' aria-label='" . $escaper->escapeHtmlAttr($lang['Save']) . "'>
                                            <i class='fa fa-check' aria-hidden='true'></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    ";

}

/*****************************
* FUNCTION: ADD RISK DETAILS *
*******************************/
function add_risk_details($template_group_id = "") {
    
    global $lang, $escaper;

    // Template group IDs are integer primary keys; casting keeps the value from reaching the markup below as a string
    $template_group_id = (int)$template_group_id;

    echo "
        <form name='submit_risk' method='post' action='' enctype='multipart/form-data' id='risk-submit-form'>
    ";

    // If customization extra is enabled
    if(customization_extra())
    {
        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        if(!$template_group_id) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }
        echo "
            <input type='hidden' name='template_group_id' id='template_group_id' value='{$template_group_id}' />
            <div class='row mb-2'>
                <div class='col-2 d-flex align-items-center justify-content-end'>
                    <label>" . $escaper->escapeHtml($lang['Subject']) . ":</label>
                </div>
                <div class='col-10'>
                    <input maxlength='" . (int)get_setting('maximum_risk_subject_length', 300) . "' title='" . $escaper->escapeHtml($lang['Subject']) . "' required name='subject' id='subject' class='form-control' type='text'>
                </div>
            </div>
        ";

        $active_fields = get_active_fields("risk", $template_group_id);

        // Top panel
        echo "
            <div class='row'>
                <div class='col-12 top-panel'>
        ";
                    display_main_detail_fields_by_panel_add('top', $active_fields, $template_group_id);
        echo "
                </div>
            </div>
            
            <div class='row'>
        ";
        // Left Panel
        echo "
                <div class='col-6 left-panel'>
        ";
                    display_main_detail_fields_by_panel_add('left', $active_fields, $template_group_id);
        echo "
                    &nbsp;
                </div>
        ";

        // Right Panel
        echo "
                <div class='col-6 right-panel'>
        ";
                    display_main_detail_fields_by_panel_add('right', $active_fields, $template_group_id);
        echo "
                    &nbsp;
                </div>
            </div>
        ";

        // Bottom panel
        echo "
            <div class='row'>
                <div class='col-12 bottom-panel'>
        ";
                    display_main_detail_fields_by_panel_add('bottom', $active_fields, $template_group_id);
        echo "
                    &nbsp;
                </div>
            </div>
        ";
    }
    else
    {
        echo "
            <div class='row mb-2'>
                <div class='col-2 d-flex align-items-center justify-content-end'>
                    <label>" . $escaper->escapeHtml($lang['Subject']) . ":</label>
                </div>
                <div class='col-10'>
                    <input maxlength='" . (int)get_setting('maximum_risk_subject_length', 300) . "' title='" . $escaper->escapeHtml($lang['Subject']) . "' required name='subject' id='subject' class='form-control' type='text'>
                </div>
            </div>
        ";

            display_risk_mapping_edit([], "top");

            display_threat_mapping_edit([], "top");

        echo "
            <div class='row'>
                <!-- first coulmn -->
                <div class='col-6 left-panel'>
        ";
                    display_category_edit('');

                    display_location_edit('');

                    display_external_reference_id_edit('');

                    display_control_regulation_edit('');

                    display_control_number_edit('');

                    display_affected_assets_edit('');

                    display_technology_edit('');

                    display_team_edit('');

                    display_additional_stakeholders_edit('');

                    display_owner_edit('');

                    display_owners_manager_edit('');

        echo "
                </div>
                <!-- first coulmn end -->

                <!-- second coulmn -->
                <div class='col-6 right-panel'>
            ";

                    display_risk_source_edit('');

                    risk_score_method_html();

                    display_risk_assessment_title_edit('');

                    display_additional_notes_edit('');

                    display_jira_issue_key_edit('');

                    display_supporting_documentation_add();

        echo "
                </div>
                <!-- second column end -->
                
            </div>
        ";
            display_risk_tags_edit();
    }

    echo "
            <div class='row'>
                <div class='col-12'>
                    <p>" . $escaper->escapeHtml($lang['NewRiskInstruction']) . "</p>
                    <div class='actions risk-form-actions d-flex justify-content-end align-items-center'>
                        <div>
                            <button type='button' name='submit' class='btn btn-submit text-end save-risk-form'>" . $escaper->escapeHtml($lang['SubmitRisk']) . "</button>
                            <button class='btn btn-secondary' id='reset_form' type='reset'>" . $escaper->escapeHtml($lang['ClearForm']) . " </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        
        <script>
            function reset_new_risk_form(reset_btn) {

                // To make sure the reset only affects the current tab
                var tab = $(reset_btn).closest('.tab-data');

                // reset the form
                $('form[name=submit_risk]', tab).trigger('reset');

                // re-draw the multiselects as they ARE reset, but their texts still display the previous selections
                $('form[name=submit_risk] span.multiselect-native-select select[multiple]', tab).multiselect('refresh');

                // Clear all the selectize widgets
                $('form[name=submit_risk] select.selectized', tab).each(function() {
                    $(this)[0].selectize.clear();
                });

                // Trigger the file removal logic for the added files
                $('form[name=submit_risk] .file-list .remove-file', tab).trigger('click');

                // Select the classic scoring and trigger a change event instead of click to make sure the logic runs properly
                $('#scoring_method', tab).find('option[value=1]').prop('selected', true).trigger('change');

            }
            $(document).ready(function(){
        		$('body').on('click', '#reset_form', function(){

                    // Reset the form
                    reset_new_risk_form(this);
                    
        		});
            });
        </script>
    ";

}

/*******************************
* FUNCTION: VIEW RISK DETAILS *
*******************************/
function view_risk_details($id, $submission_date, $submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping, $template_group_id="")
{

    global $lang;
    global $escaper;

    // Decrypt fields
    $subject = try_decrypt($subject);
    $assessment = try_decrypt($assessment);
    $notes = try_decrypt($notes);

    echo "
        <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['Details']) . "</h4>";

    //echo "<h4>". $escaper->escapeHtml($lang['Details']) ."</h4>\n";
        // If the page is the view.php page and the user has permission to modify risks
    if (basename($_SERVER['PHP_SELF']) == "view.php" && has_permission("modify_risks")) {
        // Give the option to edit the risk details
        echo "
        <div class='tabs--action position-absolute top-0 end-0'>
            <button type='submit' name='edit_details' class='btn btn-dark'>" . $escaper->escapeHtml($lang['EditDetails']) . "</button>
        </div>
        ";
    }

    // If customization extra is enabled
    if(customization_extra()) {
        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $template_group = get_custom_template_group_by_id($template_group_id);
        if(!$template_group_id || !$template_group) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }
        $active_fields = get_active_fields("risk", $template_group_id);

        // Top panel
        echo "
        <div class='row'>
            <div class='col-12 top-panel'>
        ";
                display_main_detail_fields_by_panel_view('top', $active_fields, $id, $submission_date, $submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
            </div>
        </div>
        
        <div class='row'>
        ";
        // Left Panel
        echo "
            <div class='col-6 left-panel'>
        ";
                display_main_detail_fields_by_panel_view('left', $active_fields, $id, $submission_date, $submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
            </div>
        ";

        // Right Panel
        echo "
            <div class='col-6 right-panel'>
        ";
                display_main_detail_fields_by_panel_view('right', $active_fields, $id, $submission_date, $submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
            </div>
        </div>
        ";

        // Bottom panel
        echo "
        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                display_main_detail_fields_by_panel_view('bottom', $active_fields, $id, $submission_date, $submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
            </div>
        </div>
        ";
    } else {
        echo "
        <div class='row'>
            <div class='col-12 top-panel'>
        ";
                display_risk_mapping_view($risk_catalog_mapping, "top");
                display_threat_mapping_view($threat_catalog_mapping, "top");
        echo "
            </div>
        </div>
        <div class='row'>
        ";
        // Left Panel
        echo "
            <div class='col-6 left-panel'>
        ";
                display_submission_date_view($submission_date);

                display_category_view($category);

                display_site_location_view($location);

                display_external_reference_id_view($reference_id);

                display_control_regulation_view($regulation);

                display_control_number_view($control_number);

                display_affected_assets_view($id);

                display_technology_view($technology);

                display_team_view($team);

                display_additional_stakeholders_view($additional_stakeholders);

                display_owner_view($owner);

                display_owner_manager_view($manager);
        echo "
            </div>
            
            <div class='col-6 right-panel'>
        ";
                display_submitted_by_view($submitted_by);

                display_risk_source_view($source);

                display_risk_scoring_method_view($scoring_method, $CLASSIC_likelihood, $CLASSIC_impact);

                display_risk_assessment_view($assessment);

                display_additional_notes_view($notes);
                
                display_supporting_documentation_view($id, 1);

                display_jira_issue_key_view($jira_issue_key);

        echo "
            </div>
        </div>
        
        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                display_risk_tags_view($tags);
        echo "
            </div>
        </div>
        ";
    }
}

/****************************************
* FUNCTION: VIEW PRINT RISK SCORE FORMS *
*****************************************/
function risk_score_method_html(
    $panel_name = "",
    $scoring_method = "1",
    $CLASSIC_likelihood = "",
    $CLASSIC_impact = "",
    $AccessVector = "N",
    $AccessComplexity = "L",
    $Authentication = "N",
    $ConfImpact = "C",
    $IntegImpact = "C",
    $AvailImpact = "C",
    $Exploitability = "ND",
    $RemediationLevel = "ND",
    $ReportConfidence = "ND",
    $CollateralDamagePotential = "ND",
    $TargetDistribution = "ND",
    $ConfidentialityRequirement = "ND",
    $IntegrityRequirement = "ND",
    $AvailabilityRequirement = "ND",
    $DREADDamagePotential = "10",
    $DREADReproducibility = "10",
    $DREADExploitability = "10",
    $DREADAffectedUsers = "10",
    $DREADDiscoverability = "10",
    $OWASPSkillLevel = "10",
    $OWASPMotive = "10",
    $OWASPOpportunity = "10",
    $OWASPSize = "10",
    $OWASPEaseOfDiscovery = "10",
    $OWASPEaseOfExploit = "10",
    $OWASPAwareness = "10",
    $OWASPIntrusionDetection = "10",
    $OWASPLossOfConfidentiality = "10",
    $OWASPLossOfIntegrity = "10",
    $OWASPLossOfAvailability = "10",
    $OWASPLossOfAccountability = "10",
    $OWASPFinancialDamage = "10",
    $OWASPReputationDamage = "10",
    $OWASPNonCompliance = "10",
    $OWASPPrivacyViolation = "10",
    $custom = false,
    $ContributingLikelihood = "",
    $ContributingImpacts = []
) {
    global $escaper, $lang;

    if ($custom === false) {
        $custom = get_setting("default_risk_score");
    }

    $span1 = ($panel_name == "top" || $panel_name == "bottom") ? "col-2" : "col-4";
    $span2 = ($panel_name == "top" || $panel_name == "bottom") ? "col-10" : "col-8";

    // Start building HTML
    $html = "
<div class='row mb-2 risk-details-edit-container'>
    <div class='{$span1} risk-details-edit-title d-flex align-items-center justify-content-end'>
        <label>" . $escaper->escapeHtml($lang['RiskScoringMethod']) . ":</label>
    </div>
    <div class='{$span2} risk-details-edit'>" .
        create_dropdown("scoring_methods", $scoring_method, "scoring_method", false, false, true) . "
    </div>
</div>
";

    // --- Classic scoring ---
    $html .= "
<div id='classic' class='classic-holder' style='display:" . ($scoring_method == 1 ? "block" : "none") . "'>
    <div class='row mb-2 risk-details-edit-container'>
        <div class='{$span1} risk-details-edit-title d-flex align-items-center justify-content-end'>
            <label>" . $escaper->escapeHtml($lang['CurrentLikelihood']) . ":</label>
        </div>
        <div class='{$span2} risk-details-edit'>" .
        create_dropdown('likelihood', $CLASSIC_likelihood, NULL, true, false, true) . "
        </div>
    </div>
    <div class='row mb-2 risk-details-edit-container'>
        <div class='{$span1} risk-details-edit-title d-flex align-items-center justify-content-end'>
            <label>" . $escaper->escapeHtml($lang['CurrentImpact']) . ":</label>
        </div>
        <div class='{$span2} risk-details-edit'>" .
        create_dropdown('impact', $CLASSIC_impact, NULL, true, false, true) . "
        </div>
    </div>
</div>
";

    // --- CVSS modal button & hidden inputs ---
    $html .= "
<div id='cvss' style='display:" . ($scoring_method == 2 ? "block" : "none") . "' class='cvss-holder'>
    <div class='row mb-2'>
        <div class='{$span1}'>&nbsp;</div>
        <div class='{$span2}'>
            <button type='button' id='cvssOpenModalBtn' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#cvssModal'>
                Score Using CVSS
            </button>
        </div>
    </div>
</div>
";

    // Include the modal itself
    ob_start();
    require_once realpath(__DIR__ . '/../management/partials/cvss_modal_content.php');
    $cvss_modal_html = ob_get_clean();
    $html .= $cvss_modal_html;

    // --- DREAD ---
    $html .= "
<div id='dread' style='display:" . ($scoring_method == 3 ? "block" : "none") . "' class='dread-holder'>
    <div class='row mb-2'>
        <div class='{$span1}'>&nbsp;</div>
        <div class='{$span2}'>
            <input type='button' class='btn btn-primary' name='dreadSubmit' id='dreadSubmit' value='Score Using DREAD' onclick='javascript: popupdread();' />
        </div>
    </div>
    <input type='hidden' name='DREADDamage' id='DREADDamage' value='{$escaper->escapeHtml($DREADDamagePotential)}' />
    <input type='hidden' name='DREADReproducibility' id='DREADReproducibility' value='{$escaper->escapeHtml($DREADReproducibility)}' />
    <input type='hidden' name='DREADExploitability' id='DREADExploitability' value='{$escaper->escapeHtml($DREADExploitability)}' />
    <input type='hidden' name='DREADAffectedUsers' id='DREADAffectedUsers' value='{$escaper->escapeHtml($DREADAffectedUsers)}' />
    <input type='hidden' name='DREADDiscoverability' id='DREADDiscoverability' value='{$escaper->escapeHtml($DREADDiscoverability)}' />
</div>
";

    // --- OWASP ---
    $html .= "
<div id='owasp' style='display:" . ($scoring_method == 4 ? "block" : "none") . "' class='owasp-holder'>
    <div class='row mb-2'>
        <div class='{$span1}'>&nbsp;</div>
        <div class='{$span2}'>
            <input type='button' class='btn btn-primary' name='owaspSubmit' id='owaspSubmit' value='Score Using OWASP' />
        </div>
    </div>
    <input type='hidden' name='OWASPSkillLevel' id='OWASPSkillLevel' value='{$escaper->escapeHtml($OWASPSkillLevel)}' />
    <input type='hidden' name='OWASPMotive' id='OWASPMotive' value='{$escaper->escapeHtml($OWASPMotive)}' />
    <input type='hidden' name='OWASPOpportunity' id='OWASPOpportunity' value='{$escaper->escapeHtml($OWASPOpportunity)}' />
    <input type='hidden' name='OWASPSize' id='OWASPSize' value='{$escaper->escapeHtml($OWASPSize)}' />
    <input type='hidden' name='OWASPEaseOfDiscovery' id='OWASPEaseOfDiscovery' value='{$escaper->escapeHtml($OWASPEaseOfDiscovery)}' />
    <input type='hidden' name='OWASPEaseOfExploit' id='OWASPEaseOfExploit' value='{$escaper->escapeHtml($OWASPEaseOfExploit)}' />
    <input type='hidden' name='OWASPAwareness' id='OWASPAwareness' value='{$escaper->escapeHtml($OWASPAwareness)}' />
    <input type='hidden' name='OWASPIntrusionDetection' id='OWASPIntrusionDetection' value='{$escaper->escapeHtml($OWASPIntrusionDetection)}' />
    <input type='hidden' name='OWASPLossOfConfidentiality' id='OWASPLossOfConfidentiality' value='{$escaper->escapeHtml($OWASPLossOfConfidentiality)}' />
    <input type='hidden' name='OWASPLossOfIntegrity' id='OWASPLossOfIntegrity' value='{$escaper->escapeHtml($OWASPLossOfIntegrity)}' />
    <input type='hidden' name='OWASPLossOfAvailability' id='OWASPLossOfAvailability' value='{$escaper->escapeHtml($OWASPLossOfAvailability)}' />
    <input type='hidden' name='OWASPLossOfAccountability' id='OWASPLossOfAccountability' value='{$escaper->escapeHtml($OWASPLossOfAccountability)}' />
    <input type='hidden' name='OWASPFinancialDamage' id='OWASPFinancialDamage' value='{$escaper->escapeHtml($OWASPFinancialDamage)}' />
    <input type='hidden' name='OWASPReputationDamage' id='OWASPReputationDamage' value='{$escaper->escapeHtml($OWASPReputationDamage)}' />
    <input type='hidden' name='OWASPNonCompliance' id='OWASPNonCompliance' value='{$escaper->escapeHtml($OWASPNonCompliance)}' />
    <input type='hidden' name='OWASPPrivacyViolation' id='OWASPPrivacyViolation' value='{$escaper->escapeHtml($OWASPPrivacyViolation)}' />
</div>
";

    // --- Custom ---
    $html .= "
<div id='custom' style='display:" . ($scoring_method == 5 ? "block" : "none") . "' class='custom-holder'>
    <div class='row mb-2'>
        <div class='{$span1} d-flex align-items-center justify-content-end'>
            <label>" . $escaper->escapeHtml($lang['CustomValue']) . ":</label>
        </div>
        <div class='{$span2} d-flex align-items-center'>
            <input class='form-control m-r-10' style='width: 70px;' type='number' min='0' step='0.1' max='10' name='Custom' id='Custom' value='{$escaper->escapeHtml($custom)}' />
            <small>(Must be a numeric value between 0 and 10)</small>
        </div>
    </div>
</div>
";

    // --- Contributing Risk ---
    $html .= "
<div id='contributing-risk' style='display:" . ($scoring_method == 6 ? "block" : "none") . "' class='contributing-risk-holder'>
    <div class='row mb-2'>
        <div class='{$span1}'>&nbsp;</div>
        <div class='{$span2}'>
            <input type='button' class='btn btn-primary' name='contributingRiskSubmit' id='contributingRiskSubmit' value='" . $escaper->escapeHtml($lang["ScoreUsingContributingRisk"]) ."' />
        </div>
    </div>
    <input type='hidden' name='ContributingLikelihood' id='contributing_likelihood' value='" . ($ContributingLikelihood ? $escaper->escapeHtml($ContributingLikelihood) : count(get_table("likelihood"))) . "' />";

    $max_impact_value = count(get_table("impact"));
    $contributing_risks = get_contributing_risks();
    foreach ($contributing_risks as $contributing_risk) {
        $html .= "
    <input type='hidden' class='contributing-impact' name='ContributingImpacts[{$contributing_risk['id']}]' id='contributing_impact_{$contributing_risk['id']}' value='" . $escaper->escapeHtml(empty($ContributingImpacts[$contributing_risk['id']]) ? $max_impact_value : $ContributingImpacts[$contributing_risk['id']]) . "' />";
    }
    $html .= "</div>";

    echo $html;
}

/*******************************
* FUNCTION: EDIT RISK DETAILS *
*******************************/
function edit_risk_details($id, $submission_date,$submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $AccessVector, $AccessComplexity, $Authentication, $ConfImpact, $IntegImpact, $AvailImpact, $Exploitability, $RemediationLevel, $ReportConfidence, $CollateralDamagePotential, $TargetDistribution, $ConfidentialityRequirement, $IntegrityRequirement, $AvailabilityRequirement, $DREADDamagePotential, $DREADReproducibility, $DREADExploitability, $DREADAffectedUsers, $DREADDiscoverability, $OWASPSkillLevel, $OWASPMotive, $OWASPOpportunity, $OWASPSize, $OWASPEaseOfDiscovery, $OWASPEaseOfExploit, $OWASPAwareness, $OWASPIntrusionDetection, $OWASPLossOfConfidentiality, $OWASPLossOfIntegrity, $OWASPLossOfAvailability, $OWASPLossOfAccountability, $OWASPFinancialDamage, $OWASPReputationDamage, $OWASPNonCompliance, $OWASPPrivacyViolation, $custom, $ContributingLikelihood, $ContributingImpacts, $tags, $jira_issue_key, $risk_catalog_mapping=[], $threat_catalog_mapping=[], $template_group_id="")
{

    global $lang;
    global $escaper;

    // Decrypt fields
    $subject = try_decrypt($subject);
    $assessment = try_decrypt($assessment);
    $notes = try_decrypt($notes);

    echo "
        <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['Details']) . "</h4>
        <div class='tabs--action position-absolute top-0 end-0'>
            <button type='button' class='btn btn-primary cancel-edit-details on-edit'>" . $escaper->escapeHtml($lang['Cancel']) . "</button>
            <button type='submit' name='update_details' class='btn btn-submit save-details on-edit'>" . $escaper->escapeHtml($lang['SaveDetails']) . "</button>
        </div>
    ";


    // If customization extra is enabled
    if(customization_extra()) {
        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $template_group = get_custom_template_group_by_id($template_group_id);
        if(!$template_group_id || !$template_group) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }
        $active_fields = get_active_fields("risk", $template_group_id);

        // Top panel
        echo "
        <div class='row'>
            <div class='col-12 top-panel'>
        ";
                display_main_detail_fields_by_panel_edit('top', $active_fields, $id, $submission_date,$submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $AccessVector, $AccessComplexity, $Authentication, $ConfImpact, $IntegImpact, $AvailImpact, $Exploitability, $RemediationLevel, $ReportConfidence, $CollateralDamagePotential, $TargetDistribution, $ConfidentialityRequirement, $IntegrityRequirement, $AvailabilityRequirement, $DREADDamagePotential, $DREADReproducibility, $DREADExploitability, $DREADAffectedUsers, $DREADDiscoverability, $OWASPSkillLevel, $OWASPMotive, $OWASPOpportunity, $OWASPSize, $OWASPEaseOfDiscovery, $OWASPEaseOfExploit, $OWASPAwareness, $OWASPIntrusionDetection, $OWASPLossOfConfidentiality, $OWASPLossOfIntegrity, $OWASPLossOfAvailability, $OWASPLossOfAccountability, $OWASPFinancialDamage, $OWASPReputationDamage, $OWASPNonCompliance, $OWASPPrivacyViolation, $custom, $ContributingLikelihood, $ContributingImpacts, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
            </div>
        </div>
        ";

        echo "
        <div class='row'>
        ";

        // Left Panel
        echo "
            <div class='col-6 left-panel'>
        ";
                display_main_detail_fields_by_panel_edit('left', $active_fields, $id, $submission_date,$submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $AccessVector, $AccessComplexity, $Authentication, $ConfImpact, $IntegImpact, $AvailImpact, $Exploitability, $RemediationLevel, $ReportConfidence, $CollateralDamagePotential, $TargetDistribution, $ConfidentialityRequirement, $IntegrityRequirement, $AvailabilityRequirement, $DREADDamagePotential, $DREADReproducibility, $DREADExploitability, $DREADAffectedUsers, $DREADDiscoverability, $OWASPSkillLevel, $OWASPMotive, $OWASPOpportunity, $OWASPSize, $OWASPEaseOfDiscovery, $OWASPEaseOfExploit, $OWASPAwareness, $OWASPIntrusionDetection, $OWASPLossOfConfidentiality, $OWASPLossOfIntegrity, $OWASPLossOfAvailability, $OWASPLossOfAccountability, $OWASPFinancialDamage, $OWASPReputationDamage, $OWASPNonCompliance, $OWASPPrivacyViolation, $custom, $ContributingLikelihood, $ContributingImpacts, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
                &nbsp;
            </div>
        ";

        // Right Panel
        echo "
            <div class='col-6 right-panel'>
        ";
                display_main_detail_fields_by_panel_edit('right', $active_fields, $id, $submission_date,$submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $AccessVector, $AccessComplexity, $Authentication, $ConfImpact, $IntegImpact, $AvailImpact, $Exploitability, $RemediationLevel, $ReportConfidence, $CollateralDamagePotential, $TargetDistribution, $ConfidentialityRequirement, $IntegrityRequirement, $AvailabilityRequirement, $DREADDamagePotential, $DREADReproducibility, $DREADExploitability, $DREADAffectedUsers, $DREADDiscoverability, $OWASPSkillLevel, $OWASPMotive, $OWASPOpportunity, $OWASPSize, $OWASPEaseOfDiscovery, $OWASPEaseOfExploit, $OWASPAwareness, $OWASPIntrusionDetection, $OWASPLossOfConfidentiality, $OWASPLossOfIntegrity, $OWASPLossOfAvailability, $OWASPLossOfAccountability, $OWASPFinancialDamage, $OWASPReputationDamage, $OWASPNonCompliance, $OWASPPrivacyViolation, $custom, $ContributingLikelihood, $ContributingImpacts, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
                &nbsp;
            </div>
        </div>
        ";

        // Bottom panel
        echo "
        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                display_main_detail_fields_by_panel_edit('bottom', $active_fields, $id, $submission_date,$submitted_by, $subject, $reference_id, $regulation, $control_number, $location, $source, $category, $team, $additional_stakeholders, $technology, $owner, $manager, $assessment, $notes, $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $AccessVector, $AccessComplexity, $Authentication, $ConfImpact, $IntegImpact, $AvailImpact, $Exploitability, $RemediationLevel, $ReportConfidence, $CollateralDamagePotential, $TargetDistribution, $ConfidentialityRequirement, $IntegrityRequirement, $AvailabilityRequirement, $DREADDamagePotential, $DREADReproducibility, $DREADExploitability, $DREADAffectedUsers, $DREADDiscoverability, $OWASPSkillLevel, $OWASPMotive, $OWASPOpportunity, $OWASPSize, $OWASPEaseOfDiscovery, $OWASPEaseOfExploit, $OWASPAwareness, $OWASPIntrusionDetection, $OWASPLossOfConfidentiality, $OWASPLossOfIntegrity, $OWASPLossOfAvailability, $OWASPLossOfAccountability, $OWASPFinancialDamage, $OWASPReputationDamage, $OWASPNonCompliance, $OWASPPrivacyViolation, $custom, $ContributingLikelihood, $ContributingImpacts, $tags, $jira_issue_key, $risk_catalog_mapping, $threat_catalog_mapping);
        echo "
                &nbsp;
            </div>
        </div>
        ";
    } else {
        echo "
        <div class='row'>
            <div class='col-12 top-panel'>
        ";
                display_risk_mapping_edit($risk_catalog_mapping, "top");

                display_threat_mapping_edit($threat_catalog_mapping, "top");
        echo "
            </div>
        </div>
        <div class='row'>
            <div class='col-6 left-panel'>
        ";
                display_submission_date_edit($submission_date);

                display_category_edit($category);

                display_location_edit($location);

                display_external_reference_id_edit($reference_id);

                display_control_regulation_edit($regulation);

                display_control_number_edit($control_number);

                display_affected_assets_edit($id);

                display_technology_edit($technology);

                display_team_edit($team);

                display_additional_stakeholders_edit($additional_stakeholders);

                display_owner_edit($owner);

                display_owners_manager_edit($manager);
        echo "
            </div>
            
            <div class='col-6 right-panel'>
        ";
                display_risk_source_edit($source);

                risk_score_method_html("", $scoring_method, $CLASSIC_likelihood, $CLASSIC_impact, $AccessVector, $AccessComplexity, $Authentication, $ConfImpact, $IntegImpact, $AvailImpact, $Exploitability, $RemediationLevel, $ReportConfidence, $CollateralDamagePotential, $TargetDistribution, $ConfidentialityRequirement, $IntegrityRequirement, $AvailabilityRequirement, $DREADDamagePotential, $DREADReproducibility, $DREADExploitability, $DREADAffectedUsers, $DREADDiscoverability, $OWASPSkillLevel, $OWASPMotive, $OWASPOpportunity, $OWASPSize, $OWASPEaseOfDiscovery, $OWASPEaseOfExploit, $OWASPAwareness, $OWASPIntrusionDetection, $OWASPLossOfConfidentiality, $OWASPLossOfIntegrity, $OWASPLossOfAvailability, $OWASPLossOfAccountability, $OWASPFinancialDamage, $OWASPReputationDamage, $OWASPNonCompliance, $OWASPPrivacyViolation, $custom, $ContributingLikelihood, $ContributingImpacts);

                display_risk_assessment_title_edit($assessment);

                display_additional_notes_edit($notes);
                
                display_supporting_documentation_edit($id, 1);

                display_jira_issue_key_edit($jira_issue_key);
        echo "
            </div>
        </div>";

        display_risk_tags_edit($tags);
    }
}

/*************************************
* FUNCTION: VIEW MITIGATION DETAILS *
*************************************/
function view_mitigation_details($risk_id, $mitigation_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team, $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $template_group_id="")
{
    global $lang;
    global $escaper;

    // Decrypt fields
    $current_solution = try_decrypt($current_solution);
    $security_requirements = try_decrypt($security_requirements);
    $security_recommendations = try_decrypt($security_recommendations);

    echo "
        <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['Mitigation']) . "</h4>
    ";

    if (basename($_SERVER['PHP_SELF']) == "view.php" && has_permission("plan_mitigations")) {
        // Give the option to edit the mitigation details
        echo "
        <div class='tabs--action position-absolute top-0 end-0'>
            <button type='submit' name='edit_mitigation' class='btn btn-dark'>" . $escaper->escapeHtml($lang['EditMitigation']) . "</button>
        </div>
        ";
    }

    // If customization extra is enabled
    if(customization_extra()) {
        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $template_group = get_custom_template_group_by_id($template_group_id);
        if(!$template_group_id || !$template_group) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }
        $active_fields = get_active_fields("risk", $template_group_id);

        echo "
        <div class='row'>
        ";

        // Left Panel
        echo "
            <div class='col-6 left-panel'>
        ";
                display_main_mitigation_fields_by_panel_view('left', $active_fields, $risk_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team, $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $mitigation_id);
        echo "
                &nbsp;
            </div>
        ";

        // Right Panel
        echo "
            <div class='col-6 right-panel'>
        ";
                display_main_mitigation_fields_by_panel_view('right', $active_fields, $risk_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team, $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $mitigation_id);
        echo "
                &nbsp;
            </div>
        </div>
        ";

        // Bottom panel
        echo "
        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                display_main_mitigation_fields_by_panel_view('bottom', $active_fields, $risk_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team, $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $mitigation_id);
        echo "
                &nbsp;
            </div>
        </div>
        ";
    } else {
        echo "
        <div class='row'>
        ";

        // Left Panel
        echo "
            <div class='col-6 left-panel'>
        ";

                display_mitigation_submission_date_view($mitigation_date);

                display_mitigation_planning_date_view($planning_date);

                display_mitigation_planning_strategy_view($planning_strategy);

                display_mitigation_effort_view($mitigation_effort);

                display_mitigation_cost_view($mitigation_cost);

                display_mitigation_owner_view($mitigation_owner);

                display_mitigation_team_view($mitigation_team);

                display_mitigation_percent_view($mitigation_percent);

                display_accept_mitigation_view($risk_id);

        echo "
            </div>
        ";

        // Right Panel
        echo "
            <div class='col-6 right-panel'>
        ";

                display_current_solution_view($current_solution);

                display_security_requirements_view($security_requirements);

                display_security_recommendations_view($security_recommendations);

                display_supporting_documentation_view($risk_id, 2);

        echo "
            </div>
        </div>
        ";

        // Bottom panel
        echo "
        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                print_mitigation_controls_table($mitigation_controls,$mitigation_id,"view");
        echo "
            </div>
        </div>
        ";
    }
}

/*************************************
* FUNCTION: EDIT MITIGATION DETAILS *
*************************************/
function edit_mitigation_details($risk_id, $mitigation_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team,  $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $template_group_id="")
{

    global $lang;
    global $escaper;

    // Decrypt fields
    $current_solution = try_decrypt($current_solution);
    $security_requirements = try_decrypt($security_requirements);
    $security_recommendations = try_decrypt($security_recommendations);

    echo "
        <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['Mitigation']) . "</h4>
        <div class='tabs--action position-absolute top-0 end-0'>
            <button type='button' class='btn btn-primary cancel-edit-mitigation'>" . $escaper->escapeHtml($lang['Cancel']) . "</button>
            <button type='submit' name='update_mitigation' class='btn btn-submit'>" . $escaper->escapeHtml($lang['SaveMitigation']) . "</button>
        </div>
    ";

    // If customization extra is enabled
    if(customization_extra())
    {
        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $template_group = get_custom_template_group_by_id($template_group_id);
        if(!$template_group_id || !$template_group) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }
        $active_fields = get_active_fields("risk", $template_group_id);

        echo "
        <div class='row'>
        ";
        // Left Panel
        echo "
            <div class='col-6 left-panel'>
        ";
                display_main_mitigation_fields_by_panel_edit('left', $active_fields, $risk_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team,  $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $mitigation_id);
        echo "
            </div>
        ";
        // Right Panel
        echo "
            <div class='col-6 right-panel'>
        ";
                display_main_mitigation_fields_by_panel_edit('right', $active_fields, $risk_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team,  $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $mitigation_id);
        echo "
            </div>
        </div>
        ";
        // Bottom panel
        echo "
        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                display_main_mitigation_fields_by_panel_edit('bottom', $active_fields, $risk_id, $mitigation_date, $planning_strategy, $mitigation_effort, $mitigation_cost, $mitigation_owner, $mitigation_team,  $current_solution, $security_requirements, $security_recommendations, $planning_date, $mitigation_percent, $mitigation_controls, $mitigation_id);
        echo "
            </div>
        </div>
        ";
    } else {
        echo "
        <div class='row'>
            <div class='col-6 left-panel'>
                <input type='hidden' name='tab_type' value='1' />
        ";
                display_mitigation_submission_date_edit($mitigation_date);

                display_mitigation_planning_date_edit($planning_date);

                display_mitigation_planning_strategy_edit($planning_strategy);

                display_mitigation_effort_edit($mitigation_effort);

                display_mitigation_cost_edit($mitigation_cost);

                display_mitigation_owner_edit($mitigation_owner);

                display_mitigation_team_edit($mitigation_team);

                display_mitigation_percent_edit($mitigation_percent);

                display_mitigation_controls_edit($mitigation_controls);
        echo "
            </div>
            <div class='col-6 right-panel'>
        ";
                display_current_solution_edit($current_solution);

                display_security_requirements_edit($security_requirements);

                display_security_recommendations_edit($security_recommendations);

                display_supporting_documentation_edit($risk_id, 2);
        echo "
            </div>
        </div>

        <div class='row'>
            <div class='col-12 bottom-panel'>
        ";
                // Add controls table html
                print_mitigation_controls_table($mitigation_controls,$mitigation_id,"edit");

                // Add javascript code for mitigation controls
                display_mitigation_controls_script();
        echo "
            </div>
        </div>
        ";
    }
}

/********************************************************************************************************************************
* FUNCTION: Display Mitigation Controls Dropdown                                                                                *
* Renders the mitigation controls dropdown. Can be used in multiple places due to its configurability.                          *
* selected_control_ids_string: the selected control ids as a comma separated string                                             *
* element_name: name of the rendered element                                                                                    *
* initialize: A boolean to sign whether the initialozation of the multiselect is required                                       *
* datatable_redraw: A boolean that tells the rendering logic whether the mitigation control details                             *
                    datatable is present on the page and needs logic to refresh it when the selection of the dropdown changed.  *
*********************************************************************************************************************************/
function mitigation_controls_dropdown($selected_control_ids_string = "", $element_name = "mitigation_controls[]", $initialize = true, $datatable_redraw = false) {

    global $lang, $escaper;

    require_once(realpath(__DIR__ . '/governance.php'));
    $controls = get_framework_controls_dropdown_data();

    if ($controls && !empty($controls)) {
        $selected_control_ids = empty($selected_control_ids_string) ? [] : explode(",", $selected_control_ids_string);
        $eID = "mitigation_controls_" . generate_token(10);

        echo  "
            <select id='{$eID}' name='{$element_name}' title='{$escaper->escapeHtml($lang['MitigationControls'])}' class='mitigation_controls' multiple='multiple'>
        ";

        foreach ($controls as $control) {
            if (in_array($control['id'], $selected_control_ids)) {
                echo "
                <option value='{$control['id']}' selected title='{$escaper->escapeHtml($control['long_name'])}'>{$escaper->escapeHtml($control['short_name'])}</option>
                ";
            } else {
                echo "
                <option value='{$control['id']}' title='{$escaper->escapeHtml($control['long_name'])}'>{$escaper->escapeHtml($control['short_name'])}</option>
                ";
            }
        }

        echo "
            </select>
        ";
    
        if ($initialize) {
            echo "
            <script>
                $(document).ready(function(){
                    // Because it is initialized separately from the other multiselects it needs to move to the end of the call stack
                    // so the multiple initialization calls won't interfere with each-other's DOM manipulations  
                    setTimeout(() => {
                        $('#{$eID}').multiselect({
                            enableFiltering: true,
                            enableCaseInsensitiveFiltering: true,
                            buttonWidth: '100%',
                            maxHeight: 250,
                            dropUp: true,
                            filterPlaceholder: '{$escaper->escapeHtml($lang["SelectForMitigationControls"])}'" . ($datatable_redraw ? ",
                            onDropdownHide: function() {
                                var form = $('#{$eID}').parents('form');
                                var tableId = $('.mitigation-controls-table-container', form).data('tableid');
                                $('#' + tableId).DataTable().draw();
                            }" : "") . "
                        });
                    }, 0);
                });
            </script>
            ";
        }
    
    } else {
        echo "
            <span style='vertical-align: middle;'><strong>{$escaper->escapeHtml($lang['NoControlsAvailable'])}</strong></span>
        ";
    }
}

/**********************************************
* FUNCTION: Display Mitigation Controls Table *
***********************************************/
function print_mitigation_controls_table($control_ids, $mitigation_id, $flag="view") {

    global $lang, $escaper;

    $key = uniqid(rand());
    $tableID = "mitigation-controls-table" . $key;

    echo "
        <br>
        <input type='hidden' value='" . $escaper->escapeHtml($control_ids) . "' class='active-textfield mitigation_control_ids' />
        <div class='row mb-2 mitigation-controls-table-container hide' data-tableid='{$tableID}'>
            <div class='accordion'>
                <div class='accordion-item'>
                    <h2 class='accordion-header'>
                        <button type='button' class='accordion-button' data-bs-toggle='collapse' data-bs-target='#{$tableID}-accordion-body'>Mitigation Controls</button>
                    </h2>
                    <div id='{$tableID}-accordion-body' class='accordion-collapse'>
                        <div class='accordion-body'>
                            <table id='{$tableID}' width='100%'>
                                <thead style='display:none;'>
                                    <tr>
                                        <th>&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
        <script>
            $(document).ready(function(){
                var mitigationControlDatatable = $('#{$tableID}').DataTable({
                    scrollX: true,
                    searching: false,
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    ajax: {
                        url: BASE_URL + '/api/v2/datatable/mitigation_controls',
                        type: 'POST',
                        data: function(d){
                            var form = $('#{$tableID}').parents('form');
                            d.flag = '{$flag}';
                            d.mitigation_id = '{$mitigation_id}';
                            if($('.mitigation_controls', form).length){
                                d.control_ids = $('.mitigation_controls', form).val().join(',');
                            }
                            else{
                                d.control_ids = $('.mitigation_control_ids', form).val();
                            }
                        },
                        complete: function(xhr){
                            var json = DataTable.parseCompleteResponse(xhr);
                            if(json && Number(json.recordsTotal) > 0){
                                $('#{$tableID}').parents('.mitigation-controls-table-container').removeClass('hide');
                            }else{
                                $('#{$tableID}').parents('.mitigation-controls-table-container').addClass('hide');
                            }
                        }
                    }
                });
            });
        </script>
    ";
}

/*******************************************
* FUNCTION: Add Mitigation Controls Script *
********************************************/
function display_mitigation_controls_script(){
    echo "
        <script language='javascript'>
            $(document).ready(function(){
                /**
                * events in clicking Select Mitigating Controls
                */
                $('body').on('click', '.select-mitigating-controls', function(e){
                    e.preventDefault();
                    var form = $(this).parents('form');
                    var mitigation_controls = $('input[name=mitigation_controls]', form).val();
                    var mitigation_controls_array = mitigation_controls.split(',');
                    mitigation_controls_array = mitigation_controls_array.map(function(value){ return parseInt(value); });

                    $('.mitigating-controls-modal input[type=checkbox]', form).each(function(){
                        if(mitigation_controls_array.indexOf(parseInt($(this).val())) > -1){
                            $(this).prop('checked', true);
                        }
                    })
                    $('.mitigating-controls-modal', form).modal();
                })

                /**
                * events in clicking Add button on Mitigation Controls modal
                */
                $('body').on('click', '.mitigating-controls-modal [name=add_controls]', function(e){
                    e.preventDefault();
                    var form = $(this).parents('form');
                    var mitigation_controls_array = [];
                    var mitigation_control_names_array = [];
                    $('.mitigating-controls-modal input[type=checkbox]', form).each(function(){
                        if($(this).is(':checked')){
                            mitigation_controls_array.push(parseInt($(this).val()));
                            mitigation_control_names_array.push($(this).parent().find('.name').html());
                        }
                    })
                    var mitigation_controls = mitigation_controls_array.join(',');
                    var mitigation_control_names = mitigation_control_names_array.join(', ');
                    $('input[name=mitigation_controls]', form).val(mitigation_controls);
                    $('.mitigation_control_names', form).html(mitigation_control_names);
                    $('.mitigating-controls-modal', form).modal('hide');

                    var tableId = $('.mitigation-controls-table-container', form).data('tableid');
                    $('#' + tableId).DataTable().draw();
                })
            })
        </script>
    ";
}

/*********************************
* FUNCTION: view_review_details *
*********************************/
function view_review_details($id, $review_id, $review_date, $reviewer, $review, $next_step, $next_review, $comment, $template_group_id="")
{
    global $lang;
    global $escaper;

    // Decrypt fields
    $comment = try_decrypt($comment);

    echo "
        <div class='tabs--action position-absolute top-0 end-0'>
            <button type='submit' name='view_all_reviews' class='btn btn-dark all_reviews_btn'>" . $escaper->escapeHtml($lang['ViewAllReviews']) . "</button>
            <input type='hidden' id='lang_last_review' value='" . $escaper->escapeHtml($lang['LastReview']) . "' />
            <input type='hidden' id='lang_all_reviews' value='" . $escaper->escapeHtml($lang['ViewAllReviews']) . "' />
        </div>
        
        <div class='current_review'>
            <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['LastReview']) . "</h4>
    ";

    // If customization extra is enabled
    if(customization_extra()) {

        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $template_group = get_custom_template_group_by_id($template_group_id);
        if(!$template_group_id || !$template_group) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }

        $active_fields = get_active_fields("risk", $template_group_id);

        echo "
            <div class='row'>
        ";

        // Left Panel
        echo "
                <div class='col-6 left-panel'>
        ";
                    display_main_review_fields_by_panel_view('left', $active_fields, $id, $review_id, $review_date, $reviewer, $review, $next_step, $next_review, $comment);
        echo "
                </div>
        ";

        // Right Panel
        echo "
                <div class='col-6 right-panel'>
        ";
                    display_main_review_fields_by_panel_view('right', $active_fields, $id, $review_id, $review_date, $reviewer, $review, $next_step, $next_review, $comment);
        echo "
                </div>
            </div>
        ";

        // Bottom panel
        echo "
            <div class='row'>
                <div class='col-12 bottom-panel'>
        ";
                    display_main_review_fields_by_panel_view('bottom', $active_fields, $id, $review_id, $review_date, $reviewer, $review, $next_step, $next_review, $comment);
        echo "
                </div>
            </div>
        ";

    } else {

        echo "
            <div class='row'>
                <div class='col-6 left-panel'>
        ";
                    display_review_date_view($review_date);

                    display_reviewer_view($reviewer);

                    display_review_view($review);

                    display_next_step_view($next_step, $id);

                    display_next_review_date_view($next_review);

                    display_comments_view($comment);
        echo "
                </div>
            </div>
        ";
    }

    echo "
        </div>
        <div class='all_reviews' style='display:none;'>
            <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['ReviewHistory']) . "</h4>
    ";
            get_reviews($id, $template_group_id);
    echo "
        </div>
    ";
}

/************************************
* FUNCTION: edit_review_submission *
************************************/
function edit_review_submission($id, $review_id, $review, $next_step, $next_review, $comment, $default_next_review, $template_group_id="")
{

    global $lang;
    global $escaper;

    // Decrypt fields
    $comment = try_decrypt($comment);

    echo "
        <h4 class='m-b-25'>" . $escaper->escapeHtml($lang['SubmitManagementReview']) . "</h4>
        <form name='submit_management_review' method='post' action=''>
            <div class='tabs--action position-absolute top-0 end-0'>
    ";
    //    echo "<input id=\"cancel_disable\" class=\"btn cancel-edit-review \" value=\"". $escaper->escapeHtml($lang['Cancel']) ."\" type=\"reset\">\n";
    echo "
                <button type='button' id='cancel_disable' class='btn btn-primary cancel-edit-review'>Cancel</button>
                <button type='submit' name='submit' class='btn btn-danger save-review'>" . $escaper->escapeHtml($lang['SubmitReview']) . "</button>
            </div>
    ";

    // If customization extra is enabled
    if(customization_extra()) {

        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        
        $template_group = get_custom_template_group_by_id($template_group_id);
        if(!$template_group_id || !$template_group) {
            $group = get_default_template_group("risk");
            $template_group_id = $group["id"];
        }
        $active_fields = get_active_fields("risk", $template_group_id);

        echo "
            <div class='row'>
        ";
        // Left Panel
        echo "
                <div class='col-6 left-panel'>
        ";
                    display_main_review_fields_by_panel_edit('left', $active_fields, $id, $review_id, $review, $next_step, $next_review, $comment, $default_next_review);
        echo "
                </div>
        ";
        // Right Panel
        echo "
                <div class='col-6 right-panel'>
        ";
                    display_main_review_fields_by_panel_edit('right', $active_fields, $id, $review_id, $review, $next_step, $next_review, $comment, $default_next_review);
        echo "
                </div>
            </div>
        ";
        // Bottom panel
        echo "
            <div class='row'>
                <div class='col-12 bottom-panel'>
        ";
                    display_main_review_fields_by_panel_edit('bottom', $active_fields, $id, $review_id, $review, $next_step, $next_review, $comment, $default_next_review);
        echo "
                </div>
            </div>
        ";

    } else {

        echo "
            <div class='row-fluid'>
                <div class='span5 left-panel'>
        ";
                    display_review_date_edit();

                    display_reviewer_name_edit();

                    display_review_edit($review);

                    display_next_step_edit($next_step);

                    display_comments_edit($comment);

        echo "
                </div>
                <div class='span5 right-panel'>
        ";
                    display_set_next_review_date_edit($default_next_review);
        echo "
                </div>
            </div>
        ";
    
    }

    echo "
        </form>
    ";

    return;
    
}


/*******************************
* FUNCTION: VIEW CLASSIC HELP *
*******************************/
function view_classic_help()
{

    global $escaper;

    // Get the arrray of likelihood values
    $likelihoods = get_table("likelihood");

    $likelihoods_description = array(
        "May only occur in exceptional circumstances.",
        "Expected to occur in a few circumstances.",
        "Expected to occur in some circumstances.",
        "Expected to occur in many circumstances.",
        "Expected to occur frequently and in most circumstances."
    );

    // Get the array of impact values
    $impacts = get_table("impact");

    $impacts_description = array(
        "No impact on service, no impact on reputation, complaint unlikely, or litigation risk remote.",
        "Slight impact on service, slight impact on reputation, complaint possible, or litigation possible.",
        "Some service disruption, potential for adverse publicity (avoidable with careful handling), complaint probable, or litigation probably.",
        "Service disrupted, adverse publicity not avoidable (local media), complaint probably, or litigation probable.",
        "Service interrupted for significant time, major adverse publicity not avoidable (national media), major litigation expected, resignation of senior management and board, or loss of benficiary confidence."
    );

    echo "
        <div id='divHelp' style='width:100%;overflow:auto'></div>
        <div id='likelihoodHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
    ";

    foreach($likelihoods as $index => $likelihood) {

        $description = isset($likelihoods_description[$index]) ? $likelihoods_description[$index] : "";

        echo "
                        <p><b>" . $escaper->escapeHtml($likelihood['name']) . ":</b> " . $description . "</p>
        ";
    }

    echo "
                    </td>
                </tr>
            </table>
        </div>
        
        <div id='impactHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
    ";

    foreach($impacts as $index => $impact) {

        $description = isset($impacts_description[$index]) ? $impacts_description[$index] : "";

        echo "
                        <p><b>" . $escaper->escapeHtml($impact['name']) . ":</b> " . $description . "</p>
        ";
    }

    echo "
                    </td>
                </tr>
            </table>
        </div>
    ";
}

/*****************************
* FUNCTION: VIEW OWASP HELP *
*****************************/
function view_owasp_help()
{
    echo "
        <div id='divHelp' style='width:100%;overflow:auto'></div>

        <div id='SkillLevelHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How technically skilled is this group of threat agents?</b></p>
                        <p>1 = No Technical Skills</p>
                        <p>3 = Some Technical Skills</p>
                        <p>5 = Advanced Computer User</p>
                        <p>6 = Network and Programming Skills</p>
                        <p>9 = Security Penetration Skills</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='MotiveHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How motivated is this group of threat agents to find and exploit this vulnerability?</b></p>
                        <p>1 = Low or No Reward</p>
                        <p>4 = Possible Reward</p>
                        <p>9 = High Reward</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='OpportunityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>What resources and opportunity are required for this group of threat agents to find and exploit this vulnerability?</b></p>
                        <p>0 = Full Access or Expensive Resources Required</p>
                        <p>4 = Special Access or Resources Required</p>
                        <p>7 = Some Access or Resources Required</p>
                        <p>9 = No Access or Resources Required</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='SizeHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How large is this group of threat agents?</b></p>
                        <p>2 = Developers</p>
                        <p>2 = System Administrators</p>
                        <p>4 = Intranet Users</p>
                        <p>5 = Partners</p>
                        <p>6 = Authenticated Users</p>
                        <p>9 = Anonymous Internet Users</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='EaseOfDiscoveryHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How easy is it for this group of threat agents to discover this vulnerability?</b></p>
                        <p>1 = Practically Impossible</p>
                        <p>3 = Difficult</p>
                        <p>7 = Easy</p>
                        <p>9 = Automated Tools Available</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='EaseOfExploitHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How easy is it for this group of threat agents to actually exploit this vulnerability?</b></p>
                        <p>1 = Theoretical</p>
                        <p>3 = Difficult</p>
                        <p>5 = Easy</p>
                        <p>9 = Automated Tools Available</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='AwarenessHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How well known is this vulnerability to this group of threat agents?</b></p>
                        <p>1 = Unknown</p>
                        <p>4 = Hidden</p>
                        <p>6 = Obvious</p>
                        <p>9 = Public Knowledge</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='IntrusionDetectionHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How likely is an exploit to be detected?</b></p>
                        <p>1 = Active Detection in Application</p>
                        <p>3 = Logged and Reviewed</p>
                        <p>8 = Logged Without Review</p>
                        <p>9 = Not Logged</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='LossOfConfidentialityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How much data could be disclosed and how sensitive is it?</b></p>
                        <p>2 = Minimal Non-Sensitive Data Disclosed</p>
                        <p>6 = Minimal Critical Data Disclosed</p>
                        <p>6 = Extensive Non-Sensitive Data Disclosed</p>
                        <p>7 = Extensive Critical Data Disclosed</p>
                        <p>9 = All Data Disclosed</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='LossOfIntegrityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How much data could be corrupted and how damaged is it?</b></p>
                        <p>1 = Minimal Slightly Corrupt Data</p>
                        <p>3 = Minimal Seriously Corrupt Data</p>
                        <p>5 = Extensive Slightly Corrupt Data</p>
                        <p>7 = Extensive Seriously Corrupt Data</p>
                        <p>9 = All Data Totally Corrupt</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='LossOfAvailabilityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How much service could be lost and how vital is it?</b></p>
                        <p>1 = Minimal Secondary Services Interrupted</p>
                        <p>5 = Minimal Primary Services Interrupted</p>
                        <p>5 = Extensive Secondary Services Interrupted</p>
                        <p>7 = Extensive Primary Services Interrupted</p>
                        <p>9 = All Services Completely Lost</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='LossOfAccountabilityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>Are the threat agents' actions traceable to an individual?</b></p>
                        <p>1 = Fully Traceable</p>
                        <p>7 = Possibly Traceable</p>
                        <p>9 = Completely Anonymous</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='FinancialDamageHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How much financial damage will result from an exploit?</b></p>
                        <p>1 = Less than the Cost to Fix the Vulnerability</p>
                        <p>3 = Minor Effect on Annual Profit</p>
                        <p>7 = Significant Effect on Annual Profit</p>
                        <p>9 = Bankruptcy</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='ReputationDamageHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>Would an exploit result in reputation damage that would harm the business?</b></p>
                        <p>1 = Minimal Damage</p>
                        <p>4 = Loss of Major Accounts</p>
                        <p>5 = Loss of Goodwill</p>
                        <p>9 = Brand Damage</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='NonComplianceHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How much exposure does non-compliance introduce?</b></p>
                        <p>2 = Minor Violation</p>
                        <p>5 = Clear Violation</p>
                        <p>7 = High Profile Violation</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='PrivacyViolationHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How much personally identifiable information could be disclosed?</b></p>
                        <p>3 = One Individual</p>
                        <p>5 = Hundreds of People</p>
                        <p>7 = Thousands of People</p>
                        <p>9 = Millions of People</p>
                    </td>
                </tr>
            </table>
        </div>
    ";
}

/*****************************
* FUNCTION: VIEW CVSS HELP *
*****************************/
function view_cvss_help()
{
    echo "
        <div id='divHelp' style='width:100%;overflow:auto'></div>
        <div id='AccessVectorHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Local</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A vulnerability exploitable with only local access requires the attacker to have either physical access to the vulnerable system or a local (shell) account.  Examples of locally exploitable vulnerabilities are peripheral attacks such as Firewire/USB DMA attacks, and local privilege escalations (e.g., sudo).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Adjacent Network</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A vulnerability exploitable with adjacent network access requires the attacker to have access to either the broadcast or collision domain of the vulnerable software.  Examples of local networks include local IP subnet, Bluetooth, IEEE 802.11, and local Ethernet segment.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Network</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A vulnerability exploitable with network access means the vulnerable software is bound to the network stack and the attacker does not require local network access or local access.  Such a vulnerability is often termed 'remotely exploitable'.  An example of a network attack is an RPC buffer overflow.</td>
                </tr>
            </table>
        </div>

        <div id='AccessComplexityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>
                        Specialized access conditions exist. For example:
                        <ul>
                            <li>In most configurations, the attacking party must already have elevated privileges or spoof additional systems in addition to the attacking system (e.g., DNS hijacking).</li>
                            <li>The attack depends on social engineering methods that would be easily detected by knowledgeable people. For example, the victim must perform several suspicious or atypical actions.</li>
                            <li>The vulnerable configuration is seen very rarely in practice.</li>
                            <li>If a race condition exists, the window is very narrow.</li>
                        </ul>
                    </td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Medium</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>
                        The access conditions are somewhat specialized; the following are examples:
                        <ul>
                            <li>The attacking party is limited to a group of systems or users at some level of authorization, possibly untrusted.</li>
                            <li>Some information must be gathered before a successful attack can be launched.</li>
                            <li>The affected configuration is non-default, and is not commonly configured (e.g., a vulnerability present when a server performs user account authentication via a specific scheme, but not present for another authentication scheme).</li>
                            <li>The attack requires a small amount of social engineering that might occasionally fool cautious users (e.g., phishing attacks that modify a web browsers status bar to show a false link, having to be on someones buddy list before sending an IM exploit).</li>
                        </ul>
                    </td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Low</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>
                        Specialized access conditions or extenuating circumstances do not exist. The following are examples:
                        <ul>
                            <li>The affected product typically requires access to a wide range of systems and users, possibly anonymous and untrusted (e.g., Internet-facing web or mail server).</li>
                            <li>The affected configuration is default or ubiquitous.</li>
                            <li>The attack can be performed manually and requires little skill or additional information gathering.</li>
                            <li>The race condition is a lazy one (i.e., it is technically a race but easily winnable).</li>
                        </ul>
                    </td>
                </tr>
            </table>
        </div>

        <div id='AuthenticationHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>None</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Authentication is not required to exploit the vulnerability.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Single Instance</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>The vulnerability requires an attacker to be logged into the system (such as at a command line or via a desktop session or web interface).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Multiple Instances</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Exploiting the vulnerability requires that the attacker authenticate two or more times, even if the same credentials are used each time. An example is an attacker authenticating to an operating system in addition to providing credentials to access an application hosted on that system.</td>
                </tr>
            </table>
        </div>

        <div id='ConfImpactHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>None</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is no impact to the confidentiality of the system.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Partial</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is considerable informational disclosure. Access to some system files is possible, but the attacker does not have control over what is obtained, or the scope of the loss is constrained. An example is a vulnerability that divulges only certain tables in a database.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Complete</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is total information disclosure, resulting in all system files being revealed. The attacker is able to read all of the system's data (memory, files, etc.)</td>
                </tr>
            </table>
        </div>

        <div id='IntegImpactHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>None</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is no impact to the integrity of the system.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Partial</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Modification of some system files or information is possible, but the attacker does not have control over what can be modified, or the scope of what the attacker can affect is limited. For example, system or application files may be overwritten or modified, but either the attacker has no control over which files are affected or the attacker can modify files within only a limited context or scope.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Complete</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is a total compromise of system integrity. There is a complete loss of system protection,resulting in the entire system being compromised. The attacker is able to modify any files on the target system.</td>
                </tr>
            </table>
        </div>

        <div id='AvailImpactHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>None</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is no impact to the availability of the system.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Partial</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is reduced performance or interruptions in resource availability. An example is a network-based flood attack that permits a limited number of successful connections to an Internet service.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Complete</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is a total shutdown of the affected resource. The attacker can render the resource completely unavailable.</td>
                </tr>
            </table>
        </div>

        <div id='ExploitabilityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Unproven that exploit exists</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>No exploit code is available, or an exploit is entirely theoretical.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Proof of concept code</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Proof-of-concept exploit code or an attack demonstration that is not practical for most systems is available. The code or technique is not functional in all situations and may require substantial modification by a skilled attacker.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Functional exploit exists</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Functional exploit code is available. The code works in most situations where the vulnerability exists.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Widespread</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Either the vulnerability is exploitable by functional mobile autonomous code, or no exploit is required (manual trigger) and details are widely available. The code works in every situation, or is actively being delivered via a mobile autonomous agent (such as a worm or virus).</td>
                </tr>
            </table>
        </div>

        <div id='RemediationLevelHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Official Fix</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A complete vendor solution is available. Either the vendor has issued an official patch, or an upgrade is available.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Temporary Fix</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is an official but temporary fix available. This includes instances where the vendor issues a temporary hotfix, tool, or workaround.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Workaround</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is an unofficial, non-vendor solution available. In some cases, users of the affected technology will create a patch of their own or provide steps to work around or otherwise mitigate the vulnerability.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Unavailable</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is either no solution available or it is impossible to apply.</td>
                </tr>
            </table>
        </div>

        <div id='ReportConfidenceHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Not Confirmed</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is a single unconfirmed source or possibly multiple conflicting reports. There is little confidence in the validity of the reports. An example is a rumor that surfaces from the hacker underground.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Uncorroborated</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There are multiple non-official sources, possibly including independent security companies or research organizations. At this point there may be conflicting technical details or some other lingering ambiguity.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Confirmed</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>The vulnerability has been acknowledged by the vendor or author of the affected technology. The vulnerability may also be ?Confirmed? when its existence is confirmed from an external event such as publication of functional or proof-of-concept exploit code or widespread exploitation.</td>
                </tr>
            </table>
        </div>

        <div id='CollateralDamagePotentialHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>None</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>There is no potential for loss of life, physical assets, productivity or revenue.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Low</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A successful exploit of this vulnerability may result in slight physical or property damage. Or, there may be a slight loss of revenue or productivity to the organization.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Low-Medium</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A successful exploit of this vulnerability may result in moderate physical or property damage. Or, there may be a moderate loss of revenue or productivity to the organization.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Medium-High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A successful exploit of this vulnerability may result in significant physical or property damage or loss. Or, there may be a significant loss of revenue or productivity.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>A successful exploit of this vulnerability may result in catastrophic physical or property damage and loss. Or, there may be a catastrophic loss of revenue or productivity.</td>
                </tr>
            </table>
        </div>

        <div id='TargetDistributionHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>None</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>No target systems exist, or targets are so highly specialized that they only exist in a laboratory setting. Effectively 0% of the environment is at risk.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Low</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Targets exist inside the environment, but on a small scale. Between 1% - 25% of the total environment is at risk.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Medium</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Targets exist inside the environment, but on a medium scale. Between 26% - 75% of the total environment is at risk.</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Targets exist inside the environment on a considerable scale. Between 76% - 100% of the total environment is considered at risk.</td>
                </tr>
            </table>
        </div>

        <div id='ConfidentialityRequirementHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Low</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of confidentiality is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Medium</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of confidentiality is likely to have a serious adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of confidentiality is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
            </table>
        </div>

        <div id='IntegrityRequirementHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Low</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of integrity is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Medium</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of integrity is likely to have a serious adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of integrity is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
            </table>
        </div>

        <div id='AvailabilityRequirementHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-head no-border'><b>Low</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of availability is likely to have only a limited adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>Medium</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of availability is likely to have a serious adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td class='cal-head'><b>High</b></td>
                </tr>
                <tr>
                    <td class='cal-text'>Loss of availability is likely to have a catastrophic adverse effect on the organization or individuals associated with the organization (e.g., employees, customers).</td>
                </tr>
            </table>
        </div>
    ";

}

/*****************************
* FUNCTION: VIEW DREAD HELP *
*****************************/
function view_dread_help()
{
    echo "
        <div id='divHelp' style='width:100%;overflow:auto'></div>

        <div id='DamagePotentialHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>If a threat exploit occurs, how much damage will be caused?</b></p>
                        <p>0 = Nothing</p>
                        <p>5 = Individual user data is compromised or affected.</p>
                        <p>10 = Complete system or data destruction</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='ReproducibilityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How easy is it to reproduce the threat exploit?</b></p>
                        <p>0 = Very hard or impossible, even for administrators of the application.</p>
                        <p>5 = One or two steps required, may need to be an authorized user.</p>
                        <p>10 = Just a web browser and the address bar is sufficient, without authentication.</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='ExploitabilityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>What is needed to exploit this threat?</b></p>
                        <p>0 = Advanced programming and networking knowledge, with custom or advanced attack tools.</p>
                        <p>5 = Malware exists on the Internet, or an exploit is easily performed, using available attack tools.</p>
                        <p>10 = Just a web browser</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='AffectedUsersHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How many users will be affected?</b></p>
                        <p>0 = None</p>
                        <p>5 = Some users, but not all</p>
                        <p>10 = All users</p>
                    </td>
                </tr>
            </table>
        </div>

        <div id='DiscoverabilityHelp'  style='display:none; visibility:hidden'>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                <tr>
                    <td class='cal-text'>
                        <br />
                        <p><b>How easy is it to discover this threat?</b></p>
                        <p>0 = Very hard to impossible; requires source code or administrative access.</p>
                        <p>5 = Can figure it out by guessing or by monitoring network traces.</p>
                        <p>9 = Details of faults like this are already in the public domain and can be easily discovered using a search engine.</p>
                        <p>10 = The information is visible in the web browser address bar or in a form.</p>
                    </td>
                </tr>
            </table>
        </div>
    ";
}

/**********************************************
* FUNCTION: VIEW RISKS AND ASSETS SELECTIONS *
**********************************************/
function view_risks_and_assets_selections($report, $sort_by, $asset_tags, $projects) {

    global $lang, $escaper;

    echo "
        <form name='select_report' method='POST' action=''>
            <div class='accordion'>
                <div class='accordion-item' id='filter-selections-container'>
                    <h2 class='accordion-header'>
                        <button type='button' class='accordion-button' data-bs-toggle='collapse' data-bs-target='#filter-selections-accordion-body'>" . $escaper->escapeHtml($lang['GroupAndFilteringSelections']) . "</button>
                    </h2>
                    <div id='filter-selections-accordion-body' class='accordion-collapse collapse show'>
                        <div class='accordion-body card-body'>
                            <div class='row'>
                                <div class='col-3'>
                                    <label>" . $escaper->escapeHtml($lang['Report']) . " :</label>
                                    <select id='report' name='report' class='form-select' onchange='javascript: submitFilterForm()'>
                                        <option value='0'" . ($report == 0 ? " selected" : "") . ">" . $escaper->escapeHtml($lang['RisksByAsset']) . "</option>
                                        <option value='1'" . ($report == 1 ? " selected" : "") . ">" . $escaper->escapeHtml($lang['AssetsByRisk']) . "</option>
                                    </select>
                                </div>
                                <div class='col-3'>
                                    <label>" . $escaper->escapeHtml($lang['AssetTags']) . " :</label>
    ";
                                    create_multiple_dropdown("asset_tags", $asset_tags, NULL, NULL, true, $lang['Unassigned'], "-1");
    echo "
                                </div>
                                <div class='col-3'>
                                    <label>" . $escaper->escapeHtml($lang['Project']) . " :</label>
    ";
                                    create_multiple_dropdown("projects", $projects, NULL, NULL, true, $lang['Unassigned'], "-1");
    echo "
                                </div>
    ";
    if ($report == 0) {
        echo "
                                <div class='col-3'>
                                    <label>" . $escaper->escapeHtml($lang['SortBy']) . " :</label>
                                    <select id='sort_by' name='sort_by' class='form-select' onchange='javascript: submitFilterForm()'>
                                        <option value='0'" . ($sort_by == 0 ? " selected" : "") . ">" . $escaper->escapeHtml($lang['AssetName']) . "</option>
                                        <option value='1'" . ($sort_by == 1 ? " selected" : "") . ">" . $escaper->escapeHtml($lang['AssetRisk']) . "</option>
                                    </select>
                                </div>
        ";
    }
    echo "
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        
        <script>
            function submitFilterForm() {
                $('form[name=select_report]').submit();
            }

            $(function() {
                $('#asset_tags, #projects').multiselect({
                    allSelectedText: _lang['All'],
                    enableFiltering: true,
                    maxHeight: 250,
                    buttonWidth: '100%',
                    includeSelectAllOption: true,
                    enableCaseInsensitiveFiltering: true,
                    onChange: submitFilterForm,
                    onSelectAll: submitFilterForm,
                    onDeselectAll: submitFilterForm
                });

                // Multiselects' selected options are sent to the server as separate parameters making large sets of selected options
                // go over the server's maximum allowed number of variables. To solve this we're sending the list of ids as a single JSON string
                $('form[name=select_report]').on('submit', function() {
                    // Create a hidden input with the list of selected ids in a JSON array as the value
                    $('<input>').attr({
                        type: 'hidden',
                        name: 'asset_tags',
                        value: JSON.stringify($('#asset_tags').val())
                    }).appendTo($(this));

                    // disable the original multiselect to make sure it's not submitted to the server
                    $('#asset_tags').attr('disabled','disabled');
                });
            });
        </script>
    ";

}

/*********************************************
* FUNCTION: VIEW RISKS AND ISSUES SELECTIONS *
**********************************************/
function view_risks_and_issues_selections($risk_tags, $start_date="", $end_date="")
{

    global $lang, $escaper;

    $start_date  = $start_date ? $start_date : format_date(date('Y-m-d', strtotime('-30 days')));
    $end_date  = $end_date ? $end_date : format_date(date('Y-m-d'));

    echo "
        <form name='issues_report' method='POST' action=''>
            <div class='accordion'>
                <div class='accordion-item' id='filter-selections-container'>
                    <h2 class='accordion-header'>
                        <button type='button' class='accordion-button' data-bs-toggle='collapse' data-bs-target='#filter-selections-accordion-body'>{$escaper->escapeHtml($lang['GroupAndFilteringSelections'])}</button>
                    </h2>
                    <div id='filter-selections-accordion-body' class='accordion-collapse collapse show'>
                        <div class='accordion-body card-body'>
                            <div class='row'>
                                <div class='col-4'>
                                    <label>{$escaper->escapeHtml($lang['RiskTags'])} :</label>
    ";
                                    create_multiple_dropdown("risk_tags", $risk_tags, NULL, NULL, true, $lang['Unassigned'], "-1");
    echo "
                                </div>
                                <div class='col-4'>
                                    <label>{$escaper->escapeHtml($lang['StartDate'])} :</label>
                                    <input type='text' name='start_date' value='{$escaper->escapeHtml($start_date)}' class='form-control datepicker'>
                                </div>
                                <div class='col-4'>
                                    <label>{$escaper->escapeHtml($lang['EndDate'])} :</label>
                                    <input type='text' name='end_date' value='{$escaper->escapeHtml($end_date)}' class='form-control datepicker'>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <script>
            $(function() {
                $('#risk_tags').multiselect({
                    allSelectedText: '{$escaper->escapeHtml($lang['ALL'])}',
                    enableFiltering: true,
                    maxHeight: 250,
                    buttonWidth: '100%',
                    includeSelectAllOption: true,
                    enableCaseInsensitiveFiltering: true,
                    onDropdownHide: function(){
                        $('form[name=issues_report]').submit();
                    }
                });
                $('.datepicker').initAsDatePicker();
                $('.datepicker').change(function(){
                    $('form[name=issues_report]').submit();
                });
            });
        </script>
    ";
}

/******************************************
* FUNCTION: VIEW GET RISKS BY SELECTIONS *
******************************************/
function view_get_risks_by_selections($status=0, $group=0, $sort=0, $risk_columns=[], $mitigation_columns=[], $review_columns=[], $scoring_columns=[], $unassigned_columns=[], $risk_mapping_columns=[], $custom_display_settings=[]) {

    global $lang, $escaper;
    
    $encoded_request_uri = get_encoded_request_uri();

    echo   "
        <div class='accordion-item' id='group-selections-container'>
            <h2 class='accordion-header'>
                <button type='button' class='accordion-button' data-bs-toggle='collapse' data-bs-target='#group-selections-accordion-body'>{$escaper->escapeHtml($lang['GroupAndFilteringSelections'])}</button>
            </h2>
            <div id='group-selections-accordion-body' class='accordion-collapse collapse show'>
                <div class='accordion-body card-body'>
                    <form id='get_risks_by' name='get_risks_by' method='post' action='" . $escaper->escapeHtmlAttr(build_url($encoded_request_uri)) . "'>
                        <div class='row'>
                            <!-- Risk Status Selection -->
                            <div class='col-4'>
                                <label>{$escaper->escapeHtml($lang['Status'])} :</label>
                                <select id='status' name='status' onchange='javascript: submit()' class='form-select'>
                                    <option value='0'" . ($status == 0 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['OpenRisks'])}</option>
                                    <option value='1'" . ($status == 1 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['ClosedRisks'])}</option>
                                    <option value='2'" . ($status == 2 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['AllRisks'])}</option>
                                </select>
                            </div>
                            <!-- Group By Selection -->    
                            <div class='col-4'>
                                <label>{$escaper->escapeHtml($lang['GroupBy'])} :</label>
                                <select id='group' name='group' onchange='javascript: submit()' class='form-select'>
                                    <option value='0'" . ($group == 0 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['None'])}</option>
                                    <option value='5'" . ($group == 5 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Category'])}</option>
                                    <option value='11'" . ($group == 11 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['ControlRegulation'])}</option>
                                    <option value='14'" . ($group == 14 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['MonthSubmitted'])}</option>
                                    <option value='13'" . ($group == 13 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['NextStep'])}</option>
                                    <option value='8'" . ($group == 8 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Owner'])}</option>
                                    <option value='9'" . ($group == 9 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['OwnersManager'])}</option>
                                    <option value='12'" . ($group == 12 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Project'])}</option>
                                    <option value='1'" . ($group == 1 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['RiskLevel'])}</option>
                                    <option value='10'" . ($group == 10 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['RiskScoringMethod'])}</option>
                                    <option value='4'" . ($group == 4 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['RiskSource'])}</option>
                                    <option value='2'" . ($group == 2 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Status'])}</option>
                                    <option value='6'" . ($group == 6 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Team'])}</option>
                                    <option value='7'" . ($group == 7 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Technology'])}</option>
                                </select>
                            </div>
                            <!-- Sort By Selection -->
                            <div class='col-4'>
                                <label>{$escaper->escapeHtml($lang['SortBy'])} :</label>
                                <select id='sort' name='sort' onchange='javascript: submit()' class='form-select'>
                                    <option value='0'" . ($sort == 0 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['InherentRisk'])}</option>
                                    <option value='1'" . ($sort == 1 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['ID'])}</option>
                                    <option value='2'" . ($sort == 2 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['Subject'])}</option>
                                    <option value='3'" . ($sort == 3 ? ' selected' : '') . ">{$escaper->escapeHtml($lang['ResidualRisk'])}</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    ";

    // Risk columns
        display_risk_columns($risk_columns, $mitigation_columns, $review_columns, $scoring_columns, $unassigned_columns, $risk_mapping_columns, $custom_display_settings);
}

/*************************************************
* FUNCTION: DISPLAY SAVE DYNAMIC RISK SELECTIONS *
**************************************************/
function display_save_dynamic_risk_selections() {

    global $lang, $escaper;
    
    $selection_id = !empty($_GET['selection']) ? (int)$_GET['selection'] : '';
    
    $options = get_dynamic_saved_selections($_SESSION['uid']);
    
    $private = $escaper->escapeHtml($lang['Private']);
    $public = $escaper->escapeHtml($lang['Public']);
    
    echo "
        <div class='accordion-item' id='save-selections-container'>
            <h2 class='accordion-header'>
                <button type='button' class='accordion-button collapsed' data-bs-toggle='collapse' data-bs-target='#save-selections-accordion-body'>{$escaper->escapeHtml($lang['SaveSelections'])}</button>
            </h2>
            <div id='save-selections-accordion-body' class='accordion-collapse collapse'>
                <div class='accordion-body card-body'>
                    <form method='post' >
                        <div class='row align-items-end'>
                            <div class='col-8 form-group dynamic-save-selections'>
                                <label>{$escaper->escapeHtml($lang['SavedSelections'])} :</label>

                                <script>
                                    $(document).ready(function(){
                                        $('#saved_selections').selectize({
                                            options: [
    ";

    $selection = false;
    foreach ($options as $option) {
        if ($selection_id == $option['value']) {
            $selection = $option;
        }
        echo "
                                                {
                                                    class: '{$option['type']}', 
                                                    value: '{$option['value']}', 
                                                    name: '{$escaper->escapeHtml($option['name'])}'
                                                },
        ";
    }
            
    echo "
                                            ],
                                            optgroups:
                                                [
                                                    {value: 'private', label: '{$private}'},
                                                    {value: 'public', label: '{$public}'},
                                                ]
                                            ,
                                            plugins: ['optgroup_columns'],
                                            optgroupField: 'class',
                                            labelField: 'name',
                                            searchField: ['name', 'class'],
                                            maxItems:1,
    ";

    if ($selection_id) {
        echo "
                                            items: [{$selection_id}],
        ";
    }
                
    echo "
                                            render: {
                                                optgroup_header: function (data) {
                                                    return $('<div>', {class: 'optgroup-header'}).text(data.label);
                                                },
                                                option: function (data) {
                                                    if (data.value) {
    ";

    if (check_permission("delete_saved_risk_reports")) {
        echo "
                                                        return $('<div>', {class: 'option d-flex'}).text(data.name).append($('<i>', {class: 'fa fa-trash font-10 rounded-5 p-1 delete-option-btn'}));
        ";
    } else {
        echo "
                                                        return $('<div>', {class: 'option'}).text(data.name);
        ";
    }

    echo "
                                                    } else {
                                                        return $('<div>', {class: 'option'}).text(data.name);
                                                    }
                                                },
                                                item: function (data) {
                                                    if (data.value) {
                                                        return $('<div>', {class: 'item'}).text('[' + (data.class == 'private' ? '$private' : '$public') + '] ' + data.name); 
                                                    } else {
                                                        return $('<div>', {class: 'item'}).text('');
                                                    }
                                                }
                                            }
                                        });

                                        //stop option changing and open delete confirm modal.
                                        $('.dynamic-save-selections .selectize-dropdown').on('mousedown', '.delete-option-btn', function(e) {
                                            
                                            //stop bubbling mousedown event
                                            e.stopPropagation();

                                            let id = $(e.target).parents('.option').first().data('value');
                                            confirm('{$escaper->escapeJs($lang["AreYouSureYouWantToDeleteSelction"])}', () => delete_saved_selection(id));
                                        });            
                                    });
            
                                    function delete_saved_selection(id)
                                    {
                                        $.ajax({
                                            type: 'POST',
                                            url: BASE_URL + '/api/v2/reports/delete-dynamic-selection',
                                            data:{
                                                id: id,
                                            },
                                            success: function(res){
                                                document.location.href = BASE_URL + '/reports/dynamic_risk_report.php';
                                            },
                                            error: function(xhr,status,error){
                                                if(!retryCSRF(xhr, this)){
                                                    if(xhr.responseJSON && xhr.responseJSON.status_message) {
                                                        showAlertsFromArray(xhr.responseJSON.status_message);
                                                    }
                                                }
                                            }
                                        });
                                    }
                                </script>

                                <select required id='saved_selections'></select>
                            </div>
                        </div>
                    </form>
    ";

    if (check_permission("add_saved_risk_reports")) {
        echo "
                    <form method='post' id='save-selections-form'>
                        <div class='row align-items-end'>
                            <div class='col-4'>
                                <label>{$escaper->escapeHtml($lang['Type'])} :</label>
                                <select required id='saved-selection-type' name='type' title='{$escaper->escapeHtml($lang['PleaseSelectTypeForSaving'])}' class='form-select'>
                                    <option value=''>--</option>
                                    <option value='public'>{$public}</option>
                                    <option value='private'>{$private}</option>
                                </select>
                            </div>
                            <div class='col-4'>
                                <label>{$escaper->escapeHtml($lang['Name'])} :</label>
                                <input name='name' required type='text' placeholder='{$escaper->escapeHtml($lang['Name'])}' title='{$escaper->escapeHtml($lang['Name'])}' style='max-width: unset;' class='form-control'>
                            </div>
                            <div class='col-4'>
                                <button class='btn btn-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
                            </div>
                        </div>
                    </form>
        ";
    }

    echo "
                </div>
            </div>
        </div>
            
        <script>
            $(document).ready(function(){
    ";

    if (check_permission("add_saved_risk_reports")) {
        echo "
                $('#save-selections-form').submit(function(){
                    var self = $(this);
                    var type = $('#saved-selection-type', self).val();
                    var name = $('input[name=name]', self).val();

                    // Get ordered columns from the sortable order list
                    let selected_columns = [];
                    $('#dynamic-report-column-order li[data-column]').each(function() {
                        selected_columns.push($(this).data('column'));
                    });
                    
                    // Fallback to multiselect values if order list is empty
                    if (selected_columns.length === 0) {
                        let risk_columns = $('#risk_columns').val() || [];
                        let mitigation_columns = $('#mitigation_columns').val() || [];
                        let review_columns = $('#review_columns').val() || [];
                        let scoring_columns = $('#scoring_columns').val() || [];
                        let risk_mapping_columns = $('#risk_mapping_columns').val() || [];
                        selected_columns = risk_columns.concat(mitigation_columns, review_columns, scoring_columns, risk_mapping_columns);
                    }

                    var columnFilters = [];
                    $('.risk-datatable:first .dynamic-column-filter').each(function(i){
                        // .val() is null for an empty multi-select, which made .length throw (SD-896)
                        var filter_value = $(this).val() || [];
                        if(filter_value.length > 0){
                            var data_name = $(this).attr('data-name');
                            columnFilters.push([data_name,filter_value]);
                        }
                    });
                    var selectFilters = {status:0,group:0,sort:0};
                    selectFilters.status = $('#status').val();
                    selectFilters.group = $('#group').val();
                    selectFilters.sort = $('#sort').val();
                    
                    // Include current table sort (column and direction) in saved selection
                    if (riskDataTables && riskDataTables.length > 0) {
                        var dt = riskDataTables[0];
                        var order = dt.order();
                        if (order && order.length && order[0].length >= 2) {
                            var colIndex = order[0][0];
                            var orderDir = order[0][1];
                            var th = $('.risk-datatable:first tr.main th').eq(colIndex);
                            if (th.length && th.data('name')) {
                                selectFilters.order_column = th.data('name');
                                selectFilters.order_dir = orderDir;
                            }
                        }
                    }

                    var test = $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/api/v2/reports/save-dynamic-selections',
                        data:{
                            type: type,
                            name: name,
                            columns: selected_columns,
                            selects: selectFilters,
                            columnFilters: columnFilters,
                        },
                        success: function(res){
                            var value = res.data.value;
                            if(value) {
                                var stz = $('#saved_selections')[0].selectize;
                                
                                var data = {
                                    'class':res.data.type,
                                    'value':value,
                                    'name':name 
                                };
                                stz.addOption(data);
                                stz.refreshOptions();

                                self[0].reset();
                            }
                            showAlertsFromArray(res.status_message);
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                if(xhr.responseJSON && xhr.responseJSON.status_message) {
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        }
                    });
                    
                    return false;
                });
        ";  
    }
    echo "
                $('#saved_selections').change(function(){
                    var selection = $(this).val();
                    if(selection){
                        document.location.href = BASE_URL + '/reports/dynamic_risk_report.php?selection=' + selection;
                    } else {
                        document.location.href = BASE_URL + '/reports/dynamic_risk_report.php';
                    }
                    return true;
                })
            })
        </script>
    ";
}

/*********************************
* FUNCTION: DISPLAY RISK COLUMNS *
**********************************/
function display_risk_columns($risk_columns=[], $mitigation_columns=[], $review_columns=[], $scoring_columns=[], $unassigned_columns=[], $risk_mapping_columns=[], $custom_display_settings=[]) {

    global $escaper, $lang;

    $risk_columns_option = [];
    $risk_columns_selected = [];
    $mitigation_columns_option = [];
    $mitigation_columns_selected = [];
    $review_columns_option = [];
    $review_columns_selected = [];
    $scoring_columns_option = [];
    $scoring_columns_selected = [];
    $unassigned_columns_option = [];
    $unassigned_columns_selected = [];
    $risk_mapping_columns_option = [];
    $risk_mapping_columns_selected = [];

    // If customization extra is enabled
    if(customization_extra()) {

        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        foreach ($risk_columns as $column=>$value) {

            if (stripos($column, "custom_field_") !== false) {
                $field_id = str_replace("custom_field_", "", $column);
                $custom_field = get_field_by_id($field_id);
                $name = $custom_field['name'];
            } else {
                $name = get_label_by_risk_field_name($column);
            }

            $risk_columns_option[] = array('value'=>$column, 'name'=>$name);

            if ($value == true) {
                $risk_columns_selected[] = $column;
            }
        }

        foreach ($mitigation_columns as $column=>$value) {

            if (stripos($column, "custom_field_") !== false) {
                $field_id = str_replace("custom_field_", "", $column);
                $custom_field = get_field_by_id($field_id);
                $name = $custom_field['name'];
            } else {
                $name = get_label_by_risk_field_name($column);
            }

            $mitigation_columns_option[] = array('value'=>$column, 'name'=>$name);

            if ($value == true) {
                $mitigation_columns_selected[] = $column;
            }
        }

        foreach ($review_columns as $column=>$value) {

            if (stripos($column, "custom_field_") !== false) {
                $field_id = str_replace("custom_field_", "", $column);
                $custom_field = get_field_by_id($field_id);
                $name = $custom_field['name'];
            } else {
                $name = get_label_by_risk_field_name($column);
            }

            $review_columns_option[] = array('value'=>$column, 'name'=>$name);

            if ($value == true) {
                $review_columns_selected[] = $column;
            }
        }

        foreach ($scoring_columns as $column=>$value) {
            $name = get_label_by_risk_field_name($column);
            $scoring_columns_option[] = array('value'=>$column, 'name'=>$name);
            if ($value == true) {
                $scoring_columns_selected[] = $column;
            }
        }

        foreach ($unassigned_columns as $column=>$value) {

            if (stripos($column, "custom_field_") !== false) {
                $field_id = str_replace("custom_field_", "", $column);
                $custom_field = get_field_by_id($field_id);
                $name = $custom_field['name'];
            } else {
                $name = get_label_by_risk_field_name($column);
            }

            $unassigned_columns_option[] = array('value'=>$column, 'name'=>$name);

            if ($value == true) {
                $unassigned_columns_selected[] = $column;
            }
        }
    } else {

        foreach ($risk_columns as $column=>$value) {
            $name = get_label_by_risk_field_name($column);
            $risk_columns_option[] = array('value'=>$column, 'name'=>$name);
            if ($value == true) {
                $risk_columns_selected[] = $column;
            }
        }

        foreach ($mitigation_columns as $column=>$value) {
            $name = get_label_by_risk_field_name($column);
            $mitigation_columns_option[] = array('value'=>$column, 'name'=>$name);
            if ($value == true) {
                $mitigation_columns_selected[] = $column;
            }
        }

        foreach ($review_columns as $column=>$value) {
            $name = get_label_by_risk_field_name($column);
            $review_columns_option[] = array('value'=>$column, 'name'=>$name);
            if ($value == true) {
                $review_columns_selected[] = $column;
            }
        }

        foreach ($scoring_columns as $column=>$value) {
            $name = get_label_by_risk_field_name($column);
            $scoring_columns_option[] = array('value'=>$column, 'name'=>$name);
            if ($value == true) {
                $scoring_columns_selected[] = $column;
            }
        }
    }

    foreach ($risk_mapping_columns as $column=>$value) {
        $name = get_label_by_risk_field_name($column);
        $risk_mapping_columns_option[] = array('value'=>$column, 'name'=>$name);
        if ($value == true) {
            $risk_mapping_columns_selected[] = $column;
        }
    }

    // Get all selected columns in their current order 
    $all_selected_columns = array_merge(
        $risk_columns_selected,
        $mitigation_columns_selected,
        $review_columns_selected,
        $scoring_columns_selected,
        $unassigned_columns_selected,
        $risk_mapping_columns_selected
    );

    // Reorder $all_selected_columns based on the current view's column order
    // Uses $custom_display_settings which contains either saved selection's order or user's order
    if (is_array($custom_display_settings) && count($custom_display_settings) > 0) {
        $custom_order = $custom_display_settings;
        $ordered_selected_columns = [];
        // First, add columns in the order specified by custom_display_settings
        foreach ($custom_order as $column) {
            if (in_array($column, $all_selected_columns)) {
                $ordered_selected_columns[] = $column;
            }
        }
        // Then, add any remaining columns that might not be in custom_display_settings
        foreach ($all_selected_columns as $column) {
            if (!in_array($column, $ordered_selected_columns)) {
                $ordered_selected_columns[] = $column;
            }
        }
        $all_selected_columns = $ordered_selected_columns;
    }

    // Build a lookup for all columns with their labels
    $all_columns_lookup = [];

    foreach ($risk_columns_option as $col) {
        $all_columns_lookup[$col['value']] = ['name' => $col['name'], 'category' => 'risk'];
    }

    foreach ($mitigation_columns_option as $col) {
        $all_columns_lookup[$col['value']] = ['name' => $col['name'], 'category' => 'mitigation'];
    }

    foreach ($review_columns_option as $col) {
        $all_columns_lookup[$col['value']] = ['name' => $col['name'], 'category' => 'review'];
    }

    foreach ($scoring_columns_option as $col) {
        $all_columns_lookup[$col['value']] = ['name' => $col['name'], 'category' => 'scoring'];
    }

    foreach ($unassigned_columns_option as $col) {
        $all_columns_lookup[$col['value']] = ['name' => $col['name'], 'category' => 'unassigned'];
    }

    foreach ($risk_mapping_columns_option as $col) {
        $all_columns_lookup[$col['value']] = ['name' => $col['name'], 'category' => 'risk_mapping'];
    }

    echo "
        <div class='accordion-item' id='column-selections-container'>
            <h2 class='accordion-header'>
                <button type='button' class='accordion-button collapsed' data-bs-toggle='collapse' data-bs-target='#column-selection-accordion-body'>{$escaper->escapeHtml($lang['ColumnSelections'])}</button>
            </h2>
            <div id='column-selection-accordion-body' class='accordion-collapse collapse'>
                <div class='accordion-body card-body'>
                    <div>
                        <nav class='nav nav-tabs' id='column-selection-tabs'>
                            <a class='nav-link active' id='select-columns-tab' data-bs-target='#select-columns-content' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['SelectColumns'])}</a>
                            <a class='nav-link' id='column-order-tab' data-bs-target='#column-order-content' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['ColumnOrder'])}</a>
                        </nav>
                    </div>
                    <div class='tab-content card-body my-2 border' id='column-selection-tabs-content'>

                        <!-- Tab 1: Select Columns (multiselects) -->

                        <div class='tab-pane active' id='select-columns-content'>
                            <div class='row'>
                                <div class='col-4 form-group'>
                                    <label>{$escaper->escapeHtml($lang['RiskColumns'])} :</label>
    ";
                                    create_multiple_dropdown("", $risk_columns_selected, "risk_columns", $risk_columns_option, false, "", "", true, "class='multiselect' multiple='multiple'");
    echo "
                                </div>
                                <div class='col-4 form-group'>
                                    <label>{$escaper->escapeHtml($lang['MitigationColumns'])} :</label>
    ";
                                    create_multiple_dropdown("", $mitigation_columns_selected, "mitigation_columns", $mitigation_columns_option, false, "", "", true, "class='multiselect' multiple='multiple'");
    echo "
                                </div>
                                <div class='col-4 form-group'>
                                    <label>{$escaper->escapeHtml($lang['ReviewColumns'])} :</label>
    ";
                                    create_multiple_dropdown("", $review_columns_selected, "review_columns", $review_columns_option, false, "", "", true, "class='multiselect' multiple='multiple'");
    echo "
                                </div>
                            </div>
                            <div class='row'>
                                <div class='col-4'>
                                    <label>{$escaper->escapeHtml($lang['RiskScoringColumns'])} :</label>
    ";
                                    create_multiple_dropdown("", $scoring_columns_selected, "scoring_columns", $scoring_columns_option, false, "", "", true, "class='multiselect' multiple='multiple'");
    echo "
                                </div>
    ";

    if (count($unassigned_columns_option)) {
        echo "
                                <div class='col-4'>
                                    <label>{$escaper->escapeHtml($lang['UnassignedColumns'])} :</label>
        ";
                                    create_multiple_dropdown("", $unassigned_columns_selected, "unassigned_columns", $unassigned_columns_option, false, "", "", true, "class='multiselect' multiple='multiple'");
        echo "
                                </div>
        "; 
    }

    echo "
                                <div class='col-4'>
                                    <label>{$escaper->escapeHtml($lang['RiskMappingColumns'])} :</label>
    ";
                                    create_multiple_dropdown("", $risk_mapping_columns_selected, "risk_mapping_columns", $risk_mapping_columns_option, false, "", "", true, "class='multiselect' multiple='multiple'");
    echo "
                                </div>
                            </div>
                        </div>

                        <!-- Tab 2: Column Order (drag and drop) -->

                        <div class='tab-pane' id='column-order-content'>
                            <strong class='d-inline-block mb-1'><i class='fa fa-info-circle'></i> {$escaper->escapeHtml($lang['DragAndDropToReorder'])}</strong>
                            <ul class='sortable-columns' id='dynamic-report-column-order'>
    ";
    
    // Display selected columns in their current order
    if (count($all_selected_columns) > 0) {
        foreach ($all_selected_columns as $column_key) {
            if (isset($all_columns_lookup[$column_key])) {
                $col_info = $all_columns_lookup[$column_key];
                $category_label = '';
                switch ($col_info['category']) {
                    case 'risk': $category_label = $escaper->escapeHtml($lang['Risk']); break;
                    case 'mitigation': $category_label = $escaper->escapeHtml($lang['Mitigation']); break;
                    case 'review': $category_label = $escaper->escapeHtml($lang['Review']); break;
                    case 'scoring': $category_label = $escaper->escapeHtml($lang['RiskScoring']); break;
                    case 'unassigned': $category_label = $escaper->escapeHtml($lang['Unassigned']); break;
                    case 'risk_mapping': $category_label = $escaper->escapeHtml($lang['RiskMapping']); break;
                }
                // Both sources are raw text, $custom_field['name'] and get_label_by_risk_field_name(), so this is the only escape
                $escaped_col_name = $escaper->escapeHtml($col_info['name']);
                echo "
                                <li data-column='{$escaper->escapeHtml($column_key)}' data-category='{$escaper->escapeHtml($col_info['category'])}'>
                                    <span class='drag-handle'><i class='fa fa-grip-vertical'></i></span>
                                    <span class='column-name'>{$escaped_col_name}</span>
                                    <span class='column-category'>{$category_label}</span>
                                    <span class='remove-column' title='{$escaper->escapeHtml($lang['Remove'])}'><i class='fa fa-times'></i></span>
                                </li>
                ";
            }
        }
    } else {
        echo "
                                <li class='no-columns-message'>{$escaper->escapeHtml($lang['NoColumnsSelected'])}</li>
        ";
    }
    
    echo "
                            </ul>
                        </div>
                    </div>
                    <div class='row mt-2'>
                        <div class='col-12 text-end'>
                            <button type='button' class='btn btn-submit' id='apply-column-selections'>{$escaper->escapeHtml($lang['Apply'])}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    ";

}

/********************************************************
* FUNCTION: DISPLAY RISKS OPEN BY TEAM DROPDOWN SCRIPT  *
*********************************************************/
function display_risks_open_by_team_dropdown_script() {

    global $escaper, $lang;

    echo "
        <script type='text/javascript'>
            $(function(){
                // timer identifier
                var typingTimer;                
                // time in ms (1 second)
                var doneInterval = 2000;  
                function submit_form(){
                    $('#risks_by_teams_form').submit();
                }

                function throttledFormSubmit() {
                    clearTimeout(typingTimer);
                    typingTimer = setTimeout(submit_form, doneInterval);
                }            
                
                // Team dropdown
                $('#teams').multiselect({
                    allSelectedText: '{$escaper->escapeJs($lang['AllTeams'])}',
                    includeSelectAllOption: true,
                    onChange: throttledFormSubmit,
                    onSelectAll: throttledFormSubmit,
                    onDeselectAll: throttledFormSubmit,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth: '100%',
                });
                
                // Owner dropdown
                $('#owners').multiselect({
                    allSelectedText: '{$escaper->escapeJs($lang['AllOwners'])}',
                    includeSelectAllOption: true,
                    onChange: throttledFormSubmit,
                    onSelectAll: throttledFormSubmit,
                    onDeselectAll: throttledFormSubmit,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth: '100%',
                });
                
                // Owner's dropdown
                $('#ownersmanagers').multiselect({
                    allSelectedText: '{$escaper->escapeJs($lang['AllOwnersManagers'])}',
                    includeSelectAllOption: true,
                    onChange: throttledFormSubmit,
                    onSelectAll: throttledFormSubmit,
                    onDeselectAll: throttledFormSubmit,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth: '100%',
                });
            });
        </script>
        <style type=''>
            .download-by-group, .print-by-group{
                display: none;
            }
        </style>
    ";
}

/*************************************************
* FUNCTION: GET DYNAMIC NAMES BY MAIN FIELD NAME *
**************************************************/
function get_dynamic_names_by_main_field_name($field_name)
{
    global $lang, $escaper;
    
    $data = array(
        // risks
        'ExternalReferenceId' => 
            [
                'name' => "reference_id",
                'text' => $lang['ExternalReferenceId'],
            ],
        'ControlRegulation' => 
            [
                'name' => "regulation",
                'text' => $lang['ControlRegulation'],
            ],
        'ControlNumber' => 
            [
                'name' => "control_number",
                'text' => $lang['ControlNumber'],
            ],
        'SiteLocation' => 
            [
                'name' => "location",
                'text' => $lang['SiteLocation'],
            ],
        'RiskSource' => 
            [
                'name' => "source",
                'text' => $lang['RiskSource'],
            ],
        'Category' => 
            [
                'name' => "category",
                'text' => $lang['Category'],
            ],
        'Team' => 
            [
                'name' => "team",
                'text' => $lang['Team'],
            ],
        'Technology' => 
            [
                'name' => "technology",
                'text' => $lang['Technology'],
            ],
        'Owner' => 
            [
                'name' => "owner",
                'text' => $lang['Owner'],
            ],
        'OwnersManager' => 
            [
                'name' => "manager",
                'text' => $lang['OwnersManager'],
            ],
        'SubmittedBy' => 
            [
                'name' => "submitted_by",
                'text' => $lang['SubmittedBy'],
            ],
        'RiskScoringMethod' => 
            [
                'name' => "scoring_method",
                'text' => $lang['RiskScoringMethod'],
            ],
        'SubmissionDate' => 
            [
                'name' => "submission_date",
                'text' => $lang['SubmissionDate'],
            ],
        'AffectedAssets' => 
            [
                'name' => "affected_assets",
                'text' => $lang['AffectedAssets'],
            ],
        'RiskAssessment' => 
            [
                'name' => "risk_assessment",
                'text' => $lang['RiskAssessment'],
            ],
        'AdditionalNotes' => 
            [
                'name' => "additional_notes",
                'text' => $lang['AdditionalNotes'],
            ],
//        'SupportingDocumentation' => 
//            [
//                'name' => "submission_date",
//                'text' => $lang['SubmissionDate'],
//            ],
        'AdditionalStakeholders' => 
            [
                'name' => "additional_stakeholders",
                'text' => $lang['AdditionalStakeholders'],
            ],
        
        // mitigations
        'PlanningStrategy' => 
            [
                'name' => "planning_strategy",
                'text' => $lang['PlanningStrategy'],
            ],
        'MitigationPlanning' => 
            [
                'name' => "planning_date",
                'text' => $lang['MitigationPlanning'],
            ],
        'MitigationEffort' => 
            [
                'name' => "mitigation_effort",
                'text' => $lang['MitigationEffort'],
            ],
        'MitigationCost' => 
            [
                'name' => "mitigation_cost",
                'text' => $lang['MitigationCost'],
            ],
        'MitigationOwner' => 
            [
                'name' => "mitigation_owner",
                'text' => $lang['MitigationOwner'],
            ],
        'MitigationPercent' => 
            [
                'name' => "mitigation_percent",
                'text' => $lang['MitigationPercent'],
            ],
        'MitigationTeam' => 
            [
                'name' => "mitigation_team",
                'text' => $lang['MitigationTeam'],
            ],
        'MitigationDate' => 
            [
                'name' => "mitigation_date",
                'text' => $lang['MitigationDate'],
            ],
        'MitigationControls' => 
            [
                'name' => "mitigation_controls",
                'text' => $lang['MitigationControls'],
            ],
//        'MitigationPercent' => 
//            [
//                'name' => "submission_date",
//                'text' => $lang['SubmissionDate'],
//            ],
        'AcceptMitigation' => 
            [
                'name' => "mitigation_accepted",
                'text' => $lang['MitigationAccepted'],
            ],
        'CurrentSolution' => 
            [
                'name' => "current_solution",
                'text' => $lang['CurrentSolution'],
            ],
        'SecurityRecommendations' => 
            [
                'name' => "security_recommendations",
                'text' => $lang['SecurityRecommendations'],
            ],
        'SecurityRequirements' => 
            [
                'name' => "security_requirements",
                'text' => $lang['SecurityRequirements'],
            ],
//        'MitigationSupportingDocumentation' => 
//            [
//                'name' => "submission_date",
//                'text' => $lang['SubmissionDate'],
//            ],
//        'MitigationControlsList' => 
//            [
//                'name' => "submission_date",
//                'text' => $lang['SubmissionDate'],
//            ],
        
        // Review
        'ReviewDate' => 
            [
                'name' => "review_date",
                'text' => $lang['ReviewDate'],
            ],
       'Reviewer' => 
           [
               'name' => "reviewer",
               'text' => $lang['ReviewedBy'],
           ],
//        'Review' => 
//            [
//                'name' => "submission_date",
//                'text' => $lang['SubmissionDate'],
//            ],
        'Review' => 
            [
                'name' => "review",
                'text' => $lang['Review'],
            ],
        'NextReviewDate' => 
            [
                'name' => "next_review_date",
                'text' => $lang['NextReviewDate'],
            ],
        'NextStep' => 
            [
                'name' => "next_step",
                'text' => $lang['NextStep'],
            ],
        'Tags' =>
            [
                'name' => "risk_tags",
                'text' => $lang['Tags'],
            ],
        'Comment' => 
            [
                'name' => "comments",
                'text' => $lang['Comments'],
            ],
        'RiskMapping' => 
            [
                'name' => "risk_mapping",
                'text' => $lang['RiskMapping'],
            ],
        'ThreatMapping' => 
            [
                'name' => "threat_mapping",
                'text' => $lang['ThreatMapping'],
            ]
    );
    return isset($data[$field_name]) ? $data[$field_name] : "";
}

/************************************************
* FUNCTION: DISPLAY SIMPLE AUTOCOMPLETE SCRIPT *
************************************************/
function display_simple_autocomplete_script($assets)
{
    global $escaper;
    $asset_array = array();
    foreach($assets as $asset){
        $asset_array[] = remove_line_breaks($escaper->escapeHtml($asset['name']));
    }

    echo "<script>\n";
    echo "  $(function() {\n";
        echo "    var availableAssets = ". json_encode($asset_array) .";\n";
        echo "    function split( val ) {\n";
        echo "      return val.split( /,\s*/ );\n";
        echo "    }\n";
        echo "    function extractLast( term ) {\n";
            echo "      return split( term ).pop();\n";
            echo "    }\n";
            echo "    $( \"#asset_name\" )\n";
            echo "      // don't navigate away from the field on tab when selecting an item\n";
            echo "      .bind( \"keydown\", function( event ) {\n";
                echo "        if ( event.keyCode === $.ui.keyCode.TAB && $( this ).autocomplete( \"instance\" ).menu.active ) {\n";
                    echo "          event.preventDefault();\n";
                    echo "        }\n";
                    echo "      })\n";
                    echo "      .autocomplete({\n";
                        echo "        minLength: 0,\n";
                        echo "        source: function( request, response ) {\n";
                            echo "        // delegate back to autocomplete, but extract the last term\n";
                            echo "        response( $.ui.autocomplete.filter(\n";
                            echo "        availableAssets, extractLast( request.term ) ) );\n";
                            echo "      },\n";
                            echo "      select: function( event, ui ) {\n";
                            echo "      }\n";
                            echo "    })\n";

                            echo "    .focus(function(){\n";
                            echo "          var self = \$(this);\n";
                            echo "          window.setTimeout(function(){\n";
                            echo "              self.autocomplete(\"search\", \"\");\n";
                            echo "          }, 1000);\n";
                            echo "    });\n";

                            echo "  });\n";
    echo "</script>\n";
}

/***********************************************
* FUNCTION: DISPLAY ASSET AUTOCOMPLETE SCRIPT *
***********************************************/
function display_asset_autocomplete_script($assets)
{
    global $escaper;

    echo "<script>\n";
        echo "if(jQuery.ui !== undefined){\n";
            echo "jQuery.ui.autocomplete.prototype._resizeMenu = function () {\n";
                echo "var ul = this.menu.element;\n";
                echo "ul.outerWidth(this.element.outerWidth());\n";
            echo "}\n";
        echo "}\n";

        echo "    availableAssets = [\n";

        // For each asset
        foreach ($assets as $asset)
        {
            // Display the asset name as an available asset
            echo "      \"" . remove_line_breaks($escaper->escapeJs(try_decrypt($asset['name']))) . "\",\n";
        }

        echo "    ];\n";
        echo "    split = function( val ) {\n";
        echo "          return val.split( /,\s*/ );\n";
        echo "    }\n";
        echo "    extractLast = function ( term ) {\n";
        echo "          return split( term ).pop();\n";
        echo "    }\n";

        echo "    function set_auto_complete(\$element){\n";
            echo "    \$element\n";
            echo "      // don't navigate away from the field on tab when selecting an item\n";
            echo "      .bind( \"keydown\", function( event ) {\n";
                echo "        if ( event.keyCode === $.ui.keyCode.TAB && $( this ).autocomplete( \"instance\" ).menu.active ) {\n";
                    echo "          event.preventDefault();\n";
                    echo "        }\n";
                    echo "      })\n";
            echo "      .autocomplete({\n";
                echo "          minLength: 0,\n";
                echo "          source: function( request, response ) {\n";
                    echo "          // delegate back to autocomplete, but extract the last term\n";
                    echo "          response( $.ui.autocomplete.filter(\n";
                    echo "          availableAssets, extractLast( request.term ) ) );\n";
                    echo "      },\n";
                    echo "      focus: function() { \n";
                    echo "          // prevent value inserted on focus\n";
                    echo "          return false;\n";
                    echo "      },\n";
                    echo "      select: function( event, ui ) {\n";
                        echo "        var terms = split( this.value );\n";
                        echo "        // remove the current input\n";
                        echo "        terms.pop();\n";
                        echo "        // add the selected item\n";
                        echo "        terms.push( ui.item.value );\n";
                        echo "        // add placeholder to get the comma-and-space at the end\n";
                        echo "        terms.push( \"\" );\n";
                        echo "        terms = terms.reverse().filter(function (e, i, arr) {\n";
                        echo "              return arr.indexOf(e, i+1) === -1;\n";
                        echo "        }).reverse();\n";
                        echo "        this.value = terms.join( \", \" );\n";
                        echo "        return false;\n";
                    echo "      }\n";
                echo "    })\n";
                echo "    .focus(function(){\n";
                echo "          var self = \$(this);\n";
                echo "          window.setTimeout(function(){\n";
                echo "              self.autocomplete(\"search\", \"\");\n";
                echo "          }, 1000);\n";
                echo "    });\n";
        echo "    }\n";

        echo "     $(document).ready(function(){ \n";
        echo "        set_auto_complete($( \"#assets, .assets\" )); \n";
        echo "     }) \n";

    echo "</script>\n";
}


/*********************************************
* FUNCTION: DISPLAY REGISTRATION TABLE EDIT *
*********************************************/
function display_registration_table_edit($name="", $company="", $title="", $phone="", $email="", $fname="", $lname="")
{
    global $escaper;
    global $lang;

    echo "
        <div class='registration-table-edit'>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['FirstName']) . ":</label>
                <input type='text' name='fname' id='fname' value='" . $escaper->escapeHtml($fname) . "' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['LastName']) . ":</label>
                <input type='text' name='lname' id='lname' value='" . $escaper->escapeHtml($lname) . "' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['Company']) . ":</label>
                <input type='text' name='company' id='company' value='" . $escaper->escapeHtml($company) . "' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['JobTitle']) . ":</label>
                <input type='text' name='title' id='title' value='" . $escaper->escapeHtml($title) . "' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['Phone']) . ":</label>
                <input type='tel' name='phone' id='phone' value='" . $escaper->escapeHtml($phone) . "' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['EmailAddress']) . ":</label>
                <input type='email' name='email' id='email' value='" . $escaper->escapeHtml($email) . "' class='form-control' />
            </div>
            <button type='submit' name='register' class='btn btn-submit'>" . $escaper->escapeHtml($lang['Register']) . "</button>
        </div>
    ";
}

/****************************************
* FUNCTION: DISPLAY REGISTRATION TABLE *
****************************************/
function display_registration_table($name="", $company="", $title="", $phone="", $email="", $fname="", $lname="")
{
    global $escaper;
    global $lang;

    echo "
        <div class='registration-table'>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['FirstName']) . ":</label>
                <input type='text' name='fname' id='fname' value='" . $escaper->escapeHtml($fname) . "' title='" . $escaper->escapeHtml($fname) . "' disabled='disabled' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['LastName']) . ":</label>
                <input type='text' name='lname' id='lname' value='" . $escaper->escapeHtml($lname) . "' title='" . $escaper->escapeHtml($lname) . "' disabled='disabled' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['Company']) . ":</label>
                <input type='text' name='company' id='company' value='" . $escaper->escapeHtml($company) . "' title='" . $escaper->escapeHtml($company) . "' disabled='disabled' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['JobTitle']) . ":</label>
                <input type='text' name='title' id='title' value='" . $escaper->escapeHtml($title) . "' title='" . $escaper->escapeHtml($title) . "' disabled='disabled' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['Phone']) . ":</label>
                <input type='tel' name='phone' id='phone' value='" . $escaper->escapeHtml($phone) . "' title='" . $escaper->escapeHtml($phone) . "' disabled='disabled' class='form-control' />
            </div>
            <div class='form-group'>
                <label>" . $escaper->escapeHtml($lang['EmailAddress']) . ":</label>
                <input type='email' name='email' id='email' value='" . $escaper->escapeHtml($email) . "' title='" . $escaper->escapeHtml($email) . "' disabled='disabled' class='form-control' />
            </div>
            <button type='submit' name='update' class='btn btn-submit'>" . $escaper->escapeHtml($lang['Update']) . "</button>
        </div> 
    ";
}

/*****************************
* FUNCTION: DISPLAY UPGRADE *
*****************************/
function display_upgrade()
{
    // If the upgrade extra exists
    if (file_exists(realpath(__DIR__ . '/../extras/upgrade/index.php')))
    {
        // Require the upgrade extra file
        require_once(realpath(__DIR__ . '/../extras/upgrade/index.php'));

        display_upgrades();
    }
    // The ugprade does not exist
    else
    {
        echo "There are issues obtaining the upgrade extra.  Check the error log for more information.<br />\n";
    }
}


/*******************************************
* FUNCTION: DISPLAY ADD DELETE ROW SCRIPT *
*******************************************/
function display_add_delete_row_script()
{
    echo "<script language=\"javascript\">\n";
    echo "function addRow(tableID) {\n";
        echo "var table = document.getElementById(tableID);\n";
        echo "var rowCount = table.rows.length;\n";
        echo "var row = table.insertRow(rowCount);\n";
        echo "var colCount = table.rows[1].cells.length;\n";
        echo "for(var i=0; i<colCount; i++) {\n";
            echo "var newcell = row.insertCell(i);\n";
            echo "newcell.innerHTML = table.rows[1].cells[i].innerHTML;\n";
            echo "switch(newcell.childNodes[0].type) {\n";
                echo "case \"text\":\n";
                echo "newcell.childNodes[0].value = \"\";\n";
                echo "break;\n";
                echo "case \"checkbox\":\n";
                echo "newcell.childNodes[0].checked = false;\n";
                echo "break;\n";
                echo "case \"select-one\":\n";
                echo "newcell.childNodes[0].selectedIndex = 0;\n";
                echo "break;\n";
                echo "}\n";
            echo "}\n";
        echo "}\n";
        echo "function deleteRow(tableID) {\n";
            echo "try {\n";
                echo "var table = document.getElementById(tableID);\n";
                echo "var rowCount = table.rows.length;\n";
                echo "if (rowCount > 3) {\n";
                    echo "table.deleteRow(rowCount-1);\n";
                echo "}\n";
                echo "else {\n";
                    echo "alert(\"Cannot delete all the rows.\");\n";
                echo "}\n";
            echo "}catch(e) {\n";
                echo "alert(e);\n";
            echo "}\n";
        echo "}\n";
    echo "</script>\n";
}

/***********************************************
* FUNCTION: DISPLAY VIEW ASSESSMENT QUESTIONS *
***********************************************/
function display_view_assessment_questions($assessment_id = NULL) {

    global $escaper;
    global $lang;

    echo "
        <div class='mt-2'>
            <nav class='nav nav-tabs'>
                <a class='nav-link active' data-bs-target='#self_assessments' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['Assessments'])}</a>
                <a class='nav-link' data-bs-target='#pending_risks' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['PendingRisks'])}</a>
            </nav>
        </div>
        <div class='tab-content'>
            <div id='self_assessments' class='tab-pane active card-body my-2 border'>
                <div class='hero-unit'>
                    <form name='submit_assessment' class='form-horizontal' method='POST' action=''>
    ";
    
    // If the assessment id was sent by get
    if (isset($_GET['assessment_id'])) {

        // Set the assessment id
        $assessment_id = $_GET['assessment_id'];
        
    // If the assessment id was sent by post
    } else if (isset($_POST['assessment_id'])) {

        // Set the assessment id
        $assessment_id = $_POST['assessment_id'];

    }

    // Add a hidden value for the assessment id
    echo "
                        <input type='hidden' name='assessment_id' value='{$escaper->escapeHtml($assessment_id)}' />
    ";

    // Add a hidden value for the action
    echo "
                        <input type='hidden' name='action' value='submit' />
    ";

    // Get the assessment name
    $assessment = get_assessment_names($assessment_id);
    $assessment_name = $assessment['name'];

    $show_autocomplete = get_setting("ASSESSMENT_ASSET_SHOW_AVAILABLE");
    if ($show_autocomplete) {
        $AffectedAssetsWidgetPlaceholder = $escaper->escapeHtml($lang['AffectedAssetsWidgetPlaceholder']);
    } else {
        $AffectedAssetsWidgetPlaceholder = $escaper->escapeHtml($lang['AffectedAssetsWidgetNoDropdownPlaceholder']);
    }

    echo "
                        <h3 class = 'text-center'>{$escaper->escapeHtml($assessment_name)}</h3>
                        <div class = 'form-group'>
                            <label>{$escaper->escapeHtml($lang['AssetName'])} :</label>
                            <select class='assets-asset-groups-select' name='assets_asset_groups[]' multiple placeholder='$AffectedAssetsWidgetPlaceholder'>
                            </select>
                        </div>

                        <script>
                            var assets_and_asset_groups = [];

                            $(document).ready(function() {
    ";
    if ($show_autocomplete) {

        echo "
                                $.ajax({
                                    url: BASE_URL + '/api/v2/asset-group/options',
                                    type: 'GET',
                                    dataType: 'json',
                                    success: function(res) {
                                        var data = res.data;
                                        var len = data.length;
                                        for (var i = 0; i < len; i++) {
                                            var item = data[i];
                                            if (item.class == 'group')
                                                item.id = '[' + item.name + ']';
                                            else
                                                item.id = item.name;
                                            
                                            assets_and_asset_groups.push(item);
                                        }
        ";

    }

    echo "
                                selectize_pending_risk_affected_assets_widget($('select.assets-asset-groups-select'), assets_and_asset_groups);
    ";

    if ($show_autocomplete) {
        echo "
                                    }
                                });
        ";
    }
    echo "
                            });
                        </script>
    ";
    
    // Get the assessment
    $assessment = get_assessment($assessment_id);

    // Set a variable to track the current question
    $current_question = "";


    $rows = array();
    foreach ($assessment as $row) {
        $question_id = (int)$row['question_id'];
        if (!isset($rows[$question_id])) {
            $question = $row['question'];
            $rows[$question_id] = array(
                'question' => $question,
                'answers' => array(),
            );
        }
        $rows[$question_id]['answers'][] = array(
            'id' => (int)$row['answer_id'],
            'answer' => $row['answer'],
        );
    }

    // For each row in the array
    foreach ($rows as $question_id => $row) {

        // Display the question
        echo "
                        <div class='form-group'>
                            <p class='mb-2'><strong>{$escaper->escapeHtml($row['question'])}</strong></p>
                            <div class='mb-2 d-flex align-items-center'>
        ";

        // Display the answers
        foreach ($row['answers'] as $answer) {
            echo "
                                <div class='form-check mx-4'>
                                    <input class='form-check-input' id='{$escaper->escapeHtml($answer['id'])}' type='radio' name='{$escaper->escapeHtml($question_id)}' value='{$escaper->escapeHtml($answer['id'])}' />
                                    <label class = 'form-check-label mb-0' for='{$escaper->escapeHtml($answer['id'])}'>{$escaper->escapeHtml($answer['answer'])}</label>
                                </div>
            ";
        }
        
        echo "
                            </div>
                            <div>
                                <label>Comment :</label>
                                <textarea class='form-control assessment-comment' name='comment[{$question_id}]'></textarea>
                            </div>
                        </div>
        ";
    }

    echo "
                        <div>
                            <input class='btn btn-submit' type='submit' name='submit_assessment' value='{$escaper->escapeHtml($lang['Submit'])}'/>
                        </div>
                    </form>
                </div>
            </div>
            
            <div id='pending_risks' class='tab-pane card-body my-2 border'>
    ";
                display_pending_risks($assessment_id);
    echo "  
            </div>
        </div>
    ";
}

/***********************************
* FUNCTION: DISPLAY PENDING RISKS *
***********************************/
function display_pending_risks($assessment_id = null) {

    global $escaper;
    global $lang;

    // Get the pending risks
    $risks = get_pending_risks();

    $affected_assets_placeholder = $escaper->escapeHtml($lang['AffectedAssetsWidgetPlaceholder']);

    $maxlength = (int)get_setting('maximum_risk_subject_length', 300);
    $date_time_format = get_default_datetime_format('H:i:s');

    // For each pending risk
    foreach ($risks as $risk) {

        //When assessment is selected, only show the pending risks created by that assessment
        if($assessment_id && ($risk['assessment_id'] != $assessment_id)) {
            continue;
        } 

        // Get the assessment name
        $assessment = get_assessment_names($risk['assessment_id']);
        $submission_date = format_datetime($risk['submission_date'], '', 'H:i:s');

        echo "
            <form name='submit_risk' method='post' action='' enctype='multipart/form-data' class='pending-risk-form card-body border my-2'>
                <input type='hidden' name='assessment_id' value='{$escaper->escapeHtml($risk['assessment_id'])}' />
                <input type='hidden' name='pending_risk_id' value='{$escaper->escapeHtml($risk['id'])}' />
                <div class='form-group'>
                    <label for='submission_date'>{$lang['SubmissionDate']} :</label>
                    <input type='text' class='form-control' name='submission_date' value='{$escaper->escapeHtml($submission_date)}' />
                </div>
                <div class='form-group'>
                    <label for='subject'>{$lang['Subject']} :</label>
                    <input maxlength='{$maxlength}' type='text' class='form-control' name='subject' value='{$escaper->escapeHtml($risk['subject'])}' />
                </div>
        ";

        if ($risk['scoring_method']) {

                display_score_html_from_pending_risk($risk['scoring_method'], $risk['Custom'], $risk['CLASSIC_likelihood'], $risk['CLASSIC_impact'], $risk['CVSS_AccessVector'], $risk['CVSS_AccessComplexity'], $risk['CVSS_Authentication'], $risk['CVSS_ConfImpact'], $risk['CVSS_IntegImpact'], $risk['CVSS_AvailImpact'], $risk['CVSS_Exploitability'], $risk['CVSS_RemediationLevel'], $risk['CVSS_ReportConfidence'], $risk['CVSS_CollateralDamagePotential'], $risk['CVSS_TargetDistribution'], $risk['CVSS_ConfidentialityRequirement'], $risk['CVSS_IntegrityRequirement'], $risk['CVSS_AvailabilityRequirement'], $risk['DREAD_DamagePotential'], $risk['DREAD_Reproducibility'], $risk['DREAD_Exploitability'], $risk['DREAD_AffectedUsers'], $risk['DREAD_Discoverability'], $risk['OWASP_SkillLevel'], $risk['OWASP_Motive'], $risk['OWASP_Opportunity'], $risk['OWASP_Size'], $risk['OWASP_EaseOfDiscovery'], $risk['OWASP_EaseOfExploit'], $risk['OWASP_Awareness'], $risk['OWASP_IntrusionDetection'], $risk['OWASP_LossOfConfidentiality'], $risk['OWASP_LossOfIntegrity'], $risk['OWASP_LossOfAvailability'], $risk['OWASP_LossOfAccountability'], $risk['OWASP_FinancialDamage'], $risk['OWASP_ReputationDamage'], $risk['OWASP_NonCompliance'], $risk['OWASP_PrivacyViolation']);

        } else {
                display_score_html_from_pending_risk(5, $risk['Custom']);
        }

        echo "
                <div class='form-group'>
                    <label for='owner'>{$lang['Owner']} :</label>
        ";
                    create_dropdown("enabled_users", $risk['owner'], "owner");
        echo "
                </div>
                <div class='form-group'>
                    <label for='assets_asset_groups'>{$lang['AffectedAssets']} :</label>
                    <select class='assets-asset-groups-select' name='assets_asset_groups[]' multiple placeholder='{$affected_assets_placeholder}'>
        ";

        if ($risk['affected_assets']) {
            foreach (explode(',', $risk['affected_assets']) as $value) {

                $value = $name = trim($value);

                if (preg_match('/^\[(.+)\]$/', $name, $matches)) {
                    $name = trim($matches[1]);
                    $type = 'group';
                } else {
                    $type = 'asset';
                }

                echo "
                        <option value='{$escaper->escapeHtml($value)}' selected data-class='{$type}'>{$escaper->escapeHtml($name)}</option>
                ";
            }
        }

        echo "
                    </select>
                </div>
                <div class='form-group'>
                    <label for='note'>{$lang['AdditionalNotes']} :</label>
                    <textarea class='form-control' name='note' cols='50' rows='3' id='note'>Risk created using the &quot;{$escaper->escapeHtml($assessment['name'])}&quot; assessment.\n{$escaper->escapeHtml($risk['comment'])}</textarea>
                </div>
                <div class='form-actions'>
        ";

        if (isset($_SESSION["submit_risks"]) && $_SESSION["submit_risks"] == 1) {
            echo "
                    <button type='submit' name='add' class='btn btn-submit'>{$escaper->escapeHtml($lang['Add'])}</button>
                    <button type='submit' name='delete' class='btn btn-dark'>{$escaper->escapehtml($lang['Delete'])}</button>
            ";
        }

        echo "  </div>
            </form>
        ";

    }

    echo "
            <script>
                var assets_and_asset_groups = [];
                $(document).ready(function() {
                    $.ajax({
                        url: BASE_URL + '/api/v2/asset-group/options',
                        type: 'GET',
                        dataType: 'json',
                        success: function(res) {
                            var data = res.data;
                            var len = data.length;
                            for (var i = 0; i < len; i++) {
                                var item = data[i];
                                if (item.class == 'group')
                                    item.id = '[' + item.name + ']';
                                else
                                    item.id = item.name;
                                
                                assets_and_asset_groups.push(item);
                            }

                            $('select.assets-asset-groups-select').each(function() {

                                // Need the .slice to force create a new array, 
                                // so we're not adding the items to the original
                                var combined_assets_and_asset_groups = assets_and_asset_groups.slice();
                                // Have to add the selected assets to the list of options,
                                // but only for THIS widget
                                $(this).find('option').each(function() {

                                    combined_assets_and_asset_groups.push({
                                        id: $(this).val(),
                                        name: $(this).text(),
                                        class: $(this).data('class')
                                    });
                                });

                                selectize_pending_risk_affected_assets_widget($(this), combined_assets_and_asset_groups);
                                
                                //Need it to make it as wide as the textbox below
                                $(this).parent().find('.selectize-control>div').css('width', '100%');

                            });
                        }
                    });
                    $('input[name=\"submission_date\"]').initAsDateTimePicker();
                });
            </script>
    ";
}

/******************************************
 * FUNCTION: RISK AVERAGE BASELINE METRIC *
 *****************************************/
function risk_average_baseline_metric($time = "day", $title = "") {
    
    global $escaper, $lang;

    // Get the inherent risk average values by day
    $endpoint = "/api/v2/reports/risk/average?type=inherent&timeframe={$time}";
    $inherent_averages_result = call_simplerisk_api_endpoint($endpoint);

    // Get the residual risk average values by day
    $endpoint = "/api/v2/reports/risk/average?type=residual&timeframe={$time}";
    $residual_averages_result = call_simplerisk_api_endpoint($endpoint);

    // Get the risk count values by day
    $endpoint = "/api/v2/reports/risk/opencount?timeframe={$time}";
    $count_result = call_simplerisk_api_endpoint($endpoint);

    // Create the data arrays
    $labels = $inherent_averages_result['dates'] ?? [];
    $inherent_averages = $inherent_averages_result['averages'] ?? [];
    $residual_averages = $residual_averages_result['averages'] ?? [];
    $counts = $count_result['counts'] ?? [];

    // Create the inherent average dataset
    $label = $lang['InherentRisk'];
    $inherent_average_dataset = [
        "label" => "{$label}",
        "data" => $inherent_averages,
        "fill" => "false",
        "borderColor" => "#000000",
        "borderWidth" => "1",
        "tension" => "0.1"
    ];

    // Create the residual average dataset
    $label = $lang['ResidualRisk'];
    $residual_average_dataset = [
        "label" => "{$label}",
        "data" => $residual_averages,
        "fill" => "false",
        "borderColor" => "#0000FF",
        "borderWidth" => "1",
        "tension" => "0.1"
    ];

    // Create an array of the combined datasets
    $datasets = [
        $inherent_average_dataset,
        $residual_average_dataset,
    ];

    // Add the background dataset
    $background_dataset = create_background_dataset(count($labels));
    $datasets = array_merge($datasets, $background_dataset);

    // Create a javascript array of open risks
    $risksOpened_label = $lang['OpenRisks'];
    $risksOpened = implode(',', $counts);

    // Create the Chart.js line chart
    $title = $lang['RiskAverageOverTime'];
    $element_id = "risk_score_average";
    $x_axis_title = $lang['Date'];
    $y_axis_title = $lang['RiskScore'];
    $tooltip = "
        tooltip: {
            callbacks: {
                label: function (tooltipItem) {
                    // Use the average risk score index
                    if (tooltipItem.datasetIndex === 0)
                    {
                        var dataIndex = tooltipItem.dataIndex;
                        var value = tooltipItem.formattedValue;
                        var label = tooltipItem.label;
                        var datasetLabel = tooltipItem.dataset.label;
                        result = [
                            datasetLabel + ': ' + value,
                        ];
                        return result;
                    }
                    else if (tooltipItem.datasetIndex === 1)
                    {
                        var risksOpened = [{$risksOpened}];
                        var dataIndex = tooltipItem.dataIndex;
                        var value = tooltipItem.formattedValue;
                        var label = tooltipItem.label;
                        var datasetLabel = tooltipItem.dataset.label;
                        var risksOpened_value = risksOpened[dataIndex];
                        result = [
                            datasetLabel + ': ' + value,
                            '{$risksOpened_label}: ' + risksOpened_value,
                        ];
                        return result;
                    }
                    else return '';
                }
            }
        }
    ";
    // @phan-suppress-next-line SecurityCheck-XSS -- chart data from internal API encoded via json_encode() inside function; $tooltip uses numeric values and escaped lang strings
    create_chartjs_line_code($title, $element_id, $labels, $datasets, $tooltip, $x_axis_title, $y_axis_title, 10);
}

/********************************************
 * FUNCTION: RISK FOR LIKELIHOOD AND IMPACT *
 ********************************************/
function report_likelihood_impact() {

    global $lang;
    global $escaper;

    // Get classic risks
    $risks = get_risks(10);

    // Create an empty datasets array
    $datasets = [];

    // Create arrays for each data point
    $max_x = get_likelihoods_count();
    $max_y = get_impacts_count();

    // For each x value from the max to zero
    for ($x=$max_x; $x>=0; $x--) {

        // For each y value from the max to zero
        for ($y=$max_y; $y>=0; $y--) {

            // Create the default values
            $risk_ids = [];
            $risk_subjects = [];
            $count = 0;
            $inherent_risk = 0;
            $color = '';

            // Search the $risks array for the likelihood and impact values
            foreach ($risks as $risk) {

                // If we have a matching likelihood and impact
                if ($x == $risk['CLASSIC_likelihood'] && $y == $risk['CLASSIC_impact']) {
                    // Get the risk information
                    $risk_id = $risk['id'] + 1000;
                    $risk_ids[] = $risk_id;
                    $mitigation_percent = $risk['mitigation_percent'];
                    $count = count($risk_ids);

                    // Get the inherent and residual risk scores
                    $residual_risk = round(($risk['calculated_risk'] - ($risk['calculated_risk'] * $mitigation_percent/100)), 2);
                    $inherent_risk = round($risk['calculated_risk'], 2);

                    // Get the color of the calculated risk
                    $color = get_risk_color($inherent_risk);

                    // Get the risk subject to be displayed (json_encode in bubble chart handles escaping)
                    $subject = $risk['subject'];
                    $residual_risk = "{$escaper->escapeHtml($lang['ResidualRisk'])}: {$residual_risk}";
                    $residual_risk = str_pad($residual_risk, 20);
                    $risk_subjects[] = truncate_to("{$residual_risk}[{$risk_id}] {$subject}", 50);
                }
            }

            // If we have at least one risk in the dataset
            if ($count > 0) {

                // Scale the r value based on the count but no more than 50
                $r = ($count * 3 < 50 ? $count * 3 : 50);

                // Create the dataset for these likelihood and impact values
                $dataset = [
                    "x" => $x,
                    "y" => $y,
                    "r" => $r,
                    "label" => "{$inherent_risk}",
                    "color" => "{$color}",
                    "ids" => $risk_ids,
                    "subjects" => $risk_subjects,
                    "count" => $count,
                ];

                // Add the dataset to the datasets array
                $datasets[] = $dataset;
            }
        }
    }

    // Create a custom tooltip to update the labels
    $tooltip = "
        tooltip: {
            callbacks: {
                label: function (tooltipItem) {
                    // Get the dataset index for the selected tooltip
                    var index = tooltipItem.datasetIndex;
                    // Get the score
                    var score = scores[index];
                    dataset_ids = ids[index];
                    dataset_subjects = subjects[index];
                    result = [
                        '{$escaper->escapeHtml($lang['InherentRisk'])}: ' + score,
                    ];
                    // For each risk with this score
                    for (i=0; i<dataset_ids.length; ++i)
                    {
                        // Add it to the result
                        result.push(dataset_subjects[i]);
                    }
                    return result;
                }
            }
        }
    ";

    $element_id = "likelihood_impact_chart";
    $x_axis_title = $lang['Likelihood'];
    $y_axis_title = $lang['Impact'];
    create_chartjs_bubble_code("", $element_id, $datasets, $tooltip, $x_axis_title, $y_axis_title);
}

/************************************
 * FUNCTION: GET DATA OF RISK LEVEL *
 ************************************/
function get_data_risk_level( $risk_level , $y , $x , $f){
    $data = array();
    $temp = array();
    
    $data[] = [
                'x' => 0,
                'y' => 0,
                'risk' => 0,
            ];

    for ($i=1; $i <= $x; $i++) { 
       
        for ($j=1; $j <= $y; $j++) {
            if ($f == 0) {
                if ( calculate_risk($j,$i) <= $risk_level ) {
                
                    $temp[] = [
                        'x' => $i,
                        'y' => $j,
                        'risk' => calculate_risk($j,$i)
                    ];

                }
            } else if ( $f == 1 ) {
                if ( calculate_risk($j,$i) < $risk_level ) {
                
                    $temp[] = [
                        'x' => $i,
                        'y' => $j,
                        'risk' => calculate_risk($j,$i)
                    ];

                }
            }
            
        }
    }

    $temp2 = [
        'x' => 0,
        'y' => 0,
    ];

    for ($i=1; $i <= $x; $i++) {

        $temp1 = [
            'x' => 0,
            'y' => 0,
            'risk' => 0
        ];

        for ($j=0; $j < sizeof($temp); $j++) { 
            if ( $temp[$j]['x'] == $i) {

                if ($temp[$j]['risk'] >= $temp1['risk'] ) {
                    $temp1['x'] = $temp[$j]['x'];
                    $temp1['y'] = $temp[$j]['y'];
                    $temp1['risk'] = $temp[$j]['risk'];
                }
            }
        }

        if ($temp1['y'] != $temp2['y']) {
            $data[] = [
                'x' => $temp2['x'],
                'y' => $temp1['y']
            ];
        }

        $data[] = $temp1;

        $temp2['x'] = $temp1['x'];
        $temp2['y'] = $temp1['y'];
        $temp2['risk'] = $temp1['risk'];
    }

    return $data;
}

/********************************************************
 * FUNCTION: VIEW PRINT RISK SCORE FORMS IN PENDING RISK *
 *********************************************************/
function display_score_html_from_pending_risk(
    $scoring_method="5",
    $custom=false,
    $CLASSIC_likelihood="",
    $CLASSIC_impact="",
    $AccessVector="N",
    $AccessComplexity="L",
    $Authentication="N",
    $ConfImpact="C",
    $IntegImpact="C",
    $AvailImpact="C",
    $Exploitability="ND",
    $RemediationLevel="ND",
    $ReportConfidence="ND",
    $CollateralDamagePotential="ND",
    $TargetDistribution="ND",
    $ConfidentialityRequirement="ND",
    $IntegrityRequirement="ND",
    $AvailabilityRequirement="ND",
    $DREADDamagePotential="10",
    $DREADReproducibility="10",
    $DREADExploitability="10",
    $DREADAffectedUsers="10",
    $DREADDiscoverability="10",
    $OWASPSkillLevel="10",
    $OWASPMotive="10",
    $OWASPOpportunity="10",
    $OWASPSize="10",
    $OWASPEaseOfDiscovery="10",
    $OWASPEaseOfExploit="10",
    $OWASPAwareness="10",
    $OWASPIntrusionDetection="10",
    $OWASPLossOfConfidentiality="10",
    $OWASPLossOfIntegrity="10",
    $OWASPLossOfAvailability="10",
    $OWASPLossOfAccountability="10",
    $OWASPFinancialDamage="10",
    $OWASPReputationDamage="10",
    $OWASPNonCompliance="10",
    $OWASPPrivacyViolation="10",
    $ContributingLikelihood="",
    $ContributingImpacts=[],
    $display_type = 1
) {
    global $escaper, $lang;

    if ($custom === false) {
        $custom = get_setting("default_risk_score");
    }
    if (!$scoring_method) {
        $scoring_method = 5;
    }

    // Determine container classes based on display type
    $containerClass = ($display_type === 2) ? "row mb-2" : "mb-3";
    $labelClass = ($display_type === 2) ? "col-2 d-flex align-items-center justify-content-start" : "";
    $inputClass = ($display_type === 2) ? "col-10" : "";

    $html = "
        <div class='risk-scoring-container'>
            <div class='{$containerClass}'>
                " . ($labelClass ? "<div class='{$labelClass}'><label>{$escaper->escapeHtml($lang['RiskScoringMethod'])} :</label></div>" : "") . "
                <div class='{$inputClass}'>" .
                    create_dropdown("scoring_methods", $scoring_method, "scoring_method[]", false, false, true, 'form-select') . "
                </div>
            </div>
    ";

    // Classic scoring
    $html .= "
            <div id='classic' class='classic-holder' style='display:" . ($scoring_method == 1 ? "block" : "none") . "'>
                <div class='{$containerClass}'>
                    " . ($labelClass ? "<div class='{$labelClass}'><label>{$escaper->escapeHtml($lang['CurrentLikelihood'])} :</label></div>" : "") . "
                    <div class='{$inputClass}'>" .
                        create_dropdown('likelihood', $CLASSIC_likelihood, 'likelihood[]', true, false, true, 'form-select') . "
                    </div>
                </div>
                <div class='{$containerClass}'>
                    " . ($labelClass ? "<div class='{$labelClass}'><label>{$escaper->escapeHtml($lang['CurrentImpact'])} :</label></div>" : "") . "
                    <div class='{$inputClass}'>" .
                        create_dropdown('impact', $CLASSIC_impact, 'impact[]', true, false, true, 'form-select') . "
                    </div>
                </div>
            </div>
    ";

    // CVSS scoring with modal integration
    // --- CVSS modal button & hidden inputs ---
    $html .= "
            <div id='cvss' style='display:" . ($scoring_method == 2 ? "block" : "none") . "' class='cvss-holder'>
                <div class='{$containerClass}'>
                    <button type='button' id='cvssOpenModalBtn' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#cvssModal'>
                        Score Using CVSS
                    </button>
                </div>
            </div>
    ";

    // Include the modal itself
    ob_start();
    require_once realpath(__DIR__ . '/../management/partials/cvss_modal_content.php');
    $cvss_modal_html = ob_get_clean();
    $html .= $cvss_modal_html;

    // DREAD scoring
    $html .= "
            <div id='dread' style='display: " . ($scoring_method == 3 ? "block" : "none") . ";' class='dread-holder'>
                <div class='{$containerClass}'>
                    <button type='button' class='btn btn-primary' id='dreadSubmit' onclick='popupdread();'>Score Using DREAD</button>
                    <input type='hidden' name='DREADDamage[]' id='DREADDamage' value='{$escaper->escapeHtml($DREADDamagePotential)}' />
                    <input type='hidden' name='DREADReproducibility[]' id='DREADReproducibility' value='{$escaper->escapeHtml($DREADReproducibility)}' />
                    <input type='hidden' name='DREADExploitability[]' id='DREADExploitability' value='{$escaper->escapeHtml($DREADExploitability)}' />
                    <input type='hidden' name='DREADAffectedUsers[]' id='DREADAffectedUsers' value='{$escaper->escapeHtml($DREADAffectedUsers)}' />
                    <input type='hidden' name='DREADDiscoverability[]' id='DREADDiscoverability' value='{$escaper->escapeHtml($DREADDiscoverability)}' />
                </div>
            </div>
    ";

    // OWASP scoring
    $html .= "
            <div id='owasp' style='display: " . ($scoring_method == 4 ? "block" : "none") . ";' class='owasp-holder'>
                <div class='{$containerClass}'>
                    <button type='button' class='btn btn-primary' id='owaspSubmit'>Score Using OWASP</button>
    ";

    $owasp_fields = [
        "OWASPSkillLevel","OWASPMotive","OWASPOpportunity","OWASPSize","OWASPEaseOfDiscovery",
        "OWASPEaseOfExploit","OWASPAwareness","OWASPIntrusionDetection","OWASPLossOfConfidentiality",
        "OWASPLossOfIntegrity","OWASPLossOfAvailability","OWASPLossOfAccountability","OWASPFinancialDamage",
        "OWASPReputationDamage","OWASPNonCompliance","OWASPPrivacyViolation"
    ];
    foreach ($owasp_fields as $field) {
        $value = $$field ?? "";
        $html .= "
                    <input type='hidden' name='{$field}[]' id='{$field}' value='{$escaper->escapeHtml($value)}' />
        ";
    }
    $html .= "
                </div>
            </div>
    ";

    // Custom scoring
    $html .= "
            <div id='custom' style='display: " . ($scoring_method == 5 ? "block" : "none") . ";' class='custom-holder'>
                <div class='{$containerClass}'>
                    " . ($labelClass ? "<div class='{$labelClass}'><label>{$escaper->escapeHtml($lang['CustomValue'])} :</label></div>" : "") . "
                    <div class='{$inputClass}'>
                        <input type='number' min='0' step='0.1' max='10' name='Custom[]' id='Custom' value='{$escaper->escapeHtml($custom)}' class='form-control' />
                        <small class='form-text text-muted'>(Must be a numeric value between 0 and 10)</small>
                    </div>
                </div>
            </div>
    ";

    // Contributing risk
    $html .= "
            <div id='contributing-risk' style='display: " . ($scoring_method == 6 ? "block" : "none") . ";' class='contributing-risk-holder'>
                <div class='{$containerClass}'>
                    <button type='button' class='btn btn-primary' id='contributingRiskSubmit'>{$escaper->escapeHtml($lang["ScoreUsingContributingRisk"])}</button>
                    <input type='hidden' name='ContributingLikelihood[]' id='contributing_likelihood' value='" . ($ContributingLikelihood ? $escaper->escapeHtml($ContributingLikelihood) : count(get_table("likelihood"))) . "' />
    ";

    $max_impact_value = count(get_table("impact"));
    $contributing_risks = get_contributing_risks();
    foreach ($contributing_risks as $cr) {
        $impact_value = empty($ContributingImpacts[$cr['id']]) ? $max_impact_value : $ContributingImpacts[$cr['id']];
        $html .= "
                    <input type='hidden' class='contributing-impact' name='ContributingImpacts[{$cr['id']}][]' id='contributing_impact_{$cr['id']}' value='{$escaper->escapeHtml($impact_value)}' />
        ";
    }
    $html .= "
                </div>
            </div>
    ";

    // close risk-scoring-container
    $html .= "
        </div>
    ";

    echo $html;
}

/***************************************************
* FUNCTION: DISPLAY SET DEFAULT DATE FORMAT SCRIPT *
****************************************************/
function display_set_default_date_format_script()
{
    global $escaper;
    echo "
        <script type=''>
            if($.datepicker !== undefined){
                $.datepicker.setDefaults({dateFormat: '{$escaper->escapeHtml(get_default_date_format_for_js())}'});
            }
            var default_date_format = '{$escaper->escapeHtml(get_default_date_format_for_js())}';
        </script>
    ";
}

/*******************************
 * FUNCTION: CREATE RISK TABLE *
 *******************************/
function create_risk_formula_table() {

    global $lang;
    global $escaper;

    $impacts = array_reverse(get_table("impact"));
    $likelihoods = get_table("likelihood");

    $risk_levels = get_risk_levels();
    $risk_levels_by_color = array();
    foreach ($risk_levels as $risk_level) {
        $risk_levels_by_color[$risk_level['name']] = $risk_level;
    }

    $risk_model = get_setting("risk_model");
    $need_risk_score_normalization = get_setting("need_risk_score_normalization", default: 'true');

    echo "
        <h4 class='page-title'>{$escaper->escapeHtml($lang['MyClassicRiskFormulaIs'])} :</h4>
        <form name='risk_levels' method='post' action=''>
            <div class='row'>
                <div class='col-md-4'>
                    <div class='form-group'>
                        <label>{$escaper->escapeHtml($lang['RISK'])} =</label>
    ";
                        create_dropdown("risk_models", $risk_model, null, false);
    echo "
                    </div>
                </div>
            </div>
            <div class='row'>
                <div class='col-md-4'>
                    <div class='form-group'>
                        <input class='form-check-input me-3' type='checkbox' id='need_risk_score_normalization' name='need_risk_score_normalization' " . ($need_risk_score_normalization == "true" ? "checked" : "") . " value='1'>
                        <label class='mb-0'>{$escaper->escapeHtml($lang['NormalizeScoringOnA0_10Scale'])}</label>
                    </div>
                </div>
            </div>
            <input type='submit' value='{$escaper->escapeHtml($lang['Update'])}' name='update_risk_formula' class='btn btn-submit'/>
        </form>
        <br>
    ";
    
    // Create legend table
    echo "
        <table class='risk-level-table'>
            <tr height='20px'>
                <td><div class='risk-table-veryhigh' style='background-color: {$escaper->escapeCssColor($risk_levels_by_color['Very High']['color'])}' /></td>
                <td>{$escaper->escapeHtml($risk_levels_by_color['Very High']['display_name'] . " " . $lang['Risk'])}</td>
                <td>&nbsp;</td>
                <td><div class='risk-table-high' style='background-color: {$escaper->escapeCssColor($risk_levels_by_color['High']['color'])}' /></td>
                <td>{$escaper->escapeHtml($risk_levels_by_color['High']['display_name'] . " " . $lang['Risk'])}</td>
                <td>&nbsp;</td>
                <td><div class='risk-table-medium' style='background-color: {$escaper->escapeCssColor($risk_levels_by_color['Medium']['color'])}' /></td>
                <td>{$escaper->escapeHtml($risk_levels_by_color['Medium']['display_name'] . " " . $lang['Risk'])}</td>
                <td>&nbsp;</td>
                <td><div class='risk-table-low' style='background-color: {$escaper->escapeCssColor($risk_levels_by_color['Low']['color'])}' /></td>
                <td>{$escaper->escapeHtml($risk_levels_by_color['Low']['display_name'] . " " . $lang['Risk'])}</td>
                <td>&nbsp;</td>
                <td><div class='risk-table-insignificant' style='background-color: white' /></td>
                <td>{$escaper->escapeHtml($lang['Insignificant'])}</td>
            </tr>
        </table>
        
        <br>
        
        <div class='d-flex m-l-40 mb-2 impact-btn-container'>
            <a id='add-impact' href='#'><i class='fa fa-plus' title='{$escaper->escapeHtml($lang['AddImpact'])}' width='25px'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a id='delete-impact' href='#'><i class='fa fa-minus' title='{$escaper->escapeHtml($lang['DeleteImpact'])}' width='25px'></i></a>
        </div>
        
        <div class='risk-formula-table-container overflow-x-auto'>
            <table class='risk-formula-table' border='0' cellspacing='0' cellpadding='10' style='display: block; white-space: nowrap;'>
    ";

    // For each impact level
    foreach($impacts as $i => $impact) {

        echo "
                <tr>
        ";

        // If this is the first row add the y-axis label
        if ($i == 0) {
            echo "
                    <td rowspan='" . count($impacts) . "'>
                        <div id='impact-label'>
                            <b>{$escaper->escapeHtml($lang['Impact'])}</b>
                        </div>
                    </td>
            ";
        }

        $impact_name = $impacts[$i]['name'] ? $escaper->escapeHtml($impacts[$i]['name']) : "--";
        $impact_value = $escaper->escapeHtml($impacts[$i]['value']);

        // Add the y-axis values
        echo "
                    <td bgcolor='silver' height='50px' width='200px'>
                        <span>
                            <span class='editable'>{$impact_name}</span>
                            <input type='text' class='editable' value='{$impact_name}' style='display: none;' data-type='impact' data-id='{$impact_value}'>
                        </span>                    
                    </td>
                    <td bgcolor='silver' align='center' height='50px' width='50px'>{$escaper->escapeHtml($impacts[$i]['value'])}</td>
        ";

        // For each likelihood level
        foreach($likelihoods as $j => $likelihood) {

            // Calculate risk
            $risk = calculate_risk($impact['value'], $likelihood['value']);

            // Get the risk color
            $color = get_risk_color($risk);
            $value = $escaper->escapeHtml($risk);

            echo "
                    <td align='center' bgcolor='{$escaper->escapeHtml($color)}' height='50px' width='150px'>
                        <span>
            ";

            if ($risk_model == 6) {

                echo "
                            <span class='editable'>{$value}</span>
                            <input type='text' class='editable' value='{$value}' style='display: none;' data-type='score' data-impact='{$impact['value']}' data-likelihood='{$likelihood['value']}'>
                ";

            } else {

                echo        $value;

            }

            echo "
                        </span>
                    </td>
            ";

        }

        echo "
                    <td>&nbsp;</td>
                </tr>
        ";

    }

    echo "
                <tr>
                    <td>&nbsp;</td>
                    <td bgcolor='silver'>&nbsp;</td>
                    <td bgcolor='silver'>&nbsp;</td>
    ";

    // Add the x-axis values
    foreach (range(1, count($likelihoods)) as $likelihood_value) {

        echo "
                    <td align='center' bgcolor='silver'>
                        {$likelihood_value}
                    </td>
        ";

    }

    echo "
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td bgcolor='silver'>&nbsp;</td>
                    <td bgcolor='silver'>&nbsp;</td>
    ";

    // Add the x-axis names
    foreach ($likelihoods as $likelihood) {

        $likelihood_name = $likelihood['name'] ? $escaper->escapeHtml($likelihood['name']) : "--";
        $likelihood_value = $escaper->escapeHtml($likelihood['value']);

        echo "
                    <td align='center' bgcolor='silver' height='50px' width='100px'>
                        <span>
                            <span class='editable'>{$likelihood_name}</span>
                            <input type='text' class='editable' value='{$likelihood_name}' style='display: none;' data-type='likelihood' data-id='{$likelihood_value}'>
                        </span> 
                    </td>
        ";
        
    }

    echo "
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td colspan='" . count($likelihoods) . "' align='center'><b>{$escaper->escapeHtml($lang['Likelihood'])}</b></td>
                    <td align='center'>
                        <div class='d-flex likelihood-btn-container'>
                            <a id='add-likelihood' href='#'><i class='fa fa-plus' title='{$escaper->escapeHtml($lang['AddLikelihood'])}' width='25px'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                            <a id='delete-likelihood' href='#'><i class='fa fa-minus' title='{$escaper->escapeHtml($lang['DeleteLikelihood'])}' width='25px'></i></a>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
        
        <script>
            $(document).ready(function(){

                // To save the original value
                $('#classic-risk-formula input.editable').on('focusin', function(){
                    $(this).data('original-value', $(this).val());
                });

                $('#classic-risk-formula input.editable').change(function(){

                    var container = $(this).parent();
                    var type = $(this).data('type');
                    var original_value = $(this).data('original-value');

                    switch(type) {
                        case 'impact':
                        case 'likelihood':
                            url = BASE_URL + '/api/v2/riskformula/update_impact_or_likelihood_name';
                            var value = $(this).data('id');
                            var name = $(this).val();
                            var data = {
                                value: value,
                                name: name,
                                type: type
                            };
                        break;
                        case 'score':
                            var url = BASE_URL + '/api/v2/riskformula/update_custom_score';
                            var impact = $(this).data('impact');
                            var likelihood = $(this).data('likelihood');
                            var score = $(this).val();
                            var data = {
                                impact: impact,
                                likelihood: likelihood,
                                score: score
                            };
                        break;
                    }

                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        success: function(response){
                            container.find('span.editable').text(response.data.confirmed_data ? response.data.confirmed_data : '--');
                            if (response.data.color) {
                                container.closest('td').css('background-color', response.data.color);
                            }
                            showAlertsFromArray(response.status_message);
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                container.find('span.editable').text(original_value);
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        }
                    });
                })
                
                $('#add-impact').click(function(e){
                    e.preventDefault();
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/api/v2/riskformula/add_impact',
                        success: function(data){
                            document.location.reload();
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        }
                    });
                })
                $('#delete-impact').click(function(e){
                    e.preventDefault();
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/api/v2/riskformula/delete_impact',
                        success: function(data){
                            document.location.reload();
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this))
                            {
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        }
                    });
                })
                $('#add-likelihood').click(function(e){
                    e.preventDefault();
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/api/v2/riskformula/add_likelihood',
                        success: function(data){
                            document.location.reload();
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this))
                            {
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        }
                    });
                })
                $('#delete-likelihood').click(function(e){
                    e.preventDefault();
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/api/v2/riskformula/delete_likelihood',
                        success: function(data){
                            document.location.reload();
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this))
                            {
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        }
                    });
                })
            })
        </script>
    ";

}

/**********************************************
* FUNCTION: VIEW RISKS AND CONTROLS SELECTIONS *
**********************************************/
function view_risks_and_controls_selections($report, $sort_by, $projects, $status) {

    global $lang;
    global $escaper;

    echo "
        <div class='row form-group'>
            <div class='col-3'>
                <label>{$escaper->escapeHtml($lang['Report'])} :</label>
                <select class='form-select' id='report' name='report' onchange='javascript: submit()'>
                    <option value='0'" . ($report == 0 ? " selected" : "") . ">{$escaper->escapeHtml($lang['RisksByControl'])}</option>
                    <option value='1'" . ($report == 1 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ControlsByRisk'])}</option>
                </select>
            </div>
            <div class='col-3'>
                <label>{$escaper->escapeHtml($lang['Project'])} :</label>
    "; 
                create_multiple_dropdown("projects", $projects, NULL, NULL, true, $lang['Unassigned'], "-1");
    echo "
            </div>
    ";
    if ($report == 0) {
        echo "
            <div class='col-3'>
                <label>{$escaper->escapeHtml($lang['SortBy'])} :</label>
                <select class='form-select' id='sortby' name='sort_by' onchange='javascript: submit()'>
                    <option value='0'" . ($sort_by == 0 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ControlName'])}</option>
                    <option value='1'" . ($sort_by == 1 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ControlRisk'])}</option>
                </select>
            </div>
        ";
    }
    echo "
            <div class='col-3'>
                <label>{$escaper->escapeHtml($lang['Status'])} :</label>
                <select class='form-select' id='status' name='status' onchange='javascript: submit();'>
                    <option value='0'" . ($status == 0 ? " selected" : "") . ">{$escaper->escapeHtml($lang['OpenRisks'])}</option>
                    <option value='1'" . ($status == 1 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ClosedRisks'])}</option>
                    <option value='2'" . ($status == 2 ? " selected" : "") . ">{$escaper->escapeHtml($lang['AllRisks'])}</option>
                </select>
            </div>
        </div>
            
        <script>
            $(function() {
                $('#projects').multiselect({
                    allSelectedText: '{$escaper->escapeHtml($lang['ALL'])}',
                    enableFiltering: true,
                    buttonWidth: '100%',
                    maxHeight: 250,
                    includeSelectAllOption: true,
                    enableCaseInsensitiveFiltering: true,
                    onChange: function(){
                        $('form[name=select_report]').submit();
                    }
                });
            });
        </script>
    ";
}

/********************************************
* FUNCTION: VIEW CONTROLS FILTER SELECTIONS *
*********************************************/
function view_controls_filter_selections() {

    global $lang;
    global $escaper;

    if (count($_POST) > 3) {
        $control_framework = isset($_POST['control_framework']) ? $_POST['control_framework'] : [];
        $control_family = isset($_POST['control_family']) ? $_POST['control_family'] : [];
        $control_class = isset($_POST['control_class']) ? $_POST['control_class'] : [];
        $control_phase = isset($_POST['control_phase']) ? $_POST['control_phase'] : [];
        $control_priority = isset($_POST['control_priority']) ? $_POST['control_priority'] : [];
        $control_owner = isset($_POST['control_owner']) ? $_POST['control_owner'] : [];
    } else {
        $control_framework = "all";
        $control_family = "all";
        $control_class = "all";
        $control_phase = "all";
        $control_priority = "all";
        $control_owner = "all";
    }

    echo   "
        <div class='row form-group'>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlFrameworks'])} :</label>
    ";
                create_multiple_dropdown("control_framework", $control_framework, null, getAvailableControlFrameworkList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlFamily'])} :</label>
    ";
                create_multiple_dropdown("control_family", $control_family, null, getAvailableControlFamilyList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlClass'])} :</label>
    ";
                create_multiple_dropdown("control_class", $control_class, null, getAvailableControlClassList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
        </div>
        <div class='row form-group'>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlPhase'])} :</label>
    ";
                create_multiple_dropdown("control_phase", $control_phase, null, getAvailableControlPhaseList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlPriority'])} :</label>
    ";
                create_multiple_dropdown("control_priority", $control_priority, null, getAvailableControlPriorityList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlOwner'])} :</label>
    ";
                create_multiple_dropdown("control_owner", $control_owner, null, getAvailableControlOwnerList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
        </div>
        
        <script>
            $(document).ready( function(){
                $('select[multiple]').multiselect({
                    allSelectedText: '{$escaper->escapeHtml($lang['ALL'])}',
                    enableFiltering: true,
                    maxHeight: 250,
                    buttonWidth: '100%',
                    includeSelectAllOption: true,
                    enableCaseInsensitiveFiltering: true,
                    onChange: function(){
                        $('form[name=select_report]').submit();
                    }
                });
            });
        </script>
    ";

}

/**************************************************
* FUNCTION: VIEW ASSETS AND CONTROLS SELECTIONS *
**************************************************/
function view_assets_and_controls_selections($report, $sort_by) {

    global $lang;
    global $escaper;

    echo "
        <div class='row form-group'>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['Report'])} :</label>
                <select class='form-select' id='report' name='report' onchange='javascript: submit()'>
                    <option value='0'" . ($report == 0 ? " selected" : "") . ">{$escaper->escapeHtml($lang['AssetsByControl'])}</option>
                    <option value='1'" . ($report == 1 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ControlsByAsset'])}</option>
                </select>
            </div>
    ";
    if ($report == 0) {
        echo "
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['SortBy'])} :</label>
                <select class='form-select' id='sortby' name='sort_by' onchange='javascript: submit()'>
                    <option value='0'" . ($sort_by == 0 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ControlShortName'])}</option>
                    <option value='1'" . ($sort_by == 1 ? " selected" : "") . ">{$escaper->escapeHtml($lang['ControlNumber'])}</option>
                </select>
            </div>
        ";
    }
    echo "
        </div>
    ";
}

/***************************************************
* FUNCTION: VIEW CONTROLS FILTER SELECTIONS FOR ASSETS *
****************************************************/
function view_controls_filter_selections_for_assets() {

    global $lang;
    global $escaper;

    if (count($_POST) > 1) {
        $control_framework = isset($_POST['control_framework']) ? $_POST['control_framework'] : [];
        $control_family = isset($_POST['control_family']) ? $_POST['control_family'] : [];
        $control_class = isset($_POST['control_class']) ? $_POST['control_class'] : [];
        $control_phase = isset($_POST['control_phase']) ? $_POST['control_phase'] : [];
        $control_priority = isset($_POST['control_priority']) ? $_POST['control_priority'] : [];
        $control_owner = isset($_POST['control_owner']) ? $_POST['control_owner'] : [];
    } else {
        $control_framework = "all";
        $control_family = "all";
        $control_class = "all";
        $control_phase = "all";
        $control_priority = "all";
        $control_owner = "all";
    }

    echo   "
        <div class='row form-group'>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlFrameworks'])} :</label>
    ";
                create_multiple_dropdown("control_framework", $control_framework, null, getAvailableControlFrameworkList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlFamily'])} :</label>
    ";
                create_multiple_dropdown("control_family", $control_family, null, getAvailableControlFamilyList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlClass'])} :</label>
    ";
                create_multiple_dropdown("control_class", $control_class, null, getAvailableControlClassList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
        </div>
        <div class='row form-group'>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlPhase'])} :</label>
    ";
                create_multiple_dropdown("control_phase", $control_phase, null, getAvailableControlPhaseList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlPriority'])} :</label>
    ";
                create_multiple_dropdown("control_priority", $control_priority, null, getAvailableControlPriorityList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
            <div class='col-4'>
                <label>{$escaper->escapeHtml($lang['ControlOwner'])} :</label>
    ";
                create_multiple_dropdown("control_owner", $control_owner, null, getAvailableControlOwnerList(), true, $escaper->escapeHtml($lang['Unassigned']), "-1");
    echo "
            </div>
        </div>
        
        <script>
            $(document).ready( function(){
                $('select[multiple]').multiselect({
                    allSelectedText: '{$escaper->escapeHtml($lang['ALL'])}',
                    enableFiltering: true,
                    maxHeight: 250,
                    buttonWidth: '100%',
                    includeSelectAllOption: true,
                    enableCaseInsensitiveFiltering: true,
                    onChange: function(){
                        $('form[name=select_report]').submit();
                    }
                });
            });
        </script>
    ";

}

/**********************************************
* FUNCTION: DISPLAY CONTRIBUTING RISK FORMULA *
**********************************************/
function display_contributing_risk_formula() {

    global $lang, $escaper;

    echo "
        <table id='template-for-adding' style='display: none'>
            <tr>
                <td align='center'></td>
                <td align='center'><input type='text' class='new-name form-control' value=''></td>
                <td align='center'><a class='delete-row'><i class='fa fa-trash'></i></a></td>
                <td></td>
            </tr>
        </table>
        <table id='template-for-impact-adding' style='display: none'>
            <tr>
                <td class='p-1 border-0' align='center'><input type='text' class='subject form-control' required name='subject[]' style='max-width: none'></td>
                <td class='p-1 border-0' align='center'><input type='number' class='weight form-control' required step='0.01' name='weight[]' max='1' min='0'></td>
                <td class='p-1 border-0' align='center' style='vertical-align: middle;'><a class='delete-row' href=''><i class='fa fa-trash'></i></a></td>
            </tr>
        </table>
        <div class='well card-body my-2 border'>
            <div class='row'>
                <div class='col-6'>
                    <h4>{$escaper->escapeHtml($lang["Likelihood"])}</h4>
                </div>
                <div class='col-6 text-end'>
                    <button id='likelihood-add-btn' class='btn btn-dark'><i class='fa fa-plus'></i></button>
                </div>
            </div>

            <table width='100%' id='contributing-risks-likelihood-table' class='table table-hover header'>
                <thead>
                    <tr class='text-center'>
                        <th width='10%'>{$escaper->escapeHtml($lang["Value"])}</th>
                        <th width='40%'>{$escaper->escapeHtml($lang["Name"])}</th>
                        <th width='20%'>{$escaper->escapeHtml($lang["Actions"])}</td>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
    ";

    $table_list = display_contributing_risks_likelihood_table_list();

    echo            $table_list;
    echo "
                </tbody>
            </table>
        </div>
        <div class='well card-body my-2 border'>
            <div class='row'>
                <div class='col-6'>
                    <h4>{$escaper->escapeHtml($lang["Impact"])}</h4>
                </div>
                <div class='col-6 text-end'>
                    <button id='add-impact-row' class='btn btn-dark'>{$escaper->escapeHtml($lang["AddImpact"])}</button>
                </div>
            </div>
            <form id='contributing_risk_form' method='post' action=''>
                <table width='100%' id='contributing-risk-table' class='table header'>
                    <thead>
                        <tr>
                            <th width='50%'>{$escaper->escapeHtml($lang["Subject"])}</th>
                            <th width='30%'>{$escaper->escapeHtml($lang["ContributionWeight"])}</th>
                            <th class='text-center'>{$escaper->escapeHtml($lang["Actions"])}</th>
                        </tr>
                    </thead>
                    <tbody>
    ";

    $contributing_risks = get_contributing_risks();
    foreach ($contributing_risks as $key => $contributing_risk) {

        echo "
                        <tr>
                            <td class='p-1 border-0' align='center'><input type='text' class='subject form-control' required name='existing_subject[{$contributing_risk["id"]}]' style='max-width: none' value='{$escaper->escapeHtml($contributing_risk['subject'])}'></td>
                            <td class='p-1 border-0' align='center'><input type='number' class='weight form-control' required step='0.01' name='existing_weight[{$contributing_risk["id"]}]' value='{$escaper->escapeHtml($contributing_risk['weight'])}' max='1' min='0'></td>
                            <td class='p-1 border-0' align='center' style='vertical-align: middle; " . ($key==0 ? ("display: none;") : "") . "'><a class='delete-row' href=''><i class='fa fa-trash'></i></a></td>
                        </tr>
        ";

    }
                
    echo "
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan='3' align='right'><button type='submit' name='save_contributing_risk' class='btn btn-submit'>{$escaper->escapeHtml($lang["Save"])}</button></td>
                        </tr>
                    </tfoot>
                </table>
            </form>
            <hr><br>
            <table width='100%' id='contributing-risks-impact-table' class='table table-hover v-middle header'>
                <thead>
                    <tr class='text-center'>
                        <th width='10%'>{$escaper->escapeHtml($lang["Value"])}</th>
                        <th width='40%'>{$escaper->escapeHtml($lang["Name"])}</th>
                        <th>{$escaper->escapeHtml($lang["Actions"])}</th>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
    ";

    $table_list = display_contributing_risks_impact_table_list();
    echo            $table_list;
    echo "
                </tbody>
            </table>
        </div>
        <script>
            $('#likelihood-add-btn').click(function(e){
                e.preventDefault();
                $('#contributing-risks-likelihood-table tbody').prepend($('#template-for-adding tbody').html());
            })
            $('#contributing-risk-formula').on('click', '.impact-add-btn', function(e){
                e.preventDefault();
                $(this).parents('.subject-row').after($('#template-for-adding tbody').html());
            })
            $('#contributing-risk-formula').on('click', '#add-impact-row', function(e){
                e.preventDefault();
                $('#contributing-risk-table tbody').append($('#template-for-impact-adding tbody').html());
            })
            $('body').on('click', '.delete-row', function(e){
                e.preventDefault();
                $(this).closest('tr').remove()
            });
            $('#contributing-risks-likelihood-table, #contributing-risks-impact-table').on('change','.new-name', function(){
                var name = $(this).val();
                var table_id = $(this).parents('table').attr('id');
                if(table_id == 'contributing-risks-likelihood-table') {

                    // Check if the name is empty or trimmed empty
                    if (!name || !name.trim()) {
                        showAlertFromMessage('{$escaper->escapeHtml($lang['TheNameFieldCannotBeEmptyOrContainOnlySpaces'])}');
                        return;
                    }

                    var table = 'likelihood';
                    var data = {
                        table: table,
                        name: name
                    };
                } else {
                    var table = 'impact';
                    var contributing_risks_id = $(this).closest('tr').prev().data('contributing_risks_id');
                    var data = {
                        table: table,
                        name: name,
                        contributing_risks_id : contributing_risks_id
                    };
                }
                $.ajax({
                    type: 'POST',
                    url: BASE_URL + '/api/v2/contributing_risks/add',
                    data: data,
                    success: function(data){
                        if(data.status_message){
                            showAlertsFromArray(data.status_message);
                        }
                        redraw_contributing_table_list(table);
                    },
                    error: function(xhr,status,error){
                        if(!retryCSRF(xhr, this)) {
                            if(xhr.responseJSON && xhr.responseJSON.status_message){
                                showAlertsFromArray(xhr.responseJSON.status_message);
                            }
                        }
                    },
                });
            });
            $('#contributing-risks-likelihood-table, #contributing-risks-impact-table').on('change', 'input.editable', function(){
                var _this = $(this);
                var id = _this.parent().data('id');
                var value = _this.parent().data('value');
                var table_id = $(this).parents('table').attr('id');
                var name = _this.val();

                // Check if the name is empty or trimmed empty in the contributing risks likelihood table
                if (table_id == 'contributing-risks-likelihood-table') {
                    if (!name || !name.trim()) {
                        showAlertFromMessage('{$escaper->escapeHtml($lang['TheNameFieldCannotBeEmptyOrContainOnlySpaces'])}');
                        return;
                    }
                } else {
                    if(!name) {
                        return false;
                    }
                }

                if(table_id == 'contributing-risks-likelihood-table') var table = 'likelihood';
                else var table = 'impact';


                $.ajax({
                    type: 'POST',
                    url: BASE_URL + '/api/v2/contributing_risks/update/' + table,
                    data: {
                        id: id,
                        value: value,
                        name: name
                    },
                    success: function(data){
                        if(data.status_message){
                            showAlertsFromArray(data.status_message);
                        }
                        _this.blur();
                    },
                    error: function(xhr,status,error){
                        if(!retryCSRF(xhr, this)) {
                            if(xhr.responseJSON && xhr.responseJSON.status_message){
                                showAlertsFromArray(xhr.responseJSON.status_message);
                            }
                        }
                    },
                });
            });
            $('#contributing-risks-likelihood-table, #contributing-risks-impact-table').on('click', '.delete-value', function(){
                var id = $(this).data('id');
                var value = $(this).data('value');
                var table_id = $(this).parents('table').attr('id');
                if(table_id == 'contributing-risks-likelihood-table') {
                    var table = 'likelihood';
                    var data = {
                        id: id,
                        value: value,
                    };
                } else {
                    var table = 'impact';
                    var contributing_risks_id = $(this).data('contributing_risks_id');
                    var data = {
                        id: id,
                        value: value,
                        contributing_risks_id: contributing_risks_id,
                    };
                }
                $.ajax({
                    type: 'POST',
                    url: BASE_URL + '/api/v2/contributing_risks/delete/' + table,
                    data: data,
                    dataType : 'json',
                    success: function(data){
                        if(data.status_message){
                            showAlertsFromArray(data.status_message);
                        }
                        redraw_contributing_table_list(table);
                    },
                    error: function(xhr,status,error){
                        if(!retryCSRF(xhr, this)) {
                            if(xhr.responseJSON && xhr.responseJSON.status_message){
                                showAlertsFromArray(xhr.responseJSON.status_message);
                            }
                        }
                    },
                });
            });
            function redraw_contributing_table_list(table){
                if(table == 'likelihood') var table_body = 'contributing-risks-likelihood-table';
                else var table_body = 'contributing-risks-impact-table';
                $.ajax({
                    type: 'POST',
                    data: {
                        table: table,
                    },
                    url: BASE_URL + '/api/v2/contributing_risks/table_list',
                    success: function(data){
                        $('#'+table_body+' tbody').html(data);
                        $('input.editable').each(function(){
                            resizable($(this));
                        });
                    },
                });
            }

            $('#contributing_risk_form').submit(function(){
                if(!$(this).find('.weight').length) {
                    return false;
                }
                var totalWeight = 0;
                $(this).find('.weight').each(function(){
                    totalWeight += Number($(this).val());
                    totalWeight = (+totalWeight.toFixed(4))
                })
                if(totalWeight != 1){
                    showAlertFromMessage('{$escaper->escapeHtml($lang['TotalContributingWeightsShouldBe1'])}');
                    
                    return false;
                }
            })
        </script>
    ";

}

/**********************************************
* FUNCTION: DISPLAY CONTRIBUTING RISK FORMULA *
**********************************************/
function display_contributing_risk_from_calculator()
{
    
    global $lang, $escaper;

    echo "
        <div class='row align-items-center mb-2'>
            <div class='col-3'>
                <label>" . $escaper->escapeHtml($lang["Subject"]) . "</label>
            </div>
            <div class='col-3'>
                <label>" . $escaper->escapeHtml($lang["Weight"]) . "</label>
            </div>
            <div class='col-6'>
                <label>" . $escaper->escapeHtml($lang["Impact"]) . "</label>
            </div>
        </div>
    ";

    $contributing_risks = get_contributing_risks();

    foreach($contributing_risks as $contributing_risk) {

        $impacts = get_impact_values_from_contributing_risks_id($contributing_risk['id']);

        echo "
        <div class='contributing_impact_row row align-items-center mb-2'>
            <div class='col-3'>" . 
                $escaper->escapeHtml($contributing_risk['subject']) . "
            </div>
            <div class='col-3 contributing_weight'>" . 
                $escaper->escapeHtml($contributing_risk['weight']) . "
            </div>
            <div class='col-6 contributing_impact'>" . 
                create_dropdown("impact", NULL, "contributing_impact_{$contributing_risk['id']}", false, false, true, "", "--", "", true, 0, $impacts) . "
            </div>
        </div>
        ";
    }
}

/*******************************************
* FUNCTION: DISPLAY REVIEW RISK PAGE       *
********************************************/
function display_review_risk()
{
    global $lang, $escaper;

    // Customization Extra follow-up (Task 6, review-risk-dynamic-columns):
    // resolved once here and spliced into the RiskColumns/MitigationColumns/
    // ReviewColumns <th> sections below -- null when the Customization Extra
    // isn't active, in which case none of the custom_field_ loops below emit
    // anything and the thead is exactly the static ~46-column markup it was
    // before this task.
    $active_review_risk_columns = build_active_review_risk_columns();

    echo "
        <div class='sr-table-card' id='review-risk-table-card'>
            <div class='sr-table-toolbar'>
                <div class='sr-toolbar-filters-cluster' id='review-risk-filters-cluster'>
                    <div class='sr-table-status-filter' id='review-risk-status-filter'>
                        <button class='sr-status-chip active' data-action-type='all'>{$escaper->escapeHtml($lang['All'])} <span class='n' id='review-risk-count-all'></span></button>
                        <button class='sr-status-chip' data-action-type='mitigation'>{$escaper->escapeHtml($lang['Mitigation'])} <span class='n' id='review-risk-count-mitigation'></span></button>
                        <button class='sr-status-chip' data-action-type='review'>{$escaper->escapeHtml($lang['Review'])} <span class='n' id='review-risk-count-review'></span></button>
                    </div>
                    ";
                    // Narrow-width companion for EACH of the three chip-groups on
                    // this page (this one, plus #review-risk-scope-filter and
                    // #review-risk-status-scope-filter below): a native <select>
                    // mirroring the same data-* values as its chip row's own
                    // buttons, as <option value>. Both representations are ALWAYS
                    // rendered -- which one is visible is a pure CSS display swap
                    // at the breakpoint (_tables.scss's #review-risk-status-filter/
                    // #review-risk-scope-filter/#review-risk-status-scope-filter
                    // vs. .sr-chip-select rules), the same show/hide-by-media-query
                    // convention this page's own .sr-qf-toggle/.sr-table-quickfilters
                    // pair already uses -- never a JS .hide()/.show() toggle.
                    // review-risk.js keeps both representations in sync in BOTH
                    // directions (chip click -> select value, select change -> chip
                    // click, and the initial URL-param restore on load) through one
                    // shared setter per chip-group rather than a second, separate
                    // filtering implementation -- see that file's setActionType()/
                    // setScope()/setStatusScope() for the shared contract. Each
                    // <option>'s `data-label` holds the option's bare translated
                    // text (no count) so updateChipCounts() (review-risk.js) can
                    // rebuild "label (n)" -- e.g. 'All (157)' -- from the SAME
                    // counts payload that already fills the matching chip's own
                    // <span class='n'>, with no second lang lookup needed client-
                    // side. No aria-label here, matching the three secondary filter
                    // selects immediately below (#review-risk-user-filter etc.) --
                    // this codebase's existing precedent for a toolbar filter
                    // <select> is to rely on its own visible option text, not a
                    // separate accessible name.
                    echo "
                    <select class='form-select sr-chip-select' id='review-risk-status-filter-select'>
                        <option value='all' data-label='{$escaper->escapeHtml($lang['All'])}' selected>{$escaper->escapeHtml($lang['All'])} (0)</option>
                        <option value='mitigation' data-label='{$escaper->escapeHtml($lang['Mitigation'])}'>{$escaper->escapeHtml($lang['Mitigation'])} (0)</option>
                        <option value='review' data-label='{$escaper->escapeHtml($lang['Review'])}'>{$escaper->escapeHtml($lang['Review'])} (0)</option>
                    </select>
                    <!-- Replaces the previous checkbox: checked vs unchecked
                         named only its ON state (Show my action items), leaving
                         the OFF state's meaning implicit -- ambiguous enough that
                         it read as a real usability gap. A two-option chip toggle
                         names both states explicitly, matching this same page's
                         action-type chip row shape immediately to its left rather
                         than introducing a third distinct control style. Shares
                         .sr-table-status-filter/.sr-status-chip with that chip row
                         (see _tables.scss's #review-risk-status-filter,
                         #review-risk-scope-filter shape override) -- a different id
                         so JS can target the two chip groups independently; 'mine'
                         starts active, matching the checkbox's previous default-
                         checked state. -->
                    <div class='sr-table-status-filter' id='review-risk-scope-filter'>
                        <button class='sr-status-chip' data-scope='all'>{$escaper->escapeHtml($lang['All'])} <span class='n' id='review-risk-count-all-items'></span></button>
                        <button class='sr-status-chip active' data-scope='mine'>{$escaper->escapeHtml($lang['MyActionItems'])} <span class='n' id='review-risk-count-mine'></span></button>
                    </div>
                    <select class='form-select sr-chip-select' id='review-risk-scope-filter-select'>
                        <option value='all' data-label='{$escaper->escapeHtml($lang['All'])}'>{$escaper->escapeHtml($lang['All'])} (0)</option>
                        <option value='mine' data-label='{$escaper->escapeHtml($lang['MyActionItems'])}' selected>{$escaper->escapeHtml($lang['MyActionItems'])} (0)</option>
                    </select>
                    ";
                    // Status-scope toolbar control (All/Open/Closed) -- a SEPARATE,
                    // additional control from #review-risk-status-filter (the
                    // action-type chips above) and #review-risk-scope-filter (the
                    // My Action Items/All Items chips above): all three coexist.
                    // 'open' starts active -- it reproduces today's exact page
                    // (status != Closed AND needs_mitigation/needs_review) with
                    // zero regression, since this control did not exist before.
                    // Shares .sr-table-status-filter/.sr-status-chip with the
                    // other two chip groups (see _tables.scss's
                    // #review-risk-status-filter, #review-risk-scope-filter,
                    // #review-risk-status-scope-filter shape override) -- a
                    // different id so JS can target all three chip groups
                    // independently. 'AllStatuses'/'Open'/'Closed' are all
                    // pre-existing lang keys (governance-documents.js/
                    // governance-exceptions.js/compliance.php already use
                    // 'AllStatuses'; risk status values already render 'Open'/
                    // 'Closed' elsewhere in the app) -- no new keys needed.
                    //
                    // Live counts (follow-up, matching the action-type and
                    // my-action-items chip groups above -- see
                    // getReviewRiskDatatableResponse()'s status_all/
                    // status_open/status_closed tallies, includes/api.php):
                    // each span is set by updateChipCounts() (review-risk.js),
                    // same .n badge shared across all three chip groups.
                    echo "
                    <div class='sr-table-status-filter' id='review-risk-status-scope-filter'>
                        <button class='sr-status-chip' data-status-scope='all'>{$escaper->escapeHtml($lang['All'])} <span class='n' id='review-risk-count-status-all'></span></button>
                        <button class='sr-status-chip active' data-status-scope='open'>{$escaper->escapeHtml($lang['Open'])} <span class='n' id='review-risk-count-status-open'></span></button>
                        <button class='sr-status-chip' data-status-scope='closed'>{$escaper->escapeHtml($lang['Closed'])} <span class='n' id='review-risk-count-status-closed'></span></button>
                    </div>
                    <select class='form-select sr-chip-select' id='review-risk-status-scope-filter-select'>
                        <option value='all' data-label='{$escaper->escapeHtml($lang['All'])}'>{$escaper->escapeHtml($lang['All'])} (0)</option>
                        <option value='open' data-label='{$escaper->escapeHtml($lang['Open'])}' selected>{$escaper->escapeHtml($lang['Open'])} (0)</option>
                        <option value='closed' data-label='{$escaper->escapeHtml($lang['Closed'])}'>{$escaper->escapeHtml($lang['Closed'])} (0)</option>
                    </select>
                    </div>";
                    // A fourth toolbar chip-group here (Unreviewed/Past Due/
                    // Coming Soon) was tried and removed: the Insights band's
                    // own Needs Review/Past Due/Coming Soon KPI tiles are
                    // always visible and already do exactly this filtering in
                    // one click -- a toolbar control duplicating them added
                    // clutter without adding capability, and its width pushed
                    // this row's chip-vs-select breakpoint out to ~1800px,
                    // collapsing to dropdowns on most normal windows. The
                    // underlying due_status filter/URL param, server-side
                    // validation, and Clear-Filters clearability (review-risk.js's
                    // setDueStatus()/initialUrlHadInsightsFilter) are all still
                    // in place -- only this visible, redundant toolbar control
                    // was removed. See that file's setDueStatus() for the
                    // current (chip-less) shape.
                    // + Add Risk trigger, gated on the same session permission
                    // the Submit Risk page itself is gated behind. NOTE: the
                    // task brief for this button named the session key
                    // 'submit_risk' (singular) -- grepped the whole codebase
                    // and that key does not exist anywhere; every real gate on
                    // this capability (management/index.php's own page guard,
                    // includes/api.php:~3559, api/v2/includes/risks.php,
                    // includes/assessments.php, includes/display.php's sidebar
                    // nav item) checks $_SESSION['submit_risks'] (plural).
                    // Verified live: with the singular key this button never
                    // rendered for the admin test account either. Using the
                    // plural key here so this gate actually matches the
                    // permission the embedded form's own POST target enforces
                    // server-side (management/index.php line ~11).
                    // Matches governance/documentation.php's own '+ AddDocument'
                    // button shape/pattern (btn btn-danger, the App Red accent
                    // reserved for this toolbar's one primary action). Opened via
                    // review-risk.js (explicit .modal('show'), matching this
                    // page's own convention for every other trigger button here
                    // -- e.g. #review-risk-bulk-close above -- rather than a
                    // declarative data-bs-toggle/data-bs-target pair) against
                    // #review-risk-add-modal (below), a standalone sr-modal
                    // instance embedding display_add_risk() -- see that modal's
                    // comment for the data-on-save contract.
                    //
                    // Wrapped in .sr-table-toolbar-actions (shared with
                    // extras/customization's Template Groups toolbar) rather
                    // than the old page-local .sr-table-tools: that class
                    // already carries the shared "toolbar/header Add button"
                    // radius rule (_tables.scss's .sr-table-toolbar-actions
                    // .btn selector), and pairing it with .sr-table-toolbar's
                    // own justify-content:space-between (below) pushes this
                    // one remaining right-side element to the corner without
                    // .sr-table-tools's old margin-left:auto -- which kept
                    // pushing right even after wrapping onto its own line,
                    // stranding a gap on the left. space-between naturally
                    // packs a lone wrapped item back to the start instead.
                    if (!empty($_SESSION['submit_risks'])) {
                        echo "
                <div class='sr-table-toolbar-actions'>
                    <a class='btn btn-danger' href='#' id='review-risk-add-btn' role='button'>+ {$escaper->escapeHtml($lang['AddRisk'])}</a>
                </div>";
                    }
                    echo "
            </div>";
                    // Row 2: the search box, alone, on its own row -- freed
                    // from competing with the three chip groups (row 1) and
                    // the Columns/Filters controls (row 3 below) for space.
                    // .sr-table-search-row is new/page-scoped (_tables.scss);
                    // .dt-search itself keeps the same id/markup DataTables
                    // and review-risk.js already bind to, just relocated.
                    echo "
            <div class='sr-table-search-row'>
                <div class='dt-search'>
                    <input type='search' id='review-risk-search' class='form-control' placeholder='{$escaper->escapeHtml($lang['Search'])}' aria-label='{$escaper->escapeHtml($lang['Search'])}'>
                </div>
            </div>";
                    // Row 3: Filters + Columns, together -- resolved per
                    // explicit product-owner direction (superseding an
                    // earlier .sr-qf-bar draft this task tried first): the
                    // Columns picker moves INTO .sr-qf-selects, as the last
                    // control after Owner/Team/Risk-Level/Reviewer and the
                    // Clear Filters button (see that div below) -- so at
                    // >=1100px, where .sr-table-quickfilters is a plain
                    // always-visible inline row, Columns reads as literally
                    // the last item in that same row, right next to Clear
                    // Filters. Below 1100px, .sr-table-quickfilters (Columns
                    // now included) collapses behind THIS .sr-qf-toggle
                    // button same as every other control in that row --
                    // Filters becomes the single visible trigger, and
                    // Columns appears once the sheet is opened, rather than
                    // standing outside it. .sr-qf-toggle is restyled
                    // (_tables.scss, the shared rule -- also used by
                    // compliance.php's Initiate Audits/Define Tests/Manage
                    // Audits and governance/document_exceptions.php/
                    // documentation.php) to match .filterbtn/.sr-table-filter
                    // -- the same chrome the Columns trigger itself uses --
                    // so Filters and Columns read as one consistent button
                    // family everywhere, not just here.
                    //
                    // .sr-qf-toggle stays a DIRECT CHILD of .sr-table-card --
                    // a sibling of .sr-table-toolbar, .sr-table-search-row
                    // and .sr-table-quickfilters, matching the reference
                    // implementation (governance/document_exceptions.php) --
                    // it's only ever rendered visible below the 1100px
                    // compact tier (_tables.scss's .sr-qf-toggle rules).
                    echo "
            <button type='button' class='sr-qf-toggle' id='review-risk-filters-toggle' aria-expanded='false' aria-controls='review-risk-quickfilters'>
                <i class='fa fa-filter'></i><span>{$escaper->escapeHtml($lang['Filters'])}</span>
                <span class='sr-qf-toggle-count' id='review-risk-filters-count' hidden></span>
            </button>

            <div class='sr-bulk-bar d-none' id='review-risk-bulk-bar'>
                <button type='button' class='sr-bulk-clear' id='review-risk-bulk-clear' aria-label='{$escaper->escapeHtml($lang['Clear'])}'>&times;</button>
                <span class='sr-bulk-count' id='review-risk-bulk-count'></span>
                <!-- Select all N: escalates a page-level selection to every
                     risk matching the current toolbar/secondary filters/search,
                     resolved server-side via /risk_management/review_risk/filtered_ids
                     since this grid is serverSide -- the same .sr-bulk-lnk
                     affordance the Governance controls grid and Plan Projects
                     offer. Shown by review-risk.js syncBulkBar() only while
                     there are more matching rows than are selected. -->
                <button type='button' class='sr-bulk-lnk d-none' id='review-risk-select-all-filtered'></button>
                <div class='sr-bulk-actions'>";
                    // Each bulk action button is gated on the same session
                    // permission its endpoint enforces server-side -- render
                    // only what this user could actually use, matching how
                    // Task 12's row actions are permission-gated. Every
                    // button below follows this same if-guarded-echo shape;
                    // there is no ungated bulk action.
                    if (!empty($_SESSION['comment_risk_management'])) {
                        echo "<button type='button' class='btn btn-outline-secondary btn-sm' id='review-risk-bulk-comment'>{$escaper->escapeHtml($lang['AddAComment'])}</button>";
                    }
                    if (!empty($_SESSION['modify_risks'])) {
                        echo "<button type='button' class='btn btn-outline-secondary btn-sm' id='review-risk-bulk-reassign-owner'>{$escaper->escapeHtml($lang['ReassignRiskOwner'])}</button>";
                    }
                    if (!empty($_SESSION['plan_mitigations'])) {
                        echo "<button type='button' class='btn btn-outline-secondary btn-sm' id='review-risk-bulk-reassign-mitigation-owner'>{$escaper->escapeHtml($lang['ReassignMitigationOwner'])}</button>";
                    }
                    if (!empty($_SESSION['modify_risks'])) {
                        echo "<button type='button' class='btn btn-outline-secondary btn-sm' id='review-risk-bulk-change-status'>{$escaper->escapeHtml($lang['ChangeStatus'])}</button>";
                    }
                    if (!empty($_SESSION['close_risks'])) {
                        echo "<button type='button' class='btn btn-outline-danger btn-sm' id='review-risk-bulk-close'>{$escaper->escapeHtml($lang['CloseRisk'])}</button>";
                    }
                    // Final whole-branch review, Finding 4b (re-review fix: this explanation was
                    // originally placed INSIDE the echoed double-quoted string below as an HTML
                    // <!-- --> comment, which (a) interpolated the literal $order_field token --
                    // undefined in this function's scope, emitting a PHP warning on every page
                    // render -- and (b) shipped ~700 bytes of internal-implementation detail as
                    // literal HTML to every browser. Moved out to a real PHP comment instead.
                    //
                    // Risk Level and Due Date (below) previously carried class='sortable' + a
                    // sort-ic placeholder like ID/Risk, but neither 'risk_level' nor 'due_date' is
                    // in get_risks()'s sort allowlist (functions.php's $order_field switch) --
                    // due_date can't be either, since it's computed in PHP after the query runs
                    // (see getReviewRiskDatatableResponse()'s Finding 4a comment). Clicking either
                    // header was a silent no-op. Removed the class/icon on just these two so the
                    // UI stops advertising sort behavior that doesn't exist; ID/Risk (genuinely
                    // SQL-sortable) are untouched.
                    //
                    // Column-parity follow-up (post-merge; .superpowers/sdd/review-risk-
                    // followups/column-parity-report.md): the <th data-col='...' class='d-none'>
                    // block between 'team' and 'due_date' below restores the legacy Plan Your
                    // Mitigations/Perform Management Reviews/Review Risks Regularly pages' full
                    // Columns picker as ~37 customer-opt-in columns (default-hidden, same
                    // data-col mechanism risk_score/responsible/team already use above -- see
                    // review-risk.js's COLUMN_GROUPS for the grouped picker and the matching
                    // `columns:` DataTable defs, which MUST stay in this exact same order --
                    // DataTables matches column defs and <th>s positionally, not by name).
                    echo "
                </div>
            </div>

            <div class='sr-table-quickfilters d-none' id='review-risk-quickfilters'>
                <div class='sr-qf-selects'>
                    <select id='review-risk-user-filter' class='form-select' multiple data-placeholder='{$escaper->escapeHtml($lang['AllUsers'])}'></select>
                    <select id='review-risk-team-filter' class='form-select' multiple data-placeholder='{$escaper->escapeHtml($lang['AllTeams'])}'></select>
                    <select id='review-risk-level-filter' class='form-select' multiple data-placeholder='{$escaper->escapeHtml($lang['AllRiskLevels'])}'></select>
                    <!-- Columns picker (design-system.md §6c) -- lives in
                         .sr-qf-selects (per explicit product-owner
                         direction), rather than the toolbar's old
                         .sr-table-tools zone (removed earlier this branch)
                         or a standalone wrapper. At >=1100px this row is
                         plain and always visible; below 1100px the whole row
                         (Columns included) collapses behind .sr-qf-toggle
                         above, same as every other control here.
                         .colpicker's own JS wiring (review-risk.js) is
                         entirely id/class-based (#review-risk-colpicker-btn,
                         #review-risk-colpanel, .closest('.colpicker')) with
                         no assumption about which parent it sits in or which
                         sibling comes before/after it. -->
                    <div class='colpicker'>
                        <button type='button' class='filterbtn sr-table-filter' id='review-risk-colpicker-btn'>
                            <i class='fa fa-table-columns' aria-hidden='true'></i> {$escaper->escapeHtml($lang['Columns'])}
                        </button>
                        <div class='colpanel colpanel-searchable d-none' id='review-risk-colpanel'></div>
                    </div>
                    <!-- Clear Filters -- moved to the END of this row (after
                         Columns), per explicit product-owner direction.
                         Matches every other page's sr-qf-clear button
                         (governance/document_exceptions.php, governance/
                         documentation.php): btn btn-link btn-sm sr-qf-clear
                         -- this one was missing the three Bootstrap link-
                         button base classes, rendering unstyled where every
                         other page's version reads as a small text link. -->
                    <button type='button' class='btn btn-link btn-sm sr-qf-clear d-none' id='review-risk-filters-clear'>{$escaper->escapeHtml($lang['ClearFilters'])}</button>
                </div>
            </div>

            <div class='sr-table-scroll'>
                <table id='review_risk_table' class='sr-table' width='100%'>
                    <thead>
                        <tr>
                            <th style='width:36px;'><input type='checkbox' id='review-risk-select-all'></th>
                            <th data-name='id' class='num sortable'>{$escaper->escapeHtml($lang['ID'])} <span class='sort-ic'></span></th>
                            <th data-name='subject' class='sortable'>{$escaper->escapeHtml($lang['Risk'])} <span class='sort-ic'></span></th>
                            <th>{$escaper->escapeHtml($lang['NeedsColumn'])}</th>
                            <th data-name='risk_level'>{$escaper->escapeHtml($lang['RiskLevel'])}</th>
                            <th data-col='risk_score' class='d-none'>{$escaper->escapeHtml($lang['RiskScoreColumn'])}</th>
                            <th data-col='responsible'>{$escaper->escapeHtml($lang['Owner'])}</th>
                            <th data-col='team' class='d-none'>{$escaper->escapeHtml($lang['Team'])}</th>
                            <th data-col='risk_status' class='d-none'>{$escaper->escapeHtml($lang['Status'])}</th>
                            <th data-col='submission_date' class='d-none'>{$escaper->escapeHtml($lang['SubmissionDate'])}</th>
                            <th data-col='closure_date' class='d-none'>{$escaper->escapeHtml($lang['DateClosed'])}</th>
                            <th data-col='reference_id' class='d-none'>{$escaper->escapeHtml($lang['ExternalReferenceId'])}</th>
                            <th data-col='regulation' class='d-none'>{$escaper->escapeHtml($lang['ControlRegulation'])}</th>
                            <th data-col='control_number' class='d-none'>{$escaper->escapeHtml($lang['ControlNumber'])}</th>
                            <th data-col='location' class='d-none'>{$escaper->escapeHtml($lang['SiteLocation'])}</th>
                            <th data-col='source' class='d-none'>{$escaper->escapeHtml($lang['RiskSource'])}</th>
                            <th data-col='category' class='d-none'>{$escaper->escapeHtml($lang['Category'])}</th>
                            <th data-col='additional_stakeholders' class='d-none'>{$escaper->escapeHtml($lang['AdditionalStakeholders'])}</th>
                            <th data-col='technology' class='d-none'>{$escaper->escapeHtml($lang['Technology'])}</th>
                            <th data-col='manager' class='d-none'>{$escaper->escapeHtml($lang['OwnersManager'])}</th>
                            <th data-col='submitted_by' class='d-none'>{$escaper->escapeHtml($lang['SubmittedBy'])}</th>
                            <th data-col='risk_tags' class='d-none'>{$escaper->escapeHtml($lang['Tags'])}</th>
                            <th data-col='scoring_method' class='d-none'>{$escaper->escapeHtml($lang['RiskScoringMethod'])}</th>
                            <th data-col='residual_risk' class='d-none'>{$escaper->escapeHtml($lang['ResidualRisk'])}</th>
                            <th data-col='project' class='d-none'>{$escaper->escapeHtml($lang['Project'])}</th>
                            <th data-col='days_open' class='d-none'>{$escaper->escapeHtml($lang['DaysOpen'])}</th>
                            <th data-col='affected_assets' class='d-none'>{$escaper->escapeHtml($lang['AffectedAssets'])}</th>
                            <th data-col='risk_assessment' class='d-none'>{$escaper->escapeHtml($lang['RiskAssessment'])}</th>
                            <th data-col='additional_notes' class='d-none'>{$escaper->escapeHtml($lang['AdditionalNotes'])}</th>
                            <th data-col='risk_mapping' class='d-none'>{$escaper->escapeHtml($lang['RiskMapping'])}</th>
                            <th data-col='threat_mapping' class='d-none'>{$escaper->escapeHtml($lang['ThreatMapping'])}</th>
                            <th data-col='last_comment' class='d-none'>{$escaper->escapeHtml($lang['LastComment'])}</th>";
                    // Customization Extra custom fields (is_basic=0) for this section --
                    // basic fields already have a matching static <th> above (or are
                    // skipped by build_active_review_risk_columns() itself when
                    // unresolvable), so only genuinely new custom_field_N keys need a
                    // NEW <th> here. Must stay positionally aligned with review-risk.js's
                    // COLUMN_GROUPS-replacement ordering and Task 8's `columns:` config --
                    // DataTables matches column defs to <th>s by position, not by name.
                    if ($active_review_risk_columns !== null) {
                        foreach ($active_review_risk_columns as $col) {
                            if ($col['group'] === 'RiskColumns' && strpos($col['key'], 'custom_field_') === 0) {
                                echo "<th data-col='{$escaper->escapeHtmlAttr($col['key'])}' class='d-none'>{$escaper->escapeHtml($col['label'])}</th>";
                            }
                        }
                    }
                    echo "
                            <th data-col='mitigation_planned' class='d-none'>{$escaper->escapeHtml($lang['MitigationPlanned'])}</th>
                            <th data-col='planning_strategy' class='d-none'>{$escaper->escapeHtml($lang['PlanningStrategy'])}</th>
                            <th data-col='planning_date' class='d-none'>{$escaper->escapeHtml($lang['MitigationPlanning'])}</th>
                            <th data-col='mitigation_effort' class='d-none'>{$escaper->escapeHtml($lang['MitigationEffort'])}</th>
                            <th data-col='mitigation_cost' class='d-none'>{$escaper->escapeHtml($lang['MitigationCost'])}</th>
                            <th data-col='mitigation_owner' class='d-none'>{$escaper->escapeHtml($lang['MitigationOwner'])}</th>
                            <th data-col='mitigation_team' class='d-none'>{$escaper->escapeHtml($lang['MitigationTeam'])}</th>
                            <th data-col='mitigation_accepted' class='d-none'>{$escaper->escapeHtml($lang['MitigationAccepted'])}</th>
                            <th data-col='mitigation_date' class='d-none'>{$escaper->escapeHtml($lang['MitigationDate'])}</th>
                            <th data-col='mitigation_controls' class='d-none'>{$escaper->escapeHtml($lang['MitigationControls'])}</th>
                            <th data-col='current_solution' class='d-none'>{$escaper->escapeHtml($lang['CurrentSolution'])}</th>
                            <th data-col='security_recommendations' class='d-none'>{$escaper->escapeHtml($lang['SecurityRecommendations'])}</th>
                            <th data-col='security_requirements' class='d-none'>{$escaper->escapeHtml($lang['SecurityRequirements'])}</th>";
                    // Customization Extra custom fields for the Mitigation section --
                    // see the matching RiskColumns comment above for the full rationale.
                    if ($active_review_risk_columns !== null) {
                        foreach ($active_review_risk_columns as $col) {
                            if ($col['group'] === 'MitigationColumns' && strpos($col['key'], 'custom_field_') === 0) {
                                echo "<th data-col='{$escaper->escapeHtmlAttr($col['key'])}' class='d-none'>{$escaper->escapeHtml($col['label'])}</th>";
                            }
                        }
                    }
                    echo "
                            <th data-col='review_completed' class='d-none'>{$escaper->escapeHtml($lang['ReviewCompleted'])}</th>
                            <th data-col='management_review' class='d-none'>{$escaper->escapeHtml($lang['ManagementReview'])}</th>
                            <th data-col='review_date' class='d-none'>{$escaper->escapeHtml($lang['ReviewDate'])}</th>
                            <th data-col='next_review_date' class='d-none'>{$escaper->escapeHtml($lang['NextReviewDate'])}</th>
                            <th data-col='next_step' class='d-none'>{$escaper->escapeHtml($lang['NextStep'])}</th>
                            <th data-col='comments' class='d-none'>{$escaper->escapeHtml($lang['Comments'])}</th>
                            <th data-col='reviewer' class='d-none'>{$escaper->escapeHtml($lang['ReviewedBy'])}</th>";
                    // Customization Extra custom fields for the Review section --
                    // see the matching RiskColumns comment above for the full rationale.
                    if ($active_review_risk_columns !== null) {
                        foreach ($active_review_risk_columns as $col) {
                            if ($col['group'] === 'ReviewColumns' && strpos($col['key'], 'custom_field_') === 0) {
                                echo "<th data-col='{$escaper->escapeHtmlAttr($col['key'])}' class='d-none'>{$escaper->escapeHtml($col['label'])}</th>";
                            }
                        }
                    }
                    echo "
                            <th data-name='due_date'>{$escaper->escapeHtml($lang['DueDate'])}</th>
                            <!-- .sr-actions-col (shared with admin/data_integrity.php,
                                 includes/compliance.php) -- NOT an inline fixed width.
                                 The compact-tier mixin (sr-row-actions-overflow-tier,
                                 _tables.scss) narrows this column to 44px once the
                                 standing View/Edit/Plan Mitigation/Perform Review icon
                                 cluster collapses to a single ellipsis-menu toggle
                                 below 1400px; a hardcoded inline width can't be overridden by
                                 that class-scoped rule (inline styles always win), so
                                 the fixed 150px this previously carried stayed reserved
                                 for four icons' worth of space even once only one
                                 toggle button remained -- widening the table by 106px
                                 of dead space at exactly the point where every pixel
                                 mattered, and pushing the toggle itself further into
                                 the horizontally-scrolled-away region. No width is set
                                 here at full viewport width either, matching every
                                 other .sr-actions-col consumer -- the column sizes to
                                 its own content (the icon cluster) with nothing
                                 hardcoded to fight.

                                 sr-actions-col-sticky (page-scoped, NOT part of the
                                 shared .sr-actions-col rule above): pins this column to
                                 the right edge of .sr-table-scroll's horizontal scroll
                                 so Actions stays reachable once optional columns push
                                 the table wide. review-risk.js's 'actions' column def
                                 carries the matching className on the <td> side. Scoped
                                 to #review_risk_table in _tables.scss so the OTHER
                                 .sr-actions-col consumers (admin/data_integrity.php,
                                 includes/compliance.php) are untouched. -->
                            <th class='sr-actions-col sr-actions-col-sticky'></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div class='sr-table-foot'>
                <div class='sr-table-foot-left'>
                    <div class='dt-length'><label>{$escaper->escapeHtml($lang['Show'])}
                        <select id='review-risk-length'><option value='10'>10</option><option value='25' selected>25</option><option value='50'>50</option><option value='100'>100</option><option value='-1'>{$escaper->escapeHtml($lang['ALL'])}</option></select>
                    </label></div>
                    <div class='dt-info' id='review-risk-info'></div>
                </div>
                <div class='sr-table-foot-right'>
                    <div class='dt-paging' id='review-risk-pager'></div>
                </div>
            </div>
    ";

    // Bulk Add Comment modal (Task 15). Gated on the same session permission
    // as its trigger button (#review-risk-bulk-comment, above) -- there is no
    // reason to ship the modal markup to a user who cannot see the button
    // that opens it, matching this function's existing if-guarded-echo
    // convention for every other bulk action.
    if (!empty($_SESSION['comment_risk_management'])) {
        echo "
            <div class='modal fade sr-modal' id='review-risk-comment-modal' tabindex='-1' aria-labelledby='review-risk-comment-modal-title' aria-hidden='true'>
                <div class='modal-dialog modal-dialog-centered'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <span class='sr-modal-icon'><i class='fa fa-comment' aria-hidden='true'></i></span>
                            <h4 class='modal-title' id='review-risk-comment-modal-title'></h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtml($lang['Close'])}'></button>
                        </div>
                        <div class='modal-body'>
                            <div class='alert alert-danger d-none sr-modal-inline-error' role='alert'></div>
                            <section class='sr-qcard'>
                                <div class='sr-qcard-body'>
                                    <div class='sr-qgrid'>
                                        <div class='sr-qfield sr-qfield--full'>
                                            <label class='sr-qlabel' for='review-risk-comment-text'>{$escaper->escapeHtml($lang['Comment'])} <span class='required'>*</span></label>
                                            <textarea class='form-control' id='review-risk-comment-text' rows='4'></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div class='modal-footer'>
                            <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                            <button type='button' class='btn btn-submit' id='review-risk-comment-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
                        </div>
                    </div>
                </div>
            </div>
        ";
    }

    // Bulk Reassign Risk Owner modal (Task 16). Gated on the same session
    // permission as its trigger button (#review-risk-bulk-reassign-owner,
    // above) and the same permission PATCH /risks/{id}'s updateRisk()
    // enforces server-side -- matching Task 15's comment-modal gating
    // convention immediately above.
    if (!empty($_SESSION['modify_risks'])) {
        echo "
            <div class='modal fade sr-modal' id='review-risk-reassign-owner-modal' tabindex='-1' aria-labelledby='review-risk-reassign-owner-modal-title' aria-hidden='true'>
                <div class='modal-dialog modal-dialog-centered'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <span class='sr-modal-icon'><i class='fa fa-user' aria-hidden='true'></i></span>
                            <h4 class='modal-title' id='review-risk-reassign-owner-modal-title'></h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtml($lang['Close'])}'></button>
                        </div>
                        <div class='modal-body'>
                            <div class='alert alert-danger d-none sr-modal-inline-error' role='alert'></div>
                            <section class='sr-qcard'>
                                <div class='sr-qcard-body'>
                                    <div class='sr-qgrid'>
                                        <div class='sr-qfield sr-qfield--full'>
                                            <label class='sr-qlabel' for='review-risk-reassign-owner-select'>{$escaper->escapeHtml($lang['Owner'])} <span class='required'>*</span></label>
                                            <select class='form-select' id='review-risk-reassign-owner-select'></select>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div class='modal-footer'>
                            <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                            <button type='button' class='btn btn-submit' id='review-risk-reassign-owner-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
                        </div>
                    </div>
                </div>
            </div>
        ";
    }

    // Bulk Reassign Mitigation Owner modal (Task 17). Gated on the same
    // session permission as its trigger button
    // (#review-risk-bulk-reassign-mitigation-owner, above) and the same
    // permission PATCH /risks/{id}/mitigations's saveMitigation() enforces
    // server-side -- matching Task 16's reassign-owner modal gating
    // convention immediately above.
    if (!empty($_SESSION['plan_mitigations'])) {
        echo "
            <div class='modal fade sr-modal' id='review-risk-reassign-mitigation-owner-modal' tabindex='-1' aria-labelledby='review-risk-reassign-mitigation-owner-modal-title' aria-hidden='true'>
                <div class='modal-dialog modal-dialog-centered'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <span class='sr-modal-icon'><i class='fa fa-shield-halved' aria-hidden='true'></i></span>
                            <h4 class='modal-title' id='review-risk-reassign-mitigation-owner-modal-title'></h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtml($lang['Close'])}'></button>
                        </div>
                        <div class='modal-body'>
                            <div class='alert alert-danger d-none sr-modal-inline-error' role='alert'></div>
                            <section class='sr-qcard'>
                                <div class='sr-qcard-body'>
                                    <div class='sr-qgrid'>
                                        <div class='sr-qfield sr-qfield--full'>
                                            <label class='sr-qlabel' for='review-risk-reassign-mitigation-owner-select'>{$escaper->escapeHtml($lang['Owner'])} <span class='required'>*</span></label>
                                            <select class='form-select' id='review-risk-reassign-mitigation-owner-select'></select>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div class='modal-footer'>
                            <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                            <button type='button' class='btn btn-submit' id='review-risk-reassign-mitigation-owner-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
                        </div>
                    </div>
                </div>
            </div>
        ";
    }

    // Bulk Change Status modal (Task 18). Gated on the same session
    // permission as its trigger button (#review-risk-bulk-change-status,
    // above) and the same permission updateStatusForm()'s
    // `has_permission("modify_risks") && check_access_for_risk($id)` enforces
    // server-side -- matching Task 16/17's modal gating convention above.
    // The <select> is left empty here and populated by JS
    // (review-risk.js's click handler on #review-risk-bulk-change-status)
    // from filterOptionsCache.statuses -- same "server data, JS-populated
    // select" shape the owner/mitigation-owner modals use above, since the
    // `status` table's seed values aren't hardcoded anywhere in this repo
    // (same situation as risk_levels).
    if (!empty($_SESSION['modify_risks'])) {
        echo "
            <div class='modal fade sr-modal' id='review-risk-status-modal' tabindex='-1' aria-labelledby='review-risk-status-modal-title' aria-hidden='true'>
                <div class='modal-dialog modal-dialog-centered'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <span class='sr-modal-icon'><i class='fa fa-clipboard-check' aria-hidden='true'></i></span>
                            <h4 class='modal-title' id='review-risk-status-modal-title'></h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtml($lang['Close'])}'></button>
                        </div>
                        <div class='modal-body'>
                            <div class='alert alert-danger d-none sr-modal-inline-error' role='alert'></div>
                            <section class='sr-qcard'>
                                <div class='sr-qcard-body'>
                                    <div class='sr-qgrid'>
                                        <div class='sr-qfield sr-qfield--full'>
                                            <label class='sr-qlabel' for='review-risk-status-select'>{$escaper->escapeHtml($lang['Status'])} <span class='required'>*</span></label>
                                            <select class='form-select' id='review-risk-status-select'></select>
                                            <span class='sr-qhint'>{$escaper->escapeHtml($lang['ChangeStatusHint'])}</span>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div class='modal-footer'>
                            <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                            <button type='button' class='btn btn-submit' id='review-risk-status-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
                        </div>
                    </div>
                </div>
            </div>
        ";
    }

    // Bulk Close Risk modal (Task 19). Gated on the same session permission
    // as its trigger button (#review-risk-bulk-close, above) and the same
    // permission closeriskForm()'s `check_permission("close_risks") &&
    // check_access_for_risk($id)` enforces server-side -- matching Task
    // 16/17/18's modal gating convention above. Unlike those, this is a
    // §8 destructive-confirm (no form fields): backdrop/Esc disabled, Cancel
    // is the focus target, and the body states the consequence once in a
    // `.sr-qnote` the way governance/index.php's real destructive-confirm
    // modals (framework/control delete) already do, rather than the plain
    // `<p>` the task brief's own sample used.
    //
    // No `autofocus` attribute on the Cancel button: the HTML attribute is a
    // documented Bootstrap 5 no-op here (only processed once at DOM
    // insertion, while the modal is still `display:none`; inert by the time
    // `.modal('show')` later reveals it). governance/index.php's real
    // destructive-confirm modals carry no such attribute either -- the actual
    // focus-on-open behavior lives in review-risk.js's `shown.bs.modal`
    // handler, matching governance-frameworks.js's identical fix.
    if (!empty($_SESSION['close_risks'])) {
        // Bulk Close Risk follow-up: the single-risk Close Risk flow
        // (view.php Actions -> Close Risk, management/partials/close.php)
        // prompts for a Reason (create_dropdown('close_reason'), the same
        // `close_reason` DB lookup table every close-reason report/filter in
        // the app already reads) and Close-Out Information (a free-text
        // note) before closing -- the original Task 19 bulk modal skipped
        // both fields entirely ("the spec's mockup never designed per-risk
        // reason/note collection for the bulk case," per closeRiskOnOne()'s
        // own comment in review-risk.js), sending empty strings for every
        // risk. Product-owner follow-up: bring the SAME two fields into the
        // bulk modal -- one reason/note pair applies to every selected risk
        // in the batch (not one per risk; that's a UX size that doesn't fit
        // a "select many, act once" bulk action), reusing create_dropdown()
        // with a distinct $id (last positional arg) so this doesn't collide
        // with any other close_reason dropdown elsewhere on the page (there
        // isn't one, but the single-risk form's own `id='close_reason'`
        // convention only works because that form is never on the same page
        // as this one -- an explicit distinct id here is the same
        // discipline this page's other embedded-form work already applied
        // when embedding Submit Risk's form via #review-risk-add-modal).
        // $returnHtml=true (6th positional arg) so this can be interpolated
        // into the echoed string below, matching how this whole function
        // builds its markup.
        $review_risk_close_reason_dropdown = create_dropdown('close_reason', null, null, true, false, true, '', '--', '', true, 0, null, true, 'review-risk-close-reason');
        echo "
            <div class='modal fade sr-modal' id='review-risk-close-modal' tabindex='-1' aria-labelledby='review-risk-close-modal-title' aria-hidden='true' data-bs-backdrop='static' data-bs-keyboard='false'>
                <div class='modal-dialog modal-dialog-centered'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <span class='sr-modal-icon sr-modal-icon--danger'><i class='fa fa-triangle-exclamation' aria-hidden='true'></i></span>
                            <h4 class='modal-title' id='review-risk-close-modal-title'></h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtml($lang['Close'])}'></button>
                        </div>
                        <div class='modal-body'>
                            <div class='sr-qnote'>
                                <i class='fa fa-triangle-exclamation sr-qnote-ico' aria-hidden='true'></i>
                                <span>{$escaper->escapeHtml($lang['CloseRiskBulkConfirmBody'])}</span>
                            </div>
                            <div class='mb-2'>
                                <label for='review-risk-close-reason' class='form-label'>{$escaper->escapeHtml($lang['Reason'])}:</label>
                                {$review_risk_close_reason_dropdown}
                            </div>
                            <div class='mb-2'>
                                <label for='review-risk-close-note' class='form-label'>{$escaper->escapeHtml($lang['CloseOutInformation'])}:</label>
                                <textarea name='note' id='review-risk-close-note' rows='3' class='form-control'></textarea>
                            </div>
                        </div>
                        <div class='modal-footer'>
                            <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                            <button type='button' class='btn btn-submit' id='review-risk-close-submit'>{$escaper->escapeHtml($lang['CloseRisk'])}</button>
                        </div>
                    </div>
                </div>
            </div>
        ";
    }

    // + Add Risk modal (review-risk-add-modal): an sr-modal shell (design-
    // system.md §8, "Form-in-modal") around an empty canvas div that
    // review-risk.js hands to window.RiskDetailsForm.init() (embedded: true)
    // on open -- the reusable Cards-form engine extracted from the standalone
    // Submit Risk page (js/simplerisk/common/risk-details-form.js), not the
    // legacy display_add_risk() Compliance still embeds twice
    // (compliance/testing.php and compliance/view_test.php's
    // #modal-new-risk). Deliberately NOT #modal-new-risk / the legacy 'modal
    // hide fade in' chrome those two pages use -- this page is built on the
    // sr-modal shell throughout, and that id/behavior is tied to Compliance's
    // own associate-with-a-test flow elsewhere in the app. Gated on the same
    // submit_risks session permission
    // (see the trigger button's comment above for why it's 'submit_risks',
    // plural, not the brief's originally-named 'submit_risk').
    //
    // data-on-save='refresh-and-close' is a general-purpose convention (not
    // hardcoded to this page) that risk.js's save-risk-form success handler
    // checks for: when the submitted form's closest data-on-save='refresh-
    // and-close' ancestor is found, risk.js hides that modal and fires a
    // page-agnostic 'simplerisk:risk-created' event on document instead of
    // doing its default full-page redirect to view.php. Any current or future
    // page can opt a modal into this same behavior by adding this attribute.
    if (!empty($_SESSION['submit_risks'])) {
        echo "
            <div class='modal fade sr-modal' id='review-risk-add-modal' tabindex='-1' aria-labelledby='review-risk-add-modal-title' aria-hidden='true' data-on-save='refresh-and-close'>
                <div class='modal-dialog modal-xl modal-dialog-scrollable'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <span class='sr-modal-icon'><i class='fa fa-plus' aria-hidden='true'></i></span>
                            <h4 class='modal-title' id='review-risk-add-modal-title'>{$escaper->escapeHtml($lang['NewRisk'])}</h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtml($lang['Close'])}'></button>
                        </div>
                        <div class='modal-body'>
        ";
        // .sr-qform is REQUIRED, not decorative -- see management/index.php's
        // own #submit-risk-container comment for the full explanation.
        // _questionnaire.scss scopes every .sr-cvss-metric-row/.sr-cvss-
        // holder-summary/.sr-qcard rule the widget (and every scoring
        // method, not just OWASP) needs under a `.sr-qform { ... }` parent
        // selector -- window.RiskDetailsForm.init() never adds this class
        // itself (the same convention #submit-risk-container and
        // risk-view-details.js's own dynamically-created form container
        // already follow), so the embedding page must supply it.
        // data-can-submit-risk carries the REAL submit_risks session check --
        // unlike management/index.php's own #submit-risk-container, THIS
        // modal is embedded in Review Risk, which gates on the broader
        // riskmanagement permission (management/review_risk.php), not
        // submit_risks specifically -- a reviewer without submit_risks can
        // reach this modal, so its SupportingDocumentation file input
        // (buildSupportingDocumentationWidget(), risk-details-form.js) must
        // not render unconditionally the way it used to.
        echo "<div id='review-risk-add-modal-canvas' class='sr-qform' data-can-submit-risk='" . (!empty($_SESSION['submit_risks']) ? '1' : '0') . "'></div>";
        // The sr-modal shell's documented anatomy (scss/modules/_sr-modal.scss,
        // header comment) puts a modal's actions in a .modal-footer -- 'left
        // hint text + right-aligned actions' -- pinned below the scrolling
        // body. window.RiskDetailsForm renders its own hidden submit
        // affordance and no instruction line INSIDE the <form>, since it is
        // built for embedding (see risk-details-form.js's
        // buildEmbeddedSubmitAffordance()).
        //
        // So this footer ships empty and review-risk.js fills it on open (see
        // its syncAddRiskModalFooter()). The button is NOT moved into it:
        // risk.js resolves the form to submit with $this.closest('form'), so
        // a button re-parented out of the form stops submitting. The footer
        // gets a proxy button that forwards its click to the real (CSS-hidden)
        // one still sitting inside the rendered form.
        echo "
                        </div>
                        <div class='modal-footer' id='review-risk-add-modal-footer'>
                            <span class='sr-modal-hint' id='review-risk-add-modal-hint'></span>
                        </div>
                    </div>
                </div>
            </div>
        ";
    }

    echo "
        </div>
    ";
}

/**********************************************
 * FUNCTION: DISPLAY THE DYNAMIC AUDIT REPORT *
***********************************************/
function display_dynamic_audit_report() {

    global $lang, $escaper;
    
	echo "
		<div class='card-body border my-2'>
            <strong>{$escaper->escapeHtml($lang['DynamicAuditReportHelp'])}</strong>
			<div class='row'>
				<div class='col-10'></div>
				<div class='col-2'>
					<div style='float: right;'>
	";
						render_column_selection_widget('dynamic_audit_report');
	echo "
					</div>
				</div>
			</div>
			<div class='row'>
				<div class='col-12'>
	";
					render_view_table('dynamic_audit_report');
	echo "
				</div>
			</div>
		</div>

        <script>
            $(function () {
                $('.header_filter .multiselect').multiselect({
					allSelectedText: '{$escaper->escapeHtml($lang['ALL'])}',
					includeSelectAllOption: true,
					buttonWidth: '100%',
                    maxHeight: 400,
					enableCaseInsensitiveFiltering: true,
				});
            });
        </script>
	";

}

/*****************************************
* FUNCTION: DISPLAY AUDIT TIMELINE TABLE *
******************************************/
function display_audit_timeline() {

    global $lang, $escaper;
    
    // If User has permission for complicance menu, shows Audit Timeline report
    if(!empty($_SESSION['compliance'])) {

        echo "
            <div class='card-body border my-2'>
                <div class='row'>
                    <div class='col-10'></div>
                    <div class='col-2'>
                        <div style='float: right;'>
        ";
                            render_column_selection_widget('audit_timeline');
        echo "
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-12'>
        ";
                        render_view_table('audit_timeline');
        echo "
                    </div>
                </div>
            </div>
            
            <script>
                $(function () {

                    initializeMultiselect('.header_filter .multiselect', {
                        allSelectedText: '{$escaper->escapeHtml($lang['ALL'])}',
                        includeSelectAllOption: true,
                        buttonWidth: '100%',
                        maxHeight: 400,
                        enableCaseInsensitiveFiltering: true,
                    });

                    $('.header_filter [name=last_date].datepicker').initAsDatePicker();
                    $('.header_filter [name=next_date].datepicker').initAsDatePicker();

                    // Initiate Audit Button Click Event
                    $('body').on('click', '.btn-initiate-audit', function() {
                        $.ajax({
                            url: BASE_URL + '/api/v2/compliance/audit_initiation/initiate',
                            type: 'POST',
                            data: {
                                type: 'test',
                                id: $(this).attr('id')
                            },
                            success: function(res) {
                                if (res.status_message) {
                                    showAlertsFromArray(res.status_message);
                                }
                            },
                            error: function(xhr, status, error) {
                                if (!retryCSRF(xhr, this)) {
                                    if (xhr.responseJSON && xhr.responseJSON.status_message) {
                                        showAlertsFromArray(xhr.responseJSON.status_message);
                                    }
                                }
                            }
                        });
                    });
                });    
            </script>
        ";
    }
}


/***************************************
* FUNCTION: DISPLAY REVIEW RISKS TABLE *
****************************************/
function display_review_date_issues()
{
    global $lang, $escaper;

    $tableID = "review-date-issues";

    echo "
        <table id='{$tableID}' width='100%' class='risk-datatable table table-bordered table-striped table-condensed'>
            <thead>
                <tr>
                    <th data-name='id' align='left' valign='top'>" . $escaper->escapeHtml($lang['ID']) . "</th>
                    <th data-name='subject' align='left' valign='top'>" . $escaper->escapeHtml($lang['Subject']) . "</th>
                    <th data-name='next_review' align='center' valign='top'>".$escaper->escapeHtml($lang['NextReviewDate'])."</th>
                    <th data-name='date_format' align='center' valign='top'>".$escaper->escapeHtml($lang['SuspectedDateFormat'])."</th>
                    <th data-name='action' align='center' valign='top'></th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

        <script>
            $(function () {
                var datatableInstance = $('#{$tableID}').DataTable({
                    searching: false,
                    ordering: true,
                    createdRow: function(row, data, index){
                        var background = $('.background-class', $(row)).data('background');
                        $(row).find('td').addClass(background)
                    },
                    order: [[0, 'asc']],
                    ajax: {
                        url: BASE_URL + '/api/v2/risk_management/review_date_issues',
                        data: function(d){ },
                        complete: function(response){ }
                    },
                    columnDefs : [
                        {
                            'targets' : [0],
                            'width': '5%'
                        },
                        {
                            'targets' : [-3],
                            'width': '10%'
                        },
                        {
                            'targets' : [-2],
                            'width': '12%'
                        },
                        {
                            'targets' : [-1],
                            'width': '5%'
                        },
                        {
                            'targets' : [-1, -2, -3],
                            'orderable': false,
                        },
                        {
                            'targets': -1,
                            'data': null,
                            'defaultContent': '<button class=\"confirm btn btn-submit\" style=\"padding: 2px 15px;\">" . $escaper->escapeHtml($lang['Confirm']) . "</button>'
                        }
                    ]
                });

                // Add paginate options
                datatableInstance.on('draw', function(e, settings){

                    if (datatableInstance.page() == 0) {
                        // Reload the page when no more issues left so the page load code can
                        // run the wrap-up logic
                        if (datatableInstance.rows( {page:'current'} ).count() == 0) {
                            setTimeout(function(){window.location=window.location;}, 1);
                        }
                    } else {// get to the previous page in case we confirmed the last one from the page and it's not the first page
                        if (datatableInstance.rows( {page:'current'} ).count() == 0) {
                            setTimeout(function(){datatableInstance.page('previous').draw('page');}, 1);
                        }
                    }

                    $('#{$tableID} tbody').off('click', 'button.confirm');
                    $('#{$tableID} tbody').on('click', 'button.confirm', function () {
                        var data = datatableInstance.row($(this).closest('tr')).data();
                        var format = $('#format_' + data[4]).val();
                        if (format == '') {
                            alert('" . $escaper->escapeHtml($lang['YouNeedToSpecifyTheFormatParameter']) . "');
                        } else {
                            $.ajax({
                                type: 'POST',
                                url: BASE_URL + '/api/v2/management/risk/fix_review_date_format',
                                data : {
                                    review_id: data[4],
                                    format: format
                                },
                                success: function(data){
                                    if(data.status_message){
                                        showAlertsFromArray(data.status_message);
                                    }
                                    datatableInstance.ajax.reload(null, false);
                                },
                                error: function(xhr,status,error){
                                    if(!retryCSRF(xhr, this))
                                    {
                                        if(xhr.responseJSON && xhr.responseJSON.status_message){
                                            showAlertsFromArray(xhr.responseJSON.status_message);
                                        }
                                    }
                                }
                            });
                        }
                    });
                });                     
            });
        </script>
    ";
}

/**********************************
 * FUNCTION: GET AUDIT TRAIL HTML *
 **********************************/
function get_audit_trail_html($id = NULL, $days = 7, $log_type=NULL) {

    global $escaper;

    // If the ID is greater than 1000 or NULL
    if ($id > 1000 || $id === NULL) {

        $logs = get_audit_trail($id, $days, $log_type);

        foreach ($logs as $log) {

            $date = date(get_default_datetime_format("g:i A T"), strtotime($log['timestamp']));

            echo "
                <p>{$escaper->escapeHtml($date)} > {$escaper->escapeHtml($log['message'])}</p>
            ";
        }

        // Return true
        return true;

    // Otherwise this is not a valid ID
    } else {
        // Return false
        return false;
    }
}

/*************************************
 * FUNCTION: DISPLAY SIDE NAVIGATION *
 *************************************/
function display_side_navigation($active)
{
	global $escaper;
	global $lang;

	// Display the smaller side navigation
	echo "<div id=\"sidenavsmall\" class=\"sidenavsmall\">\n";

        echo "  <div class=\"navbtn\">\n";
        echo "    <a href=\"javascript:void(0)\" onclick=\"hideUnhideNav()\"><img src=\"../images/menu-icon-png-3-lines-white-horizontal.png\" /></a>\n";
        echo "  </div>\n";

	echo ($active == "GovernanceRiskCompliance" ? "<li class=\"active\">\n" : "<li>\n");
	echo "  <a href=\"../reports/index.php\">GRC</a>\n";
	echo "</li>\n";

        // If the incident management extra is enabled
        if (incident_management_extra())
        {
                // Include the incident management extra
                require_once(realpath(__DIR__ . '/../extras/incident_management/index.php'));

                // If the user has incident management permissions
		if (check_permission("im_incidents"))
                {
			echo ($active == "IncidentManagement" ? "<li class=\"active\">\n" : "<li>\n");
        		echo "  <a href=\"../incidents/index.php\">IM</a>\n";
			echo "</li>\n";
		}
	}

	// If the vulnerability management extra is enabled
	if (vulnmgmt_extra())
	{
		// Include the vulnerability management extra
		require_once(realpath(__DIR__ . '/../extras/vulnmgmt/index.php'));

		// If the user has vulnerability management permissions
		if (check_permission("vm_vulnerabilities"))
		{
			echo ($active == "VulnerabilityManagement" ? "<li class=\"active\">\n" : "<li>\n");
			echo "  <a href=\"../vulnerabilities/index.php\">VM</a>\n";
                        echo "</li>\n";
                }
        }

        echo "</div>\n";

	// Display the larger side navigation
        echo "<div id=\"sidenavbig\" class=\"sidenavbig\" style=\"display: none;\">\n";

        echo "  <div class=\"navbtn\">\n";
        echo "    <a href=\"javascript:void(0)\" onclick=\"hideUnhideNav()\"><img src=\"../images/menu-icon-png-3-lines-white-horizontal.png\" /></a>\n";
        echo "  </div>\n";
        
        echo ($active == "GovernanceRiskCompliance" ? "<li class=\"active\">\n" : "<li>\n");
        echo "  <a href=\"../reports/index.php\">" . $escaper->escapeHtml($lang['GovernanceRiskCompliance']) . "</a>\n";
        echo "</li>\n";
        
        // If the incident management extra is enabled
        if (incident_management_extra())
        {
                // Include the incident management extra
                require_once(realpath(__DIR__ . '/../extras/incident_management/index.php'));
                
                // If the user has incident management permissions
		if (check_permission("im_incidents"))
                {
                        echo ($active == "IncidentManagement" ? "<li class=\"active\">\n" : "<li>\n");
                        echo "  <a href=\"../incidents/index.php\">" . $escaper->escapeHtml($lang['IncidentManagement']) . "</a>\n";
                        echo "</li>\n";
                }
        }

	// If the vulnerability management extra is enabled
        if (vulnmgmt_extra())
        {
                // Include the vulnerability management extra
                require_once(realpath(__DIR__ . '/../extras/vulnmgmt/index.php'));

                // If the user has vulnerability management permissions
                if (check_permission("vm_vulnerabilities"))
                {
                        echo ($active == "VulnerabilityManagement" ? "<li class=\"active\">\n" : "<li>\n");
                        echo "  <a href=\"../vulnerabilities/index.php\">" . $escaper->escapeHtml($lang['VulnerabilityManagement']) . "</a>\n";
                        echo "</li>\n";
                }
        }

        echo "</div>\n";

	echo "<script>\n";
	echo "function hideUnhideNav(){\n";
	echo "  if (document.getElementById('sidenavsmall').style.display == 'none'){\n";
	echo "    document.getElementById('sidenavsmall').style.display = '';\n";
	echo "    document.getElementById('sidenavbig').style.display = 'none';\n";
	echo "  } else if (document.getElementById('sidenavbig').style.display == 'none'){\n";
	echo "    document.getElementById('sidenavsmall').style.display = 'none';\n";
	echo "    document.getElementById('sidenavbig').style.display = '';\n";
	echo "  }\n";
	echo "}\n";
	echo "</script>\n";
}

function get_label_by_risk_field_name($field){
    global $lang, $escaper;

    // The label map only depends on the active language, so build it once per language instead
    // of once per call (it holds ~100 RAW, unescaped labels and this is called per column per
    // page — every caller must escape the returned label for its own output context).
    // The fingerprint reads a few strings that differ between languages, so a change of
    // $lang (a different user's locale, or a test swapping it) rebuilds the map.
    static $cached_map = null;
    static $cached_fingerprint = null;
    $fingerprint = implode("\0", [$lang['ID'] ?? '', $lang['Status'] ?? '', $lang['Subject'] ?? '', $lang['Owner'] ?? '', $lang['Description'] ?? '', $lang['ContributingRisk'] ?? '', $lang['Team'] ?? '']);
    if ($cached_map === null || $cached_fingerprint !== $fingerprint)
    {
        $cached_map = get_risk_field_label_map();
        $cached_fingerprint = $fingerprint;
    }

    if (isset($cached_map[$field]))
    {
        return $cached_map[$field];
    }

    // Contributing impact columns depend on rows in the database, so they are resolved on demand
    if (is_string($field) && strpos($field, "Contributing_Impact_") === 0)
    {
        foreach (get_contributing_risks() as $contributing_risk)
        {
            if ("Contributing_Impact_" . $contributing_risk['id'] === $field)
            {
                return $lang['ContributingRisk'].": ".$lang['Impact']." - ".$contributing_risk['subject'];
            }
        }
    }

    return null;
}

/*************************************************
 * FUNCTION: GET RISK FIELD LABEL MAP             *
 * Returns RAW, unescaped label for every static  *
 * risk column. Callers must escape for their own *
 * output context (HTML, JS string, etc.).        *
 *************************************************/
function get_risk_field_label_map(){
    global $lang;
	// Names list of Risk columns
	$columns = array(
		'id' => $lang['ID'],
		'risk_status' => $lang['Status'],
		'closure_date' => $lang['DateClosed'],
        'subject' => $lang['Subject'],
        'risk_mapping' => $lang['RiskMapping'],
        'threat_mapping' => $lang['ThreatMapping'],
		'reference_id' => $lang['ExternalReferenceId'],
		'regulation' => $lang['ControlRegulation'],
		'control_number' => $lang['ControlNumber'],
		'location' => $lang['SiteLocation'],
		'source' => $lang['RiskSource'],
		'category' => $lang['Category'],
		'team' => $lang['Team'],
		'additional_stakeholders' => $lang['AdditionalStakeholders'],
		'technology' => $lang['Technology'],
		'owner' => $lang['Owner'],
		'manager' => $lang['OwnersManager'],
		'submitted_by' => $lang['SubmittedBy'],
		'risk_tags' => $lang['Tags'],
		'submission_date' => $lang['SubmissionDate'],
        'project' => $lang['Project'],
        'project_status' => $lang['ProjectStatus'],
		'days_open' => $lang['DaysOpen'],
		'affected_assets' => $lang['AffectedAssets'],
		'risk_assessment' => $lang['RiskAssessment'],
        'additional_notes' => $lang['AdditionalNotes'],
        'closed_by' => $lang['ClosedBy'],
        'close_reason' => $lang['CloseReason'],
        'close_out' => $lang['CloseOutInformation'],

		'mitigation_planned' => $lang['MitigationPlanned'],
		'planning_strategy' => $lang['PlanningStrategy'],
		'planning_date' => $lang['MitigationPlanning'],
		'mitigation_effort' => $lang['MitigationEffort'],
		'mitigation_cost' => $lang['MitigationCost'],
		'mitigation_owner' => $lang['MitigationOwner'],
		'mitigation_team' => $lang['MitigationTeam'],
		'mitigation_accepted' => $lang['MitigationAccepted'],
		'mitigation_date' => $lang['MitigationDate'],
        'mitigation_controls' => $lang['MitigationControls'],
        'mitigation_percent' => $lang['MitigationPercent'],
		'current_solution' => $lang['CurrentSolution'],
		'security_recommendations' => $lang['SecurityRecommendations'],
		'security_requirements' => $lang['SecurityRequirements'],

		'management_review' => $lang['ManagementReview'],
        'review' => $lang['Review'],
        'review_date' => $lang['ReviewDate'],
        'reviewer' => $lang['ReviewedBy'],
		'next_review_date' => $lang['NextReviewDate'],
		'next_step' => $lang['NextStep'],
		'comments' => $lang['Comments'],

        'scoring_method' => $lang['RiskScoringMethod'],
        'calculated_risk' => $lang['InherentRiskCurrent'],
        'residual_risk' => $lang['ResidualRiskCurrent'],
        'calculated_risk_30' => _lang_raw('InherentRiskDays', ['days' => 30]),
        'residual_risk_30' => _lang_raw('ResidualRiskDays', ['days' => 30]),
        'calculated_risk_60' => _lang_raw('InherentRiskDays', ['days' => 60]),
        'residual_risk_60' => _lang_raw('ResidualRiskDays', ['days' => 60]),
        'calculated_risk_90' => _lang_raw('InherentRiskDays', ['days' => 90]),
        'residual_risk_90' => _lang_raw('ResidualRiskDays', ['days' => 90]),

        'CLASSIC_likelihood' => $lang['Classic'].": ".$lang['Likelihood'],
        'CLASSIC_impact' => $lang['Classic'].": ".$lang['Impact'],
        'CVSS_AccessVector' => "CVSS: ".$lang['AccessVector'],
        'CVSS_AccessComplexity' => "CVSS: ".$lang['AccessComplexity'],
        'CVSS_Authentication' => "CVSS: ".$lang['Authentication'],
        'CVSS_ConfImpact' => "CVSS: ".$lang['ConfidentialityImpact'],
        'CVSS_IntegImpact' => "CVSS: ".$lang['IntegrityImpact'],
        'CVSS_AvailImpact' => "CVSS: ".$lang['AvailabilityImpact'],
        'CVSS_Exploitability' => "CVSS: ".$lang['Exploitability'],
        'CVSS_RemediationLevel' => "CVSS: ".$lang['RemediationLevel'],
        'CVSS_ReportConfidence' => "CVSS: ".$lang['ReportConfidence'],
        'CVSS_CollateralDamagePotential' => "CVSS: ".$lang['CollateralDamagePotential'],
        'CVSS_TargetDistribution' => "CVSS: ".$lang['TargetDistribution'],
        'CVSS_ConfidentialityRequirement' => "CVSS: ".$lang['ConfidentialityRequirement'],
        'CVSS_IntegrityRequirement' => "CVSS: ".$lang['IntegrityRequirement'],
        'CVSS_AvailabilityRequirement' => "CVSS: ".$lang['AvailabilityRequirement'],
        'DREAD_DamagePotential' => "DREAD: ".$lang['DamagePotential'],
        'DREAD_Reproducibility' => "DREAD: ".$lang['Reproducibility'],
        'DREAD_Exploitability' => "DREAD: ".$lang['Exploitability'],
        'DREAD_AffectedUsers' => "DREAD: ".$lang['AffectedUsers'],
        'DREAD_Discoverability' => "DREAD: ".$lang['Discoverability'],
        'OWASP_SkillLevel' => "OWASP: ".$lang['SkillLevel'],
        'OWASP_Motive' => "OWASP: ".$lang['Motive'],
        'OWASP_Opportunity' => "OWASP: ".$lang['Opportunity'],
        'OWASP_Size' => "OWASP: ".$lang['Size'],
        'OWASP_EaseOfDiscovery' => "OWASP: ".$lang['EaseOfDiscovery'],
        'OWASP_EaseOfExploit' => "OWASP: ".$lang['EaseOfExploit'],
        'OWASP_Awareness' => "OWASP: ".$lang['Awareness'],
        'OWASP_IntrusionDetection' => "OWASP: ".$lang['IntrusionDetection'],
        'OWASP_LossOfConfidentiality' => "OWASP: ".$lang['LossOfConfidentiality'],
        'OWASP_LossOfIntegrity' => "OWASP: ".$lang['LossOfIntegrity'],
        'OWASP_LossOfAvailability' => "OWASP: ".$lang['LossOfAvailability'],
        'OWASP_LossOfAccountability' => "OWASP: ".$lang['LossOfAccountability'],
        'OWASP_FinancialDamage' => "OWASP: ".$lang['FinancialDamage'],
        'OWASP_ReputationDamage' => "OWASP: ".$lang['ReputationDamage'],
        'OWASP_NonCompliance' => "OWASP: ".$lang['NonCompliance'],
        'OWASP_PrivacyViolation' => "OWASP: ".$lang['PrivacyViolation'],
        'Contributing_Likelihood' => $lang['ContributingRisk'].": ".$lang['Likelihood'],

        'risk_mapping_risk_grouping' => $lang['RiskGrouping'],
        'risk_mapping_risk' => $lang['Risk'],
        'risk_mapping_description' => $lang['Description'],
        'risk_mapping_function' => $lang['Function'],
	);
	return $columns;
}

/***********************************
 * FUNCTION: DISPLAY LICENSE CHECK *
 ***********************************/
function display_license_check()
{
	global $lang;
	global $escaper;

	if (!isset($_SESSION['license_check'])) {
		return;
	}

	$state = $_SESSION['license_check'];

	// 'pass' and unset/empty mean everything is fine — no banner needed.
	if ($state === 'pass' || $state === '') {
		return;
	}

	// Map each non-passing state to a distinct lang key and alert style.
	// 'fail' (remove_extras) uses alert-danger; all others use alert-warning
	// because they are informational rather than active-deactivation states.
	$message_key = match ($state) {
		'lock'      => 'LicenseStateLockMessage',
		'fail'      => 'LicenseStateFailMessage',
		'anonymous' => 'LicenseStateAnonymousMessage',
		default     => 'LicenseStateUnknownMessage',
	};
	$alert_class = ($state === 'fail') ? 'alert-danger' : 'alert-warning';

	echo "
        <div class='license_check alert {$alert_class} mt-2 mb-0'>" .
            $escaper->escapeHtml($lang[$message_key]) . "
        </div>
    ";
}

/******************************************
 * FUNCTION: DISPLAY CONTROL GAP ANALYSIS *
 ******************************************/
function display_control_gap_analysis() {

    global $lang, $escaper;

    // If User has permission for governance menu, shows Control Gap Analysis report
    if (!empty($_SESSION['governance'])) {

        // Begin the framework filter form
        echo "
            <div class='card-body border my-2'>
                <form class='w-50' id='framework_form' name='framework_form' method='post' action=''>
        ";

        // Add the filter
        echo "
                    <label>{$escaper->escapeHtml($lang['ControlFramework'])} :</label>
        ";

        // If no framework was posted
        if (!isset($_POST['framework'])) {

            // Set the filter option to None Selected
            $framework = null;

        } else {

            $framework = (int)$_POST['framework'];

        }

                    // Create the dropdown
                    create_dropdown("frameworks", $framework, "framework", blankText: $lang['NoneSelected'], customHtml: "onchange='this.form.submit();'");

        echo "
                </form>
            </div>

            <script>
                $(function () {
                    
                    // Make the Control Framework dropdown to be searchable
                    $('#framework').select2();
                    
                });
            </script>
        ";

        // If a framework id was posted
        if ($framework != null) {

            echo "
            <div class='card-body border'>
            ";

                // Display the control maturity spider chart
                display_control_maturity_spider_chart($framework);
                
            echo " 
            </div>
            <div class='row my-2'>
                <div class='col-12'>
                    <div>
                        <nav class='nav nav-tabs'>
                            <a class='nav-link active' data-bs-target='#below_maturity' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['BelowMaturity'])}</a>
                            <a class='nav-link' data-bs-target='#at_maturity' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['AtMaturity'])}</a>
                            <a class='nav-link' data-bs-target='#above_maturity' data-bs-toggle='tab'>{$escaper->escapeHtml($lang['AboveMaturity'])}</a>
                        </nav>
                    </div>
                    <div class='tab-content card-body border mt-2'>
                        <div id='below_maturity' class='tab-pane active' tabindex='0'>
            ";
                            display_gap_analysis_table($framework, "below_maturity");
            echo "
                        </div>
                        <div id='at_maturity' class='tab-pane' tabindex='0'>
            ";
                            display_gap_analysis_table($framework, "at_maturity");
            echo "
                        </div>
                        <div id='above_maturity' class='tab-pane' tabindex='0'>
            ";
                            display_gap_analysis_table($framework, "above_maturity");
            echo "
                        </div>
                    </div>
                </div>
            </div>

            <script>
                $(function() {

                    // Scroll to the top of the page when loading the page.
                    $('.content-wrapper')[0].scrollIntoView();

                    // As a default, when clicking the tab, we set the page to scroll to the top so it doesn't jump to the tab's content
                    // by calling $('.content-wrapper')[0].scrollIntoView() in the 'click' and 'shown.bs.tab' event handler.
                    // To prevent the page from scrolling to the top of it, we should remove those event handlers.
                    $(document).off('shown.bs.tab', 'nav a[data-bs-toggle=\"tab\"]');
                    $(document).off('click', 'nav a[data-bs-toggle=\"tab\"]');
                    
                    // We should change the hash and scroll to the tab when the tab is clicked.
                    $(document).on('click', 'nav a[data-bs-toggle=\"tab\"]', function (e) {
                        
                        // change the hash
                        let hash = $(this).data('bs-target');
                        window.location.hash = hash.replace('#', '');

                        // If we don't set the following, it jumps to the tab's content when clicking the tab.
                        $(this).parent().parent().parent()[0].scrollIntoView();

                    });

                });
            </script>
            ";
        }
    }
}

/****************************************
 * FUNCTION: DISPLAY GAP ANALYSIS TABLE *
 ****************************************/
function display_gap_analysis_table($framework, $maturity) {

	global $lang, $escaper;

	$tableID = "control-gap-analysis-" . $maturity;

	echo "
        <table id='{$tableID}' width='100%' class='risk-datatable table table-bordered table-striped table-condensed'>
            <thead >
                <tr >
                    <th data-name='control_number' align='left' width='50px' valign='top'>{$escaper->escapeHtml($lang['ControlNumber'])}</th>
                    <th data-name='control_short_name' align='left' width='200px' valign='top'>{$escaper->escapeHtml($lang['ControlShortName'])}</th>
                    <th data-name='control_phase' align='left' width='50px' valign='top'>{$escaper->escapeHtml($lang['ControlPhase'])}</th>
                    <th data-name='control_family' align='left' width='50px' valign='top'>{$escaper->escapeHtml($lang['ControlFamily'])}</th>
                    <th data-name='control_current_maturity' align='left' width='50px' valign='top'>{$escaper->escapeHtml($lang['CurrentControlMaturity'])}</th>
                    <th data-name='control_desired_maturity' align='center' width='50px' valign='top'>{$escaper->escapeHtml($lang['DesiredControlMaturity'])}</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        <script>
            $(function() {
                var form = $('#{$tableID}').parents('form');
                var datatableInstance_{$maturity} = $('#{$tableID}').DataTable({
                    createdRow: function(row, data, index){
                        var background = $('.background-class', $(row)).data('background');
                        $(row).find('td').addClass(background)
                    },
                    order: [[1, 'asc']],
                    ajax: {
                        url: BASE_URL + '/api/v2/reports/governance/control_gap_analysis?framework_id={$escaper->escapeHtml($framework)}&maturity={$escaper->escapeHtml($maturity)}',
                        data: function(d){
                        },
                        complete: function(response){
                        }
                    }
                });
            });
        </script>
    ";
}

/*************************************************************
* FUNCTION: DISPLAY CONTRIBUTING RISKS LIKELIHOOD TABLE LIST *
**************************************************************/
function display_contributing_risks_likelihood_table_list(){

    global $lang, $escaper;

    $rows = get_contributing_risks_likelihood_list();
    $str = "";
    foreach($rows as $row){
        if(count($rows) != 1) $delete_button = "<a class='delete-value' data-id='{$row['id']}' data-value='{$row['value']}'><i class='fa fa-trash'></i></a>";
        else $delete_button = "";
        $str .= "
            <tr>
                <td align='center'>{$row['value']}</td>
                <td align='center'>
                    <span data-id='{$row['id']}' data-value='{$row['value']}'><span class='editable'>{$escaper->escapeHtml($row['name'])}</span>
                    <input type='text' class='editable' value='{$escaper->escapeHtml($row['name'])}' style='display: none;'></span>
                </td>
                <td align='center'>{$delete_button}</td>
                <td></td>
            </tr>
        ";
    }
    return $str;
}
/*********************************************************
* FUNCTION: DISPLAY CONTRIBUTING RISKS IMPACT TABLE LIST *
**********************************************************/
function display_contributing_risks_impact_table_list(){
    global $lang, $escaper;
    $rows = get_contributing_risks_impact_list();
    $str = "";
    $prev_subject = "";
    foreach($rows as $row){
        if($prev_subject != $row['subject']) {
            $str .= "
                <tr class='subject-row' data-value='{$row['value']}' data-contributing_risks_id='{$row['contributing_risks_id']}'>
                    <td align='center'>{$escaper->escapeHtml($row['subject'])}</td>
                    <td></td>
                    <td align='center'>
                        <button class='impact-add-btn btn btn-dark'><i class='fa fa-plus'></i></button>
                    </td>
                    <td></td>
                </tr>
            ";
        }
        $prev_subject = $row['subject'];
        $str .= "
            <tr>
                <td align='center'>{$row['value']}</td>
                <td align='center'>
                    <span data-id='{$row['id']}' data-value='{$row['value']}'><span class='editable'>{$escaper->escapeHtml($row['name'])}</span>
                    <input type='text' class='editable' value='{$escaper->escapeHtml($row['name'])}' style='display: none;'></span>
                </td>
                <td align='center'>
                    <a class='delete-value' data-id='{$row['id']}' data-value='{$row['value']}' data-contributing_risks_id='{$row['contributing_risks_id']}'><i class='fa fa-trash'></i></a>
                </td>
                <td></td>
            </tr>
        ";
    }
    return $str;
}

function display_datetimepicker_javascript($initialize = false) {

    $app_version = current_version("app");
    // @phan-suppress-next-line SecurityCheck-XSS -- build_url() called with hardcoded asset path; base URL is admin-configured
    echo "<script src='" . build_url("js/jquery.datetimepicker.full.min.js?{$app_version}") . "'></script>\n";
    // @phan-suppress-next-line SecurityCheck-XSS -- build_url() called with hardcoded asset path; base URL is admin-configured
    echo "<link rel='stylesheet' href='" . build_url("css/jquery.datetimepicker.min.css?{$app_version}") . "'/>\n";

    if ($initialize) {
        // Initialize if needed
        // @phan-suppress-next-line SecurityCheck-XSS -- get_default_datetime_format() returns admin-configured date format string with no user input
        echo "
            <script>
                $(document).ready(function(){
                    $('input.datetimepicker').datetimepicker({
                        lazyInit: true,
                        format: '" . get_default_datetime_format() . "',
                        step: 5
                    });
                });
            </script>
        ";
    }
}

/********************************
* FUNCTION: DISPLAY ADD PROJECT *
*********************************/
function display_add_projects($template_group_id = "") {

    global $escaper;

    // Resolve the tab-per-group selector when called at the top level (no
    // group given yet) -- same shape as display_add_risk() for Risk and
    // render_create_modal() for Asset: Organizational Hierarchy scopes the
    // offered groups to the current user's business unit; otherwise every
    // custom_template_group for this fgroup is offered. A caller that passes
    // a specific group id skips the picker and renders straight through to a
    // single un-tabbed form; the per-pane bodies go to
    // display_add_projects_fields(), never back through here.
    $template_groups = [];
    if (!$template_group_id && customization_extra()) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        // The same candidate set resolve_template_group_id() validates a
        // submitted id against -- one helper, so the tabs offered here and
        // the ids accepted on create can never drift apart.
        $template_groups = get_template_groups_for_user('project');
    }

    if (count($template_groups) > 1) {

        echo "
            <div class='mt-2'>
                <nav class='nav nav-tabs'>
        ";
        foreach ($template_groups as $index => $template_group) {
            $active = $index == 0 ? "active" : "";
            echo "
                    <a class='nav-link {$active}' data-bs-target='#project_template_group_{$template_group['id']}' data-bs-toggle='tab'>" . $escaper->escapeHtml($template_group['name']) . "</a>
            ";
        }
        echo "
                </nav>
            </div>
            <div class='tab-content'>
        ";
        foreach ($template_groups as $index => $template_group) {
            $pane_active = $index == 0 ? "show active" : "";
            echo "
                <div class='tab-pane fade {$pane_active}' id='project_template_group_{$template_group['id']}'>
                    <form id='project-new' name='project-new' method='post' class='project-new-form'>
            ";
            display_add_projects_fields($template_group['id']);
            echo "
                    </form>
                </div>
            ";
        }
        echo "
            </div>
        ";
        return;
    }

    // Zero or one resolved group: carry the single real id forward so the
    // field body below scopes to and records the correct group without a
    // visible tab picker. Falls back to "" (unresolved) when customization
    // never resolved any group at all -- display_add_projects_fields() then
    // resolves the real Default group itself, matching pre-existing behavior.
    if (count($template_groups) == 1) {
        $template_group_id = $template_groups[0]['id'];
    }

    echo "
        <form id='project-new' name='project-new' method='post' class='project-new-form'>
    ";
    display_add_projects_fields($template_group_id);
    echo "
        </form>
    ";
}

/****************************************************
* FUNCTION: DISPLAY ADD PROJECT FIELDS (PER-GROUP)   *
*****************************************************/
function display_add_projects_fields($template_group_id) {

    global $lang, $escaper;

    // If customization extra is enabled
    if(customization_extra()) {

        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        if(!$template_group_id) {
            $group = get_default_template_group("project");
            $template_group_id = $group["id"];
        }

        // Carry the resolved template group forward so add_project_api()
        // stores which admin-defined field layout this record was created
        // under, instead of silently defaulting. No id= here (Task 25's
        // Asset precedent): this helper renders once per pane when multiple
        // template groups exist, and a shared id would be duplicated across
        // panes' forms -- name= is enough since it submits via its own
        // per-pane <form>.
        echo "
            <input type='hidden' name='template_group_id' value='" . (int)$template_group_id . "'>
            <section class='sr-qcard'>
                <div class='sr-qcard-head'><h3>{$escaper->escapeHtml($lang['Details'])}</h3></div>
                <div class='sr-qcard-body'>
                    <div class='sr-qgrid'>
        ";

        $active_fields = get_active_fields("project", $template_group_id);
        foreach($active_fields as $field) {
            if($field['is_basic'] == 1) {
                switch($field['name']) {
                    case 'ProjectName':
                        echo "
                            <div class='sr-qfield sr-qfield--full'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['NewProjectName'])}<span class='required'>*</span></label>
                                <input type='text' name='new_project' value='' class='form-control' required>
                            </div>
                        ";
                        break;
                    case 'DueDate':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DueDate'])}</label>
                                <input type='text' name='due_date' class='form-control datepicker' value='' autocomplete='off'>
                            </div>
                        ";
                        break;
                    case 'Consultant':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['Consultant'])}</label>
                        ";
                                create_dropdown("enabled_users", NULL, "consultant", true, false, false, "", $escaper->escapeHtml($lang['Unassigned']));
                        echo "
                            </div>
                        ";
                        break;
                    case 'BusinessOwner':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['BusinessOwner'])}</label>
                        ";
                                create_dropdown("enabled_users", NULL, "business_owner", true, false, false, "", $escaper->escapeHtml($lang['Unassigned']));
                        echo "
                            </div>
                        ";
                        break;
                    case 'DataClassification':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DataClassification'])}</label>
                        ";
                                create_dropdown("data_classification", NULL, "data_classification", true, false, false, "", $escaper->escapeHtml($lang['Unassigned']));
                        echo "
                            </div>
                        ";
                        break;
                }
            }
            else {
                display_custom_field_edit($field, [], "label");
            }
        }

        echo "
                    </div>
                </div>
            </section>
        ";
    } else {
        echo "
            <section class='sr-qcard'>
                <div class='sr-qcard-head'><h3>{$escaper->escapeHtml($lang['Details'])}</h3></div>
                <div class='sr-qcard-body'>
                    <div class='sr-qgrid'>
                        <div class='sr-qfield sr-qfield--full'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['NewProjectName'])}<span class='required'>*</span></label>
                            <input type='text' name='new_project' value='' class='form-control' required>
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DueDate'])}</label>
                            <input type='text' name='due_date' class='form-control datepicker' value='' autocomplete='off'>
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['Consultant'])}</label>" .
                            create_dropdown("enabled_users", NULL, "consultant", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['BusinessOwner'])}</label>" .
                            create_dropdown("enabled_users", NULL, "business_owner", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DataClassification'])}</label>" .
                            create_dropdown("data_classification", NULL, "data_classification", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                        </div>
                    </div>
                </div>
            </section>
        ";
    }
}
/*********************************
* FUNCTION: DISPLAY EDIT PROJECT *
*********************************/
function display_edit_projects($template_group_id = ""){
    
    global $lang, $escaper;
    
    // If customization extra is enabled
    if(customization_extra()) {

        // Include the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        if(!$template_group_id) {
            $group = get_default_template_group("project");
            $template_group_id = $group["id"];
        }

        echo "
            <section class='sr-qcard'>
                <div class='sr-qcard-head'><h3>{$escaper->escapeHtml($lang['Details'])}</h3></div>
                <div class='sr-qcard-body'>
                    <div class='sr-qgrid'>
        ";

        $active_fields = get_active_fields("project", $template_group_id);
        foreach($active_fields as $field) {
            if($field['is_basic'] == 1) {
                switch($field['name']) {
                    case 'ProjectName':
                        echo "
                            <div class='sr-qfield sr-qfield--full'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['Name'])}<span class='required'>*</span></label>
                                <input type='text' name='name' class='form-control' required>
                            </div>
                        ";
                        break;
                    case 'DueDate':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DueDate'])}</label>
                                <input type='text' name='due_date' class='form-control datepicker' value='' autocomplete='off'>
                            </div>
                        ";
                        break;
                    case 'Consultant':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['Consultant'])}</label>" .
                                create_dropdown("enabled_users", NULL, "consultant", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                            </div>
                        ";
                        break;
                    case 'BusinessOwner':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['BusinessOwner'])}</label>" .
                                create_dropdown("enabled_users", NULL, "business_owner", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                            </div>
                        ";
                        break;
                    case 'DataClassification':
                        echo "
                            <div class='sr-qfield'>
                                <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DataClassification'])}</label>" .
                                create_dropdown("data_classification", NULL, "data_classification", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                            </div>
                        ";
                        break;
                }
            } else {
                display_custom_field_edit($field, [], "label");
            }
        }

        echo "
                    </div>
                </div>
            </section>
        ";
    } else {
        echo "
            <section class='sr-qcard'>
                <div class='sr-qcard-head'><h3>{$escaper->escapeHtml($lang['Details'])}</h3></div>
                <div class='sr-qcard-body'>
                    <div class='sr-qgrid'>
                        <div class='sr-qfield sr-qfield--full'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['Name'])}<span class='required'>*</span></label>
                            <input type='text' name='name' class='form-control' required>
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DueDate'])}</label>
                            <input type='text' name='due_date' class='form-control datepicker' value='' autocomplete='off'>
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['Consultant'])}</label>" .
                            create_dropdown("enabled_users", NULL, "consultant", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['BusinessOwner'])}</label>" .
                            create_dropdown("enabled_users", NULL, "business_owner", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                        </div>
                        <div class='sr-qfield'>
                            <label class='sr-qlabel'>{$escaper->escapeHtml($lang['DataClassification'])}</label>" .
                            create_dropdown("data_classification", NULL, "data_classification", true, false, true, "", $escaper->escapeHtml($lang['Unassigned'])) . "
                        </div>
                    </div>
                </div>
            </section>
        ";
    }
}
/**********************************************
 * FUNCTION: DISPLAY PLAN PROJECTS (SR-2229)  *
 **********************************************/
function display_plan_projects()
{
    global $lang, $escaper;

    $can_add    = check_permission('add_projects') ? 'true' : 'false';
    $can_manage = check_permission('manage_projects') ? 'true' : 'false';
    $can_delete = check_permission('delete_projects') ? 'true' : 'false';
    $can_modify = has_permission('modify_risks') ? 'true' : 'false';
    $can_close  = has_permission('close_risks') ? 'true' : 'false';

    // Both cards are DIRECT children of .content: _tables.scss's
    // `.content:has(> .sr-table-card)` is what swaps the page's white slab for
    // the gray ground, and a .row/.col-12 wrapper defeats it (see
    // compliance/audits.php for the full rationale).
    echo "
        <div class='sr-table-card mb-3' id='plan-projects-card'
             data-can-add='{$can_add}' data-can-manage='{$can_manage}'
             data-can-delete='{$can_delete}' data-can-modify-risks='{$can_modify}'
             data-can-close-risks='{$can_close}'>
            <div class='sr-table-toolbar' id='plan-projects-toolbar'>
                <div class='sr-table-status-filter' id='plan-projects-status-filter'>
                    <span class='sr-status-chip active' data-status='1'>{$escaper->escapeHtml($lang['Active'])} <span class='n' id='plan-projects-count-1'></span></span>
                    <span class='sr-status-chip' data-status='2'>{$escaper->escapeHtml($lang['OnHold'])} <span class='n' id='plan-projects-count-2'></span></span>
                    <span class='sr-status-chip' data-status='3'>{$escaper->escapeHtml($lang['Completed'])} <span class='n' id='plan-projects-count-3'></span></span>
                    <span class='sr-status-chip' data-status='4'>{$escaper->escapeHtml($lang['Canceled'])} <span class='n' id='plan-projects-count-4'></span></span>
                    <span class='sr-status-chip' data-status='all'>{$escaper->escapeHtml($lang['ALL'])} <span class='n' id='plan-projects-count-all'></span></span>
                    <span class='sr-status-chip sr-status-chip--attn' data-status='unassigned'>{$escaper->escapeHtml($lang['Unassigned'])} <span class='n' id='plan-projects-count-unassigned'></span></span>
                </div>
                <div class='sr-table-tools'>
                    <div class='dt-search'>
                        <input type='search' id='plan-projects-search' class='form-control' placeholder='{$escaper->escapeHtmlAttr($lang['SearchProjectsPlaceholder'])}' aria-label='{$escaper->escapeHtmlAttr($lang['SearchProjectsPlaceholder'])}'>
                    </div>
                    <button type='button' class='sr-qf-toggle' id='plan-projects-filters-toggle' aria-expanded='false' aria-controls='plan-projects-quickfilters'>
                        <i class='fa fa-filter'></i><span>{$escaper->escapeHtml($lang['Filters'])}</span>
                        <span class='sr-qf-toggle-count' id='plan-projects-filters-count' hidden></span>
                    </button>
                    <div class='colpicker'>
                        <button type='button' class='filterbtn sr-table-filter' id='plan-projects-colpicker-btn' aria-haspopup='true' aria-expanded='false'>
                            <i class='fa fa-table-columns' aria-hidden='true'></i> {$escaper->escapeHtml($lang['Columns'])}
                        </button>
                        <div class='colpanel colpanel-searchable d-none' id='plan-projects-colpanel'></div>
                    </div>
    ";
    if ($can_add === 'true') {
        echo "
                    <button type='button' class='btn btn-danger' id='plan-projects-add-btn'>+ {$escaper->escapeHtml($lang['AddProject'])}</button>
        ";
    }
    echo "
                </div>
            </div>
            <div class='sr-bulk-bar d-none' id='plan-projects-bulk-bar'>
                <button type='button' class='sr-bulk-clear' id='plan-projects-bulk-clear' aria-label='{$escaper->escapeHtmlAttr($lang['Clear'])}'>&times;</button>
                <span class='sr-bulk-count' id='plan-projects-bulk-count'></span>
                <!-- Select all N: escalates a page-level selection to every
                     project matching the current chip/search/filters, the same
                     .sr-bulk-lnk affordance the Governance controls grid offers.
                     Shown by plan-projects.js syncBulkBar() only while there are
                     more matching rows than are selected. -->
                <button type='button' class='sr-bulk-lnk d-none' id='plan-projects-select-all-filtered'></button>
                <div class='sr-bulk-actions'>
    ";
    if ($can_manage === 'true') {
        echo "      <button type='button' class='btn btn-outline-secondary btn-sm' id='plan-projects-bulk-status'>{$escaper->escapeHtml($lang['ChangeStatus'])}</button>";
    }
    if ($can_delete === 'true') {
        echo "      <button type='button' class='btn btn-outline-danger btn-sm' id='plan-projects-bulk-delete'>{$escaper->escapeHtml($lang['Delete'])}</button>";
    }
    echo "
                </div>
            </div>
            <div class='sr-table-quickfilters d-none' id='plan-projects-quickfilters'>
                <div class='sr-qf-selects'>
                    <select id='plan-projects-consultant-filter' class='form-select' multiple data-placeholder='{$escaper->escapeHtmlAttr($lang['AllConsultants'])}' aria-label='{$escaper->escapeHtmlAttr($lang['Consultant'])}'></select>
                    <select id='plan-projects-owner-filter' class='form-select' multiple data-placeholder='{$escaper->escapeHtmlAttr($lang['AllBusinessOwners'])}' aria-label='{$escaper->escapeHtmlAttr($lang['BusinessOwner'])}'></select>
                    <select id='plan-projects-classification-filter' class='form-select' multiple data-placeholder='{$escaper->escapeHtmlAttr($lang['AllDataClassifications'])}' aria-label='{$escaper->escapeHtmlAttr($lang['DataClassification'])}'></select>
                    <select id='plan-projects-due-filter' class='form-select' data-placeholder='{$escaper->escapeHtmlAttr($lang['AnyDueStatus'])}' aria-label='{$escaper->escapeHtmlAttr($lang['DueDate'])}'>
                        <option value=''>{$escaper->escapeHtml($lang['AnyDueStatus'])}</option>
                        <option value='on_track'>{$escaper->escapeHtml($lang['OnTrack'])}</option>
                        <option value='due_soon'>{$escaper->escapeHtml($lang['DueSoon'])}</option>
                        <option value='overdue'>{$escaper->escapeHtml($lang['Overdue'])}</option>
                        <option value='none'>{$escaper->escapeHtml($lang['NoDueDate'])}</option>
                    </select>
                    <button type='button' class='btn btn-link btn-sm sr-qf-clear d-none' id='plan-projects-filters-clear'>{$escaper->escapeHtml($lang['ClearFilters'])}</button>
                </div>
            </div>
            <div id='plan-projects-grid'>
            <div class='sr-table-scroll'>
                <table id='plan_projects_table' class='sr-table' width='100%'>
                    <thead><tr>
                        <th class='sr-drag-col'></th>
                        <th class='sr-check-col'><input type='checkbox' class='form-check-input' id='plan-projects-select-all' aria-label='{$escaper->escapeHtmlAttr($lang['SelectAll'])}'></th>
                        <th class='sr-caret-col'></th>
                        <th class='num' data-col-fixed='priority'>{$escaper->escapeHtml($lang['Priority'])}</th>
                        <th data-col-fixed='name'>{$escaper->escapeHtml($lang['ProjectName'])}</th>
                        <th data-col='due_date'>{$escaper->escapeHtml($lang['DueDate'])}</th>
                        <th data-col='consultant'>{$escaper->escapeHtml($lang['Consultant'])}</th>
                        <th data-col='business_owner'>{$escaper->escapeHtml($lang['BusinessOwner'])}</th>
                        <th data-col='data_classification'>{$escaper->escapeHtml($lang['DataClassification'])}</th>
                        <th data-col='risk_count' class='num'>{$escaper->escapeHtml($lang['Risks'])}</th>
                        <th data-col='highest_risk'>{$escaper->escapeHtml($lang['HighestRisk'])}</th>
                        <th data-col='status' class='d-none'>{$escaper->escapeHtml($lang['Status'])}</th>
                        <!-- sr-actions-col-sticky: pins the actions column to the
                             right edge of .sr-table-scroll's horizontal scroll, the
                             same opt-in Review Risk's grid uses (rule scoped by table
                             id in _tables.scss; plan-projects.js's column def carries
                             the class onto the <td>s). -->
                        <th class='sr-actions-col sr-actions-col-sticky'></th>
                    </tr></thead>
                    <tbody></tbody>
                </table>
            </div>
            </div>
            <div id='plan-projects-queue' class='d-none'>
            <div class='sr-bulk-bar d-none' id='unassigned-risks-bulk-bar'>
                <button type='button' class='sr-bulk-clear' id='unassigned-risks-bulk-clear' aria-label='{$escaper->escapeHtmlAttr($lang['Clear'])}'>&times;</button>
                <span class='sr-bulk-count' id='unassigned-risks-bulk-count'></span>
                <button type='button' class='sr-bulk-lnk d-none' id='unassigned-risks-select-all-filtered'></button>
                <div class='sr-bulk-actions'>
                    <button type='button' class='btn btn-outline-secondary btn-sm' id='unassigned-risks-bulk-assign'>{$escaper->escapeHtml($lang['AssignToProject'])}</button>
                </div>
            </div>
            <div class='sr-table-scroll'>
                <table id='unassigned_risks_table' class='sr-table' width='100%'>
                    <thead><tr>
                        <th class='sr-check-col'><input type='checkbox' class='form-check-input' id='unassigned-risks-select-all' aria-label='{$escaper->escapeHtmlAttr($lang['SelectAll'])}'></th>
                        <th class='num'>{$escaper->escapeHtml($lang['ID'])}</th>
                        <th>{$escaper->escapeHtml($lang['Subject'])}</th>
                        <th>{$escaper->escapeHtml($lang['InherentRisk'])}</th>
                        <th>{$escaper->escapeHtml($lang['Owner'])}</th>
                        <th>{$escaper->escapeHtml($lang['Team'])}</th>
                        <th>{$escaper->escapeHtml($lang['Reviewed'])}</th>
                        <th class='sr-actions-col sr-actions-col-sticky'></th>
                    </tr></thead>
                    <tbody></tbody>
                </table>
            </div>
            </div>
        </div>
    ";
}

/*****************************************************
 * FUNCTION: DISPLAY PLAN PROJECTS MODALS (SR-2229)  *
 *****************************************************/
function display_plan_projects_modals()
{
    global $lang, $escaper;

    // Add
    echo "
    <div class='modal fade sr-modal' id='project-modal-add' tabindex='-1' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered modal-dialog-scrollable'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <span class='sr-modal-icon'><i class='fa fa-folder-plus'></i></span>
                    <h4 class='modal-title'>{$escaper->escapeHtml($lang['NewProject'])}</h4>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Close'])}'></button>
                </div>
                <div class='modal-body sr-qform'>
    ";
    display_add_projects();
    echo "
                </div>
                <div class='modal-footer'>
                    <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                    <button type='button' class='btn btn-submit project-add-save-btn' name='add_project'>{$escaper->escapeHtml($lang['Add'])}</button>
                </div>
            </div>
        </div>
    </div>";

    // Edit
    echo "
    <div class='modal fade sr-modal' id='project-modal-edit' tabindex='-1' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered modal-dialog-scrollable'>
            <div class='modal-content'>
                <form id='project-edit' action='#' method='post'>
                    <input type='hidden' name='project_id' value=''>
                    <div class='modal-header'>
                        <span class='sr-modal-icon'><i class='fa fa-edit'></i></span>
                        <h4 class='modal-title'>{$escaper->escapeHtml($lang['EditProject'])}</h4>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Close'])}'></button>
                    </div>
                    <div class='modal-body sr-qform'>
    ";
    display_edit_projects();
    echo "
                    </div>
                    <div class='modal-footer'>
                        <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                        <button type='submit' class='btn btn-submit' name='edit_project'>{$escaper->escapeHtml($lang['Update'])}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>";

    // Change status (single + bulk; JS fills #project-status-consequence)
    echo "
    <div class='modal fade sr-modal' id='project-status-modal' tabindex='-1' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <span class='sr-modal-icon'><i class='fa fa-arrow-right-arrow-left'></i></span>
                    <h4 class='modal-title'>{$escaper->escapeHtml($lang['ChangeProjectStatus'])}</h4>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Close'])}'></button>
                </div>
                <div class='modal-body'>
                    <section class='sr-qcard'>
                        <div class='sr-qcard-body'>
                            <div class='sr-qstack' id='project-status-options'>
    ";
    foreach ([1 => 'Active', 2 => 'OnHold', 3 => 'Completed', 4 => 'Canceled'] as $value => $key) {
        echo "
                                <label class='form-check'><input class='form-check-input' type='radio' name='project_status' value='{$value}'> <span class='form-check-label'>{$escaper->escapeHtml($lang[$key])}</span></label>";
    }
    echo "
                            </div>
                            <div class='sr-qnote d-none' id='project-status-consequence'></div>
                        </div>
                    </section>
                </div>
                <div class='modal-footer'>
                    <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                    <button type='button' class='btn btn-submit' id='project-status-confirm'>{$escaper->escapeHtml($lang['Update'])}</button>
                </div>
            </div>
        </div>
    </div>";

    // Delete (single + bulk)
    echo "
    <div class='modal fade sr-modal' id='project-delete-modal' tabindex='-1' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <span class='sr-modal-icon sr-modal-icon--danger'><i class='fa fa-trash'></i></span>
                    <h4 class='modal-title'>{$escaper->escapeHtml($lang['Delete'])}</h4>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Close'])}'></button>
                </div>
                <div class='modal-body'>
                    <section class='sr-qcard'><div class='sr-qcard-body'>
                        <p id='project-delete-question'>{$escaper->escapeHtml($lang['AreYouSureYouWantToDeleteThisProject'])}</p>
                        <p class='sr-qhint' id='project-delete-consequence'></p>
                    </div></section>
                </div>
                <div class='modal-footer'>
                    <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                    <button type='button' class='btn btn-danger' id='project-delete-confirm'>{$escaper->escapeHtml($lang['Delete'])}</button>
                </div>
            </div>
        </div>
    </div>";

    // Assign to project (queue: single + bulk)
    echo "
    <div class='modal fade sr-modal' id='assign-project-modal' tabindex='-1' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <span class='sr-modal-icon'><i class='fa fa-folder-open'></i></span>
                    <h4 class='modal-title'>{$escaper->escapeHtml($lang['AssignToProject'])}</h4>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Close'])}'></button>
                </div>
                <div class='modal-body sr-qform'>
                    <section class='sr-qcard'><div class='sr-qcard-body'>
                        <div class='sr-qfield sr-qfield--full'>
                            <label class='sr-qlabel' for='assign-project-select'>{$escaper->escapeHtml($lang['ProjectName'])}</label>
                            <select id='assign-project-select' class='form-select' data-placeholder='{$escaper->escapeHtmlAttr($lang['ProjectName'])}'></select>
                        </div>
                    </div></section>
                </div>
                <div class='modal-footer'>
                    <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                    <button type='button' class='btn btn-submit' id='assign-project-confirm'>{$escaper->escapeHtml($lang['AssignToProject'])}</button>
                </div>
            </div>
        </div>
    </div>";

    // Add risks to this project: the shared faceted picker's modal markup.
    // Same DOM shape as display_control_picker_modal() (this file) and the
    // #document-control-picker markup in governance/documentation.php,
    // minus the facet columns (this picker has no framework/family facets --
    // facets: []): a JS-filled scope status span, the search box, the
    // results list and the selected panel.
    display_faceted_picker_modal_markup([
        'modalId' => 'add-risks-picker', 'searchId' => 'add-risks-picker-search',
        'listId' => 'add-risks-picker-list', 'selectedId' => 'add-risks-picker-selected',
        'countId' => 'add-risks-picker-count', 'selectedCountId' => 'add-risks-picker-selected-count',
        'scopeId' => 'add-risks-picker-scope', 'commitId' => 'add-risks-picker-commit',
        'title' => $lang['AddRisksToThisProject'],
    ]);
}

/******************************************************************************
 * FUNCTION: DISPLAY FACETED PICKER MODAL MARKUP                             *
 ******************************************************************************
 * The shared DOM shell factored out of display_control_picker_modal() (this
 * file) and the #document-control-picker markup in
 * governance/documentation.php: the modal frame, title, search box, results
 * list, selected panel and counts, and the commit/cancel footer -- but with
 * NO facet columns (facets: []). Both existing callers keep their own
 * framework/family facet-column copies; migrating them onto this helper is
 * out of scope here.
 *
 * $ids keys (all required): modalId, searchId, listId, selectedId, countId,
 * selectedCountId, scopeId, commitId, title. The caller wires up filtering,
 * search and selection entirely client-side against these ids.
 ******************************************************************************/
function display_faceted_picker_modal_markup(array $ids) {
    global $lang, $escaper;

    $modal_id           = $ids['modalId'];
    $search_id          = $ids['searchId'];
    $list_id            = $ids['listId'];
    $selected_id        = $ids['selectedId'];
    $count_id           = $ids['countId'];
    $selected_count_id  = $ids['selectedCountId'];
    $scope_id           = $ids['scopeId'];
    $commit_id          = $ids['commitId'];
    $title              = (string)($ids['title'] ?? '');
    $title_id           = "{$modal_id}-title";

    echo "
    <div id='{$modal_id}' class='modal fade sr-modal sr-picker-modal' tabindex='-1' aria-hidden='true' aria-labelledby='{$title_id}'>
        <div class='modal-dialog modal-xl modal-dialog-centered'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <span class='sr-modal-icon'><i class='fa fa-list-check' aria-hidden='true'></i></span>
                    <h5 class='modal-title' id='{$title_id}'>{$escaper->escapeHtml($title)}</h5>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Close'])}'></button>
                </div>

                <div class='sr-picker-search'>
                    <i class='fa fa-magnifying-glass sr-picker-search-icon' aria-hidden='true'></i>
                    <input type='text' id='{$search_id}' class='sr-picker-search-input' autocomplete='off'
                           placeholder='{$escaper->escapeHtmlAttr($lang['Search'])}'
                           aria-label='{$escaper->escapeHtmlAttr($lang['Search'])}'>
                    <span class='sr-picker-scope' id='{$scope_id}'></span>
                </div>

                <div class='sr-picker-panes'>
                    <div class='sr-picker-pane sr-picker-pane--list'>
                        <div class='sr-picker-pane-head'>
                            <span>{$escaper->escapeHtml($title)}</span>
                            <span class='sr-picker-pane-count' id='{$count_id}'></span>
                        </div>
                        <div class='sr-picker-scroll' id='{$list_id}' role='listbox' aria-multiselectable='true'
                             aria-label='{$escaper->escapeHtmlAttr($title)}'></div>
                    </div>

                    <div class='sr-picker-pane sr-picker-pane--selected'>
                        <div class='sr-picker-pane-head'>
                            <span>{$escaper->escapeHtml($lang['Selected'])}</span>
                            <span class='sr-picker-pane-count' id='{$selected_count_id}'></span>
                        </div>
                        <div class='sr-picker-scroll sr-picker-selected' id='{$selected_id}'></div>
                    </div>
                </div>

                <div class='modal-footer sr-picker-foot'>
                    <span class='sr-picker-hint'>{$escaper->escapeHtml($lang['PickerKeyboardHint'])}</span>
                    <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                    <button type='button' class='btn btn-submit' id='{$commit_id}'>{$escaper->escapeHtml($title)}</button>
                </div>
            </div>
        </div>
    </div>";
}

/**
 * Renders the column selection widget, including the modal window, the button that opens the modal on click
 * and the javascripts required for saving the selections.
 *
 * The emitted JS variable is namespaced per-view (`custom_display_settings_{$view}`) so that a single page
 * can render this widget for multiple views without one view's selection clobbering another's. The sibling
 * renderer `display_custom_document_control_columns()` still emits an un-namespaced variable -- that's
 * intentional, because its only caller (reports/documents_to_controls.php) only ever renders one of those
 * widgets per page so there is no name conflict to resolve. (The other sibling, `display_custom_risk_columns()`,
 * was retired in Task 22 along with the three legacy risk-queue pages that were its only callers.) If you
 * ever add a second widget call to the same page, namespace those too.
 */
function render_column_selection_widget($view) {

    global $field_settings_display_groups, $escaper, $lang;
    
    // The function returns the whole settings including the 'display_settings' field that contains the list of names of selected columns
    $settings = display_settings_get_saved_selection($view);
    
    // If there're no saved settings for this view yet
    if (empty($settings)) {

        // then we load the list of default selected fields
        $settings = field_settings_get_display_defaults($view);

    } else {

        // For this we only need the list of names in the 'display_settings' field
        $settings = $settings['display_settings'];

    }
    
    $groups = [];
    foreach (field_settings_get_localization($view) as $group_name => $group) {

        $groups[$group_name] = [
            'header' => empty($field_settings_display_groups[$group_name]['header_key']) ? false : $escaper->escapeHtml($lang[$field_settings_display_groups[$group_name]['header_key']]),
            'fields' =>  $group
        ];

    }
    
    echo "
        <script>

            // This is the list of selected columns for the view
            var custom_display_settings_{$view} = " . json_encode($settings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ";

            $(function() {
                $('form#custom_display_settings-{$view}').submit(function() {
                    event.preventDefault();
                    var form = new FormData($(this)[0]);
                    $.blockUI({message:\"<i class=\'fa fa-spinner fa-spin\' style=\'font-size:24px\'></i>\"});
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/api/v2/ui/column_settings',
                        data: form,
                        async: true,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function(data){
                            $('#setting_modal-{$view}').modal('hide');
                            if(data.status_message){
                                showAlertsFromArray(data.status_message);
                            }
                            document.location.reload(true);
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        },
                        complete: function() {
                            $.unblockUI();
                        }
                    });
                });
            });
        </script>

        <a class='sr-columns-btn float-end' data-sr-role='dt-settings' data-sr-target='{$view}_datatable' data-bs-toggle='modal' data-bs-target='#setting_modal-{$view}'><i class='fa fa-table-columns' aria-hidden='true'></i><span>{$escaper->escapeHtml($lang['Columns'])}</span></a>
        <div id='setting_modal-{$view}' class='modal fade sr-modal' tabindex='-1' role='dialog' aria-labelledby='setting_modal-{$view}' aria-hidden='true'>
            <div class='modal-dialog modal-dialog-scrollable modal-dialog-centered'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <span class='sr-modal-icon'><i class='fa fa-table-columns'></i></span>
                        <h4 class='modal-title'>{$escaper->escapeHtml($lang['ColumnSelections'])}</h4>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='{$escaper->escapeHtmlAttr($lang['Cancel'])}'></button>
                    </div>
                    <div class='modal-body'>
                        <form id='custom_display_settings-{$view}' name='custom_display_settings-{$view}' method='post' class='sr-qcard-form'>
                            <input type='hidden' name='display_settings_view' value='{$view}'>
    ";

    foreach ($groups as $group_name => $group) {

        echo "
                            <section class='sr-qcard'>
        ";

        // If the group has a header setup, then render it
        if ($group['header']) {

            echo "
                                <div class='sr-qcard-head'>
                                    <h3>{$group['header']}</h3>
                                </div>
            ";

        }

        echo "
                                <div class='sr-qcard-body'>
                                    <div class='sr-qgrid'>
        ";

        // @phan-suppress-next-line PhanTypeMismatchForeach
        foreach ($group['fields'] as $field_name => $text) {

            echo "
                                        <div class='form-check'>
                                            <input class='form-check-input' type='checkbox' name='{$field_name}' id='checkbox_{$field_name}-{$view}-{$group_name}' " . (in_array($field_name, $settings) ? "checked" : "") . "/>
                                            <label class='form-check-label' for='checkbox_{$field_name}-{$view}-{$group_name}'>{$text}</label>
                                        </div>
            ";

        }

        echo "
                                    </div>
                                </div>
                            </section>
        ";
    }

    echo "
                        </form>
                    </div>
                    <div class='modal-footer'>
                        <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                        <button type='submit' form='custom_display_settings-{$view}' class='btn btn-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
                    </div>
                </div>
            </div>
        </div> <!-- modal -->
    ";

}



/**
 * @phan-suppress PhanTypeArraySuspiciousNullable
 * @phan-suppress PhanTypeMismatchForeach
 */
function render_field_edit_popup_modal($view) {
    global $field_settings_views, $field_settings_display_groups, $field_settings, $escaper, $lang;

    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $view_type = $field_settings_views[$view]['view_type'];
    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $view_edit_ajax_uri = $field_settings_views[$view]['edit']['edit_ajax_uri'];
    //$id_field_settings = !empty($field_settings_views[$view]['id_field']) ?  $field_settings[$view_type][$field_settings_views[$view]['id_field']] : false;
    $groups = [];
    $has_header = false;
    foreach (field_settings_get_localization($view) as $group_name => $group) {
        $groups[$group_name] = [
            'header' => empty($field_settings_display_groups[$group_name]['header_key']) ? false : $escaper->escapeHtml($lang[$field_settings_display_groups[$group_name]['header_key']]),
            'fields' =>  $group
        ];
        
        $has_header = $has_header || !empty($groups[$group_name]['header']);
    }
    
    echo "
        <script>
            $(function() {
    ";
    if ($has_header) {
        echo "
                // .off() is there to make sure there's no multiple click handlers on it in case multiple of this widget is rendered on the same page
                $('body').off('click', '#edit_popup_modal-{$view} .collapsible--toggle span.collapse-title').on('click', '#edit_popup_modal-{$view} .collapsible--toggle span.collapse-title', function(event) {
                    event.preventDefault();
                    $(this).closest('.collapsible--toggle').next('.collapsible').slideToggle('400');
                    $(this).find('i').toggleClass('fa-caret-right fa-caret-down');
                });
        ";
                    
    }
    
    echo "
                $('form#edit_popup-{$view}').submit(function() {
                    event.preventDefault();

                    // Create a JSON object based on the control mapping row
                    $(this).find(\"table.mapping_control_table input[name='mapped_controls[]']\").each(function() {
                    	let _this = $(this), tr = _this.closest('tr');

                    	_this.val(JSON.stringify({
                    		control_maturity: tr.find(\"select[name='control_maturity[]']\").val(),
                    		control_id: tr.find(\"select[name='control_id[]']\").val()
                    	}));
                    });

                    var form = new FormData($(this)[0]);
                    $.blockUI({message:\"<i class=\'fa fa-spinner fa-spin\' style=\'font-size:24px\'></i>\"});
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '{$view_edit_ajax_uri}',
                        data: form,
                        async: true,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function(data){
                            
                            if(data.status_message){
                                showAlertsFromArray(data.status_message);
                            }

                            $('#edit_popup_modal-{$view}').modal('hide');
                            // document.location.reload(true);
                            datatableInstances['{$view}'].draw();
                            
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        },
                        complete: function() {
                            $.unblockUI();
                        }
                    });
                });
            });
        </script>
        <div id='edit_popup_modal-{$view}' class='modal fade' tabindex='-1' aria-hidden='true'>
            <div class='modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h4 class='modal-title'>
    ";
    if ($view == 'asset_verified') {
        echo "
                            {$escaper->escapeHtml($lang['EditAsset'])}
        ";
    } else {
        echo "
                            {$escaper->escapeHtml($lang['Edit'])}
        ";
    }
    echo "
                        </h4>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                    </div>
                    <div class='modal-body edit-popup-container'>
                        <form id='edit_popup-{$view}' name='edit_popup-{$view}' method='post'>
                            <input type='hidden' name='edit_view' value='{$view}'>";

    // If there's an id field setup add a hidden field for it
    if (!empty($field_settings_views[$view]['id_field'])) {
        echo "
                            <input type='hidden' name='{$field_settings_views[$view]['id_field']}' class='edit_input'/>
        ";
    }

    if ($customization = customization_extra()) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $active_fields = get_active_fields($view_type);
        $mapped_custom_field_settings = [];
        foreach ($active_fields as $active_field) {

            // Skip this step for basic fields
            if ($active_field['is_basic']) {
                continue;
            }

            $field_name = "custom_field_{$active_field['id']}";

            $type = null;
            switch($active_field['type']) {
                case "shorttext":
                case "hyperlink":
                    $type = 'short_text';
                    break;
                case "longtext":
                    $type = 'long_text';
                    break;
                case "date":
                    $type = 'date';
                    break;
                case "dropdown":
                    $type = "select[{$field_name}]";
                    break;
                case "multidropdown":
                    $type = "multiselect[{$field_name}]";
                    break;
                case "user_multidropdown":
                    $type = "multiselect[user]";
                    break;
            }

            $mapped_custom_field_settings[$field_name] = [
                'type' => $type,
                'required' => $active_field['required'],
                'alphabetical_order' => $active_field['alphabetical_order'],
                'editable' => true,
            ];
        }
    }
    
    foreach ($groups as $group_name => $group) {
        // If the group has a header setup, then render it
        if ($group['header']) {
            echo "
                            <h4 class='collapsible--toggle clearfix'>
                                <span class='collapse-title'><i class='fa fa-caret-down'></i>{$group['header']}</span>
                            </h4>
                            <div class='collapsible'>
            ";
        }
        echo "
                            <div class='row'>
                                <div class='col-12'>
        ";
        
        foreach ($group['fields'] as $field_name => $text) {
            // If it's not in the field settings then it's a custom field
            $field_setting = $field_settings[$view_type][$field_name] ?? $mapped_custom_field_settings[$field_name];
            $required = $field_setting['required'];
            // Currently not displaying uneditable fields, we could display but make them disabled
            if (!$field_setting['editable']) {
                continue;
            }


            $required_text = $required ? "<span class='required'>*</span>" : '';
            $required_attribute = $required ? " required " : '';

            [$field_type, $field_sub_type] = array_pad(preg_split('/(\[|\])/', $field_setting['type'], 0, PREG_SPLIT_NO_EMPTY), 2, false);
            
            $custom_html_structure = ['long_text', 'mapped_controls'];
            
            if (!in_array($field_type, $custom_html_structure)) {
                echo "
                                    <div class='form-group row'>
                                        <label class='col-3' for='edit_{$field_name}-{$view}-{$group_name}'>{$text}{$required_text}</label>
                                        <div class='col-9'>
                ";
            }

            switch($field_type) {
                case 'short_text':
                    echo "
                                            <input type='text' name='{$field_name}' id='edit_{$field_name}-{$view}-{$group_name}' autocomplete='off' class='form-control edit_input'{$required_attribute}/>";
                    break;
                case 'long_text':
                    echo "
                                    <div class='form-group row'>
                                        <label class='col-12' for='edit_{$field_name}-{$view}-{$group_name}'>{$text}{$required_text}</label>
                                        <div class='col-12'>
                                            <textarea name='{$field_name}' id='edit_{$field_name}-{$view}-{$group_name}' style='width: 100%;' class='form-control edit_input'{$required_attribute}></textarea>";
                    break;
                case 'select':
                    create_dropdown($field_sub_type, null, $field_name, !$field_setting['required'], false, false, " class='form-select edit_input' {$required_attribute}", '--', '', true, $field_setting['alphabetical_order'] ?? 0);
                    break;
                case 'multiselect':
                    create_multiple_dropdown($field_sub_type, null, $field_name, null, false, "--", "", true, " {$required_attribute}", $field_setting['alphabetical_order'] ?? 0, additionalClasses: 'edit_input');
                    echo "
                                            <script>
                                                $(function() {
                                                    $('#edit_popup-{$view} #{$field_name}.multiselect').multiselect({buttonWidth: '100%', enableFiltering: true, enableCaseInsensitiveFiltering: true, maxHeight: 250});
                                                });
                                            </script>
                    ";
                    break;
                case 'datetime':
                case 'date':
                    echo "
                                            <input type='text' name='{$field_name}' id='edit_{$field_name}-{$view}-{$group_name}' style='cursor: default;' class='form-control {$field_type}picker edit_input' autocomplete='off'{$required_attribute}/>";
                    break;
                case 'tags':
                    $tag_input_id = "edit_{$field_name}_{$view}_{$group_name}";
                    echo "
                                            <select class='edit_input' readonly id='{$tag_input_id}' name='{$field_name}[]' multiple placeholder='Select/Add tag'{$required_attribute}></select>
                                            <script>
                                                $(function() {
                                                    var tags_{$tag_input_id}_selectize = $('#{$tag_input_id}').selectize({
                                                        plugins: ['remove_button', 'restore_on_backspace'],
                                                        delimiter: '|',
                                                        create: true,
                                                        valueField: 'label',
                                                        labelField: 'label',
                                                        searchField: 'label',
                                                        sortField: [{ field: 'label', direction: 'asc' }],
                                                        onChange: function() { $('#{$tag_input_id}').data('changed', true);},
                                                    });
                                                    // One tag-options request per tag type per page, shared by
                                                    // every tags field on it (a page can render both the create
                                                    // and the edit modal, e.g. Manage assets).
                                                    var srTagReqs = window.srTagOptionsRequests = window.srTagOptionsRequests || {};
                                                    if (!srTagReqs['{$view_type}']) {
                                                        srTagReqs['{$view_type}'] = $.ajax({
                                                            url: BASE_URL + '/api/v2/management/tag_options_of_type?type={$view_type}',
                                                            type: 'GET',
                                                            dataType: 'json',
                                                            error: function(xhr,status,error){
                                                                if(!retryCSRF(xhr, this)){
                                                                    if(xhr.responseJSON && xhr.responseJSON.status_message){
                                                                        showAlertsFromArray(xhr.responseJSON.status_message);
                                                                    }
                                                                }
                                                            }
                                                        });
                                                    }
                                                    srTagReqs['{$view_type}'].done(function(res) {
                                                        tags_{$tag_input_id}_selectize[0].selectize.addOption(res.data);
                                                        tags_{$tag_input_id}_selectize[0].selectize.refreshOptions(true);
                                                    });
                                                });
                                            </script>";
                    break;
                case 'mapped_controls':
                    echo "
                                    <div class='form-group row'>
                                        <div class='col-12'>
                                            <div class='row p-2'>
                                                <div class='bg-light border'>
                                                    <div class='row'>
                                                        <label class='col-10 col-form-label' for='edit_{$field_name}-{$view}-{$group_name}'>{$text}{$required_text}</label>
                                                        <div class='col-2 text-end col-form-label'>
                                                            <button type='button' name='add_control' class='btn btn-primary btn-sm add-control'>{$escaper->escapeHtml($lang['AddControl'])}</button>
                                                        </div>
                                                    </div>
                                                    <div class='row'>
                                                        <div class='col-12'>
                                                            <table width='100%' class='table table-bordered mapping_control_table' name='{$field_name}' style='table-layout: fixed;'>
                                                                <thead>
                                                                    <tr>
                                                                        <th width='23%'>{$escaper->escapeHtml($lang['CurrentMaturity'])}</th>
                                                                        <th>{$escaper->escapeHtml($lang['Control'])}</th>
                                                                        <th width='12%'>{$escaper->escapeHtml($lang['Actions'])}</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

";
                    break;
            }
            echo "
                                        </div>
                                    </div>
            "; 
        }

        echo "
                                </div>
                            </div>";
            // Only have to add these if the section had a header
        if ($group['header']) {
            echo "
                            </div>
            ";
        }
    }

    echo "
                        </form>
                    </div>
                    <div class='modal-footer'>
                        <button class='btn btn-secondary' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
                        <button type='submit' form='edit_popup-{$view}' class='btn btn-submit'>{$escaper->escapeHtml($lang['Update'])}</button>
                    </div>
                </div>
            </div>
        </div>
    ";
}


/**
 * @phan-suppress PhanTypeArraySuspiciousNullable
 * @phan-suppress PhanTypeMismatchForeach
 */
function render_create_modal($view) {

    global $field_settings_views, $field_settings_display_groups, $field_settings, $escaper, $lang;

    $view_type = $field_settings_views[$view]['view_type'];
    $view_create_ajax_uri = $field_settings_views[$view]['create']['create_ajax_uri'];
    //$id_field_settings = !empty($field_settings_views[$view]['id_field']) ?  $field_settings[$view_type][$field_settings_views[$view]['id_field']] : false;

    // Resolve which admin-defined template group(s) this create form should
    // offer -- mirrors display_add_risk()'s resolution exactly (Organizational
    // Hierarchy assigns groups by the current user's business unit; otherwise
    // every group for the fgroup is offered). Zero or one resolved group (the
    // only possibility without Organizational Hierarchy, and the common case
    // even with it) renders exactly one un-tabbed form, same as before this
    // change -- see docs/superpowers/plans/2026-09-05-template-group-business-unit-redesign.md
    // Track B, Task 25.
    $template_groups = [];
    if (customization_extra()) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        // The same candidate set resolve_template_group_id() validates a
        // submitted id against -- one helper, so the tabs offered here and
        // the ids accepted on create can never drift apart.
        $template_groups = get_template_groups_for_user($view_type);
    }
    // Always iterate at least one pane. A single resolved group (whether
    // that's the Default group, or -- with Organizational Hierarchy -- the
    // one specific group this user's business unit is assigned to) still
    // renders as one un-tabbed form, but its real id is carried through so
    // the create endpoint stores the correct group even without a visible
    // tab picker. Only when customization never resolves any group (the
    // extra is disabled) does this fall back to a null-id pane, which is a
    // no-op scoping-wise (identical results to the old unscoped/union query).
    $render_panes = !empty($template_groups) ? $template_groups : [['id' => null, 'name' => null]];
    $multi_group = count($render_panes) > 1;

    $panes = [];
    $has_header = false;
    foreach ($render_panes as $template_group) {
        $tgid = $template_group['id'];
        $groups = [];
        foreach (field_settings_get_localization($view, true, true, true, $tgid) as $group_name => $group) {
            $groups[$group_name] = [
                'header' => empty($field_settings_display_groups[$group_name]['header_key']) ? false : $escaper->escapeHtml($lang[$field_settings_display_groups[$group_name]['header_key']]),
                'fields' =>  $group
            ];

            $has_header = $has_header || !empty($groups[$group_name]['header']);
        }
        $panes[] = ['id' => $tgid, 'name' => $template_group['name'], 'groups' => $groups];
    }

    echo "
        <script>
            $(function() {
                const view = '{$escaper->escapeHtml($view)}';
    ";

    if ($has_header) {

        echo "
                // .off() is there to make sure there's no multiple click handlers on it in case multiple of this widget is rendered on the same page
                $('body').off('click', '#create_popup_modal-' + CSS.escape(view) + ' .collapsible--toggle span.collapse-title').on('click', '#create_popup_modal-' + CSS.escape(view) + ' .collapsible--toggle span.collapse-title', function(event) {
                    event.preventDefault();
                    $(this).closest('.collapsible--toggle').next('.collapsible').slideToggle('400');
                    $(this).find('i').toggleClass('fa-caret-right fa-caret-down');
                });
        ";

    }

    echo "
                // Reset form fields when the modal is opened. There is one
                // <form id=\"create_popup-{view}\"> per template-group tab
                // when more than one group is offered (mirrors
                // display_add_risk()'s established one-<form>-per-pane
                // pattern, which also duplicates ids across panes) -- the
                // selectors below already match every such form, and
                // resetForm() iterates every matched element.
                $('#create_popup_modal-' + CSS.escape(view)).on('show.bs.modal', function() {
                    // Re-assert the first tab/pane as active every time the
                    // modal opens. Something elsewhere on the page (a
                    // sitewide Bootstrap Tab/ARIA-enhancement pass over every
                    // [data-bs-toggle=tab] on the page, which also stamps
                    // role=tabpanel onto every .tab-pane it finds) strips the
                    // server-rendered active/show state from these panes
                    // before the user ever interacts with them, leaving the
                    // modal looking blank until a tab is clicked. Re-applying
                    // it here is a self-contained, defensive fix that doesn't
                    // depend on tracking down that other script.
                    var modalTabLinks = $(this).find('.nav-tabs .nav-link');
                    if (modalTabLinks.length) {
                        modalTabLinks.removeClass('active');
                        modalTabLinks.first().addClass('active');
                        var modalTabPanes = $(this).find('.tab-pane');
                        modalTabPanes.removeClass('show active');
                        modalTabPanes.first().addClass('show active');
                    }

                    // Reset the form to clear any previous data
                    resetForm($('form#create_popup-' + CSS.escape(view)), true, true);

                    // Clear any WYSIWYG editor content
                    if (typeof setEditorContent === 'function') {
                        $('form#create_popup-' + CSS.escape(view) + ' textarea.create_input').each(function() {
                            setEditorContent($(this).attr('id'), '');
                        });
                    }

                    // Remove dynamically added control mapping rows
                    $('form#create_popup-' + CSS.escape(view) + ' table.mapping_control_table tbody').html('');
                });

                // Bound once per matched form (jQuery attaches .submit() to
                // every element sharing the id), and \$(this) inside always
                // refers to whichever pane's form actually fired -- so this
                // already works correctly whether there's one form or several.
                $('form#create_popup-' + CSS.escape(view)).submit(function(event) {
                    event.preventDefault();

                    // Create a JSON object based on the control mapping row
                    $(this).find(\"table.mapping_control_table input[name='mapped_controls[]']\").each(function() {
                    	let _this = $(this), tr = _this.closest('tr');

                    	_this.val(JSON.stringify({
                    		control_maturity: tr.find(\"select[name='control_maturity[]']\").val(),
                    		control_id: tr.find(\"select[name='control_id[]']\").val()
                    	}));
                    });

                    var form = new FormData(this);
                    $.blockUI({message:\"<i class=\'fa fa-spinner fa-spin\' style=\'font-size:24px\'></i>\"});
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '{$view_create_ajax_uri}',
                        data: form,
                        async: true,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function(data){

                            if(data.status_message){
                                showAlertsFromArray(data.status_message);
                            }

                            $('#create_popup_modal-{$view}').modal('hide');
                            // document.location.reload(true);
                            datatableInstances['{$view}'].draw();
                        },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        },
                        complete: function() {
                            $.unblockUI();
                        }
                    });
                });
    ";

    if ($multi_group) {
        echo "
                // With multiple template-group tabs, the Save button lives
                // once in the shared modal footer (rather than once per pane)
                // so route its click to whichever pane's <form> is the
                // currently visible (active) tab.
                $('#create_popup_modal-' + CSS.escape(view) + ' .create-popup-save-btn').on('click', function(event) {
                    event.preventDefault();
                    $(this).closest('.modal-content').find('form.create-popup-form:visible').trigger('submit');
                });
        ";
    }

    echo "
            });
        </script>
        <div id='create_popup_modal-{$view}' class='modal fade' tabindex='-1' aria-hidden='true'>
            <div class='modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h4 class='modal-title'>
    ";
    if ($view == 'asset_verified') {
        echo "
                            {$escaper->escapeHtml($lang['NewAsset'])}
        ";
    } else {
        echo "
                            {$escaper->escapeHtml($lang['Create'])}
        ";
    }
    echo "
                        </h4>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                    </div>
                    <div class='modal-body'>
    ";

    if ($multi_group) {
        echo "
                        <div class='mt-2'>
                            <nav class='nav nav-tabs'>
        ";
        foreach ($panes as $index => $pane) {
            $tab_active = $index == 0 ? "active" : "";
            echo "
                                <a class='nav-link {$tab_active}' data-bs-target='#{$escaper->escapeHtml($view)}_template_group_{$pane['id']}' data-bs-toggle='tab'>" . $escaper->escapeHtml($pane['name']) . "</a>
            ";
        }
        echo "
                            </nav>
                        </div>
                        <div class='tab-content'>
        ";
    }

    foreach ($panes as $index => $pane) {

        $tgid = $pane['id'];
        $groups = $pane['groups'];

        if ($multi_group) {
            $pane_active = $index == 0 ? "show active" : "";
            echo "
                        <div class='tab-pane fade {$pane_active}' id='{$escaper->escapeHtml($view)}_template_group_{$tgid}'>
            ";
        }

        echo "
                        <form id='create_popup-{$view}' name='create_popup-{$view}' method='post' class='create-popup-form'>
                            <input type='hidden' name='create_view' value='{$view}'>
    ";

        // If there's an id field setup add a hidden field for it
        if (!empty($field_settings_views[$view]['id_field'])) {

            echo "
                            <input type='hidden' name='{$field_settings_views[$view]['id_field']}' class='create_input'/>
            ";

        }

        // Carry the resolved template group forward so the create endpoint
        // stores which admin-defined field layout this record was created
        // under, instead of silently defaulting. Omitted when customization
        // never resolved a real group (matches pre-existing behavior exactly
        // -- the backend resolves the real Default group when this is absent).
        if ($tgid !== null) {
            echo "
                            <input type='hidden' name='template_group_id' value='" . (int)$tgid . "'>
            ";
        }

        echo "
                            <div class='well create-popup-container'>
    ";

        if ($customization = customization_extra()) {

            require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

            $active_fields = get_active_fields($view_type, $tgid);
            $mapped_custom_field_settings = [];

            foreach ($active_fields as $active_field) {

                // Skip this step for basic fields
                if ($active_field['is_basic']) {
                    continue;
                }

                $field_name = "custom_field_{$active_field['id']}";

                $type = null;
                switch($active_field['type']) {
                    case "shorttext":
                    case "hyperlink":
                        $type = 'short_text';
                        break;
                    case "longtext":
                        $type = 'long_text';
                        break;
                    case "date":
                        $type = 'date';
                        break;
                    case "dropdown":
                        $type = "select[{$field_name}]";
                        break;
                    case "multidropdown":
                        $type = "multiselect[{$field_name}]";
                        break;
                    case "user_multidropdown":
                        $type = "multiselect[user]";
                        break;
                }

                $mapped_custom_field_settings[$field_name] = [
                    'type' => $type,
                    'required' => $active_field['required'],
                    'alphabetical_order' => $active_field['alphabetical_order'],
                ];
            }
        }

        foreach ($groups as $group_name => $group) {

        // If the group has a header setup, then render it
        if ($group['header']) {
            echo "
                            <div class='row'>
                                <h4 class='collapsible--toggle clearfix'>
                                    <span class='collapse-title'><i class='fa fa-caret-down'></i>{$group['header']}</span>
                                </h4>
                                <div class='collapsible'>
            ";
        }

        echo "
                            <div class='row'>
                                <div class='col-12'>
        ";

        foreach ($group['fields'] as $field_name => $text) {

            // If it's not in the field settings then it's a custom field
            $field_setting = $field_settings[$view_type][$field_name] ?? $mapped_custom_field_settings[$field_name];
            $required = $field_setting['required'];
            
            $required_text = $required ? "<span class='required'>*</span>" : '';
            $required_attribute = $required ? " required " : '';

            [$field_type, $field_sub_type] = array_pad(preg_split('/(\[|\])/', $field_setting['type'], 0, PREG_SPLIT_NO_EMPTY), 2, false);

            $custom_html_structure = ['long_text', 'mapped_controls'];

            if (!in_array($field_type, $custom_html_structure)) {
                echo "
                                    <div class='form-group row'>
                                        <label class='col-3' for='create_{$field_name}-{$view}-{$group_name}'>{$text}{$required_text}</label>
                                        <div class='col-9'>
                ";
            }

            switch ($field_type) {
                case 'short_text':
                    echo "
                                            <input type='text' name='{$field_name}' id='create_{$field_name}-{$view}-{$group_name}' autocomplete='off' class='form-control create_input'{$required_attribute}/>
                    ";
                    break;
                case 'long_text':
                    echo "
                                    <div class='form-group row'>
                                        <label class='col-12' for='create_{$field_name}-{$view}-{$group_name}'>{$text}{$required_text}</label>
                                        <div class='col-12'>
                                            <textarea name='{$field_name}' id='create_{$field_name}-{$view}-{$group_name}' style='width: 100%;' class='form-control create_input'{$required_attribute}></textarea>
                    ";
                    break;
                case 'select':
                    create_dropdown($field_sub_type, null, $field_name, !$field_setting['required'], false, false, " class='form-select create_input' {$required_attribute}", '--', '', true, $field_setting['alphabetical_order'] ?? 0);
                    break;
                case 'multiselect':
                    create_multiple_dropdown($field_sub_type, null, $field_name, null, false, "--", "", true, " class='form-select multiselect create_input' {$required_attribute}", $field_setting['alphabetical_order'] ?? 0);
                    echo "
                                            <script>
                                                $(function() {
                                                    $('#create_popup-{$view} #{$field_name}.multiselect').multiselect({buttonWidth: '100%', enableFiltering: true, enableCaseInsensitiveFiltering: true, maxHeight: 250});
                                                });
                                            </script>
                    ";
                    break;
                case 'datetime':
                case 'date':
                    echo "
                                            <input type='text' name='{$field_name}' id='create_{$field_name}-{$view}-{$group_name}' style='cursor: default;' class='form-control {$field_type}picker create_input' autocomplete='off'{$required_attribute}/>";
                    break;
                case 'tags':
                    $tag_input_id = "create_{$field_name}_{$view}_{$group_name}";
                    echo "
                                            <select class='create_input' readonly id='{$tag_input_id}' name='{$field_name}[]' multiple placeholder='Select/Add tag'{$required_attribute}></select>
                                            <script>
                                                $(function() {
                                                    var tags_{$tag_input_id}_selectize = $('#{$tag_input_id}').selectize({
                                                        plugins: ['remove_button', 'restore_on_backspace'],
                                                        delimiter: '|',
                                                        create: true,
                                                        valueField: 'label',
                                                        labelField: 'label',
                                                        searchField: 'label',
                                                        sortField: [{ field: 'label', direction: 'asc' }],
                                                        onChange: function() { $('#{$tag_input_id}').data('changed', true);},
                                                    });
                                                    // One tag-options request per tag type per page, shared by
                                                    // every tags field on it (a page can render both the create
                                                    // and the edit modal, e.g. Manage assets).
                                                    var srTagReqs = window.srTagOptionsRequests = window.srTagOptionsRequests || {};
                                                    if (!srTagReqs['{$view_type}']) {
                                                        srTagReqs['{$view_type}'] = $.ajax({
                                                            url: BASE_URL + '/api/v2/management/tag_options_of_type?type={$view_type}',
                                                            type: 'GET',
                                                            dataType: 'json',
                                                            error: function(xhr,status,error){
                                                                if(!retryCSRF(xhr, this)){
                                                                    if(xhr.responseJSON && xhr.responseJSON.status_message){
                                                                        showAlertsFromArray(xhr.responseJSON.status_message);
                                                                    }
                                                                }
                                                            }
                                                        });
                                                    }
                                                    srTagReqs['{$view_type}'].done(function(res) {
                                                        tags_{$tag_input_id}_selectize[0].selectize.addOption(res.data);
                                                        tags_{$tag_input_id}_selectize[0].selectize.refreshOptions(true);
                                                    });
                                                });
                                            </script>
                    ";
                    break;
                case 'mapped_controls':
                    echo "
                                    <div class='form-group row'>
                                        <div class='col-12'>
                                            <div class='row p-2'>
                                                <div class='bg-light border'>
                                                    <div class='row'>
                                                        <label class='col-10 col-form-label' for='create_{$field_name}-{$view}-{$group_name}'>{$text}{$required_text}</label>
                                                        <div class='col-2 text-end col-form-label'>
                                                            <button type='button' name='add_control' class='btn btn-primary btn-sm add-control'>{$escaper->escapeHtml($lang['AddControl'])}</button>
                                                        </div>
                                                    </div>
                                                    <div class='row'>
                                                        <div class='col-12'>
                                                            <table width='100%' class='table table-bordered mapping_control_table' name='{$field_name}' style='table-layout: fixed;'>
                                                                <thead>
                                                                    <tr>
                                                                        <th width='23%'>{$escaper->escapeHtml($lang['CurrentMaturity'])}</th>
                                                                        <th>{$escaper->escapeHtml($lang['Control'])}</th>
                                                                        <th width='12%'>{$escaper->escapeHtml($lang['Actions'])}</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                    ";
                    break;
            }
            
            
            echo "
                                        </div>
                                    </div>
            ";
        }
        
        echo "
                                </div>
                            </div>
        ";
        // Only have to add these if the section had a header
        if ($group['header']) {
            echo "
                                </div>
                            </div>
            ";
        }
        }

        echo "
                            </div>
                        </form>
        ";

        if ($multi_group) {
            echo "
                        </div>
            ";
        }
    }

    if ($multi_group) {
        echo "
                        </div>
        ";
    }

    echo "
                    </div>
                    <div class='modal-footer'>
                        <button class='btn btn-secondary' data-bs-dismiss='modal'>{$escaper->escapeHtml($lang['Cancel'])}</button>
    ";
    if ($multi_group) {
        // One shared Save button routes to whichever pane's form is active --
        // see the .create-popup-save-btn click handler above.
        echo "
                        <button type='button' class='btn btn-submit create-popup-save-btn'>{$escaper->escapeHtml($lang['Save'])}</button>
        ";
    } else {
        echo "
                        <button type='submit' form='create_popup-{$view}' class='btn btn-submit'>{$escaper->escapeHtml($lang['Save'])}</button>
        ";
    }
    echo "
                    </div>
                </div>
            </div>
        </div>
    ";
}


/**
 * Renders the datatable for the view based on the settings in '$field_settings_views' global variable
 * 
 * -Wires in the API endpoint setup in the settings as the datasource
 * -Adds the filter bar and logic for the filtering
 * -Adds editing functionality(inline or popup)
 *
 * @param string $view
 *
 * @phan-suppress PhanTypeArraySuspiciousNullable, PhanTypeArraySuspiciousNull, PhanTypeMismatchForeach
 */
function render_view_table($view) {
    global $lang, $escaper, $field_settings, $field_settings_views;

    if ($customization = customization_extra()) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
    }

    $view_type = $field_settings_views[$view]['view_type'];
    $datatable_data_type_associative = $field_settings_views[$view]['datatable_data_type'] === 'associative';
    $datatable_filter_submit_delay = $field_settings_views[$view]['datatable_filter_submit_delay'] ?? 400;
    $view_editable = !empty($field_settings_views[$view]['edit']);
    $view_edit_type = $view_editable ? $field_settings_views[$view]['edit']['type'] : false;
    $view_edit_type_inline = $view_edit_type && $view_edit_type === 'inline';
    $view_edit_type_popup = $view_edit_type && $view_edit_type === 'popup';
    $view_edit_ajax_uri = $view_editable ? $field_settings_views[$view]['edit']['edit_ajax_uri'] : false;
    
    $settings = display_settings_get_display_settings_for_view($view);
    $localizations = field_settings_get_localization($view, false);

    $actions_column_info = !empty($field_settings_views[$view]['actions_column']) ? $field_settings_views[$view]['actions_column'] : false;
    $actions_column_first = $actions_column_info && $actions_column_info['position'] === 'first';

    // Bulk-select checkbox column: an existing field (typically 'id') always
    // prepended as column 0, regardless of the viewer's saved Columns
    // customization -- unlike a normal display field, a checkbox column
    // isn't something a user should be able to toggle off (that would break
    // bulk-select entirely), and default_enabled_columns doesn't apply once
    // a per-user selection is saved. Mirrors actions_column's own
    // unconditional-inclusion pattern; the page's own script overrides the
    // field's cell rendering into a checkbox via a columnDefs targets:0
    // override (this function has no per-column render hook of its own).
    $selection_column_field = !empty($field_settings_views[$view]['selection_column']) ? $field_settings_views[$view]['selection_column'] : false;

    $order_index = false;
    $order_dir = "asc";

    $header_row = "";
    $filter_header_row = "";

    if ($actions_column_info) {
        if ($actions_column_first) {
            $settings = array_merge([$actions_column_info['field_name']], $settings);
        } else {
            $settings []= $actions_column_info['field_name'];
        }

        $localizations[$actions_column_info['field_name']] = $escaper->escapeHtml($field_settings[$view_type][$actions_column_info['field_name']]['localization_key']);
    }

    if ($selection_column_field) {
        $settings = array_merge([$selection_column_field], $settings);
        // Header cell text is swapped for a select-all checkbox client-side
        // (this function only renders the label as text).
        $localizations[$selection_column_field] = '';
    }

    // A view can prefer a specific multi-column default sort over "first
    // orderable field, ascending" (Manage Audits sorts by urgency -- oldest
    // Next Test Date, then oldest Last Test Date as the tiebreaker -- rather
    // than alphabetically by Test Name, which has no bearing on which audit
    // needs attention first). Resolved against $settings -- the ACTUAL
    // per-user column list, already reflecting the actions/selection-column
    // merges above -- rather than a hardcoded index, since a customized
    // column selection changes which index each field lands at. A
    // configured field the viewer has hidden via the Columns picker is
    // simply skipped (array_search returns false) rather than breaking the
    // sort or pointing it at the wrong column.
    $default_order_pairs = [];
    if (!empty($field_settings_views[$view]['default_order'])) {
        foreach ($field_settings_views[$view]['default_order'] as $default_order_field) {
            $default_order_index = array_search($default_order_field[0], $settings, true);
            if ($default_order_index !== false) {
                $default_order_pairs []= "[{$default_order_index}, '{$default_order_field[1]}']";
            }
        }
    }

    // Iterate through the list of selected fields
    foreach ($settings as $field_idx => $field_name) {

        // The selection column is never a candidate default sort column,
        // even though the field it reuses (e.g. 'id') is itself orderable --
        // see the searchable/orderable override below for why.
        $is_selection_column = $selection_column_field && $field_name === $selection_column_field;

        if ($order_index === false && !$is_selection_column && !empty($field_settings[$view_type][$field_name]['orderable']) && $field_settings[$view_type][$field_name]['orderable']) {
            $order_index = $field_idx;
        }

        // If there's a custom column style defined for the field then use that instead of the default
        if ($is_selection_column) {
            // Narrow, like Define Tests'/Initiate Audits' own checkbox
            // column -- the underlying field's own custom_column_style (if
            // any) is sized for its OTHER, non-checkbox uses.
            $style = "width:34px;min-width:34px;";
        } else if (!empty($field_settings[$view_type][$field_name]['custom_column_style'])) {
            $style = $field_settings[$view_type][$field_name]['custom_column_style'];
        } else {
            $style = "min-width:100px;";
        }

        $header_row .= "<th data-name='{$field_name}' align='left' style='{$style}'>{$localizations[$field_name]}</th>";

        // non render-related logic
        switch($field_name) {
            case 'calculated_risk':
                $order_index = $field_idx;
                $order_dir = "desc";
                break;
        }

        // Only render the search field if in the configuration it's set as searchable or it's a custom field which as of now always searchable
        if ((!empty($field_settings[$view_type][$field_name]['searchable']) && $field_settings[$view_type][$field_name]['searchable']) || str_starts_with($field_name, 'custom_field_')) {

            // render-related logic for views
            $filter_field = "";
            
            $filter_field = get_filter_field_for_views($view, $field_name, $localizations);

            $filter_header_row .= "
                <th data-column-number='{$field_idx}' data-name='{$field_name}' align='left' style='{$style}'>{$filter_field}</th>
            ";
        } else {
            // add an empty header cell if the field isn't searchable
            $filter_header_row .= "<th></th>";
        }
    }

    $datatable_id = "{$view}_datatable";
    echo "
        <table id='{$datatable_id}' width='100%' class='datatable table table-bordered table-striped " . ($view_editable ? " editable-{$view_edit_type}" : '') . "' data-view='{$view}'>
            <thead >
                <tr class='header'>{$header_row}</tr>
                <tr class='header_filter'>{$filter_header_row}</tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    ";
    
    if ($view_edit_type_popup) {
        render_field_edit_popup_modal($view);
    }

    echo "
        <script>
            // Storing the datatable instances in a dictionary so it can be reached by other parts of the code by the name of the view
            // Only initialize if it doesn't exist yet
            if (typeof datatableInstances === 'undefined') {
                datatableInstances = [];
            }

            $(function() {
                // Save the datatable instance into the dictionary
                datatableInstances['{$view}'] = $('#{$datatable_id}').DataTable({
                    scrollX: true,
    " .
    (!empty($default_order_pairs) ? "
                    order: [" . implode(', ', $default_order_pairs) . "],
    " : ($order_index !== false ? "
                    order: [[{$order_index}, '{$order_dir}']],
    " : "
                    ordering: false,
    ")) .
    ((!empty($field_settings_views[$view]['datatable_options']) && $field_settings_views[$view]['datatable_options']) ?
                    $field_settings_views[$view]['datatable_options'] : "") . "
                    ajax: {
                        url: BASE_URL + '{$field_settings_views[$view]['datatable_ajax_uri']}',
                        type: 'post',
                        // Opt-in extra-parameter hook: a no-op for every view
                        // that doesn't define window.getExtraAjaxData_{view}
                        // (all_audits' Test Date range filter is the one
                        // consumer today -- see display_audits(), includes/
                        // compliance.php). Exists because some filters need a
                        // value to reach the server independent of whether
                        // their underlying field is one of the currently
                        // displayed/toggleable columns.
                        data: function(d){
                            if (typeof window.getExtraAjaxData_{$view} === 'function') {
                                $.extend(d, window.getExtraAjaxData_{$view}());
                            }
                        },
                        complete: function(response){ },
                        error: function(xhr,status,error){
                            if(!retryCSRF(xhr, this)){
                                if(xhr.responseJSON && xhr.responseJSON.status_message){
                                    showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                            }
                        },
                    },
                    columns: [
    ";
    
    $actions_column_info = !empty($field_settings_views[$view]['actions_column']) ? $field_settings_views[$view]['actions_column'] : false;

    // If the array isn't associative then if the foreach is constructed this way then the $field_idx will have the index of the array element
    foreach ($settings as $field_idx => $field_name) {
        
        // if it's not defined in the settings it's probably a custom field
        if ($customization && empty($field_settings[$view_type][$field_name]) && preg_match('/custom_field_([\d]+)/', $field_name, $matches) === 1) {
            $custom_field = get_field_by_id($matches[1]);
            $searchable = 'true';
            $orderable = !in_array($custom_field['type'], ['multidropdown', 'user_multidropdown']) ? 'true' : 'false';
            // by default custom fields are editable, but only need this when the edit type is inline
            $editable_cell = $view_edit_type_inline;
            $has_display_field = in_array($custom_field['type'], ['dropdown', 'multidropdown', 'user_multidropdown']);
        } else {
            $searchable = $field_settings[$view_type][$field_name]['searchable'] ? 'true' : 'false';
            $orderable = $field_settings[$view_type][$field_name]['orderable'] ? 'true' : 'false';
            $editable_cell = $view_edit_type_inline && $field_settings[$view_type][$field_name]['editable'];
            $has_display_field = $field_settings[$view_type][$field_name]['has_display_field'];
        }

        // The selection column reuses an existing field (e.g. 'id') purely
        // for its data, not its catalog semantics -- sorting/searching by
        // whatever that field's own settings say (id is orderable/searchable
        // for its OTHER, non-checkbox uses) makes no sense on a checkbox
        // column, so both are forced off here regardless of the underlying
        // field's own flags.
        if ($selection_column_field && $field_name === $selection_column_field) {
            $searchable = 'false';
            $orderable = 'false';
        }

        // Get the renderer if there's any defined for the field
        $renderer = !empty($field_settings[$view_type][$field_name]['renderer']) ? $field_settings[$view_type][$field_name]['renderer'] : false;
        // DataTables auto-detects each column's type (numeric/date/string) from
        // the cell values it sees, and right-aligns anything it classifies as
        // numeric or date -- fine for an actual date/number column, wrong for
        // free-text content that can merely LOOK like one (a tag named "2024",
        // for instance). 'column_type' lets a field opt out of that guesswork.
        $column_type = !empty($field_settings[$view_type][$field_name]['column_type']) ? $field_settings[$view_type][$field_name]['column_type'] : false;
        $display_post_fix = $has_display_field ? '_display' : '';
        
        
        if ($actions_column_info && $actions_column_info['field_name'] == $field_name) {
            $class_name = 'cell-action';
        } elseif($editable_cell) {
            $class_name = 'cell-editable';
        } else {
            $class_name = false;
        }
        
        // If the data coming from the server side as an associative array we need to add the configuration a bit differently.
        // The 'name' attribute lets future code reference a column by name via DataTables' "<name>:name" selector
        // (e.g. table.column('subject:name').search(...)) without having to know its index. No current consumer relies on it;
        // it is emitted unconditionally so callers added later don't need to revisit render_view_table.
        if ($datatable_data_type_associative) {
            echo "
                        {
                            'name': '{$field_name}',
                            'data': '{$field_name}{$display_post_fix}',
                            'searchable': {$searchable},
                            'orderable': {$orderable}" .
                            ($class_name ? ",
                            'className': '{$class_name}'" : "") .
                            ($renderer ? ",
                            'render': {$renderer}" : "") .
                            ($column_type ? ",
                            'type': '{$column_type}'" : "") . ",
                            'defaultContent': ''
                        },
            ";
        } else {
            echo "
                        {
                            'name': '{$field_name}',
                            'target': '{$field_idx}',
                            'searchable': {$searchable},
                            'orderable': {$orderable}" .
                            ($class_name ? ",
                            'className': '{$class_name}'" : "") .
                            ($renderer ? ",
                            'render': {$renderer}" : "") .
                            ($column_type ? ",
                            'type': '{$column_type}'" : "") . ",
                            'defaultContent': ''
                        },
            ";
        }
        
    }
    echo "
                    ],
                });
    ";
    
    // Only need this section when inline edit is enabled for the view
    if ($view_edit_type_inline) {
        echo "
            // Only define the function if it doesn't exist yet
            if (typeof getColumnsToTriggerRedrawWhenChanged !== 'function') {

                var columnsToTriggerRedrawWhenChanged = [];
                // The function is to gather the column names that when their field changed have to trigger a re-draw as the changes could affect the sorting/filtering
                // defining it as a global function 
                window.getColumnsToTriggerRedrawWhenChanged = function(instance) {
                    var settings = instance.settings();
                    var columns = settings.init().columns;
                    var fields = [];

                    // Get the fields the datatable is sorted by
                    for (const order of settings.order()) {
                        fields.push(columns[order[0]].data);
                    }

                    // Get the fields filtered on
                    var len = instance.columns().count();
                    for (i = 0; i < len; i++) {
                        // Add to the list if the search field isn't empty and the field isn't added yet
                        if (instance.column(i).search() && fields.indexOf(columns[i].data) === -1) {
                            fields.push(columns[i].data);    
                        }
                    }

                    return fields;
                }
            }

            // Only define the function if it doesn't exist yet
            if (typeof make_resizable !== 'function') {
                function make_resizable(element, view) {
                    var factor = 7.6;
                    function resize() {
                        element.width((element.val().length + 1) * factor);
                        datatableInstances[view].columns.adjust();
                    }

                    for (const event of ['keyup', 'keypress', 'focus', 'blur', 'change']) {
                        element.on(event, resize);
                    }
                    resize();
                }
            }
        ";
    }
    
    echo "
                // Add paginate options
                datatableInstances['{$view}'].on('draw', function(e, settings) {
                    " . ($view_edit_type_inline ? "columnsToTriggerRedrawWhenChanged = getColumnsToTriggerRedrawWhenChanged(datatableInstances['{$view}']);" : "") . "
                });

                var filter_submit_timer;
                // we should attach this event handler to the only elements in the filter part of the table header not a dropdown menu.
                $('body').on('change input', '#{$datatable_id}_wrapper tr.header_filter input:not(.multiselect-container.dropdown-menu *), #{$datatable_id}_wrapper tr.header_filter select:not(.multiselect-container.dropdown-menu *)', function () {
                    clearTimeout(filter_submit_timer);

                    // Retrieve all selected values for multi-select
                    var _val;
                    if ($(this).is('select[multiple]')) {
                        // Get all selected options
                        _val = $(this).val();
                    } else {
                        // For single inputs or non-multi-selects
                        _val = this.value;
                    }
                    var column_number = $(this).closest('th').attr('data-column-number');
                    if (datatableInstances['{$view}'].column(column_number).search() !== _val) {
                        filter_submit_timer = setTimeout(function() {
                          datatableInstances['{$view}'].column(column_number).search(_val).draw();
                        }, {$datatable_filter_submit_delay});
                    }
                });
    ";

    if ($view_edit_type_inline) {
        echo "
                // When clicking on a cell that's not edited the text should be replaced with the component used to edit it
                $('body').on('click', '#{$datatable_id} td.cell-editable', function() {

                    var _this = $(this);
                    // If the cell is already edited then there's nothing left to do
                    if (_this.hasClass('editing')) {
                        return;
                    }

                    // Mark the cell as being edited
                    _this.addClass('editing');

                    var instance = datatableInstances['{$view}'];

                    $(this).html(instance.cell(this).render('edit'));
                    instance.columns.adjust();
                    _this.find('.edited-field').focus();

                    // If it's a textarea save its original width to be able to detect if it changed
                    var textarea = $('textarea.edited-field', _this);
                    if (textarea !== undefined && textarea.length) {
                        textarea.data('old_width', textarea[0].clientWidth);
                    }

                    // If it's an input field, make it resizable
                    var input = $('input[type=text].edited-field', _this);
                    if (input !== undefined && input.length) {
                        make_resizable(input, '{$view}');
                    }
                });

                // Save the changes when the component loses focus
                $('body').on('blur', '#{$datatable_id} td.cell-editable.editing', function() {
                    var _this = $(this);
                    _this.removeClass('editing');
    
                    var instance = datatableInstances['{$view}'];
                    var rowData = instance.row(this).data();                
                    var columns = instance.settings().init().columns;
                    var colIndex = instance.cell(this).index().column;
                    var editedField = _this.find('.edited-field');
                    var fieldDataChanged = editedField.data('changed') === true;

                    // Only if the data changed
                    if (fieldDataChanged) {
    
                        var id = rowData['id'];    
                        var fieldName = columns[colIndex].data;
                        var fieldValue = editedField.val();

                        // Check if the field's name is in the list of fields that should trigger a redraw when changed
                        var needsRedraw = columnsToTriggerRedrawWhenChanged.indexOf(fieldName) !== -1;
    
                        // Hit the edit API and save the field's new value
                        $.ajax({
                            type: 'POST',
                            url: BASE_URL + '{$view_edit_ajax_uri}',
                            data : {
                                id: id,
                                fieldName: fieldName,
                                fieldValue: fieldValue,
                                view: '{$view}',
                            },
                            context: this,
                            success: function(data){
                                if(data.status_message){
                                    showAlertsFromArray(data.status_message);
                                }
                                // Have to re-populate the cell with the data coming from the server, not trusting data on the client side
                                if (data.data) {
                                    var cell = instance.cell(this);
                                    // Set the data to the cell and let it be rendered too
                                    cell.data(data.data);
                                    // Adjust the columns
                                    instance.columns.adjust();
                                    // Redraw the whole table if a column that's used for sorting or filtering is edited
                                    if (needsRedraw) {
                                        instance.draw();
                                    }
                                }
                            },
                            error: function(xhr,status,error){
                                if(!retryCSRF(xhr, this)) {
                                	showAlertsFromArray(xhr.responseJSON.status_message);
                                }
                                _this.html(instance.cell(this).render('display'));
                            }
                        });
                    } else {
                        _this.html(instance.cell(this).render('display'));
                        instance.columns.adjust();
                    }
                });

                // Detect width resize of textareas in the table when inline editing to adjust the width of the headers
                $('body').on('mouseup', '#{$datatable_id} td.cell-editable textarea.edited-field', function() {
                    // On mouseup(supposedly after dragging the resize widget on the lower right) we check if the current width is matching with the width saved on the textarea
                    if($(this)[0].clientWidth != $(this).data('old_width')){
                        // If it doesn't then adjust the header column widths 
                        datatableInstances['{$view}'].columns.adjust();
                        // and save the current width so this logic only triggers if the width changed again 
                        $(this).data('old_width', $(this)[0].clientWidth); 
                    }
                });
        ";
    }

    echo "
            });
        </script>
    ";
}

/*****************************************
 * FUNCTION: DISPLAY GENERIC MULTISELECT *
 *****************************************/
function display_generic_multiselect($select_name, $select_array = [], $selected_array = [])
{
    global $escaper;

    // Add the select to the text
    $text = "<select class='form-select multiselect' multiple='multiple' id='" . $escaper->escapeHtml($select_name) . "' name='" . $escaper->escapeHtml($select_name) . "[]' >\n";

    // For each group in the array
    foreach ($select_array as $key => $group)
    {
        // Begin the option group
        $text .= "  <optgroup label='" . $escaper->escapeHtml($key) . "'>\n";

        // For each item in the group
        foreach ($group as $value)
        {
            // Check if the value is selected
            $selected = (in_array($value, $selected_array) ? " selected" : "");

            // Display the value as an option
            $text .= "  <option value='"  . $escaper->escapeHtml($value) . "'{$selected}>" . $escaper->escapeHtml($value) . "</option>\n";
        }

        // End the option group
        $text .= "  </optgroup>\n";
    }

    $text .= "</select>";

    // Output the text
    echo $text;
}

/******************************************
 * FUNCTION: DISPLAY GENERIC RADIO SELECT *
 ******************************************/
function display_generic_radio_select($select_name, $select_array = [], $selected_value = null)
{
    global $escaper;

    // Create the default text
    $text = "";

    // For each of the values in the array
    foreach ($select_array as $value)
    {
        // Get the value text and html
        $value_text = $value['text'];
        $value_html = $value['html'];

        // Check if the value is selected
        $selected = ($selected_value == $value_text ? " checked='checked'" : "");

        // Add the value as an option
        // NOTE: The value is not HTML encoded as we don't want to strip out HTML in this function, but make sure you HTML encode
        // any user supplied data from the select_array first.
        $text .= "
            <div class='row'>
                <div class='col-sm-1'>
                    <input type='radio' name='" . $escaper->escapeHtml($select_name) . "' value='" . $escaper->escapeHtml($value_text) . "' {$selected}/>
                </div>
                <div class='col'>{$value_html}</div>
            </div>";
    }

    // Output the text
    echo $text;
}

/**************************************
 * FUNCTION: DISPLAY GENERIC DROPDOWN *
 **************************************/
function display_generic_dropdown($select_name, $select_array = [], $selected_value = null)
{
    global $escaper;

    // Create the default text
    $text = "<select name='" . $escaper->escapeHtml($select_name) . "' class='form-select'>\n";

    // For each of the values in the array
    foreach ($select_array as $value)
    {
        // Check if the value is selected
        $selected = ($selected_value == $value ? " selected" : "");

        // Add the value as an option
        // NOTE: The value is not HTML encoded as we don't want to strip out HTML in this function, but make sure you HTML encode
        // any user supplied data from the select_array first.
        $text .= "<option value='" . $escaper->escapeHtml($value) . "'{$selected}>" . $escaper->escapeHtml($value) . "</option>\n";
    }

    $text .= "</select>";

    // Output the text
    echo $text;
}

/*********************************************
 * FUNCTION: DISPLAY GENERIC KEYED DROPDOWN  *
 * Like display_generic_dropdown(), but for  *
 * key => display maps (e.g. slug taxonomies)*
 * where the submitted option VALUE must be  *
 * the key, not the display text.            *
 *********************************************/
function display_generic_keyed_dropdown($select_name, $select_array = [], $selected_value = null)
{
    global $escaper;

    // Create the default text
    $text = "<select name='" . $escaper->escapeHtml($select_name) . "' class='form-select'>\n";

    // For each key => display pair in the array
    foreach ($select_array as $key => $value)
    {
        // Check if this key is selected
        $selected = ($selected_value == $key ? " selected" : "");

        // Add the option: value = key, text = display
        // NOTE: neither the key nor the value is HTML encoded as we don't want to strip
        // out HTML in this function, but make sure you HTML encode any user supplied
        // data from the select_array first.
        $text .= "<option value='" . $escaper->escapeHtml($key) . "'{$selected}>" . $escaper->escapeHtml($value) . "</option>\n";
    }

    $text .= "</select>";

    // Output the text
    echo $text;
}

/*************************************************
 * FUNCTION: DISPLAY DOCUMENTS TO CONTROLS TABLE *
 *************************************************/
function display_document_to_controls()
{

    global $lang, $escaper;

    $user = get_user_by_id($_SESSION['uid']);
    $settings = json_decode($user["custom_documents_to_controls_display_settings"] ?? '', true);
    $document_columns_setting = isset($settings["document_columns"])?$settings["document_columns"]:[];
    $control_columns_setting = isset($settings["control_columns"])?$settings["control_columns"]:[];
    $matching_columns_setting = isset($settings["matching_columns"])?$settings["matching_columns"]:[];
    $columns_setting = array_merge($document_columns_setting, $control_columns_setting, $matching_columns_setting);
    $columns = [];

    foreach($columns_setting as $column) {
        if(stripos($column[0], "custom_field_") !== false) {
            if(customization_extra() && $column[1] == 1) $columns[] = $column[0];
        } else if($column[1] == 1) {
            $columns[] = $column[0];
        }
    }
    if(!count($columns)) {
        $columns = array("document","control_number","selected","matching","recommendation");
    }

    $tr = "";
    $index = 0;
    $order_index = 0;
    $order_dir = "asc";

    // If the Customization Extra exists
    $file = realpath(__DIR__ . '/../extras/customization/index.php');
    if (file_exists($file)) {
        // Load it
        require_once($file);
    }

    foreach($columns as $column) {

        if($column == "document_id") {
            $order_index = $index;
            $order_dir = "asc";
        }
        if($column == "ai_reasoning") {
            $style = "min-width:250px;";
        } else {
            $style = "min-width:100px;";
        }

        if(($pos = stripos($column, "custom_field_")) !== false) {
            if(customization_extra()) {
                $field_id = str_replace("custom_field_", "", $column);
                $custom_field = get_field_by_id($field_id);
                $label = $escaper->escapeHtml($custom_field['name']);
                $tr .= "<th data-name='" . $escaper->escapeHtmlAttr($column) . "' align='left' style='" . $style . "'>" . $label . "</th>";
                $index++;
            }
        } else {
            $label = $escaper->escapeHtml(get_label_by_document_field_name($column));
            $tr .= "<th data-name='" . $escaper->escapeHtmlAttr($column) . "' align='left' style='" . $style . "'>" . $label . "</th>";
            $index++;
        }
    }

    $tableID = "documents-to-controls";
    echo "
        <table id='{$tableID}' width='100%' class='document-control-datatable table table-bordered table-striped table-condensed'>
            <thead >
                <tr>{$tr}</tr> 
            </thead>
            <tbody>
            </tbody>
        </table>
        <script>
            $(function(){
                var pageLength = 10;
                var form = $('#{$tableID}').parents('form');
                $('#{$tableID} thead tr').clone(true).appendTo( '#{$tableID} thead');
                $('#{$tableID} thead tr:eq(1) th').each( function (i) {
                    var title = $(this).text();
                    var data_name = $(this).attr('data-name');
                    if(data_name == 'selected') {
                        $(this).html( '<select name=\"selected\" class= \"form-control\"><option value=\"\">--</option><option value=\"1\">" . $escaper->escapeHtml($lang['Yes']) . "</option><option value=\"0\">" . $escaper->escapeHtml($lang['No']) . "</option></select>' );
                    } else if(data_name == 'tfidf_match') {
                        $(this).html( '<select name=\"tfidf_match\" class= \"form-control\"><option value=\"\">--</option><option value=\"1\">" . $escaper->escapeHtml($lang['Yes']) . "</option><option value=\"0\">" . $escaper->escapeHtml($lang['No']) . "</option></select>' );
                    } else if(data_name == 'ai_match') {
                        $(this).html( '<select name=\"ai_match\" class= \"form-control\"><option value=\"\">--</option><option value=\"1\">" . $escaper->escapeHtml($lang['Yes']) . "</option><option value=\"0\">" . $escaper->escapeHtml($lang['No']) . "</option></select>' );
                    } else if(data_name == 'matching') {
                        $(this).html( '<select name=\"recommendation\" class= \"form-control\"><option value=\"\">--</option><option value=\"DefiniteMatch\">" . $escaper->escapeHtml($lang['DefiniteMatch']) . "</option><option value=\"LikelyMatch\">" . $escaper->escapeHtml($lang['LikelyMatch']) . "</option><option value=\"PossibleMatch\">" . $escaper->escapeHtml($lang['PossibleMatch']) . "</option><option value=\"UnlikelyMatch\">" . $escaper->escapeHtml($lang['UnlikelyMatch']) . "</option><option value=\"NotAMatch\">" . $escaper->escapeHtml($lang['NotAMatch']) . "</option></select>' );
                    } else if(data_name == 'recommendation') {
                        $(this).html( '<select name=\"recommendation\" class= \"form-control\"><option value=\"\">--</option><option value=\"AddControlToPolicy\">" . $escaper->escapeHtml($lang['AddControlToPolicy']) . "</option><option value=\"ConsiderAddingControl\">" . $escaper->escapeHtml($lang['ConsiderAddingControl']) . "</option><option value=\"RemoveControlFromPolicy\">" . $escaper->escapeHtml($lang['RemoveControlFromPolicy']) . "</option><option value=\"NoActionRequired\">" . $escaper->escapeHtml($lang['NoActionRequired']) . "</option></select>' );
                    } else {
                        $(this).html(''); // To clear the title out of the header cell
                        $('<input type=\"text\" class= \"form-control\">').attr('name', title).attr('placeholder', title).appendTo($(this));
                    }

                    $( 'input, select', this ).on( 'change', function () {
                        if ( datatableInstance.column(i).search() !== this.value ) {
                            datatableInstance.column(i).search( this.value ).draw();
                        }
                    });
                });
                var datatableInstance = $('#{$tableID}').DataTable({
                    searching: true,
                    ordering: true,
                    orderCellsTop: true,
                    scrollX: true,
                    createdRow: function(row, data, index){
                        var background = $('.background-class', $(row)).data('background');
                        $(row).find('td').addClass(background)
                    },
                    order: [[{$order_index}, '{$order_dir}']],
                    ajax: {
                        url: BASE_URL + '/api/v2/governance/documents/controls',
                        type: 'post',
                        data: function(d){
                        },
                        complete: function(response){
                        }
                    },
                });
                
                $(document).ready(function(){
                    $('.sortable-document').sortable({
                        connectWith: '.sortable-document'
                    });
                    $('.sortable-control').sortable({
                        connectWith: '.sortable-control'
                    });
                    $('.sortable-matching').sortable({
                        connectWith: '.sortable-matching'
                    });
                    $('#save_display_settings').click(function(){
                        var document_checkboxes = $('.sortable-document .hidden-checkbox');
                        var documentColumns = [];
                        document_checkboxes.each(function(){
                            var check_val = $(this).is(':checked')?1:0;
                            documentColumns.push([$(this).attr('name'),check_val]);
                        });
                        var control_checkboxes = $('.sortable-control .hidden-checkbox');
                        var controlColumns = [];
                        control_checkboxes.each(function(){
                            var check_val = $(this).is(':checked')?1:0;
                            controlColumns.push([$(this).attr('name'),check_val]);
                        });
                        var matching_checkboxes = $('.sortable-matching .hidden-checkbox');
                        var matchingColumns = [];
                        matching_checkboxes.each(function(){
                            var check_val = $(this).is(':checked')?1:0;
                            matchingColumns.push([$(this).attr('name'),check_val]);
                        });
                        $.ajax({
                            type: 'POST',
                            url: BASE_URL + '/api/v2/governance/save_custom_documents_to_controls_display_settings',
                            data:{
                                document_columns: documentColumns,
                                control_columns: controlColumns,
                                matching_columns: matchingColumns,
                            },
                            success: function(res){
                                $('#setting_modal').modal('hide');
                                showAlertsFromArray(res.status_message);
                                document.location.reload();
                            },
                            error: function(xhr,status,error){
                                if(!retryCSRF(xhr, this)){
                                    if(xhr.responseJSON && xhr.responseJSON.status_message) {
                                        showAlertsFromArray(xhr.responseJSON.status_message);
                                    }
                                }
                            }
                        });
                        return false;
                    });
                });
            });
            
        </script>
    ";
}

/*******************************************************
 * FUNCTION: DISPLAY CUSTOMER DOCUMENT CONTROL COLUMNS *
 *******************************************************/
function display_custom_document_control_columns($custom_setting_field = "custom_documents_to_controls_display_settings") {

    global $escaper, $lang;
    $user = get_user_by_id($_SESSION['uid']);
    $settings = json_decode($user[$custom_setting_field], true);

    $document_columns_setting = isset($settings["document_columns"])?$settings["document_columns"]:[];
    $document_setting = [];
    foreach ($document_columns_setting as $column) {
        $document_setting[$column[0]] = $column[1];
    }

    $control_columns_setting = isset($settings["control_columns"])?$settings["control_columns"]:[];
    $control_setting = [];
    foreach ($control_columns_setting as $column) {
        $control_setting[$column[0]] = $column[1];
    }

    $matching_columns_setting = isset($settings["matching_columns"])?$settings["matching_columns"]:[];
    $matching_setting = [];
    foreach ($matching_columns_setting as $column) {
        $matching_setting[$column[0]] = $column[1];
    }

    $columns_setting = array_merge($document_columns_setting, $control_columns_setting, $matching_columns_setting);
    $columns = [];
    foreach ($columns_setting as $column) {
        if (stripos($column[0], "custom_field_") !== false) {
            if (customization_extra() && $column[1] == 1) {
                $columns[] = $column[0];
            }
        } else if ($column[1] == 1) {
            $columns[] = $column[0];
        }
    }

    if (!count($columns)) {
        if ($custom_setting_field == "custom_documents_to_controls_display_settings") {
            $document_setting = ["document_id" => 0, "document" => 1];
            $control_setting = ["control_id" => 0, "control_number" => 1, "control_short_name" => 0, "selected" => 1];
            $matching_setting = ["score" => 0, "tfidf_similarity" => 0, "keyword_match" => 0, "tfidf_match" => 0, "ai_match" => 0, "ai_confidence" => 0, "ai_reasoning" => 0, "matching" => 1, "recommendation" => 1];
        } else {
            $document_setting = ["document_id" => 0, "document" => 1];
            $control_setting = ["control_id" => 0, "control_number" => 1, "control_short_name" => 0, "selected" => 1];
            $matching_setting = ["score" => 0, "tfidf_similarity" => 0, "keyword_match" => 0, "tfidf_match" => 0, "ai_match" => 0, "ai_confidence" => 0, "ai_reasoning" => 0, "matching" => 1, "recommendation" => 1];
        }
    }

    $str = "
        <style>
            #column-selections-container label{color:#000;}
            ul.sortable{list-style:none;margin:0;}
            ul.sortable li{border: 1px dotted #cccccc;margin:2px 0;padding:5px;}
        </style>
        <div class='well accordion' id='column-selections-container'>
    ";

    // Names of document columns
    $document_columns = [
        'document_id' => $escaper->escapeHtml($lang['DocumentID']),
        'document' => $escaper->escapeHtml($lang['Document']),
    ];

    // Names of control columns
    $control_columns = [
        'control_id' => $escaper->escapeHtml($lang['ControlID']),
        'control_number' => $escaper->escapeHtml($lang['ControlNumber']),
        'control_short_name' => $escaper->escapeHtml($lang['ControlShortName']),
        'selected' => $escaper->escapeHtml($lang['Selected']),
    ];

    // Names of matching columns
    $matching_columns = [
        'score' => $escaper->escapeHtml($lang['Score']),
        'tfidf_similarity' => $escaper->escapeHtml($lang['TFIDFSimilarity']),
        'keyword_match' => $escaper->escapeHtml($lang['MatchingKeywords']),
        'tfidf_match' => $escaper->escapeHtml($lang['TFIDFMatch']),
        'ai_match' => $escaper->escapeHtml($lang['AIMatch']),
        'ai_confidence' => $escaper->escapeHtml($lang['AIConfidence']),
        'ai_reasoning' => $escaper->escapeHtml($lang['AIReasoning']),
        'matching' => $escaper->escapeHtml($lang['Matching']),
        'recommendation' => $escaper->escapeHtml($lang['Recommendation']),
    ];

    $document_columns_keys = array_values(array_unique(array_merge(array_keys($document_setting),array_keys($document_columns))));
    $control_columns_keys = array_values(array_unique(array_merge(array_keys($control_setting),array_keys($control_columns))));
    $matching_columns_keys = array_values(array_unique(array_merge(array_keys($matching_setting),array_keys($matching_columns))));

    // Document columns
    $str .= "
            <div class='accordion-item'>
                <h2 class='accordion-header'>
                    <button type='button' class='accordion-button collapsed' data-bs-toggle='collapse' data-bs-target='#DocumentColumns_container'>{$escaper->escapeHtml($lang['DocumentColumns'])}</button>
                </h2>
                <div id='DocumentColumns_container' class='accordion-collapse collapse'>
                    <div class='accordion-body card-body'>
                        <div class='row'>
                            <div class='col-6'>
                                <div class='p-3 h-100 border'>
                                    <ul class='sortable sortable-document mb-0 ps-0'>
    ";

    // variable to store the custom display settings
    $custom_display_settings = [];

    $half_num = ceil(count($document_columns_keys)/2);
    for ($i = 0; $i < $half_num ; $i++) {

        $field = $document_columns_keys[$i];
        $elem_id = "checkbox_" . $field;
        $check_val = isset($document_setting[$field]) ? $document_setting[$field] : 0;
        $checked = $check_val ? "checked='yes'" : "";

        // if the field is checked, add it to the custom display settings
        if ($check_val) {
            $custom_display_settings[] = $field;
        }

        if (isset($document_columns[$field])) {
            $str .= "
                                        <li>
                                            <input class='hidden-checkbox form-check-input' type='checkbox' name='{$field}' id='{$elem_id}' {$checked}/>
                                            <label class='ms-2' for='{$elem_id}'>{$document_columns[$field]}</label>
                                        </li>
            ";
        }
    }

    $str .= "
                                    </ul>
                                </div>
                            </div>
                            <div class='col-6'>
                                <div class='p-3 h-100 border'>
                                    <ul class='sortable sortable-document mb-0 ps-0'>
    ";

    for (; $i < count($document_columns_keys) ; $i++) {

        $field = $document_columns_keys[$i];
        $elem_id = "checkbox_" . $field;
        $check_val = isset($document_setting[$field]) ? $document_setting[$field] : 0;
        $checked = $check_val ? "checked='yes'" : "";

        // if the field is checked, add it to the custom display settings
        if ($check_val) {
            $custom_display_settings[] = $field;
        }

        if (isset($document_columns[$field])) {
            $str .= "
                                        <li>
                                            <input class='hidden-checkbox form-check-input' type='checkbox' name='{$field}' id='{$elem_id}' {$checked}/>
                                            <label for='{$elem_id}'>{$document_columns[$field]}</label>
                                        </li>
            ";
        }
    }

    $str .= "
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    ";

    // Control columns
    $str .= "
            <div class='accordion-item'>
                <h2 class='accordion-header'>
                    <button type='button' class='accordion-button collapsed' data-bs-toggle='collapse' data-bs-target='#ControlColumns_container'>{$escaper->escapeHtml($lang['ControlColumns'])}</button>
                </h2>
                <div id='ControlColumns_container' class='accordion-collapse collapse'>
                    <div class='accordion-body card-body'>
                        <div class='row'>
                            <div class='col-6'>
                                <div class='p-3 h-100 border'>
                                    <ul class='sortable sortable-control mb-0 ps-0'>
    ";

    $half_num = ceil(count($control_columns_keys)/2);
    for ($i = 0; $i < $half_num ; $i++) {

        $field = $control_columns_keys[$i];
        $check_val = isset($control_setting[$field]) ? $control_setting[$field] : 0;
        $elem_id = "checkbox_" . $field;
        $checked = $check_val ? "checked='yes'" : "";

        // if the field is checked, add it to the custom display settings
        if ($check_val) {
            $custom_display_settings[] = $field;
        }

        if (isset($control_columns[$field])) {
            $str .= "
                                        <li>
                                            <input class='hidden-checkbox form-check-input' type='checkbox' name='{$field}' id='{$elem_id}' {$checked}/>
                                            <label class='ms-2' for='{$elem_id}'>{$control_columns[$field]}</label>
                                        </li>
            ";
        }
    }

    $str .= "
                                    </ul>
                                </div>
                            </div>
                            <div class='col-6'>
                                <div class='p-3 h-100 border'>
                                    <ul class='sortable sortable-control mb-0 ps-0'>
    ";

    for (; $i < count($control_columns_keys) ; $i++) {

        $field = $control_columns_keys[$i];
        $elem_id = "checkbox_" . $field;
        $check_val = isset($control_setting[$field]) ? $control_setting[$field] : 0;
        $checked = $check_val ? "checked='yes'" : "";

        // if the field is checked, add it to the custom display settings
        if ($check_val) {
            $custom_display_settings[] = $field;
        }

        if (isset($control_columns[$field])) {
            $str .= "
                                        <li>
                                            <input class='hidden-checkbox form-check-input' type='checkbox' name='{$field}' id='{$elem_id}' {$checked}/>
                                            <label for='{$elem_id}'>{$control_columns[$field]}</label>
                                        </li>
            ";
        }
    }

    $str .= "
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    ";

    // Matching columns
    $str .= "
            <div class='accordion-item'>
                <h2 class='accordion-header'>
                    <button type='button' class='accordion-button collapsed' data-bs-toggle='collapse' data-bs-target='#MatchingColumns_container'>{$escaper->escapeHtml($lang['MatchingColumns'])}</button>
                </h2>
                <div id='MatchingColumns_container' class='accordion-collapse collapse'>
                    <div class='accordion-body card-body'>
                        <div class='row'>
                            <div class='col-6'>
                                <div class='p-3 h-100 border'>
                                    <ul class='sortable sortable-matching mb-0 ps-0'>
    ";

    $half_num = ceil(count($matching_columns_keys)/2);
    for ($i = 0; $i < $half_num ; $i++) {

        $field = $matching_columns_keys[$i];
        $check_val = isset($matching_setting[$field]) ? $matching_setting[$field] : 0;
        $elem_id = "checkbox_" . $field;
        $checked = $check_val ? "checked='yes'" : "";

        // if the field is checked, add it to the custom display settings
        if ($check_val) {
            $custom_display_settings[] = $field;
        }

        if (isset($matching_columns[$field])) {
            $str .= "
                                        <li>
                                            <input class='hidden-checkbox form-check-input' type='checkbox' name='{$field}' id='{$elem_id}' {$checked}/>
                                            <label class='ms-2' for='{$elem_id}'>{$matching_columns[$field]}</label>
                                        </li>
            ";
        }
    }
    $str .= "
                                    </ul>
                                </div>
                            </div>
                            <div class='col-6'>
                                <div class='p-3 h-100 border'>
                                    <ul class='sortable sortable-matching mb-0 ps-0'>
    ";

    for (; $i < count($matching_columns_keys) ; $i++) {

        $field = $matching_columns_keys[$i];
        $elem_id = "checkbox_" . $field;
        $check_val = isset($matching_setting[$field]) ? $matching_setting[$field] : 0;
        $checked = $check_val ? "checked='yes'" : "";

        // if the field is checked, add it to the custom display settings
        if ($check_val) {
            $custom_display_settings[] = $field;
        }

        if (isset($matching_columns[$field])) {
            $str .= "
                                        <li>
                                            <input class='hidden-checkbox form-check-input' type='checkbox' name='{$field}' id='{$elem_id}' {$checked}/>
                                            <label for='{$elem_id}'>{$matching_columns[$field]}</label>
                                        </li>
            ";
        }
    }

    $str .= "
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    ";
    echo $str;

    echo "
        <script>

            // variable to store the custom display settings
            var custom_display_settings = " . json_encode($custom_display_settings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ";

        </script>
    ";
}

function get_label_by_document_field_name($field){
    global $lang, $escaper;
    // List of document to control mapping columns
    $columns = [
        'document_id' => $lang['DocumentID'],
        'document' => $lang['Document'],
        'control_id' => $lang['ControlID'],
        'control_number' => $lang['ControlNumber'],
        'control_short_name' => $lang['ControlShortName'],
        'selected' => $lang['Selected'],
        'score' => $lang['Score'],
        'tfidf_similarity' => $lang['TFIDFSimilarity'],
        'keyword_match' => $lang['MatchingKeywords'],
        'tfidf_match' => $lang['TFIDFMatch'],
        'ai_match' => $lang['AIMatch'],
        'ai_confidence' => $lang['AIConfidence'],
        'ai_reasoning' => $lang['AIReasoning'],
        'matching' => $lang['Matching'],
        'recommendation' => $lang['Recommendation'],
    ];

    return $columns[$field];
}

/******************************************************
 * FUNCTION: ADVANCED SEARCH LOCKED TYPE KEYS          *
 ******************************************************/
/**
 * The entity types Advanced Search covers regardless of other Extras, as
 * plural lang keys. Shared by the locked topbar popover and the locked Search
 * page so the promise is stated once.
 *
 * @return list<string>
 */
function advanced_search_locked_type_keys(): array
{
    return ['Risks', 'Frameworks', 'Controls', 'Documents', 'Exceptions', 'Tests', 'Audits', 'Assets', 'AssetGroups'];
}

/******************************************************
 * FUNCTION: DISPLAY LOCKED TOPBAR SEARCH              *
 ******************************************************/
/**
 * The topbar search when the Advanced Search Extra is not active: present,
 * legible, plainly not actionable, with one popover saying what it unlocks.
 * Shares the .sr-locked treatment (scss/modules/_locked-affordance.scss).
 *
 * It is a <button>, not an <input>: nothing can be typed or submitted, so
 * there is no search behavior to misfire. The popover body is rendered here as
 * a hidden panel of server-escaped text; js/simplerisk/theme/topbar-search-
 * locked.js turns it into a Bootstrap popover. Nothing is built from user input.
 *
 * @param array $locked advanced_search_acquisition_state()'s return shape
 *
 * @return void
 */
function display_locked_topbar_search(array $locked): void
{
    global $lang, $escaper;

    // The entity types Advanced Search covers regardless of other Extras.
    // Conditional ones (incidents, assessments, vulnerabilities) depend on
    // Extras this customer may not have, so they are not promised here.
    $type_keys = advanced_search_locked_type_keys();

    $note      = $locked['note_key'] !== null ? ($lang[$locked['note_key']] ?? '') : '';
    $link_text = $locked['link_key'] !== null ? ($lang[$locked['link_key']] ?? '') : '';
    $href      = $locked['unlock_href'] ?? null;
?>
			<li class="nav-item nav-item-search sr-locked-search-item">
				<div class="nav-link">
					<div class="search-box sr-locked sr-locked-search" data-sr-locked-state="<?= $escaper->escapeHtmlAttr($locked['state']) ?>">
						<button type="button" class="sr-locked-search__trigger" aria-haspopup="dialog" aria-expanded="false" aria-label="<?= $escaper->escapeHtmlAttr($lang['AdvancedSearchLockedAria']) ?>">
							<i class="fas fa-search align-middle" aria-hidden="true"></i>
							<span class="sr-locked-search__placeholder"><?= $escaper->escapeHtml($lang['AdvancedSearchLockedPlaceholder']) ?></span>
							<span class="sr-locked-badge"><i class="fa fa-lock" aria-hidden="true"></i> <?= $escaper->escapeHtml($lang['LockedAffordanceBadge']) ?></span>
						</button>
					</div>
				</div>
				<div class="sr-locked-search__panel" hidden data-sr-popover-title="<?= $escaper->escapeHtmlAttr($lang['AdvancedSearchExtra']) ?>">
					<p class="sr-locked-search__pitch"><?= $escaper->escapeHtml($lang['AdvancedSearchLockedPitch']) ?></p>
					<div class="sr-locked-search__unlocks">
						<span class="sr-locked-search__unlocks-label"><?= $escaper->escapeHtml($lang['AdvancedSearchUnlocksLabel']) ?></span>
						<ul class="sr-locked-search__types">
<?php foreach ($type_keys as $type_key) { ?>
							<li class="sr-chip"><?= $escaper->escapeHtml($lang[$type_key]) ?></li>
<?php } ?>
						</ul>
					</div>
<?php if ($note !== '') { ?>
					<span class="sr-locked-note"><?= $escaper->escapeHtml($note) ?></span>
<?php } ?>
<?php if ($link_text !== '' && $href) { ?>
					<a class="sr-locked-link" href="<?= $escaper->escapeHtmlAttr($href) ?>"<?= !empty($locked['external']) ? ' target="_blank" rel="noopener"' : '' ?>><?= $escaper->escapeHtml($link_text) ?></a>
<?php } ?>
				</div>
			</li>
<?php
}

/******************************************************
 * FUNCTION: DISPLAY LOCKED SEARCH PAGE                *
 ******************************************************/
/**
 * The Search page body when the Advanced Search Extra is not active (spec
 * §5.4): the same pitch, type chips, note and unlock link as the topbar
 * popover, as one card. No input, no form: there is no search behaviour.
 *
 * @param array $locked advanced_search_acquisition_state()'s return shape
 *
 * @return void
 */
function display_locked_search_page(array $locked): void
{
    global $lang, $escaper;

    $note      = $locked['note_key'] !== null ? ($lang[$locked['note_key']] ?? '') : '';
    $link_text = $locked['link_key'] !== null ? ($lang[$locked['link_key']] ?? '') : '';
    $href      = $locked['unlock_href'] ?? null;
?>
<section class="sr-table-card sr-locked-search-page sr-locked" data-sr-locked-state="<?= $escaper->escapeHtmlAttr($locked['state']) ?>">
    <div class="sr-table-toolbar">
        <span class="sr-table-title"><?= $escaper->escapeHtml($lang['AdvancedSearchExtra']) ?></span>
        <span class="sr-locked-badge"><i class="fa fa-lock" aria-hidden="true"></i> <?= $escaper->escapeHtml($lang['LockedAffordanceBadge']) ?></span>
    </div>
    <div class="sr-locked-search-page__body">
        <p class="sr-locked-search__pitch"><?= $escaper->escapeHtml($lang['AdvancedSearchLockedPitch']) ?></p>
        <span class="sr-locked-search__unlocks-label"><?= $escaper->escapeHtml($lang['AdvancedSearchUnlocksLabel']) ?></span>
        <ul class="sr-locked-search__types">
<?php foreach (advanced_search_locked_type_keys() as $type_key) { ?>
            <li class="sr-chip"><?= $escaper->escapeHtml($lang[$type_key]) ?></li>
<?php } ?>
        </ul>
<?php if ($note !== '') { ?>
        <span class="sr-locked-note"><?= $escaper->escapeHtml($note) ?></span>
<?php } ?>
<?php if ($link_text !== '' && $href) { ?>
        <a class="sr-locked-link" href="<?= $escaper->escapeHtmlAttr($href) ?>"<?= !empty($locked['external']) ? ' target="_blank" rel="noopener"' : '' ?>><?= $escaper->escapeHtml($link_text) ?></a>
<?php } ?>
    </div>
</section>
<?php
}

/******************************************************
 * FUNCTION: DISPLAY SEARCH PAGE BODY                  *
 ******************************************************/
/**
 * search/index.php's body. Extras ship separately from Core, so an active
 * Advanced Search Extra older than this Core has no page renderer: that case
 * gets an "update the Extra" card instead of a fatal, the way header.php
 * guards its Extra calls with function_exists().
 *
 * @param bool        $extra_active advanced_search_extra()
 * @param array|null  $locked       advanced_search_acquisition_state()'s shape; used when the Extra is not active
 * @param string      $renderer     the Extra's page renderer (injected by tests)
 *
 * @return void
 */
function display_search_page_body(bool $extra_active, ?array $locked, string $renderer = 'render_advanced_search_page'): void
{
    global $lang, $escaper;

    if (!$extra_active) {
        if ($locked !== null) {
            display_locked_search_page($locked);
        }
        return;
    }

    if (function_exists($renderer)) {
        $renderer();
        return;
    }

    // No log here: write_debug_log() reads settings from the database and
    // this render is pinned by a DB-free test; search/index.php logs it.
?>
<section class="sr-table-card sr-locked-search-page" data-sr-search-unavailable="extra_outdated">
    <div class="sr-table-toolbar">
        <span class="sr-table-title"><?= $escaper->escapeHtml($lang['AdvancedSearchExtra']) ?></span>
    </div>
    <div class="sr-locked-search-page__body">
        <span class="sr-locked-note"><?= $escaper->escapeHtml(_lang_raw('UpdateInstalledExtrasOutOfDate', ['extrasToUpdate' => $lang['AdvancedSearch']])) ?></span>
    </div>
</section>
<?php
}

?>