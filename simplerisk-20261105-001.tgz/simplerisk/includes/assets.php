<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Include required configuration files
require_once(realpath(__DIR__ . '/functions.php'));
require_once(realpath(__DIR__ . '/extras.php'));
load_language_file();
require_once(realpath(__DIR__ . '/displayassets.php'));
require_once(realpath(__DIR__ . '/permissions.php'));
require_once(realpath(__DIR__ . '/assets_write_rules.php'));
require_once(realpath(__DIR__ . '/asset_scoring.php'));
require_once(realpath(__DIR__ . '/../vendor/autoload.php'));

/************************
 * FUNCTION: PING CHECK *
 ************************/
function ping_check($ip)
{
    // Used by the background discovery job (includes/assets_discovery.php). Only a literal IPv4 address ever
    // reaches the shell, and it still goes through escapeshellarg().
    if (!is_string($ip) || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return false;
    }

    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') { // Server OS is Windows
        $cmd = sprintf('ping -n 1 -w 1 %s', escapeshellarg($ip));
    } else { // Server OS is Linux
        $cmd = sprintf('ping -c 1 -W 1 %s', escapeshellarg($ip));

    }
    exec($cmd, $res, $rval);
    return $rval === 0;
}

/**************************
 * FUNCTION: ASSET EXISTS *
 **************************/
function asset_exists($name)
{
    global $escaper;

    // One rule for every caller (SR-37): surrounding space never makes a
    // different name, and the lookup is case-insensitive -- the unencrypted
    // column's collation, and encrypted_asset_exists() by construction.
    // Callers that look a name up and add it when missing (scanner imports,
    // Import-Export, risk/asset forms) rely on this matching add_asset().
    $name = trim((string)$name);

    write_debug_log("Checking if asset named \"" . $escaper->escapeHtml($name) . "\" exists", 'debug');

    // If the encryption extra is enabled
    if (encryption_extra())
    {
        write_debug_log("Encryption extra is enabled", 'debug');

        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));

        // Call the encrypted asset exists function
        return encrypted_asset_exists($name);
    }
    else
    {
        write_debug_log("Encryption extra is not enabled", 'debug');
        
        // Open the database connection
        $db = db_open();
        
        // Check if the asset name is in the database
        $stmt = $db->prepare("SELECT id FROM `assets` WHERE name=:name;");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->execute();

        // If it is then get the id and return the asset's id
        if ($stmt->rowCount() > 0) {

            $asset_id = $stmt->fetch(PDO::FETCH_COLUMN);

            // Close the database connection
            db_close($db);

            write_debug_log("Asset was found", 'debug');
            return $asset_id;
        }

        // Close the database connection
        db_close($db);

        write_debug_log("Asset was not found", 'debug');
        return false;
    }
}

/**
 * Every asset whose name could equal $name under the asset name rule
 * (assets_name_key()), as id => plaintext name, plus $self_id's own current
 * name. The input of assets_name_conflict() and assets_name_for_storage().
 *
 * With the Encryption Extra the candidates come from the Extra's
 * encrypted_asset_name_candidates(). The Extra ships separately from Core,
 * so an older Extra may not have it: then the asset_exists() lookup stands
 * in (it finds one holder of the name, which is all the conflict check needs
 * outside the case-twin edge). $encrypted and $function_exists are
 * injectable for tests (null = encryption_extra() / function_exists()).
 *
 * @return array<int,string>
 */
function asset_name_candidates(string $name, int $self_id, ?bool $encrypted = null, ?callable $function_exists = null): array
{
    $name = trim($name);
    $function_exists = $function_exists ?? 'function_exists';

    if ($encrypted ?? encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
        if ($function_exists('encrypted_asset_name_candidates')) {
            $names = encrypted_asset_name_candidates($name);
        } else {
            $names = [];
            $found = asset_exists($name);
            if ($found) {
                $names[(int)$found] = $name;
            }
        }
    } else {
        $db = db_open();
        $stmt = $db->prepare("SELECT `id`, `name` FROM `assets` WHERE `name` = :name;");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->execute();
        $names = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'name', 'id');
        db_close($db);
    }

    // The asset's own current name, wherever its row sits in the order.
    $own = $self_id > 0 ? get_asset_by_id($self_id) : false;
    if ($own) {
        $names[$self_id] = (string)try_decrypt($own['name']);
    }

    return $names;
}

/**
 * Whether an asset OTHER than $self_id already holds $name under the asset
 * name rule (assets_name_key()). Used by the edit paths instead of comparing
 * asset_exists() with the id being edited: with the Encryption Extra two case
 * twins can already exist, and the lookup returns whichever twin it lands on,
 * which would refuse the other twin's save under its own name.
 */
function asset_name_taken_by_other(string $name, int $self_id, ?bool $encrypted = null, ?callable $function_exists = null): bool
{
    return assets_name_conflict(asset_name_candidates($name, $self_id, $encrypted, $function_exists), trim($name), $self_id);
}

/**
 * The asset name check of an edit, in one place for every edit path that
 * writes the name: the name is trimmed (SR-37, as add_asset() does), refused
 * when blank or held by another asset, and otherwise returned as the value to
 * store (assets_name_for_storage()). Null = refused.
 */
function asset_name_for_edit($name, int $self_id): ?string
{
    $name = trim((string)$name);
    if ($name === '') {
        return null;
    }
    $names = asset_name_candidates($name, $self_id);
    if (assets_name_conflict($names, $name, $self_id)) {
        return null;
    }
    return assets_name_for_storage($names, $name, $self_id, !encryption_extra());
}

/**
 * Checks if an asset exists with the provided id
 * 
 * @param int $id ID we want to check for
 * @return boolean
 */
function asset_exists_by_id($id) {

    // Open the database connection
    $db = db_open();

    // Check if the asset name is in the database
    $stmt = $db->prepare("SELECT 5 FROM `assets` WHERE id=:id;");
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();

    $result = $stmt->fetchColumn();

    // Close the database connection
    db_close($db);

    return !empty($result) && (int)$result === 5;
}

/**********************************
 * FUNCTION: ASSET EXISTS (EXACT) *
 **********************************/
function asset_exists_exact($ip, $name, $value, $location, $teams, $details, $verified)
{
    global $escaper;

    write_debug_log("Checking if asset named \"" . $escaper->escapeHtml($name) . "\" exists", 'debug');

    // If the encryption extra is enabled
    if (encryption_extra())
    {
        write_debug_log("Encryption extra is enabled", 'debug');

        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));

        // Call the encrypted asset exists function
        $exists = encrypted_asset_exists_exact($ip, $name, $value, $location, $teams, $details, $verified);

        // Return the result
        return $exists;
    }
    else
    {
        write_debug_log("Encryption extra is not enabled", 'debug');

        // Open the database connection
        $db = db_open();

        // Check if the asset is in the database
        $stmt = $db->prepare("SELECT id FROM `assets` WHERE `name`=:name AND `ip`=:ip AND `value`=:value AND `location`=:location AND `teams`=:teams AND `details`=:details AND `verified`=:verified;");
        $stmt->bindParam(":ip", $ip, PDO::PARAM_STR, 15);
        $stmt->bindParam(":name", $name, PDO::PARAM_STR, 200);
        $stmt->bindParam(":value", $value, PDO::PARAM_INT, 2);
        $stmt->bindParam(":location", $location, PDO::PARAM_STR);
        $stmt->bindParam(":teams", $teams, PDO::PARAM_STR);
        $stmt->bindParam(":details", $details, PDO::PARAM_STR);
        $stmt->bindParam(":verified", $verified, PDO::PARAM_INT);
        $stmt->execute();
        $assets = $stmt->fetchAll();

        // Close the database connection
        db_close($db);

        // If the assets array contains at least one value
        if (count($assets) > 0)
        {
            write_debug_log("Asset was found", 'debug');
            return true;
        }
        else
        {
            write_debug_log("Asset was not found", 'debug');
            return false;
        }
    }
}


/********************************************************
 * FUNCTION: ADD ASSET BY NAME WITH FORCED VERIFICATION *
 * Used for adding an asset while defining its verified *
 * status, but without specifying the default values    *
 ********************************************************/
/**
 * Whether an asset the session user creates interactively starts verified:
 * the user holds asset_verify, or the auto_verify_new_assets setting is on.
 * Shared by add_asset() and the legacy create modal's endpoint
 * (create_asset_API_v2(), POST /api/v2/assets/create_asset) so the two
 * creation paths cannot disagree.
 */
function asset_new_verified_for_current_user(): bool
{
    return assets_verification_for_new(
        asset_user_can('verify'),
        (bool)get_setting("auto_verify_new_assets"),
        false
    ) === 1;
}

function add_asset_by_name_with_forced_verification($name, $verified = false) {
    // !!!!!!Update the values if the add_asset's default values change!!!!!!
    return add_asset('', $name, 5, 0, 0, "", "", $verified);
}

/***********************
 * FUNCTION: ADD ASSET *
 ***********************/
function add_asset($ip, $name, $value=5, $location="", $teams="", $details = "", $tags = "", $verified = false, $mapped_controls=[], $associated_risks = [], $imported = false, $template_group_id = null, $custom_values = null, $verified_is_explicit = false, $scoring = null)
{
    global $lang;

    // Trim BEFORE the duplicate check (SR-37). Checking the untrimmed name let
    // " web01" past the check for an existing "web01"; the trimmed insert then
    // hit the UNIQUE key and ON DUPLICATE KEY UPDATE silently overwrote that
    // asset (with the Encryption Extra, which has no such key, it created a
    // second one).
    $name = trim((string)$name);

    // Asset Scoring while the database upgrade is pending: refused before
    // anything is created (POST /assets answers this case itself, earlier).
    if (is_array($scoring) && asset_scoring_write_refusal($scoring, asset_scoring_schema_ready()) !== null) {
        asset_scoring_log_once('schema_pending_refused', 'Asset scoring: a save carrying scoring selections was refused because the assets table has no scoring columns yet. Run the SimpleRisk database upgrade.', 'notice');
        return false;
    }

    // If the asset does not already exist
    if (!asset_exists($name)) {

        // Trim whitespace from the ip and value
        $ip     = trim($ip);
        $value  = trim($value);
        $location   = is_array($location) ? assets_id_csv($location) : $location;
        $teams   = is_array($teams) ? assets_id_csv($teams) : $teams;

        if (!$name) {
            return false;
        }

        // See if we need to encrypt values
        $ip_encrypted = try_encrypt($ip);
        $name_encrypted = try_encrypt($name);
        $details_encrypted = try_encrypt($details);

        // Verification rule for a NEW asset (asset-management redesign, spec D2/D8).
        // An explicit truthy $verified (import, discovery, forced-verification
        // callers) is kept as-is, and an $imported caller's value is never
        // second-guessed. Otherwise the asset is verified iff the acting user
        // holds asset_verify or the auto_verify_new_assets setting is on. There
        // is no session in CLI/cron/queue contexts, so asset_user_can() is false
        // there and non-interactive creation lands unverified unless one of the
        // explicit paths above (or the auto-verify setting) says otherwise.
        // $verified_is_explicit (POST /assets, R11): the caller already decided,
        // so a false $verified means "create unverified" rather than "decide
        // for me". Defaults to false, so every other caller is unchanged.
        if (!$verified && !$imported && !$verified_is_explicit) {
            $verified = asset_new_verified_for_current_user();
        }

        // Resolve (and validate, when explicitly submitted) the
        // template_group_id this asset is created under. See
        // resolve_template_group_id() in the Customization Extra for the
        // fallback/ownership rules; the Core guard only loads that file when
        // the Extra is actually active, so this never fatals on an install
        // without it.
        $template_group_id = resolve_template_group_id_from_core('asset', $template_group_id);

        // Open the database connection
        $db = db_open();

        $stmt = $db->prepare("INSERT INTO `assets` (ip, name, value, location, teams, details, verified, template_group_id) VALUES (:ip, :name, :value, :location, :teams, :details, :verified, :template_group_id) ON DUPLICATE KEY UPDATE `ip`=:ip, `value`=:value, `location`=:location, `teams`=:teams, `details`=:details, `verified`=:verified;");
        $stmt->bindParam(":ip", $ip_encrypted, PDO::PARAM_STR);
        $stmt->bindParam(":name", $name_encrypted, PDO::PARAM_STR);
        $stmt->bindParam(":value", $value, PDO::PARAM_INT, 2);
        $stmt->bindParam(":location", $location, PDO::PARAM_STR);
        $stmt->bindParam(":teams", $teams, PDO::PARAM_STR);
        $stmt->bindParam(":details", $details_encrypted, PDO::PARAM_STR);
        $stmt->bindParam(":verified", $verified, PDO::PARAM_INT);
        $stmt->bindParam(":template_group_id", $template_group_id, PDO::PARAM_INT);
        $stmt->execute();

        $asset_id = $db->lastInsertId();

        // Close the database connection
        db_close($db);

        // Save control mappings
        if(is_array($mapped_controls)&&count($mapped_controls)>0) save_asset_to_controls($asset_id, $mapped_controls);

        // If customization extra is enabled
        if(customization_extra())
        {
            // Include the extra
            require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

            // An explicit custom_field[<id>] => value map (POST /assets) is
            // limited to the fields of the group the asset was filed under;
            // null keeps the historical read of $_POST['custom_field'].
            $custom_values_to_save = null;
            if (is_array($custom_values)) {
                $custom_values_to_save = assets_split_custom_field_input($custom_values, asset_custom_fields_by_id_for_group((int)$template_group_id))['values'];
            }

            // If there is error in saving custom asset values, return false
            if(!save_custom_field_values($asset_id, "asset", $custom_values_to_save))
            {
                delete_asset($asset_id);
                return false;
            }
        }

        updateTagsOfType($asset_id, 'asset', $tags);

        // Asset Scoring selections (POST /assets only; ruling G5: the
        // Preferences default is never applied here). Not logged per
        // objective: the "added" line below covers a create.
        // A failed write fails the create: the asset is removed again rather
        // than reported as added without the scoring the caller sent.
        if (is_array($scoring) && $scoring) {
            try {
                $applied = asset_scoring_apply((int)$asset_id, $scoring, false);
            } catch (\Throwable $e) {
                $applied = null;
                write_debug_log("Asset scoring: saving the scoring selections of new asset {$asset_id} failed: " . get_class($e) . " [" . (string)$e->getCode() . "]", 'error');
            }
            if ($applied === null) {
                delete_asset($asset_id);
                return false;
            }
        }

        update_asset_risks_associations($asset_id, $associated_risks);

        if (notification_extra()) {
            require_once(realpath(__DIR__ . '/../extras/notification/index.php'));

            // Send the notification about the updated risks
            foreach ($associated_risks as $risk_id) {
                notify_risk_update($risk_id);
            }
        }

        // Updates order_by_name (no-op if encryption extra is disabled)
        call_extra_function(
            'encryption_extra',
            __DIR__ . '/../extras/encryption/index.php',
            'update_name_order_for_asset',
            [$asset_id, $name]
        );

        // No session in the discovery worker (or any queue/cron caller).
        $by_user = $_SESSION['user'] ?? '';
        $message = "Asset '{$name}' was added by user '{$by_user}'.";
        write_log($asset_id , $_SESSION['uid'] ?? 0, $message, "asset");

        trigger_workflow_event('asset.created', [
            'asset_id' => $asset_id,
            'name'     => $name,
        ]);

        // Return success or failure
        return $asset_id;
    }
    // The asset already exists
    else
    {
        set_alert(true, "bad", $lang['ErrorAssetAlreadyExists']);
        return false;
    }
}


/**
 * Whether an edit by the current user must return a verified asset to
 * unverified (spec section 10): the stored row is verified, the edit changes
 * its name or IP address, and the user does not hold asset_verify. A null
 * $name / $ip means "not supplied, leave alone" and never counts as a change.
 * Shared by update_asset() (PATCH /assets/{id}) and update_asset_API_v2()
 * (POST /assets/update_asset, the Manage assets Edit modal).
 */
function asset_edit_demotes_verification(int $asset_id, $name, $ip): bool
{
    $current = get_asset_by_id($asset_id);
    if (!$current || (int)$current['verified'] !== 1) {
        return false;
    }

    // Stored name/ip are ciphertext when the Encryption Extra is on; compare plaintext to plaintext.
    $identity_changed = assets_identity_changed(
        (string)try_decrypt($current['name']),
        (string)try_decrypt($current['ip']),
        is_null($name) ? null : (string)$name,
        is_null($ip) ? null : (string)$ip
    );

    return assets_verification_after_edit(1, asset_user_can('verify'), $identity_changed) === 0;
}

/**
 * Audit line for an asset returned to unverified by an identity edit.
 * _lang() escapes the parameters; do not pre-escape them.
 */
function asset_write_unverified_by_edit_log(int $asset_id, $name): void
{
    $message = _lang('AssetUnverifiedByEditLog', [
        'name' => (string)$name,
        'user' => $_SESSION['user'] ?? '',
    ]);
    write_log($asset_id, $_SESSION['uid'] ?? 0, $message, "asset");
}

/**
 * The template group an asset record is laid out and validated against: the
 * asset's own group when it is a real asset template group, otherwise the
 * asset Default. Rows written without a group carry the schema default of 1,
 * which is the RISK Default group, so it cannot be trusted as-is. Without the
 * Customization Extra's table there are no groups and the stored value is
 * returned unchanged.
 *
 * @param array<string,mixed> $asset an assets row
 */
function asset_record_template_group_id(array $asset): int
{
    $stored = (int)($asset['template_group_id'] ?? 1);
    if (!table_exists('custom_template_group')) {
        return $stored;
    }

    $db = db_open();
    $stmt = $db->prepare("SELECT COUNT(*) FROM `custom_template_group` WHERE `id` = :id AND `fgroup` = 'asset'");
    $stmt->bindValue(':id', $stored, PDO::PARAM_INT);
    $stmt->execute();
    $is_asset_group = (int)$stmt->fetchColumn() > 0;
    if (!$is_asset_group) {
        $default = $db->query("SELECT `id` FROM `custom_template_group` WHERE `fgroup` = 'asset' AND `is_default` = 1 ORDER BY `id` LIMIT 1")->fetchColumn();
        $stored = $default !== false ? (int)$default : $stored;
    }
    db_close($db);

    return $stored;
}

/**
 * The custom (is_basic = 0) fields active in an asset's template group, keyed
 * by field id -- the only custom_field[<id>] keys an asset write may store.
 * Empty without the Customization Extra.
 *
 * @return array<int,array<string,mixed>>
 */
function asset_custom_fields_by_id_for_asset(int $asset_id): array
{
    if (!customization_extra() || !table_exists('custom_template')) {
        return [];
    }
    require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

    $asset = get_asset_by_id($asset_id);
    if (!$asset) {
        return [];
    }

    return asset_custom_fields_by_id_for_group(asset_record_template_group_id($asset));
}

/**
 * The custom (is_basic = 0) fields active in an asset template group, keyed
 * by field id. Empty without the Customization Extra.
 *
 * @return array<int,array<string,mixed>>
 */
function asset_custom_fields_by_id_for_group(int $template_group_id): array
{
    if (!customization_extra() || !table_exists('custom_template')) {
        return [];
    }
    require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

    $fields = [];
    foreach (get_active_fields('asset', $template_group_id, 1) as $field) {
        if ((int)$field['is_basic'] === 0) {
            $fields[(int)$field['id']] = $field;
        }
    }
    return $fields;
}

/**
 * The one response every asset record route gives for an asset the caller may
 * not see AND for one that does not exist (asset record modal, Task 4: the
 * product owner's rule that the modal never reveals a foreign-team asset).
 * Same status, same message, no data, so neither the status nor the body is
 * an existence oracle under Team Separation.
 */
function asset_record_not_available_response(): void
{
    global $escaper, $lang;
    require_once(realpath(__DIR__ . '/services.php'));
    json_response(404, $escaper->escapeHtml($lang['AssetNotAvailable']), NULL);
}

/**
 * One asset's audit-log entries (log_type 'asset'), newest first, from the
 * last $days days. write_log() stores the id minus 1000 in audit_log.risk_id,
 * so the lookup applies the same offset (get_audit_trail() only serves ids
 * above 1000, which most asset ids are not). Entity-less rows at stored id 0
 * carry other log types (see assets_discovery_write_audit()). The CALLER must have checked
 * check_access_for_asset().
 *
 * Messages are decrypted and entity-decoded once to plain text (some asset
 * messages are built with _lang(), which escapes its parameters before
 * storage): every string in the result is RAW text for text setters.
 *
 * @return array<int,array{timestamp:string,timestamp_display:string,message:string,user_id:int,user_name:?string}>
 */
function get_asset_audit_trail_entries(int $asset_id, int $days): array
{
    // Entity-less asset logs (discovery runs, the discovery settings) also sit
    // at stored id 0 -- where asset #1000's own rows land -- but under their
    // own log types ('asset_discovery', 'asset_settings'), which the
    // log_type = 'asset' filter below leaves out.
    $stored_id = $asset_id - 1000;

    $db = db_open();
    $stmt = $db->prepare("
        SELECT a.`timestamp`, a.`message`, a.`user_id`, u.`name` AS user_name
        FROM `audit_log` a
            LEFT JOIN `user` u ON u.`value` = a.`user_id`
        WHERE a.`risk_id` = :stored_id AND a.`log_type` = 'asset'
            AND a.`timestamp` > (NOW() - INTERVAL :days DAY)
        ORDER BY a.`timestamp` DESC, a.`id` DESC
        LIMIT 500
    ");
    $stmt->bindValue(':stored_id', $stored_id, PDO::PARAM_INT);
    $stmt->bindValue(':days', $days, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    db_close($db);

    $format = get_default_datetime_format("g:i A T");
    return array_map(static function (array $row) use ($format): array {
        $message = (string)try_decrypt((string)$row['message']);
        return [
            'timestamp' => (string)$row['timestamp'],
            'timestamp_display' => date($format, strtotime((string)$row['timestamp'])),
            'message' => html_entity_decode($message, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'user_id' => (int)$row['user_id'],
            'user_name' => $row['user_name'] === null ? null : (string)$row['user_name'],
        ];
    }, $rows);
}

/**
 * Whether every maturity in a [maturity => [control ids]] mapping is a real
 * control_maturity value and every control id a live (not deleted)
 * framework control. An empty mapping is valid.
 *
 * @param array<int,int[]> $mapping
 */
function asset_control_mapping_references_valid(array $mapping): bool
{
    if ($mapping === []) {
        return true;
    }

    $maturities = array_values(array_unique(array_map('intval', array_keys($mapping))));
    $controls = array_values(array_unique(array_map('intval', array_merge(...array_values($mapping)))));

    $db = db_open();
    $stmt = $db->prepare("SELECT COUNT(DISTINCT `value`) FROM `control_maturity` WHERE `value` IN (" . implode(',', array_fill(0, count($maturities), '?')) . ")");
    $stmt->execute($maturities);
    $maturities_ok = (int)$stmt->fetchColumn() === count($maturities);

    $controls_ok = false;
    if ($maturities_ok) {
        $stmt = $db->prepare("SELECT COUNT(DISTINCT `id`) FROM `framework_controls` WHERE `deleted` = 0 AND `id` IN (" . implode(',', array_fill(0, count($controls), '?')) . ")");
        $stmt->execute($controls);
        $controls_ok = (int)$stmt->fetchColumn() === count($controls);
    }
    db_close($db);

    return $maturities_ok && $controls_ok;
}

/**
 * The escaped-once 400 message for an asset_mapped_controls_from_request()
 * error key. The cap message takes the limit as a placeholder (_lang()
 * escapes the parameter; the lang text itself is trusted).
 */
function asset_mapped_controls_error_message(string $error_key): string
{
    global $escaper, $lang;
    if ($error_key === 'AssetMappedControlsTooMany') {
        return _lang('AssetMappedControlsTooMany', ['max' => ASSETS_MAX_MAPPED_CONTROLS]);
    }
    return $escaper->escapeHtml($lang[$error_key]);
}

/**
 * The control mapping a POST/PATCH /assets body asks for, fully validated
 * before anything is written: 'mapping' is null (body names none: leave it),
 * [] (explicit clear) or [maturity => [ids]]; 'error' is the lang key of the
 * 400 to answer instead, or null.
 *
 * @param array<string,mixed> $body
 * @return array{error:?string, mapping:?array}
 */
function asset_mapped_controls_from_request(array $body): array
{
    $parsed = assets_parse_mapped_controls_body($body);
    switch ($parsed['status']) {
        case 'absent':
            return ['error' => null, 'mapping' => null];
        case 'clear':
            return ['error' => null, 'mapping' => []];
        case 'too_many':
            return ['error' => 'AssetMappedControlsTooMany', 'mapping' => null];
        case 'ok':
            if (!validate_asset_control_mapping($parsed['mapping'])) {
                return ['error' => 'ControlMappedToDifferentMaturitiesOnAsset', 'mapping' => null];
            }
            if (!asset_control_mapping_references_valid($parsed['mapping'])) {
                return ['error' => 'AssetMappedControlsInvalid', 'mapping' => null];
            }
            return ['error' => null, 'mapping' => $parsed['mapping']];
        default:
            return ['error' => 'AssetMappedControlsInvalid', 'mapping' => null];
    }
}

/**
 * $scoring: Asset Scoring selections (objective => level code or null), only
 * the objectives the caller names. Refused (false, nothing written) while the
 * scoring columns are missing, and written FIRST, so a failed scoring write
 * fails the update before any other field changes. $scoring_writer is a test
 * seam (default asset_scoring_apply()).
 */
function update_asset($asset_id, $ip, $name, $value=null, $location=null, $teams=null, $details=null, $tags=null, $verified=null, $mapped_controls=[], $associated_risks=[], $skip_name_order_update = false, $custom_values = null, $scoring = null, ?callable $scoring_writer = null) {
    global $escaper, $lang;

    // Return false if the asset we try to update doesn't exist
    if (!asset_exists_by_id($asset_id)) {
        return false;
    }

    // Custom field values (custom_field[<id>] => value), null = not supplied.
    // Filtered to the fields of this asset's template group and checked for
    // an emptied required field BEFORE anything is written, so a refused edit
    // changes nothing.
    $custom_field_values = null;
    if (is_array($custom_values) && customization_extra()) {
        $split = assets_split_custom_field_input($custom_values, asset_custom_fields_by_id_for_asset((int)$asset_id));
        $rejection = assets_custom_field_rejection($split, true);
        if ($rejection !== null) {
            set_alert(true, "bad", $lang[$rejection]);
            return false;
        }
        $custom_field_values = $split['values'];
    }

    // A mapping naming a control or maturity that does not exist is refused
    // before any write as well.
    if (is_array($mapped_controls) && !asset_control_mapping_references_valid($mapped_controls)) {
        set_alert(true, "bad", $lang['AssetMappedControlsInvalid']);
        return false;
    }

    // Asset Scoring while the database upgrade is pending: refused before any
    // write (the API handlers answer this case themselves, earlier).
    $scoring = is_array($scoring) ? $scoring : [];
    if (asset_scoring_write_refusal($scoring, asset_scoring_schema_ready()) !== null) {
        asset_scoring_log_once('schema_pending_refused', 'Asset scoring: a save carrying scoring selections was refused because the assets table has no scoring columns yet. Run the SimpleRisk database upgrade.', 'notice');
        set_alert(true, "bad", $lang['AssetScoringUpgradePending']);
        return false;
    }

    // The columns store CSV; an array (the v2 PATCH body) is imploded here the
    // way add_asset() does it.
    if (is_array($location)) {
        $location = assets_id_csv($location);
    }
    if (is_array($teams)) {
        $teams = assets_id_csv($teams);
    }

    // Make sure we're not updating something that doesn't need updating
    /*$risk_association_unchanged = array_equal($associated_risks, get_associated_risks_for_asset($asset_id));
    if (asset_exists_exact($ip, $name, $value, $location, $teams, $details, $verified) && areTagsEqual($asset_id, 'asset', $tags) && asset_control_mapping_exact_match($asset_id, $mapped_controls) && $risk_association_unchanged) {
        return false;
    }*/

    // Check if the name we want to update TO is held by ANOTHER asset. The
    // asset is never compared with itself. The name is trimmed before the
    // check AND before it is stored (SR-37, as add_asset() does); a blank
    // name is refused (asset_name_for_edit()).
    if (!is_null($name)) {
        $name = asset_name_for_edit($name, (int)$asset_id);
        if ($name === null) {
            return false;
        }
    }

    // SR-2310: a save that changes nothing writes no audit line and fires no
    // asset.updated event. Only after every refusal above, so those still apply.
    if (asset_update_is_noop((int)$asset_id, $ip, $name, $value, $location, $teams, $details, $tags, $verified, $mapped_controls, $associated_risks, $custom_field_values, $scoring)) {
        return true;
    }

    $encryption_extra = encryption_extra();
    $notification_extra = notification_extra();



    // Store the original asset for later, but only if we'll actually use it
    if ($encryption_extra && !$skip_name_order_update) {
        $original_asset = get_asset_by_id($asset_id);
    }

    // Asset Scoring first, each change audited: if the write fails (a
    // database error) the update fails here, before any other field is
    // written, instead of reporting success for a partial save. An empty set
    // (a body naming no objective) skips it.
    if ($scoring) {
        try {
            $applied = ($scoring_writer ?? 'asset_scoring_apply')((int)$asset_id, $scoring, true);
        } catch (\Throwable $e) {
            $applied = null;
            write_debug_log("Asset scoring: saving the scoring selections of asset {$asset_id} failed: " . get_class($e) . " [" . (string)$e->getCode() . "]", 'error');
        }
        if ($applied === null) {
            set_alert(true, "bad", $lang['ThereWasAProblemUpdatingTheAsset']);
            return false;
        }
    }

    // A verified asset whose identity (name or IP) is changed by a user who
    // cannot verify goes back to unverified. Callers that pass an explicit
    // $verified (integrations re-sending the existing value) are not overridden.
    $unverified_by_identity_edit = false;
    if (is_null($verified) && asset_edit_demotes_verification((int)$asset_id, $name, $ip)) {
        $verified = 0;
        $unverified_by_identity_edit = true;
    }

    $ip = is_null($ip)?null:try_encrypt($ip);
    $details = is_null($details)?null:try_encrypt($details);

    $data = array(
        "ip"                    => $ip,
        // null = "leave alone"; encrypting null would store a ciphertext of "" and blank the name
        "name"                  => is_null($name) ? null : try_encrypt($name),
        "value"                 => $value,
        "location"              => $location,
        "teams"                 => $teams,
        "details"               => $details,
        "verified"              => $verified,
    );

    $set_clauses = array();
    foreach($data as $key => $val){
        if(!is_null($val))
            $set_clauses[] = " {$key}=:{$key} ";
    }

    // Only run the UPDATE when at least one column actually changes. A caller
    // that names none of these columns -- e.g. PATCH /assets/{id} carrying only
    // `associated_risks` or `tags`, both of which are handled below rather than
    // in the assets row -- would otherwise produce
    // `UPDATE assets SET  WHERE id = :id` and fail with a SQL syntax error
    // (SQLSTATE 42000) instead of updating the associations it was asked to.
    if ($set_clauses) {
        $sql = "UPDATE assets SET " . implode(",", $set_clauses) . " WHERE id = :id ";

        // Open the database connection
        $db = db_open();

        // Update the risk
        $stmt = $db->prepare($sql);
        $stmt->bindParam(":id", $asset_id, PDO::PARAM_INT);
        foreach($data as $key => $val){
            if(!is_null($val)){
                $stmt->bindParam(":{$key}", $data[$key]);
            }
            unset($val);
        }

        $stmt->execute();

        // Close the database connection
        db_close($db);
    }

    if(!is_null($mapped_controls)) {
        save_asset_to_controls($asset_id, $mapped_controls);
    }

    // Validated above with save_custom_field_values()'s own emptiness rule, so
    // a false here is unexpected (a database error) -- report it, don't
    // swallow it.
    if (!empty($custom_field_values)) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        if (!save_custom_field_values($asset_id, "asset", $custom_field_values)) {
            write_debug_log("Saving the custom field values of asset {$asset_id} failed after validation.", 'error');
            return false;
        }
    }

    updateTagsOfType($asset_id, 'asset', $tags);

    // Storing the current list of associated risks, so we can calculate the list of risk changes for the risk update notification
    $associated_risks_original = get_associated_risks_for_asset($asset_id);

    // null means "the caller did not name this field" -- same convention the
    // scalar columns above already use. Without this guard a null would fall
    // through array_equal() (which is false for a non-array) into
    // update_asset_risks_associations(), which deletes every association and
    // then fatals on `foreach (null)`. An explicitly-sent empty array is a
    // different thing and still clears the associations.
    if (!is_null($associated_risks) && !array_equal($associated_risks, $associated_risks_original)) {
        update_asset_risks_associations($asset_id, $associated_risks);

        if ($notification_extra) {
            require_once(realpath(__DIR__ . '/../extras/notification/index.php'));

            // Get what risks were removed or added for the notification. We can ignore those that weren't changed
            $associated_risks_need_notified = array_unique(array_merge(array_diff($associated_risks, $associated_risks_original), array_diff($associated_risks_original, $associated_risks)));

            // Only send the notification about the updated risks that were changed on the asset
            if (!empty($associated_risks_need_notified)) {
                foreach ($associated_risks_need_notified as $risk_id) {
                    notify_risk_update($risk_id);
                }
            }
        }
    }

    // If the encryption extra is enabled, updates order_by_name
    // get_asset_by_id() returns the stored (encrypted) name, so compare it
    // decrypted: comparing ciphertext with the new plaintext was always
    // "changed" and re-ordered the bucket on every save.
    if (!$skip_name_order_update && !is_null($name) && $encryption_extra && isset($original_asset) && try_decrypt($original_asset['name']) !== $name) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
        update_name_order_for_asset($asset_id, $name);
    }


    // A partial update (PATCH without a name, e.g. verify/unverify) names the
    // asset by its stored name instead of logging `Asset ""`.
    $log_name = is_null($name) ? (string)get_name_by_value('assets', $asset_id, '', true) : $name;

    $message = "Asset \"" . $log_name . "\" was modified by user \"" . $_SESSION['user'] . "\".";
    write_log($asset_id, $_SESSION['uid'] ?? 0, $message, "asset");

    if ($unverified_by_identity_edit) {
        asset_write_unverified_by_edit_log((int)$asset_id, $log_name);
    }

    trigger_workflow_event('asset.updated', [
        'asset_id' => $asset_id,
        'name'     => $name,
    ]);

    return true;
}

/**
 * SR-2310: loads the stored asset and asks assets_update_has_changes() whether
 * the update_asset() arguments differ from it. Arguments are as update_asset()
 * holds them at that point (name already trimmed, location / teams as CSV,
 * $custom_field_values already split and filtered). Any doubt answers "not a
 * no-op".
 *
 * @param array<int,mixed>|null $custom_field_values
 * @param array<string,?string> $scoring
 */
function asset_update_is_noop(int $asset_id, $ip, $name, $value, $location, $teams, $details, $tags, $verified, $mapped_controls, $associated_risks, ?array $custom_field_values, array $scoring): bool
{
    $row = get_asset_by_id($asset_id);
    if (!$row) {
        return false;
    }

    $stored = [
        'ip'       => try_decrypt($row['ip']),
        'name'     => try_decrypt($row['name']),
        'details'  => try_decrypt($row['details']),
        'value'    => $row['value'],
        'location' => $row['location'],
        'teams'    => $row['teams'],
        'verified' => $row['verified'],
        'tags'     => (array)getTagsOfTaggee($asset_id, 'asset'),
        'controls' => get_existing_mapped_controls_for_asset($asset_id),
        'risks'    => get_associated_risks_for_asset($asset_id),
        'custom'   => [],
        'scoring'  => [],
    ];
    $submitted = [
        'ip' => $ip, 'name' => $name, 'details' => $details, 'value' => $value,
        'location' => $location, 'teams' => $teams, 'verified' => $verified,
        'tags' => $tags, 'controls' => $mapped_controls, 'risks' => $associated_risks,
    ];

    if ($scoring) {
        foreach (array_keys($scoring) as $objective) {
            $stored['scoring'][$objective] = $row[$objective] ?? null;
        }
        $submitted['scoring'] = $scoring;
    }

    if (!empty($custom_field_values)) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $fields = [];
        foreach (get_custom_fields('asset') as $field) {
            $fields[(int)$field['id']] = $field;
        }
        $db = db_open();
        $stmt = $db->prepare("SELECT `field_id`, `value` FROM `custom_asset_data` WHERE `asset_id` = :asset_id");
        $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
        $stmt->execute();
        $stored_rows = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        db_close($db);

        $submitted['custom'] = [];
        foreach ($custom_field_values as $field_id => $custom_value) {
            $field_id = (int)$field_id;
            if (!isset($fields[$field_id])) {
                return false;
            }
            $field = $fields[$field_id];
            if (is_array($custom_value)) {
                $custom_value = implode(",", $custom_value);
            }
            if ($field['type'] == "date") {
                // Same conversion save_custom_field_values() applies
                $custom_value = get_standard_date_from_default_format($custom_value);
                if ($custom_value == "0000-00-00") {
                    $custom_value = "";
                }
            } elseif ($field['required'] == 1) {
                $custom_value = trim((string)$custom_value);
            }
            $submitted['custom'][$field_id] = $custom_value;
            $stored['custom'][$field_id] = array_key_exists($field_id, $stored_rows)
                ? decrypt_custom_value_for_compare($field, $stored_rows[$field_id])
                : null;
        }
    }

    return !assets_update_has_changes($stored, $submitted);
}

/**
 * Stored custom value as plain text: only the Encryption Extra encrypts them.
 */
function decrypt_custom_value_for_compare(array $field, $stored_value)
{
    if (encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
        return decrypt_custom_value($field, $stored_value);
    }
    return $stored_value;
}

/**
* Returns the list of risk ids that are associated to the asset
*/
function get_associated_risks_for_asset($asset_id) {
    
    // Open the database connection
    $db = db_open();
    
    $stmt = $db->prepare("SELECT `risk_id` FROM `risks_to_assets` WHERE `asset_id` = :asset_id;");
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $risk_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Close the database connection
    db_close($db);
    
    return $risk_ids;
}

function update_asset_risks_associations($asset_id, $associated_risks) {
    // Open the database connection
    $db = db_open();

    // Resolve before any mutation -- also needed for the AI cache invalidation
    // list below. Deliberately unfiltered by Team Separation: cache
    // invalidation is system bookkeeping, not a user-facing read (see
    // risks_associated_with()'s docblock), and it includes indirect
    // (asset-group) risk associations that this function never writes to.
    $previously_associated = risks_associated_with('asset', (int)$asset_id, $db);

    // SR-2027: every caller of this function has already authorized the
    // asset itself (check_access_for_asset()), but not the risk ids being
    // attached to -- or detached from -- it. Without a per-risk check here, a
    // caller with only Asset permission could use their asset-edit access to
    // create, or silently remove, a cross-team risk<->asset edge for a risk
    // they cannot see. filter_accessible_risk_ids() authorizes each risk id
    // individually and drops any risk the caller cannot see -- fail-open when
    // Team Separation is off, so behavior is unchanged on the base product.
    $authorized_risks = filter_accessible_risk_ids($associated_risks);

    // Only remove the direct associations the caller can actually see. A
    // wholesale DELETE would let a caller unlink a hidden cross-team risk
    // simply by omitting it from $associated_risks.
    $current_direct_risks = get_associated_risks_for_asset($asset_id);
    $removable_risks = filter_accessible_risk_ids($current_direct_risks);

    if (!empty($removable_risks)) {
        $placeholders = implode(',', array_fill(0, count($removable_risks), '?'));
        $stmt = $db->prepare("DELETE FROM `risks_to_assets` WHERE `asset_id` = ? AND `risk_id` IN ($placeholders);");
        $stmt->bindValue(1, $asset_id, PDO::PARAM_INT);
        $i = 2;
        foreach ($removable_risks as $risk_id) {
            $stmt->bindValue($i++, (int)$risk_id, PDO::PARAM_INT);
        }
        $stmt->execute();
    }

    foreach($authorized_risks as $risk_id){
        $stmt = $db->prepare("INSERT INTO `risks_to_assets` (asset_id, risk_id) VALUES (:asset_id, :risk_id);");
        $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
        $stmt->bindParam(":risk_id", $risk_id, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Both sides of the swap changed: risks that lost the asset and risks that
    // gained it.
    ai_invalidate_risk_analysis(
        array_merge($previously_associated, $authorized_risks),
        $db
    );

    // Close the database connection
    db_close($db);
}

/***************************************
 * FUNCTION: SAVE CONTROL TO FRAMEWORK *
 ***************************************/
function save_control_to_assets($control_id, $mapped_assets)
{
    // Open the database connection
    $db = db_open();

    // Delete all current control asset relations
    $stmt = $db->prepare("DELETE FROM `control_to_assets` WHERE control_id=:control_id;");
    $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
    $stmt->execute();
    // Delete all current control asset group relations
    $stmt = $db->prepare("DELETE FROM `control_to_asset_groups` WHERE control_id=:control_id;");
    $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
    $stmt->execute();

    foreach($mapped_assets as $row){
        $control_maturity = $row[0];
        $assets_and_groups = $row[1];
        // For each asset or group
        foreach ($assets_and_groups as $value)
        {
            // Trim whitespaces
            $value = trim($value);
            
            // Selected an existing asset or group
            if (preg_match('/^([\d]+)_(group|asset)$/', $value, $matches)) {
                list(, $id, $type) = $matches;
            } elseif (preg_match('/^new_asset_(.*)$/', $value, $matches)) { // Entered the name of a new asset
                $name = trim($matches[1]);
                // Check if the asset already exists, but not verified(since it didnt show up in the widget)
                $id = asset_exists($name);

                if ($id) {
                    set_alert(true, "bad", _lang('ErrorAssetAlreadyExistsAsVerified', array('asset_name' => $name)));
                    continue;
                }
                // Add new asset
                $id = add_asset('', $name);
                $type = 'asset';                
            } else {
                //Invalid input
                continue;
            }

            // SR-2032: $id here is client-controlled (posted as
            // "<id>_asset"/"<id>_group" in $mapped_assets). The caller's
            // Modify Controls permission authorizes acting on the control,
            // not on an arbitrary cross-team asset id, so a Team A user with
            // only control-management access could otherwise map -- and
            // thereby disclose -- a hidden Team B asset. check_access_for_
            // asset() is fail-open when Team Separation is off, so behavior
            // is unchanged on the base product.
            if ($type=='asset' && !check_access_for_asset($id)) {
                continue;
            }

            if ($type=='asset' && !get_exist_mapping_asset_control($id, $control_id, $control_maturity)) {
                $stmt = $db->prepare("INSERT INTO `control_to_assets` (asset_id, control_id, control_maturity) VALUES (:asset_id, :control_id, :control_maturity)");
                $stmt->bindParam(":asset_id", $id, PDO::PARAM_INT);
                $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
                $stmt->bindParam(":control_maturity", $control_maturity, PDO::PARAM_INT);
                $stmt->execute();
            } elseif ($type=='group' && !get_exist_mapping_asset_control($id, $control_id, $control_maturity, 'group')) {
                $stmt = $db->prepare("INSERT INTO `control_to_asset_groups` (asset_group_id, control_id, control_maturity) VALUES (:asset_group_id, :control_id, :control_maturity)");
                $stmt->bindParam(":asset_group_id", $id, PDO::PARAM_INT);
                $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
                $stmt->bindParam(":control_maturity", $control_maturity, PDO::PARAM_INT);
                $stmt->execute();
            }
        }

    }
    // Close the database connection
    db_close($db);  
}
/************************************
 * FUNCTION: SAVE ASSET TO CONTROLS *
 ************************************/
function save_asset_to_controls($asset_id, $control_mappings)
{
    // Open the database connection
    $db = db_open();

    // Delete all current asset control relations
    $stmt = $db->prepare("DELETE FROM `control_to_assets` WHERE asset_id=:asset_id;");
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->execute();
    
    foreach($control_mappings as $maturity_id => $control_ids){
        foreach($control_ids as $control_id){
            if(!get_exist_mapping_asset_control($asset_id, $control_id, $maturity_id)){
                $stmt = $db->prepare("INSERT INTO `control_to_assets` (asset_id, control_id, control_maturity) VALUES (:asset_id, :control_id, :control_maturity)");
                $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
                $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
                $stmt->bindParam(":control_maturity", $maturity_id, PDO::PARAM_INT);
                $stmt->execute();
            }
        }

    }
    // Close the database connection
    db_close($db);
    return; 
}

/**
 * Get the existing control mapping for an asset
 * In the response control ids are grouped by the maturity ids.
 *
 * @param int $asset_id
 * @return array
 */
function get_existing_mapped_controls_for_asset(int $asset_id): array
{
    $db = db_open();
    // Get the existing mapped controls for this asset grouped by maturity
    $stmt = $db->prepare("SELECT `control_maturity`, `control_id` FROM `control_to_assets` WHERE `asset_id`=:asset_id");
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_COLUMN);
}

/*********************************************
 * FUNCTION: GET EXIST MAPPING ASSET CONTROL *
 *********************************************/
function get_exist_mapping_asset_control($asset_or_group_id, $control_id, $control_maturity, $type = 'asset')
{
    // Open the database connection
    $db = db_open();
    if($type == 'group') {
        $tbl_name = 'control_to_asset_groups';
        $junction_id_name = 'asset_group_id';
    } else {
        $tbl_name = 'control_to_assets';
        $junction_id_name = 'asset_id';
    }
    $sql = "SELECT * FROM `{$tbl_name}`  WHERE {$junction_id_name} = :asset_or_group_id AND control_id = :control_id AND control_maturity = :control_maturity;";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(":asset_or_group_id", $asset_or_group_id, PDO::PARAM_INT);
    $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
    $stmt->bindParam(":control_maturity", $control_maturity, PDO::PARAM_INT);
    $stmt->execute();
    $mappings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);
    return $mappings;
}
/**********************************************
 * FUNCTION: GET MAPPING CONTROLS BY ASSET ID *
 **********************************************/
function get_mapping_controls_by_asset_id($asset_id)
{
    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("
        SELECT cta.*, cm.name control_maturity_name, c.short_name control_name
        FROM control_to_assets cta 
        LEFT JOIN control_maturity cm ON cta.control_maturity = cm.value
        LEFT JOIN framework_controls c ON c.id = cta.control_id
        WHERE asset_id=:asset_id ORDER BY id;
    ");
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->execute();

    $rows = $stmt->fetchALL(PDO::FETCH_ASSOC);

    // Close the database connection
    db_close($db);

    return $rows;
}
/*********************************************************************
 * FUNCTION: GET MAPPED-ASSET SEARCH TEXT FOR A SET OF CONTROLS      *
 *********************************************************************
 * The mapped-asset text of MANY controls at once, as [control_id => "text"].
 * The batched counterpart of calling get_control_to_assets() once per control,
 * which is what the control table's free-text search was doing -- one database
 * connection and one query per control, for every control that did not match a
 * core field. On a 1,001-control catalogue that was 409ms of a 2,951ms search.
 *
 * Text-for-searching only, NOT a batched get_control_to_assets(): that function
 * returns per-maturity rows and is shaped for rendering. The search only ever
 * looked at three strings on those rows -- the maturity name, the asset names
 * and the asset-group names -- so this returns exactly those, joined, and skips
 * reproducing the row structure (and its delicate GROUP BY) altogether.
 *
 * Asset names are decrypted and asset-group names are not, mirroring
 * get_control_to_assets() exactly -- `assets` is in
 * $tables_where_name_is_encrypted and `asset_groups` is not.
 *
 * Injection-safe: every id is (int)-cast before it reaches the string, so the
 * interpolated IN list can only contain digits and commas.
 *
 * @param array $control_ids the controls to read
 * @return array [control_id => searchable text]; controls with no mappings are absent
 *********************************************************************/
function get_control_to_assets_search_text(array $control_ids)
{
    $ids = [];
    foreach ($control_ids as $control_id) {
        $control_id = (int)$control_id;
        if ($control_id) {
            // Keyed, so duplicates cannot widen the IN list.
            $ids[$control_id] = $control_id;
        }
    }

    if (!$ids) {
        return [];
    }

    $id_list = implode(',', $ids);

    // Open the database connection
    $db = db_open();

    $parts = [];

    // Directly-mapped assets.
    $stmt = $db->query("
        SELECT c2a.control_id, cm.name AS maturity_name, assets.name AS asset_name
        FROM control_to_assets c2a
            LEFT JOIN control_maturity cm ON cm.value = c2a.control_maturity
            LEFT JOIN assets ON assets.id = c2a.asset_id
        WHERE c2a.control_id IN ({$id_list});
    ");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $control_id = (int)$row['control_id'];
        $parts[$control_id][] = (string)$row['maturity_name'];
        $parts[$control_id][] = try_decrypt((string)$row['asset_name']);
    }

    // Assets reached through an asset group.
    $stmt = $db->query("
        SELECT c2ag.control_id, cm.name AS maturity_name, ag.name AS asset_group_name
        FROM control_to_asset_groups c2ag
            LEFT JOIN control_maturity cm ON cm.value = c2ag.control_maturity
            LEFT JOIN asset_groups ag ON ag.id = c2ag.asset_group_id
        WHERE c2ag.control_id IN ({$id_list});
    ");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $control_id = (int)$row['control_id'];
        $parts[$control_id][] = (string)$row['maturity_name'];
        $parts[$control_id][] = (string)$row['asset_group_name'];
    }

    // Close the database connection
    db_close($db);

    $search_text = [];
    foreach ($parts as $control_id => $texts) {
        $texts = array_filter(array_map('trim', $texts), function ($text) {
            return $text !== "";
        });
        if ($texts) {
            $search_text[$control_id] = implode("\n", $texts);
        }
    }

    return $search_text;
}

/**********************************************
 * FUNCTION: GET MAPPING ASSETS BY CONTROL ID *
 **********************************************/
function get_control_to_assets($control_id)
{
    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("
        SELECT
            cm.value control_maturity,
            cm.name control_maturity_name,
            GROUP_CONCAT(DISTINCT c2a.asset_id),
            GROUP_CONCAT(DISTINCT assets.name) asset_name,
            GROUP_CONCAT(DISTINCT c2ag.asset_group_id),
            GROUP_CONCAT(DISTINCT ag.name) asset_group_name
        FROM control_maturity cm 
            LEFT JOIN control_to_assets c2a ON cm.value = c2a.control_maturity AND c2a.control_id=:control_id
            LEFT JOIN assets ON assets.id = c2a.asset_id
            LEFT JOIN control_to_asset_groups c2ag ON cm.value = c2ag.control_maturity AND c2ag.control_id=:control_id
            LEFT JOIN asset_groups ag ON ag.id = c2ag.asset_group_id
        WHERE
            c2a.control_id=:control_id
            OR c2ag.control_id=:control_id
        GROUP BY
            c2a.control_maturity
        ORDER BY
            c2a.id;
    ");
    $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
    $stmt->execute();

    $rows = $stmt->fetchALL(PDO::FETCH_ASSOC);
    // decrypt data
    foreach($rows as &$row){
        $asset_name = explode(',', (string)$row['asset_name']);
        $asset_name_str = implode(", ", array_map(function($name){
            return try_decrypt($name);
        }, $asset_name));
        // Try to decrypt the asset name
        $row['asset_name'] = $asset_name_str;
    }

    // Close the database connection
    db_close($db);

    return $rows;
}


/**
 * Returns whether the asset has the exact same control mappings as the one provided
 * 
 * @param int $asset_id the id of the asset
 * @param array $control_mapping the control mapping in a format of {maturity_id1:[control_id1, control_id2, ...], ...}
 * @return boolean
 */
function asset_control_mapping_exact_match($asset_id, $control_mapping){
    
    $db = db_open();
    
    // Get the asset's control mapping
    $stmt = $db->prepare("				
        SELECT
            CONCAT('{', GROUP_CONCAT(DISTINCT `cm`.`data` ORDER BY `cm`.`data` SEPARATOR ','), '}')
        FROM
            (SELECT
            	`a`.`id` AS asset_id,
            	CONCAT(
                    '\"', `cta`.`control_maturity`, '\":', JSON_ARRAYAGG(`cta`.`control_id`)
                ) as data
            FROM
            	`assets` a
            	LEFT JOIN `control_to_assets` cta ON `cta`.`asset_id` = `a`.`id`
            WHERE
            	`cta`.`id` IS NOT NULL
                and `a`.`id` = :asset_id
            GROUP BY
            	`a`.`id`,
            	`cta`.`control_maturity`
            ORDER BY
            	`a`.`id`) cm
        GROUP BY `cm`.`asset_id`
    ");
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->execute();
    $asset_control_mapping = $stmt->fetchColumn();
    
    // Close the database connection
    db_close($db);
    
    // If we're comparing two empty lists then it's an exact match
    if (empty($asset_control_mapping) && empty($control_mapping)) {
        return true;
    }

    // If one is empty, but the other isn't, then they can't be the same(obviously)
    if (empty($asset_control_mapping) != empty($control_mapping)) {
        return false;
    }

    // decode the string into an array
    $asset_control_mapping = json_decode($asset_control_mapping, true);

    // If the number of elements doesn't match, return false
    if (count($asset_control_mapping) != count($control_mapping)) {
        return false;
    }

    
    // Flatten the mnulti-dimensional arrays so we can easily compare the composition of the two
    // Example:  {1:[3, 5], 3:[3, 5]} => ["1:3", "1:5", "3:3", "3:5"]
    $flat_asset_control_mapping = [];
    $flat_control_mapping = [];
    foreach ($control_mapping as $maturity => $control_ids) {
        foreach ($control_ids as $control_id) {
            $flat_control_mapping []= "{$maturity}:{$control_id}";
        }
    }
    foreach ($asset_control_mapping as $maturity => $control_ids) {
        foreach ($control_ids as $control_id) {
            $flat_asset_control_mapping []= "{$maturity}:{$control_id}";
        }
    }

    // If the number of elements doesn't match, return false. It's ifferent from the previous similar check, because that only checked the number
    // of groups when it was grouped by maturity id. This one is the number of the all the controls involved.
    if (count($flat_asset_control_mapping) != count($flat_control_mapping)) {
        return false;
    }

    // To properly check the diff of two arrays we have to check both directions
    return array_diff($flat_asset_control_mapping, $flat_control_mapping) == array_diff($flat_control_mapping, $flat_asset_control_mapping);
}

/*******************************
 * FUNCTION: DELETE ALL ASSETS *
 *******************************/
function delete_all_assets($verified = false) {
    try {
        // Open the database connection
        $db = db_open();

        // Get the names of the affected assets to be able to log which ones got deleted/discarded
        $stmt = $db->prepare("SELECT `id`, `name` FROM `assets` WHERE `verified` = :verified;");
        $stmt->bindParam(":verified", $verified, PDO::PARAM_INT);
        $stmt->execute();
        $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($assets)) {
            return false;
        }

        // Delete the assets
        $stmt = $db->prepare("DELETE FROM `assets` WHERE `verified` = :verified;");
        $stmt->bindParam(":verified", $verified, PDO::PARAM_INT);
        $stmt->execute();

        // Close the database connection
        db_close($db);

        // If customization extra is enabled, delete custom_asset_data related with asset ID
        if(customization_extra()) {
            require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
            foreach ($assets as $asset) {
                delete_custom_data_by_row_id($asset['id'], "asset");
            }
        }

        // Clean up after the delete
        cleanup_after_delete('assets');

        // Write a log for each asset deleted
        foreach ($assets as $asset) {
            $message = _lang($verified ? 'AssetDeletedLog' : 'AssetDiscardedLog', [
                'name' => try_decrypt($asset['name']),
                'user' => $_SESSION['user']
            ]);
            write_log($asset['id'], $_SESSION['uid'] ?? 0, $message, "asset");
        }
        return true;
    } catch (Exception $e) {
        // Log the exception and return false
        write_debug_log($e, 'error');
        return false;
    }}

/**************************
 * FUNCTION: DELETE ASSET *
 **************************/
function delete_asset($asset_id) {
    
    // Open the database connection
    $db = db_open();

    // Get the name BEFORE deleting the asset
    $name = get_name_by_value('assets', $asset_id, "", true);

    // Delete the assets entry
    $stmt = $db->prepare("DELETE FROM `assets` WHERE `id`=:id;");
    $stmt->bindParam(":id", $asset_id, PDO::PARAM_INT);
    $return = $stmt->execute();

    // Close the database connection
    db_close($db);

    // Delete custom_asset_data related with asset ID (no-op if customization extra is disabled)
    call_extra_function(
        'customization_extra',
        __DIR__ . '/../extras/customization/index.php',
        'delete_custom_data_by_row_id',
        [$asset_id, "asset"]
    );

    // Clean up after the delete
    cleanup_after_delete('assets');

    $message = _lang('AssetDeletedLog', [
        'name' => $name,
        'user' => $_SESSION['user']
    ]);

    write_log($asset_id, $_SESSION['uid'] ?? 0, $message, "asset");

    trigger_workflow_event('asset.deleted', [
        'asset_id' => $asset_id,
        'name'     => $name,
    ]);

    // Return success or failure
    return $return;
}


/*******************************
 * FUNCTION: VERIFY ALL ASSETS *
 *******************************/
function verify_all_assets() {
    try {
        // Open the database connection
        $db = db_open();
        
        // Get the names of the not verified assets to be able to log which ones got verified
        $stmt = $db->prepare("SELECT `id`, `name` FROM `assets` WHERE `verified` = 0;");
        $stmt->execute();
        $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($assets)) {
            return false;
        }

        // Verify the unverified assets
        $stmt = $db->prepare("UPDATE `assets` SET `verified` = 1 WHERE `verified` = 0;");
        $stmt->execute();

        // Close the database connection
        db_close($db);

        // Write a log for each asset verified
        foreach ($assets as $asset) {
            $message = _lang('AssetVerifiedLog', [
                'name' => try_decrypt($asset['name']),
                'user' => $_SESSION['user']
            ]);
            write_log($asset['id'], $_SESSION['uid'] ?? 0, $message, "asset");
        }

        return true;
    } catch (Exception $e) {
        // Log the exception and return false
        error_log($e);
        return false;
    }
}

/**************************
 * FUNCTION: VERIFY ASSET *
 **************************/
function verify_asset($asset_id)
{
    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("UPDATE `assets` SET `verified` = 1 WHERE `id` = :id");
    $stmt->bindParam(":id", $asset_id, PDO::PARAM_INT);
    $return = $stmt->execute();

    // Close the database connection
    db_close($db);

    $message = _lang('AssetVerifiedLog', [
        'name' => get_name_by_value('assets', $asset_id, "", true),
        'user' => $_SESSION['user']
    ]);

    write_log($asset_id, $_SESSION['uid'] ?? 0, $message, "asset");

    // Return success or failure
    return $return;
}

/********************************
 * FUNCTION: GET ENTERED ASSETS *
 ********************************/
function get_entered_assets($verified=null)
{
    // Open the database connection
    $db = db_open();

    $params = [];

    if ($verified !== null) {
        $where = " WHERE `a`.`verified`=:verified";
        $params['verified'] = $verified;
    } else $where = " WHERE 1";

    $where .= call_extra_function(
        'team_separation_extra',
        __DIR__ . '/../extras/separation/index.php',
        'get_user_teams_query_for_assets',
        ['a', false, true],
        ''
    );

    if (encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }

    $stmt = $db->prepare("
        SELECT
            a.*,
            GROUP_CONCAT(DISTINCT tg.tag ORDER BY tg.tag ASC SEPARATOR ',') as tags
        FROM
            `assets` a
            LEFT JOIN tags_taggees tt ON tt.taggee_id = a.id AND tt.type = 'asset'
            LEFT JOIN tags tg on tg.id = tt.tag_id
        {$where}
        GROUP BY
            a.id
        ORDER BY
            a.id, " . (encryption_extra() ? "a.order_by_name" : "a.name") . "
    ;");
    $stmt->execute($params);

    // Store the list in the assets array
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Sort by name, ignoring case. The column holds ciphertext when the
    // Encryption Extra is on, so sort on the decrypted value (SR-37); the rows
    // themselves are returned as stored, and callers decrypt.
    $keys = array_map(fn($asset) => mb_strtolower(trim((string)try_decrypt($asset['name']))), $assets);
    array_multisort($keys, SORT_ASC, SORT_STRING, $assets);

    // Close the database connection
    db_close($db);

    // Return the array of assets
    return $assets;
}

/***********************************
 * FUNCTION: GET VERIFIED ASSETS *
 ***********************************/
function get_verified_assets()
{
    return get_entered_assets(true);
}

/*****************************
 * FUNCTION: GET ASSET BY ID *
 *****************************/
function get_asset_by_id($id)
{
    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("
        SELECT a.*,
            GROUP_CONCAT(DISTINCT tg.tag ORDER BY tg.tag ASC SEPARATOR ',') as tags
        FROM
            `assets` a
            LEFT JOIN tags_taggees tt ON tt.taggee_id = a.id AND tt.type = 'asset'
            LEFT JOIN tags tg on tg.id = tt.tag_id
        where a.id=:id
        GROUP BY
            a.id
        ORDER BY name;
        ");
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();

    // Store the list in the assets array
    $asset = $stmt->fetch(PDO::FETCH_ASSOC);

    // Close the database connection
    db_close($db);

    // Return the array of assets
    return $asset;
}

/*****************************************
 * FUNCTION: TAG AFFECTED ASSETS TO RISK *
 *****************************************/
function tag_assets_to_risk($risk_id, $assets, $entered_assets=false)
{
    if($entered_assets === false)
    {
        $entered_assets = get_entered_assets();
    }

    // Create an array from the assets
    $assets = explode(",", $assets);

    // Open the database connection
    $db = db_open();

    // Clear any current assets for this risk
    $stmt = $db->prepare("DELETE FROM `risks_to_assets` WHERE risk_id = :risk_id");
    $stmt->bindParam(":risk_id", $risk_id, PDO::PARAM_INT);
    $stmt->execute();

    // For each asset
    foreach ($assets as $asset)
    {
        // Trim whitespace
        $asset = trim($asset);
        
        // If the asset is not null
        if ($asset != "")
        {
            $asset_id = false;
            foreach($entered_assets as $entered_asset){
                if($asset == try_decrypt($entered_asset['name'])){
                    $asset_id = $entered_asset['id'];
                    break;
                }
            }
            if(!$asset_id){
                $asset_id = add_asset('', $asset);
            }

            // Add the new assets for this risk
            $stmt = $db->prepare("INSERT INTO `risks_to_assets` (`risk_id`, `asset_id`) VALUES (:risk_id, :asset_id)");
            $stmt->bindParam(":risk_id", $risk_id, PDO::PARAM_INT);
            $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
            $stmt->execute();
        }
    }

    // Add the asset_id column to risks_to_assets
    //$stmt = $db->prepare("UPDATE `risks_to_assets` INNER JOIN `assets` ON `assets`.name = `risks_to_assets`.asset SET `risks_to_assets`.asset_id = `assets`.id;");
    //$stmt->execute();

    // The risk's attached assets are part of its AI context.
    ai_invalidate_risk_analysis([(int)$risk_id], $db);

    // Close the database connection
    db_close($db);
}

/**************************************
 * FUNCTION: DISPLAY EDIT ASSET TABLE *
 **************************************/
function display_edit_asset_table()
{
    global $lang;
    global $escaper;
    $tags_active = false;

    // If the customization extra is enabled, shows fields by asset customization
    if (customization_extra())
    {
        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $active_fields = get_active_fields("asset");

        foreach($active_fields as $field) {
            if($field['is_basic'] == 1 && $field['name'] === 'Tags') {
                $tags_active = true;
                break;
            }
        }

        $customization = true;
    } else {
        $customization = false;
        $tags_active = true;
    }

    if ($tags_active == true) {
        echo "<div class='tag-max-length-warning'>" . $escaper->escapeHtml($lang['MaxTagLengthWarning']) . "</div>\n";
    }

    echo "<table id=\"edit-assets-table\" class=\"table table-bordered table-condensed sortable\">\n";

    // Display the table header
    echo "<thead>\n";
    echo "<tr>\n";
    
    // If the customization extra is enabled, shows fields by asset customization
    if ($customization)
    {
        // @phan-suppress-next-line PhanPossiblyUndeclaredVariable
        display_main_detail_asset_fields_th($active_fields);
    }
    // If the customization extra is disabled, Show default main fields
    else
    {
        display_asset_name_th();
        display_asset_ip_address_th();
        display_asset_valuation_th();
        display_asset_site_location_th();
        display_asset_team_th();
        display_asset_details_th();
        display_asset_tags_th();
    }
    echo "<th align=\"left\">" . $escaper->escapeHtml($lang['Verified']) . "</th>\n";
    echo "</tr>\n";
    echo "</thead>\n";
    echo "<tbody>\n";

    // If the customization extra, set custom values
    if (customization_extra())
    {
        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $active_fields = get_active_fields("asset");
    }
    // If the customization extra is disabled, Show default main fields
    else
    {
        $active_fields = [];
    }

    // Get the array of assets
    $assets = get_entered_assets();

    // For each asset
    foreach ($assets as $asset)
    {
        // Get the asset IP decrypted
        $asset_ip = try_decrypt($asset['ip']);

        // If the IP address is not valid
        if (!preg_match('/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/', $asset_ip))
        {
                $asset_ip = "N/A";
        }

        echo "<tr data-id=\"" . $escaper->escapeHtml($asset['id']) . "\">\n";
        
        // If the customization extra, set custom values
        if($active_fields)
        {
            display_main_detail_asset_fields_td_edit($active_fields, $asset);        
        }
        else
        {
            display_asset_name_td_edit($asset['id'], $asset['name']);
            display_asset_ip_address_td($asset['ip']);
            display_asset_valuation_td_edit($asset['id'], $asset['value']);
            display_asset_site_location_td_edit($asset['id'], $asset['location']);
            display_asset_team_td_edit($asset['id'], $asset['teams']);
            display_asset_details_td_edit($asset['id'], $asset['details']);
            display_asset_tags_td_edit($asset['id'], $asset['tags']);
        }
        echo "<td>" . $escaper->escapeHtml(localized_yes_no($asset['verified'])) . "</td>\n";
        echo "</tr>\n";
    }

    echo "</tbody>\n";
    echo "</table>\n";
}


/**********************************
 * FUNCTION: IMPORT ASSET *
 * team: string splitted by comma
 *********************************/
function import_asset($ip, $name, $value, $location, $teams, $details, $tags, $verified, $mapped_controls=[])
{
    // Trim whitespace from the name, ip, and value
    $name       = trim($name);
    $ip         = trim($ip);
    $value      = trim($value);
    $location   = $location ? trim($location) : "";
    $teams      = $teams ? trim($teams) : "";

    $asset_id   = asset_exists($name);

    if ($asset_id == false)
    {
	    write_debug_log("An asset named \"{$name} was not found so adding a new asset.", 'info');

	    return add_asset($ip, $name, $value, $location, $teams, $details, $tags, $verified, [], [], true);
    }

    if (asset_exists_exact($ip, $name, $value, $location, $teams, $details, $verified)
        && areTagsEqual($asset_id, 'asset', $tags) && asset_control_mapping_exact_match($asset_id, $mapped_controls)) {
        //return "noop"; // To notify the caller that no operation was done
        $exact = true;
    } else $exact = false;

    // Open the database connection
    $db = db_open();

    // Don't overwrite the non-encoded values because later we want to use those
    $enc_details = try_encrypt($details);
    $enc_ip = try_encrypt($ip);

    // Update the asset
    $stmt = $db->prepare("UPDATE assets SET ip = :ip, value = :value, location = :location, teams = :teams, details = :details, verified = :verified WHERE id = :asset_id");
    $stmt->bindParam(":ip", $enc_ip, PDO::PARAM_STR);
    $stmt->bindParam(":value", $value, PDO::PARAM_INT, 2);
    $stmt->bindParam(":location", $location, PDO::PARAM_STR);
    $stmt->bindParam(":teams", $teams, PDO::PARAM_STR);
    $stmt->bindParam(":details", $enc_details, PDO::PARAM_STR);
    $stmt->bindParam(":verified", $verified, PDO::PARAM_INT);
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_STR);
    $stmt->execute();

    // Close the database connection
    db_close($db);

    if(!is_null($mapped_controls)) save_asset_to_controls($asset_id, $mapped_controls);

    updateTagsOfType($asset_id, 'asset', $tags);

    // Check if we have updated the asset
    if (!$exact) {
        $message = "An asset named \"" . $name . "\" was modified by username \"" . $_SESSION['user'] . "\".";
        write_log($asset_id, $_SESSION['uid'] ?? 0, $message, "asset");

        return $asset_id;
    }

    return $asset_id;
}

/*****************************
 * FUNCTION: ASSET MIN VALUE *
 *****************************/
function asset_min_value()
{
        // Open the database connection
        $db = db_open();

        // Update the asset
        $stmt = $db->prepare("SELECT min_value FROM asset_values WHERE id=1;");
        $stmt->execute();

        // Get the minimum value
        $min_value = $stmt->fetchAll();

        // Close the database connection
        db_close($db);

    // Return the minimum value
    return $min_value[0][0];
}

/*****************************
 * FUNCTION: ASSET MAX VALUE *
 *****************************/
function asset_max_value()
{
        // Open the database connection
        $db = db_open();

        // Update the asset
        $stmt = $db->prepare("SELECT max_value FROM asset_values WHERE id=10;");
        $stmt->execute();

        // Get the max value
        $max_value = $stmt->fetchAll();

        // Close the database connection
        db_close($db);

        // Return the maximum value
        return $max_value[0][0];
}

/********************************
 * FUNCTION: UPDATE ASSET VALUE *
 ********************************/
function update_asset_value($id, $min_value, $max_value, $valuation_level_name = false)
{
    // Open the database connection
    $db = db_open();

    // Set the value for the level
    $stmt = $db->prepare("
        UPDATE
            `asset_values`
        SET
            `min_value` = :min_value,
            `max_value` = :max_value"
            . ($valuation_level_name !== false ? ",`valuation_level_name` = :valuation_level_name " : "") . "
        WHERE
            id = :id;
    ");
    $stmt->bindParam(":id", $id, PDO::PARAM_INT, 2);
    $stmt->bindParam(":min_value", $min_value, PDO::PARAM_INT, 11);
    $stmt->bindParam(":max_value", $max_value, PDO::PARAM_INT, 11);

    if ($valuation_level_name !== false)
        $stmt->bindParam(":valuation_level_name", $valuation_level_name, PDO::PARAM_STR);

    $stmt->execute();

    // Close the database connection
    db_close($db);

    // Return success
    return true;
}

/*************************************************
 * FUNCTION: ASSET VALUATION LINEAR ROWS         *
 *************************************************/
/**
 * PURE. The ten `asset_values` rows a LINEAR distribution over
 * [$min_value, $max_value] produces, as [id => ['min_value', 'max_value']]
 * for ids 1..10.
 *
 * Splitting the arithmetic out from the write is what lets the Preferences
 * page ask "would this submit change anything?" before touching the table.
 * Every level is one wider-or-equal step of ($max - $min) / 10; level 1 opens
 * on $min_value, each later level opens one above its predecessor's ceiling,
 * and level 10 is forced onto $max_value so the rounding drift accumulated
 * across the previous nine buckets is absorbed rather than left as a gap.
 *
 * No range validation: an inverted or degenerate range simply produces a
 * degenerate distribution, exactly as this arithmetic always has. Callers
 * validate before calling.
 */
function asset_valuation_linear_rows($min_value, $max_value): array
{
    $min_value = (int)$min_value;
    $max_value = (int)$max_value;

    // Get the increment
    $increment = (int)round(($max_value - $min_value) / 10);

    // Set the value for level 1
    $value = $min_value + $increment;
    $rows = [1 => ['min_value' => $min_value, 'max_value' => $value]];

    // For each value from 2 to 10
    for ($i = 2; $i <= 10; $i++) {

        // The minimum value is the current value + 1
        $level_min = $value + 1;

        // If this is not level 10
        if ($i != 10) {
            // The new value is the current value + the increment
            $value = $value + $increment;
        } else {
            $value = $max_value;
        }

        $rows[$i] = ['min_value' => $level_min, 'max_value' => $value];
    }

    return $rows;
}

/*************************************************
 * FUNCTION: ASSET VALUATION EXPONENTIAL ROWS    *
 *************************************************/
/**
 * PURE. The ten `asset_values` rows an EXPONENTIAL (geometric) distribution
 * over [$min_value, $max_value] produces, as [id => ['min_value', 'max_value']]
 * for ids 1..10.
 *
 * Each bucket's upper boundary is $min_value * r^i where
 * r = ($max_value / $min_value)^(1/10) and i runs 1..10. Level 1's lower bound
 * is $min_value; each later level's lower bound is the previous level's upper
 * bound + 1; level 10's upper bound is forced to $max_value to absorb rounding
 * drift.
 *
 * $min_value may be zero -- a geometric progression cannot start at zero, so
 * that case anchors on max^(1/10) (the 10th root of max) instead, which
 * produces the natural "0-10, 11-100, 101-1000, ..." sequence when max is a
 * power of ten.
 *
 * Returns an EMPTY ARRAY for a range the progression cannot express (a
 * negative minimum, or a maximum that does not exceed the minimum). Callers
 * are expected to validate and report the refusal themselves; returning no
 * rows means no rows are written.
 */
function asset_valuation_exponential_rows($min_value, $max_value): array
{
    $min_value = (float)$min_value;
    $max_value = (float)$max_value;

    // Range must actually be a range, and max must be positive (so the
    // geometric progression has somewhere to terminate). min can be
    // zero -- that's the natural starting point for an exponential range
    // (e.g. 0-10, 11-100, 101-1000, ...).
    if ($min_value < 0 || $max_value <= $min_value || $max_value <= 0) {
        return [];
    }

    // Compute the geometric step r and level 1's upper bound. min=0 needs
    // a special anchor (geometric needs a non-zero start), so we anchor on
    // max^(1/10) -- i.e. the 10th root of max -- which produces the natural
    // "0-10, 11-100, 101-1000, ..." sequence when max is a power of 10.
    // min>0 uses the standard (max/min)^(1/10) ratio with level 1's upper
    // bound = min*r.
    if ($min_value == 0.0) {
        $r = pow($max_value, 1.0 / 10.0);
        $level_1_lower = 0;
        $level_1_upper = (int)round($r);
    } else {
        $r = pow($max_value / $min_value, 1.0 / 10.0);
        $level_1_lower = (int)round($min_value);
        $level_1_upper = (int)round($min_value * $r);
    }

    // Set the value for level 1
    $rows = [1 => ['min_value' => $level_1_lower, 'max_value' => $level_1_upper]];
    $value = $level_1_upper;

    // For each level from 2 to 10
    for ($i = 2; $i <= 10; $i++) {

        // The minimum value is the previous level's upper bound + 1
        $level_min = $value + 1;

        // If this is not level 10, compute the upper bound
        if ($i != 10) {
            // anchor is max^(1/10) when min=0, else min
            $value = ($min_value == 0.0)
                ? (int)round(pow($r, $i))
                : (int)round($min_value * pow($r, $i));
        } else {
            // Force the last bucket to land exactly on $max_value so any
            // rounding drift across the previous buckets doesn't leave a
            // gap at the top of the range.
            $value = (int)round($max_value);
        }

        $rows[$i] = ['min_value' => $level_min, 'max_value' => $value];
    }

    return $rows;
}

/*************************************************
 * FUNCTION: ASSET VALUATION ROWS TO UPDATE      *
 *************************************************/
/**
 * PURE. Which of $desired actually differs from what is already stored.
 *
 * $desired is [id => ['min_value' => ..., 'max_value' => ..., and optionally
 * 'valuation_level_name' => ...]]; $current is the row set
 * get_asset_valuation_array() returns. The return is the SUBSET OF $desired,
 * keyed by the same ids, that would change something if written.
 *
 * Both comparisons are deliberately loose about type, because both sides
 * arrive in different shapes and a strict comparison would report every row
 * changed on every submit:
 *
 *   min_value / max_value  -- posted as strings by <input type="number">,
 *                             returned as ints by the INT columns.
 *   valuation_level_name   -- '' when the admin left the box empty, NULL in
 *                             the database when the level was never named.
 *
 * A level name is only compared when $desired carries one. The Linear and
 * Exponential modes rebuild the boundaries without touching the names, so for
 * them an existing name is not a difference.
 *
 * An id with no stored counterpart is reported as work: it cannot be shown to
 * be unchanged, so it is not claimed to be.
 */
function asset_valuation_rows_to_update(array $desired, array $current): array
{
    // Index the stored rows by id. PDO's default fetch mode gives each row
    // both string and numeric keys; only the string keys are read here.
    $stored = [];
    foreach ($current as $row) {
        if (isset($row['id'])) {
            $stored[(int)$row['id']] = $row;
        }
    }

    $to_update = [];

    foreach ($desired as $id => $row) {

        $existing = $stored[(int)$id] ?? null;

        if ($existing === null) {
            $to_update[$id] = $row;
            continue;
        }

        if ((int)$row['min_value'] !== (int)($existing['min_value'] ?? 0)
            || (int)$row['max_value'] !== (int)($existing['max_value'] ?? 0)) {
            $to_update[$id] = $row;
            continue;
        }

        if (array_key_exists('valuation_level_name', $row)
            && (string)$row['valuation_level_name'] !== (string)($existing['valuation_level_name'] ?? '')) {
            $to_update[$id] = $row;
        }
    }

    return $to_update;
}

/*************************************************
 * FUNCTION: APPLY ASSET VALUATION ROWS          *
 *************************************************/
/**
 * Write $rows (in the shape asset_valuation_rows_to_update() consumes) to
 * `asset_values`, SKIPPING every row that already holds those values.
 *
 * Returns the number of rows actually written, so a caller can tell an admin
 * what really happened instead of announcing a save on every click. All five
 * Preferences tabs share one <form>, so this function is reached on every
 * Update regardless of which tab the admin was looking at -- returning 0 is
 * the common case, not the exceptional one.
 */
function apply_asset_valuation_rows(array $rows): int
{
    $to_update = asset_valuation_rows_to_update($rows, get_asset_valuation_array());

    foreach ($to_update as $id => $row) {
        update_asset_value(
            $id,
            $row['min_value'],
            $row['max_value'],
            array_key_exists('valuation_level_name', $row) ? $row['valuation_level_name'] : false
        );
    }

    return count($to_update);
}

/*********************************
 * FUNCTION: UPDATE ASSET VALUES *
 *********************************/
/**
 * Rebuild the ten asset valuation levels as a LINEAR distribution over
 * [$min_value, $max_value], writing only the levels that actually change.
 *
 * Returns the number of rows written -- 0 when the stored levels already match
 * the distribution, which is what an untouched form re-submitted from another
 * tab produces.
 */
function update_asset_values($min_value, $max_value): int
{
    return apply_asset_valuation_rows(asset_valuation_linear_rows($min_value, $max_value));
}

/*********************************************
 * FUNCTION: UPDATE ASSET VALUES EXPONENTIAL *
 *********************************************/
/**
 * Rebuild the ten asset valuation levels as an EXPONENTIAL distribution over
 * [$min_value, $max_value], writing only the levels that actually change.
 *
 * Returns the number of rows written. A range the progression cannot express
 * yields no rows and therefore writes nothing and returns 0; callers validate
 * the range and report the refusal themselves rather than relying on this.
 */
function update_asset_values_exponential($min_value, $max_value): int
{
    return apply_asset_valuation_rows(asset_valuation_exponential_rows($min_value, $max_value));
}

/*******************************************
 * FUNCTION: DISPLAY ASSET VALUATION TABLE *
 *******************************************/
function display_asset_valuation_table($form_id = '') {

    global $lang, $escaper;

    // When the table is rendered inside a tab/page that wraps a different
    // outer form, callers can pass a form ID so each input is associated
    // with the manual asset valuation form via the HTML5 form attribute.
    $form_attr = $form_id !== '' ? " form='" . $escaper->escapeHtmlAttr($form_id) . "'" : '';

    // Open the database connection
    $db = db_open();

    echo "
        <table class='my-2' border='0' cellspacing='5' cellpadding='5'>
    ";

    // Display the table header
    echo "
            <thead>
                <tr>
                    <th class='text-center'>{$escaper->escapeHtml($lang['ValueRange'])}</th>
                    <th class='text-center'>{$escaper->escapeHtml($lang['MinimumValue'])}</th>
                    <th class='text-center'>{$escaper->escapeHtml($lang['MaximumValue'])}</th>
                    <th class='text-center'>{$escaper->escapeHtml($lang['ValuationLevelName'])}</th>
                </tr>
            </thead>
            <tbody>
    ";

    // Get the asset values
    $stmt = $db->prepare("SELECT * FROM asset_values;");
    $stmt->execute();
    $values = $stmt->fetchAll();

    // The configured Default Currency Symbol prefixes each boundary (SR-2075).
    // It used to be a "$" drawn by the stylesheet, whatever the setting said.
    // The setting is free text an administrator types, so it is escaped here.
    $currency = (string)get_setting('currency');
    $prefix = $currency !== '' ? "<span class='input-group-text'>{$escaper->escapeHtml($currency)}</span>" : '';

    // For each asset value
    foreach ($values as $value) {

        // Minimum value for field
        $minimum = (int)$value['id'] - 1;
        $level = $escaper->escapeHtmlAttr($value['id']);

        // data-valuation-bound / data-valuation-level are what
        // js/simplerisk/asset_valuation.js keeps neighbouring levels in step by.
        echo "
                <tr>
                    <td class='text-center'>{$escaper->escapeHtml($value['id'])}</td>
                    <td class='text-center'>
                        <div class='input-group'>{$prefix}<input type='number' min='{$escaper->escapeHtml($minimum)}' name='min_value_{$level}' value='{$escaper->escapeHtml($value['min_value'])}' data-valuation-bound='min' data-valuation-level='{$level}' class='form-control'{$form_attr}/></div>
                    </td>
                    <td class='text-center'>
                        <div class='input-group'>{$prefix}<input type='number' min='{$escaper->escapeHtml($minimum)}' name='max_value_{$level}' value='{$escaper->escapeHtml($value['max_value'])}' data-valuation-bound='max' data-valuation-level='{$level}' class='form-control'{$form_attr}/></div>
                    </td>
                    <td class='text-center'>
                        <input type='text' name='valuation_level_name_{$escaper->escapeHtml($value['id'])}' value='{$escaper->escapeHtml($value['valuation_level_name'])}'  class='form-control' placeholder='{$escaper->escapeHtml($lang['EnterAValuationLevelName'])}'{$form_attr}/>
                    </td>
                </tr>
        ";

    }

    echo "
            </tbody>
        </table>
    ";

    // Close the database connection
    db_close($db);

}

/*********************************************
 * FUNCTION: CREATE ASSET VALUATION DROPDOWN *
 *********************************************/
function create_asset_valuation_dropdown($name, $selected = NULL, $id = NULL, $customHtml="")
{
    global $escaper;

    if(!$id){
        $id = $name;
    }
        // Open the database connection
        $db = db_open();

        // Get the asset values
        $stmt = $db->prepare("SELECT * FROM asset_values;");
        $stmt->execute();
        $values = $stmt->fetchAll();
        
    echo "<select id=\"" . $escaper->escapeHtml($id) . "\" name=\"" . $escaper->escapeHtml($name) . "\" {$customHtml} class=\"form-select\"  >\n";

        // For each asset value
        foreach ($values as $value)
        {
            // If the option is selected
            if ($selected == $value['id'])
            {
                $text = " selected";
            }
            else $text = "";

        echo "  <option value=\"" . $escaper->escapeHtml($value['id']) . "\"" . $text . ">";

        $valuation_level_name = "";
        if (!empty($value['valuation_level_name']))
            $valuation_level_name = " (" . $escaper->escapeHtml($value['valuation_level_name']) . ")";

        if ($value['min_value'] === $value['max_value'])
        {
            echo $escaper->escapeHtml(get_setting("currency")) . $escaper->escapeHtml(number_format($value['min_value'])) . $valuation_level_name;
        }
        else
        {
            echo $escaper->escapeHtml(get_setting("currency")) . $escaper->escapeHtml(number_format($value['min_value'])) . " to " . $escaper->escapeHtml(get_setting("currency")) . $escaper->escapeHtml(number_format($value['max_value'])) . $valuation_level_name;
        }

        echo "</option>\n";
    }

    echo "</select>\n";

    // Close the database connection
    db_close($db);
}

/********************************************
 * FUNCTION: UPDATE DEFAULT ASSET VALUATION *
 ********************************************/
function update_default_asset_valuation($value)
{
        // Open the database connection
        $db = db_open();

        // Update the default asset valuation
        $stmt = $db->prepare("UPDATE `settings` SET value=:value WHERE name='default_asset_valuation'");
    $stmt->bindParam(":value", $value, PDO::PARAM_INT, 2);
        $stmt->execute();

        // Close the database connection
        db_close($db);

    // Return true
    return true;
}

/*****************************************
 * FUNCTION: GET DEFAULT ASSET VALUATION *
 *****************************************/
function get_default_asset_valuation()
{
    // Open the database connection
    $db = db_open();

    // Update the default asset valuation
    $stmt = $db->prepare("SELECT value FROM `settings` WHERE name='default_asset_valuation'");
    $stmt->execute();

    $value = $stmt->fetchAll();

    // Close the database connection
    db_close($db);

    // Return the value
    return $value[0][0];
}

/***********************************
 * FUNCTION: GET ASSET ID BY VALUE *
 ***********************************/
function get_asset_id_by_value($value){
    $currency = get_currency_symbol();
    $value = strtolower(str_replace(array($currency, ','), '', $value));
    
    $min_max = explode("to", $value);
    $min = intval($min_max[0]);
    $max = isset($min_max[1]) ? intval($min_max[1]) : false;
    if(!isset($GLOBALS['default_asset_valuation'])){
        $GLOBALS['default_asset_valuation'] = get_default_asset_valuation();
    }

    if(!isset($GLOBALS['asset_values'])){
        // Open the database connection
        $db = db_open();

        // Update the default asset valuation
        $stmt = $db->prepare("SELECT * FROM `asset_values` ");
        $stmt->execute();
        // Close the database connection
        db_close($db);

        $GLOBALS['asset_values'] = $stmt->fetchAll();
    }
    
    $id = $GLOBALS['default_asset_valuation'];
    if($max === false){
        // if $value is single dollar.
        foreach($GLOBALS['asset_values'] as $asset_value){
            if($asset_value['min_value'] <= $min && $asset_value['max_value'] >= $min){
                $id = $asset_value['id'];
                break;
            }
        }
    }else{
        foreach($GLOBALS['asset_values'] as $asset_value){
            if($asset_value['min_value'] <= $min && $asset_value['max_value'] >= $max){
                $id = $asset_value['id'];
            }
        }
    }

    return $id;
}

/***********************************
 * FUNCTION: GET ASSET VALUE BY ID *
 ***********************************/
function get_asset_value_by_id($id="", $export=false)
{
    global $escaper;

    if (!empty($GLOBALS['asset_valuations_by_id'])) {
        if (!empty($GLOBALS['asset_valuations_by_id'][$id])) {
            return $GLOBALS['asset_valuations_by_id'][$id];
        }
    } else {
        $GLOBALS['asset_valuations_by_id'] = [];
    }

    if(!isset($GLOBALS['default_asset_valuation'])){
        $GLOBALS['default_asset_valuation'] = get_default_asset_valuation();
    }

    if(!isset($GLOBALS['asset_values'])){
        // Open the database connection
        $db = db_open();

        // Update the default asset valuation
        $stmt = $db->prepare("SELECT * FROM `asset_values` ");
        $stmt->execute();
        // Close the database connection
        db_close($db);

        $GLOBALS['asset_values'] = $stmt->fetchAll();
    }

    $value = "";
    foreach($GLOBALS['asset_values'] as $asset_value){
        if($asset_value['id'] == $id){
            $value = $asset_value;
            break;
        }
    }

    // If a value exists
    if (empty($value))
    {
        $id = $GLOBALS['default_asset_valuation'];

        foreach($GLOBALS['asset_values'] as $asset_value){
            if($asset_value['id'] == $id){
                $value = $asset_value;
                break;
            }
        }
    }

    if(!empty($value)) {
        if ($value['min_value'] === $value['max_value']) {
            $asset_value = get_setting("currency") . number_format($value['min_value']);
        } else {
            $asset_value = get_setting("currency") . number_format($value['min_value']) . " to " . get_setting("currency") . number_format($value['max_value']);
        }

        if (!$export && !empty($value['valuation_level_name'])) {
            $asset_value .= " ({$value['valuation_level_name']})";
        }
    }else{
        $asset_value = "Undefined";
    }

    $GLOBALS['asset_valuations_by_id'][$id] = $asset_value;

    // Return the asset value
    return $asset_value;
}

/***************************************
 * FUNCTION: GET ASSET VALUATION ARRAY *
 ***************************************/
function get_asset_valuation_array()
{
    // Open the database connection
    $db = db_open();

    // Update the default asset valuation
    $stmt = $db->prepare("SELECT * FROM `asset_values`");
    $stmt->execute();

    $asset_valuation_array = $stmt->fetchAll();

    // Close the database connection
    db_close($db);

    // Return the array
    return $asset_valuation_array;
}

/*****************************************
 * FUNCTION: ASSET VALUATION FOR RISK ID *
 *****************************************/
function asset_valuation_for_risk_id($risk_id)
{
    $db = db_open();

    $stmt = $db->prepare("
        SELECT
            (SELECT
                COALESCE(sum(`av`.`max_value`), 0)
            FROM
                `risks_to_asset_groups` rtag
                INNER JOIN `assets_asset_groups` aag ON `rtag`.`asset_group_id` = `aag`.`asset_group_id`
                INNER JOIN `assets` a ON `aag`.`asset_id` = `a`.`id`
                INNER JOIN `asset_values` av ON `a`.`value` = `av`.`id`
            WHERE
                `rtag`.`risk_id`=:risk_id
                AND `a`.`id` NOT IN (SELECT `asset_id` FROM `risks_to_assets` WHERE `risk_id` = :risk_id))
            +
            (SELECT
                COALESCE(sum(`av`.`max_value`), 0)
            FROM
                `risks_to_assets` rta
                INNER JOIN `assets` a ON `rta`.`asset_id` = `a`.`id`
                INNER JOIN `asset_values` av ON `a`.`value` = `av`.`id`
            WHERE
                `rta`.`risk_id`=:risk_id)
        FROM dual;
    ");
    $stmt->bindParam(":risk_id", $risk_id, PDO::PARAM_INT);
    $stmt->execute();

    $value = $stmt->fetch()[0];

    db_close($db);
    
    return $value;   
}


/*********************************************
 * FUNCTION: ASSET VALUATION FOR ASSET GROUP *
 *********************************************/
function asset_valuation_for_asset_group($asset_group_id)
{
    $db = db_open();

    $stmt = $db->prepare("
        SELECT
            SUM(`av`.`max_value`)
        FROM
            `assets_asset_groups` aag
            INNER JOIN `assets` a ON `aag`.`asset_id` = `a`.`id`
            INNER JOIN `asset_values` av ON `a`.`value` = `av`.`id`
        WHERE
            `aag`.`asset_group_id` = :asset_group_id;
    ");
    $stmt->bindParam(":asset_group_id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();

    $value = $stmt->fetch()[0];

    db_close($db);
    
    return $value;   
}


/************************************
 * FUNCTION: DISPLAY ADD ASSET FORM *
 ************************************/
function display_add_asset()
{
    // If the customization extra is enabled, shows fields by asset customization
    if (customization_extra())
    {
        write_debug_log("Customization extra is enabled", 'debug');

        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $active_fields = get_active_fields("asset");
        $inactive_fields = get_inactive_fields("asset");

        display_main_detail_asset_fields_add($active_fields);
        display_main_detail_asset_fields_add($inactive_fields);

        echo "
            <script>
                $(function() {
                    $(\"#add-asset-container select.multiselect[name^='custom_field[']\").multiselect({buttonWidth: '300px', enableFiltering: true, enableCaseInsensitiveFiltering: true});
                });
            </script>
        ";
    }
    // If the customization extra is disabled, shows fields by default fields
    else
    {
        display_asset_name_edit();

        display_asset_ip_address_edit();

        display_asset_valuation_edit();

        display_asset_site_location_edit();

        display_asset_team_edit();

        display_asset_associated_risks_add();

        display_asset_details_edit();

        display_asset_mapping_controls_edit();

        display_asset_tags_add();
    }
}


/*********************************************************
 * FUNCTION: CREATE ASSET GROUP                          *
 * $name: name of the asset group                        *
 * $selected_assets: The assets associated to the group  * 
 *********************************************************/
/**
 * The asset group name rule applied to the stored groups (SR-1881); see
 * asset_group_name_check(). Every create and rename path -- the v2 CRUD
 * routes, the legacy /asset-group/* RPC and the Import-Export Extra -- asks
 * this rather than get_value_by_name(), whose first-match lookup could
 * resolve a group's own name to a different row and refuse the save.
 *
 * @param string   $name    the requested name, already normalised
 * @param int|null $self_id the group being edited; null on create
 * @return array{conflict:bool,name:string}
 */
function check_asset_group_name(string $name, ?int $self_id = null): array
{
    $db = db_open();
    $groups = $db->query("SELECT `id`, `name` FROM `asset_groups`;")->fetchAll(PDO::FETCH_ASSOC);
    db_close($db);

    return asset_group_name_check($groups, $name, $self_id);
}

function create_asset_group($name, $selected_assets=false) {

    $db = db_open();

    $stmt = $db->prepare("
        INSERT INTO
            `asset_groups` (`name`)
        VALUES
            (:name);"
    );
    $stmt->bindParam(":name", $name, PDO::PARAM_STR);
    $stmt->execute();

    $id = $db->lastInsertId();

    db_close($db);

    update_assets_of_asset_group($selected_assets, $id, $name, true);

    return $id;
}

/*********************************************************
 * FUNCTION: UPDATE ASSET GROUP                          *
 * $id: id of the asset group                            *
 * $name: name of the asset group                        *
 * $selected_assets: The assets associated to the group  *
 *********************************************************/
function update_asset_group($id, $name, $selected_assets) {

    $db = db_open();

    $stmt = $db->prepare("
        UPDATE
            `asset_groups`
        SET
            `name`=:name
        WHERE
            `id`=:id;"
    );
    $stmt->bindParam(":name", $name, PDO::PARAM_STR);
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();

    if(!is_null($selected_assets)) update_assets_of_asset_group($selected_assets, $id, $name);

    db_close($db);
}

/********************************************
 * FUNCTION: DELETE ASSET GROUP             *
 * $asset_group_id: id of the asset group   *
 ********************************************/
function delete_asset_group($asset_group_id) {

    $name = get_name_by_value('asset_groups', $asset_group_id, false, true);

    if (!$name)
        return false;

    $db = db_open();

    // Delete the group
    $stmt = $db->prepare("
        DELETE FROM
            `asset_groups`
        WHERE
            `id`=:id;"
    );
    $stmt->bindParam(":id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();

    db_close($db);

    // Delete leftover junction entries
    cleanup_after_delete('asset_groups');
    
    $message = _lang_raw('AssetGroupDeleteAuditLog', array(
            'user' => $_SESSION['user'],
            'group_name' => $name,
            'id' => $asset_group_id
        ));

    write_log($asset_group_id + 1000, $_SESSION['uid'] ?? 0, $message, 'asset_group');

    return true;
}


/************************************************
 * FUNCTION: REMOVE ASSET FROM ASSET GROUP      *
 * $asset_id: id of the asset we want to remove *
 *            from the asset group              *
 * $asset_group_id: id of the asset group       *
 ************************************************/
function remove_asset_from_asset_group($asset_id, $asset_group_id) {

    $asset_group_name = get_name_by_value('asset_groups', $asset_group_id, false, true);
    $asset_name = get_name_by_value('assets', $asset_id, false, true);

    if (!$asset_group_name || !$asset_name)
        return false;

    $db = db_open();

    // Remove asset from the group
    $stmt = $db->prepare("
        DELETE FROM
            `assets_asset_groups`
        WHERE
            `asset_id`=:asset_id AND
            `asset_group_id`=:asset_group_id;"
    );
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->bindParam(":asset_group_id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();

    db_close($db);

    $message = _lang_raw('AssetGroupRemoveAssetAuditLog', array(
            'user' => $_SESSION['user'],
            'asset_name' => $asset_name,
            'asset_id' => $asset_id,
            'group_name' => $asset_group_name,
            'group_id' => $asset_group_id
        ));

    write_log($asset_group_id + 1000, $_SESSION['uid'] ?? 0, $message, 'asset_group');

    return true;
}

/*****************************
 * FUNCTION: GET ASSET GROUP *
 *****************************/
function get_asset_group($asset_group_id) {

    $db = db_open();

    if (encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }

    $stmt = $db->prepare("
        SELECT
            *
        FROM
            `asset_groups`
        WHERE
            `id` = :asset_group_id;
    ");
    $stmt->bindParam(":asset_group_id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($result))
        return [];

    $result = $result[0];

    // Load assets currently assigned to the group
    $stmt = $db->prepare("
        SELECT
            `a`.id, `a`.`name`
        FROM
            `assets` a
            INNER JOIN `assets_asset_groups` aag ON `aag`.`asset_id` = `a`.`id` AND `aag`.`asset_group_id` = :asset_group_id
        ORDER BY
            " . (encryption_extra() ? "a.order_by_name" : "a.name") . ";
    ");
    $stmt->bindParam(":asset_group_id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();
    $result['selected_assets'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("
        SELECT
            `a`.id, `a`.`name`
        FROM
            `assets` a
            LEFT OUTER JOIN `assets_asset_groups` aag ON `aag`.`asset_id` = `a`.`id` AND `aag`.`asset_group_id` = :asset_group_id
        WHERE
            `aag`.`asset_id` IS NULL
        ORDER BY
            " . (encryption_extra() ? "a.order_by_name" : "a.name") . ";
    ");
    $stmt->bindParam(":asset_group_id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();
    $result['available_assets'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);

    foreach($result['selected_assets'] as &$asset)
        $asset['name'] = try_decrypt($asset['name']);
    
    foreach($result['available_assets'] as &$asset)
        $asset['name'] = try_decrypt($asset['name']);
    
    return $result;
}


/***************************************
 * FUNCTION: GET ASSETS OF ASSET GROUP *
 ***************************************/
function get_assets_of_asset_group($asset_group_id) {

    $db = db_open();

    if (encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }

    // Load assets currently assigned to the group
    $stmt = $db->prepare("
        SELECT
            `a`.*
        FROM
            `assets` a
            INNER JOIN `assets_asset_groups` aag ON `aag`.`asset_id` = `a`.`id`
        WHERE
            `aag`.`asset_group_id` = :asset_group_id
        ORDER BY
            " . (encryption_extra() ? "a.order_by_name" : "a.name") . ";
    ");
    $stmt->bindParam(":asset_group_id", $asset_group_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);
    
    foreach($result as &$asset) {
        $asset['name'] = try_decrypt($asset['name']);
        $asset['ip'] = try_decrypt($asset['ip']);
        $asset['details'] = try_decrypt($asset['details']);
    }

    return $result;
}

/*****************************************************************
 * FUNCTION: UPDATE ASSETS OF ASSET GROUP                        *
 * $assets: id list of the assets that are in the group          *
 * $asset_group_id: id of the asset group                        *
 * $asset_group_name: name of the asset group(for the audit log) *
 * $create: info on whether it was called on create or update.   *
 * If called for create it won't check what changed, won't       *
 * try to disassociate removed assets, just adds the new ones.   *
 *****************************************************************/
function update_assets_of_asset_group($assets, $asset_group_id, $asset_group_name, $create=false) {

    $db = db_open();

    $assets_to_remove = [];
    $assets_current = [];
    $assets_to_add = [];

    if (!$create) {
        //Get the current assets
        $assets_current = array_column(get_assets_of_asset_group($asset_group_id), 'id');

        // Clever usage of array_diffs to calculate what assets are removed from the group
        // and what assets are added
        $assets_to_remove = array_diff($assets_current, $assets);
        $assets_to_add = array_diff($assets, $assets_current);

        // If there're assets to remove
        if ($assets_to_remove) {

            //building an array of parameters to bind
            $params = array(":asset_group_id" => $asset_group_id);

            // building the list of strings to be used in the `in` part of the sql
            // to be able to bind the params
            // We need this to be able to delete all the connections to the removed
            // assets in one go, instead of using a loop
            $assets_to_remove_in = [];
            foreach ($assets_to_remove as $i => $asset_id)
            {
                $key = ":id".$i;
                $assets_to_remove_in[] = $key;
                $params[$key] = $asset_id;
            }

            // making the comma separated list to be included in the sql
            $assets_to_remove_in = implode(", ", $assets_to_remove_in);

            // Remove the entries from the junction table that connected the deleted assets to the group
            $stmt = $db->prepare("
                delete
                    `aag`
                from
                    `assets` a
                    INNER JOIN `assets_asset_groups` aag ON `aag`.`asset_id` = `a`.`id`
                where
                    `aag`.`asset_group_id` = :asset_group_id and
                    `a`.`id` in ({$assets_to_remove_in});
            ");
            $stmt->execute($params);
        }
    } else {
        $assets_to_add = $assets;
    }

    //If there're assets to add
    if ($assets_to_add) {
        //building an array of parameters to bind
        $params = array(":asset_group_id" => $asset_group_id);

        // building the list of strings to be used in the `in` part of the sql
        // to be able to bind the params
        // We need this to be able to delete all the connections to the removed
        // assets in one go, instead of using a loop
        $assets_to_add_values = [];
        foreach ($assets_to_add as $i => $asset_id)
        {
            $key = ":id".$i;
            $assets_to_add_values[] = "({$key}, :asset_group_id)";
            $params[$key] = $asset_id;
        }

        // making the comma separated list to be included in the sql
        $assets_to_add_values = implode(", ", $assets_to_add_values);

        // Remove the entries from the junction table that connected the deleted assets to the group
        $stmt = $db->prepare("
            INSERT INTO
                `assets_asset_groups` (`asset_id`, `asset_group_id`)
            VALUES
                {$assets_to_add_values};
        ");
        $stmt->execute($params);
    }

    db_close($db);

    // No audit logging is needed if nothing changed
    if ($create || $assets_to_add || $assets_to_remove) {
        global $lang;

        $asset_changes = [];

        $assets = get_names_by_values('assets', $assets, false, false, true);
        $assets_to_add = get_names_by_values('assets', $assets_to_add, false, false, true);

        if ($assets_to_add)
            $asset_changes[] = _lang_raw('AssetGroupUpdateAuditLogAdded', array('assets_added' => $assets_to_add));

        if (!$create) {
            $assets_to_remove = get_names_by_values('assets', $assets_to_remove, false, false, true);
            if ($assets_to_remove)
                $asset_changes[] = _lang_raw('AssetGroupUpdateAuditLogRemoved', array('assets_removed' => $assets_to_remove));

            $assets_current = get_names_by_values('assets', $assets_current, false, false, true);

            $message = _lang_raw('AssetGroupUpdateAuditLog', array(
                    'user' => $_SESSION['user'],
                    'group_name' => $asset_group_name,
                    'id' => $asset_group_id,
                    'assets_from' => $assets_current,
                    'assets_to' => $assets,
                    'asset_changes' => implode(", ", $asset_changes)
                ));
        } else {
            $message = _lang_raw('AssetGroupCreateAuditLog', array(
                    'user' => $_SESSION['user'],
                    'group_name' => $asset_group_name,
                    'id' => $asset_group_id,
                    'assets_to' => $assets
                ));
        }

        write_log($asset_group_id + 1000, $_SESSION['uid'] ?? 0, $message, 'asset_group');
    }
}

/************************************************************************************************************
 * FUNCTION: PROCESS SELECTED ASSETS ASSET GROUPS OF TYPE                                                   *
 * Processing the data coming from the widget used for selecting assets and asset groups.                   *
 * $item_id: Id of the item we want to associate the assets and asset groups with                           *
 * $assets_and_groups: data from the widget. Can contain asset/asset group ids or names of new assets       *
 * $type: The type of the item the assets/asset groups are being assigned to                                *
 * Currently supported types: risk, assessment_answer, questionnaire_answer, questionnaire_risk, incident   *
 *                                                                                                          *
 * There's also the ability to enforce team separation logic for the assets in a way that prevents          *
 * accidental removal of assets in case the submitting user had no permission editing an asset that is      *
 * assigned to the item, but wasn't displayed(because the user has no permission to the asset) thus wasn't  *
 * sent to the server as a selected asset.                                                                  * 
 ************************************************************************************************************/
function process_selected_assets_asset_groups_of_type($item_id, $assets_and_groups, $type) {

    $db = db_open();

    // The logic is about items that have assets with teams assigned when team separation is enabled.
    // It can happen that a user opens an item to edit but don't have access to all the assets assigned to it.
    // In this case the user can edit the assets that they have access to, but leave the others intact(they're not even displayed)
    $team_separation_asset_saving_logic = false;

    // make the junction config that's maintained in the functions.php available here
    global $junction_config;
    
    // set the names of the junction tables and fields required for the query for the type provided
    switch($type) {
        case 'risk':
            if (!check_permission("riskmanagement")) {
                return;
            }
            $junction_config_type = 'risks';
            $assets_junction_name = 'risks_to_assets';
            $asset_groups_junction_name = 'risks_to_asset_groups';
            $forced_asset_verification_state = null;
            $team_separation_asset_saving_logic = true;
            break;
        case 'assessment_answer':
            if (!check_permission("assessments")) {
                return;
            }
            $junction_config_type = 'assessment_answers';
            $assets_junction_name = 'assessment_answers_to_assets';
            $asset_groups_junction_name = 'assessment_answers_to_asset_groups';
            $forced_asset_verification_state = true;
            break;
        case 'questionnaire_answer':
            if(!assessments_extra() || !check_permission("assessments") || !table_exists("questionnaire_answers_to_assets") || !table_exists("questionnaire_answers_to_asset_groups")) {
                return;
            }
            $junction_config_type = 'questionnaire_answers';
            $assets_junction_name = 'questionnaire_answers_to_assets';
            $asset_groups_junction_name = 'questionnaire_answers_to_asset_groups';
            $forced_asset_verification_state = true;
            break;
        case 'questionnaire_risk':
            if(!assessments_extra() || !check_permission("assessments")) {
                return;
            }
            $junction_config_type = 'questionnaire_risk_details';
            $assets_junction_name = 'questionnaire_risk_to_assets';
            $asset_groups_junction_name = 'questionnaire_risk_to_asset_groups';
            $forced_asset_verification_state = true;
            break;
        case 'incident':
            if(!incident_management_extra() || !check_permission("im_incidents")) {
                return;
            }
            $junction_config_type = 'incident_management_incidents';
            $assets_junction_name = 'incident_management_incident_to_assets';
            $asset_groups_junction_name = 'incident_management_incident_to_asset_groups';
            $forced_asset_verification_state = null;
            $team_separation_asset_saving_logic = true;
            break;
        default:
            return;
    }
    
    // Use the data setup in the junction configuration
    $asset_junction_item_id_name = $junction_config[$junction_config_type]['junctions'][$assets_junction_name];
    $asset_group_junction_item_id_name = $junction_config[$junction_config_type]['junctions'][$asset_groups_junction_name];
    $asset_junction_asset_id_name = $junction_config['assets']['junctions'][$assets_junction_name];
    $asset_group_junction_asset_group_id_name = $junction_config['asset_groups']['junctions'][$asset_groups_junction_name];

    // Save whether the separation extra is enabled so don't have to query the database all the time
    $separation = team_separation_extra();
    
    // Using the team separation saving logic only makes sense if the team separation extra is activated and the user isn't an admin
    $team_separation_asset_saving_logic = $team_separation_asset_saving_logic && $separation && !is_admin();


    $stmt = $db->prepare("DELETE FROM `{$asset_groups_junction_name}` WHERE {$asset_group_junction_item_id_name} = :item_id");
    $stmt->bindParam(":item_id", $item_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $assets = [];
    $new_assets = [];
    // For each asset or group
    foreach ($assets_and_groups as $value)
    {
        // Trim whitespaces
        $value = trim($value);
        
        // Selected an existing asset or group
        if (preg_match('/^([\d]+)_(group|asset)$/', $value, $matches)) {
            list(, $aag_id, $aag_type) = $matches;
        } elseif (preg_match('/^new_asset_(.*)$/', $value, $matches)) { // Entered the name of a new asset
            $name = trim($matches[1]);
            // Check if the asset already exists, but not verified(since it didnt show up in the widget)
            $aag_id = asset_exists($name);
            
            if ($aag_id) {
                set_alert(true, "bad", _lang('ErrorAssetAlreadyExistsAsVerified', array('asset_name' => $name)));
                continue;
            }
            
            if ($forced_asset_verification_state === null) {
                $aag_id = add_asset('', $name);
            } else {
                $aag_id = add_asset_by_name_with_forced_verification($name, $forced_asset_verification_state);
            }
            $aag_type = 'asset';
            $new_assets []= $aag_id;
        } else {
            //Invalid input
            continue;
        }
        
        if ($aag_type == 'asset') {
            // If it's an asset we're storing it for later to apply the team separation asset saving logic if needed
            $assets []= $aag_id;
        } elseif ($aag_type == 'group') {
            // Add the new group for this type
            $stmt = $db->prepare("INSERT INTO `$asset_groups_junction_name` (`$asset_group_junction_item_id_name`, `$asset_group_junction_asset_group_id_name`) VALUES (:type_id, :asset_group_id)");
            $stmt->bindParam(":asset_group_id", $aag_id, PDO::PARAM_INT);
            $stmt->bindParam(":type_id", $item_id, PDO::PARAM_INT);
            $stmt->execute();
        }
    }
       
    // So the Issue we're solving below is that
    //     a,  there's no validation on whether the user updating the incident has access to the assets sent over to the server
    //         to be associated to the item(can be exploited by sending over IDs that the user have no permission to)
    //     b,  when a user who doesn't have permission to all the assets associated with the item edits the item
    //         can accidentally remove those assets because the logic just saves those that are sent over. To solve this
    //         we're adding back the assets the user has no permission to edit
    // If team separation is enabled
    if ($team_separation_asset_saving_logic) {
        //Include the team separation extra
        require_once(realpath(__DIR__ . '/../extras/separation/index.php'));
        
        $user_id = (int)$_SESSION['uid'];

        // If there're assets and we have to check if the user has access to them
        if (!empty($assets)) {
            // Sanitize the assets(remove assets sent from the client side that are not accessible by the user)
            // This logic would wrongly exclude the assets created through the widget if the 'Allow all users to see assets not assigned to a team' option isn't enabled
            // since they won't have a team assigned, so we're adding back the ids of the newly created assets
            // It's still needed to filter out attempts of adding pre-existing assets that the user has no permission to
            $stmt = $db->prepare("
                SELECT
                	`a`.`id`
                FROM `assets` a
                	LEFT JOIN `user_to_team` u2t ON FIND_IN_SET(`u2t`.`team_id`, `a`.`teams`)
                WHERE
                	(`u2t`.`user_id` = :user_id" . (get_setting('allow_all_to_asset_noassign_team') ? " OR `a`.`teams` = ''" : '') . ")
                    AND `a`.`id` IN (" . implode(',', $assets) . ")
                GROUP BY
                	`a`.`id`;
            ");
            
            $stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
            $stmt->execute();
            $assets = $stmt->fetchAll(PDO::FETCH_COLUMN);
        }
        
        // Get all the asset ids that are associated to the item
        $stmt = $db->prepare("SELECT `asset_id` FROM `{$assets_junction_name}` WHERE `{$asset_junction_item_id_name}` = :item_id;");
        $stmt->bindParam(":item_id", $item_id, PDO::PARAM_INT);
        $stmt->execute();
        
        // Store the list of associated risk ids in the array
        $all_associated_assets = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // If there were associated assets in the first place
        if (!empty($all_associated_assets)) {
            // then get the assets the user actually had access to modify
            $stmt = $db->prepare("
                SELECT
                    `a`.`id`
                FROM `{$assets_junction_name}` aj
                    INNER JOIN `assets` a ON `aj`.`asset_id` = `a`.`id`
                WHERE
                    `aj`.`{$asset_junction_item_id_name}` = :item_id
                    AND " . get_user_teams_query_for_assets('a', false) . "
                GROUP BY
                    `a`.`id`
            ");
            $stmt->bindParam(":item_id", $item_id, PDO::PARAM_INT);
            $stmt->execute();
            $accessable_assets = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // If the user had access to any of the assets then to get the assets he/she doesn't have access to
            // we need the diff of the two lists
            if (!empty($accessable_assets)) {
                $not_accessable_assets = array_diff($all_associated_assets, $accessable_assets);
            } else {
                // But if the user doesn't have access to any of the already associated assets then it means
                // we have to add back all of them
                $not_accessable_assets = $all_associated_assets;
            }
            
            // Add the assets that weren't editable by the user back before saving
            $assets = array_merge($assets, $not_accessable_assets);
        }
    }

    // We add back the new assets to make sure they get assigned even though due to team separation settings
    // it may be possible that the user won't see the assets they just created(if the 'Allow all users to see assets not assigned to a team' option isn't enabled)
    $assets = array_unique(array_merge($assets, $new_assets));

    // Clear any current asset associations for this type
    $stmt = $db->prepare("DELETE FROM `{$assets_junction_name}` WHERE {$asset_junction_item_id_name} = :item_id");
    $stmt->bindParam(":item_id", $item_id, PDO::PARAM_INT);
    $stmt->execute();

    // re-create the asset associations for the item
    foreach ($assets as $asset_id) {
        $stmt = $db->prepare("INSERT INTO `$assets_junction_name` (`$asset_junction_item_id_name`, `$asset_junction_asset_id_name`) VALUES (:item_id, :asset_id)");
        $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
        $stmt->bindParam(":item_id", $item_id, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Close the database connection
    db_close($db);    
}

/***************************************************
 * FUNCTION: IMPORT SELECTED ASSETS ASSET GROUPS   *
 * Processing the data coming from the import      *
 * $type_id: Id of the risk                        *
 * $asset_and_group_names: data from the import.   *
 * Can contain asset/asset group names.            *
 * Group names are marked by being wrapped in      *
 * square brackets. For example: [group name 1]    *
 * $type: The type of the association              *
 ***************************************************/
function import_assets_asset_groups_for_type($type_id, $asset_and_group_names, $type) {

    // Open the database connection
    $db = db_open();

    switch($type) {
        case 'risk':
            $assets_junction_name = 'risks_to_assets';
            $asset_groups_junction_name = 'risks_to_asset_groups';
            $junction_id_name = 'risk_id';
            $forced_asset_verification_state = null;
        break;
        case 'questionnaire_answer':
            if(!assessments_extra() || !table_exists("questionnaire_answers_to_assets") || !table_exists("questionnaire_answers_to_asset_groups"))
            {
                return;
            }
            $assets_junction_name = 'questionnaire_answers_to_assets';
            $asset_groups_junction_name = 'questionnaire_answers_to_asset_groups';
            $junction_id_name = 'questionnaire_answer_id';
            $forced_asset_verification_state = true;
        break;
        
        default:
            return;
    }

    // Clear any current assets for this type
    $stmt = $db->prepare("DELETE FROM `$assets_junction_name` WHERE $junction_id_name = :$junction_id_name");
    $stmt->bindParam(":$junction_id_name", $type_id, PDO::PARAM_INT);
    $stmt->execute();

    $stmt = $db->prepare("DELETE FROM `$asset_groups_junction_name` WHERE $junction_id_name = :$junction_id_name");
    $stmt->bindParam(":$junction_id_name", $type_id, PDO::PARAM_INT);
    $stmt->execute();    

    // For each asset or group
    foreach (array_unique(explode(',', $asset_and_group_names)) as $name)
    {
        // Trim whitespaces
        $name = trim($name);

        if (preg_match('/^\[(.+)\]$/', $name, $matches)) {
            $name = trim($matches[1]);
            $type = 'group';
        } else $type = 'asset';

        if ($type=='asset') {
            $id = asset_exists($name);

            if (!$id)
                $id = add_asset('', $name);

        } elseif ($type=='group') {
            $id = get_value_by_name('asset_groups', $name);

            if (!$id)
                $id = create_asset_group($name);
        }

        if ($type=='asset') {
            // Add the new asset for this type
            $stmt = $db->prepare("INSERT INTO `$assets_junction_name` (`$junction_id_name`, `asset_id`) VALUES (:$junction_id_name, :asset_id)");
            $stmt->bindParam(":asset_id", $id, PDO::PARAM_INT);
        } elseif ($type=='group') {
            // Add the new group for this type
            $stmt = $db->prepare("INSERT INTO `$asset_groups_junction_name` (`$junction_id_name`, `asset_group_id`) VALUES (:$junction_id_name, :asset_group_id)");
            $stmt->bindParam(":asset_group_id", $id, PDO::PARAM_INT);
        }

        $stmt->bindParam(":$junction_id_name", $type_id, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Close the database connection
    db_close($db);    
}

function get_asset_groups_table() {

    global $escaper;

    echo "<table id='asset-groups-table' class='easyui-treegrid asset-groups-table'>";
    echo "<thead>";

        // If the customization extra is enabled, shows fields by asset customization
    if (customization_extra()) {
        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $active_fields = get_active_fields("asset");

        display_main_detail_asset_fields_treegrid_th($active_fields);
    }
    // If the customization extra is disabled, Show default main fields
    else {
        display_asset_name_treegrid_th();
        display_asset_ip_address_treegrid_th();
        display_asset_valuation_treegrid_th();
        display_asset_site_location_treegrid_th();
        display_asset_team_treegrid_th();
        display_asset_details_treegrid_th();
        display_asset_tags_treegrid_th();
        display_asset_actions_treegrid_th();
    }

    echo "</thead>\n";

    echo "</table>";

    // The treegrid is initialized here (rather than via the <table>'s own
    // data-options="...") because jQuery EasyUI parses data-options with
    // new Function(), which the hardened CSP's script-src (no 'unsafe-eval')
    // blocks -- see PR #2321. Columns are derived from the <th>s echoed
    // above (plain `field`/`align`/`width` attributes, not data-options),
    // so no columns option is needed here.
    echo "<script>
        $(function() {
            $('#asset-groups-table').treegrid({
                iconCls: 'icon-ok',
                animate: false,
                fitColumns: true,
                nowrap: true,
                pagination: true,
                pageSize: 10,
                pageList: [5,10,20,100],
                url: BASE_URL + '/api/v2/asset-group/tree',
                method: 'GET',
                idField: 'id',
                treeField: 'name',
                scrollbarSize: 0,
                loadFilter: function(data, parentId) {
                    return data.data;
                },
                onLoadSuccess: function(row, data){
                    //fixTreeGridCollapsableColumn();
                    //It's there to be able to have it collapsed on load
                    /*var tree = $('#asset-groups-table');
                    tree.treegrid('collapseAll');
                    tree.treegrid('options').animate = true;*/
                    if (data && data.total)
                        $('#asset-groups-count').text(data.total);
                }
            });
        });
    </script>";
}

function get_asset_groups_for_treegrid($offset, $rows) {

    global $lang, $escaper;

    $result = [];

    $db = db_open();

    $stmt = $db->prepare("select count(*) from `asset_groups`;");
    $stmt->execute();
    $result["total"] = $stmt->fetch()[0];

    $stmt = $db->prepare("
        SELECT
            `ag`.*,
            IF(`aag`.`asset_group_id` IS NULL, 'open', 'closed') as state
        FROM
            `asset_groups` ag
            LEFT OUTER JOIN `assets_asset_groups` aag ON `aag`.`asset_group_id` = `ag`.`id`
        GROUP BY
            `ag`.`id`
        ORDER BY
            `ag`.`name`
        LIMIT $offset,$rows;");
    $stmt->execute();
    $groups = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $update_tooltip = $escaper->escapeHtml($lang['UpdateAssetGroupTooltip']);
    $delete_tooltip = $escaper->escapeHtml($lang['DeleteAssetGroupTooltip']);

    foreach($groups as &$group) {
        $group['name'] = $escaper->escapeHtml($group['name']);
        $group['actions'] = "
            <div class='actions-cell d-flex justify-content-center align-items-center w-100'>
                <a title='{$update_tooltip}' class='asset-group--update' data-id='{$group['id']}'><i class='fa fa-edit'></i></a>
                <a title='{$delete_tooltip}' class='asset-group--delete' data-id='{$group['id']}'><i class='fa fa-trash'></i></a>
            </div>";
    }

    $result["rows"] = $groups;

    db_close($db);

    return $result;
}

function get_assets_of_asset_group_for_treegrid($id){

    global $lang, $escaper;

    $result = [];

    if (encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }

    $db = db_open();

    $stmt = $db->prepare("
        SELECT
            a.*,
            GROUP_CONCAT(DISTINCT tg.tag ORDER BY tg.tag ASC SEPARATOR ', ') as tags
        FROM
            `assets` a
            INNER JOIN assets_asset_groups aag ON aag.asset_id = a.id and aag.asset_group_id = $id
            LEFT JOIN tags_taggees tt ON tt.taggee_id = a.id AND tt.type = 'asset'
            LEFT JOIN tags tg on tg.id = tt.tag_id
        GROUP BY
            a.id
        ORDER BY
            " . (encryption_extra() ? "a.order_by_name" : "a.name") . ";
    ");

    $stmt->execute();
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $remove_tooltip = $escaper->escapeHtml($lang['RemoveAssetTooltip']);

    // If the customization extra, set custom values
    $active_fields = [];
    $customization_enabled = customization_extra();
    if ($customization_enabled)
    {
        // Load the extra
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));
        $active_fields = get_active_fields("asset");
    }

    foreach($assets as $asset) {
        $asset['state'] = 'open';
        $asset['parent'] = $id;

        $asset['name'] = $escaper->escapeHtml(try_decrypt($asset['name']));

        // the second parameter of preg_match() should be of type STRING. So if $asset['ip'] is NULL or UNDEFINED, then it should be converted into EMPTY STRING.
        $asset['ip'] = try_decrypt($asset['ip']) ?? '';
        
        if (!preg_match('/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/', $asset['ip']))
        {
            $asset['ip'] = "N/A";
        }

        $asset['location'] = $asset['location'] ? $escaper->escapeHtml(get_name_by_value("location", $asset['location'])) : "N/A";
        $asset['teams'] = $asset['teams'] ? $escaper->escapeHtml(get_name_by_value("team", $asset['teams'])) : "N/A";
        $asset['value'] = $escaper->escapeHtml(get_asset_value_by_id($asset['value']));

        $asset['details'] = $escaper->purifyHtml(try_decrypt($asset['details']));
        $asset['tags'] = $escaper->escapeHtml($asset['tags']);

        $asset['actions'] = "
            <div class='actions-cell d-flex justify-content-center align-items-center w-100'>
                <a title='{$remove_tooltip}' class='asset--remove' data-asset-id='{$asset['id']}' data-asset-group-id='{$id}'><i class='fa fa-times'></i></a>
            </div>";

        $asset['id'] = $asset['id'] . '-' . $id;

        // If customization extra is enabled
        if($customization_enabled)
        {
            $custom_values = get_custom_value_by_row_id($asset['id'], "asset");
            
            foreach($active_fields as $field)
            {
                if($field['is_basic'] !== 1)
                {
                    $value = "";
                    // Get value of custom field
                    foreach($custom_values as $custom_value)
                    {
                        if($custom_value['field_id'] == $field['id']){
                            $value = $custom_value['value'];
                            break;
                        }
                    }

                    if ($value) {
                        $asset[$field['id']] = get_custom_field_name_by_value($field['id'], $field['type'], $field['encryption'], $value);
                    }
                }
            }
        }

        $result[] = $asset;
    }

    db_close($db);

    return $result;
}

/**
 * Getting the list of verified assets and asset groups. If the id and type are provided then it sets the selected field to true for assets/asset groups that are selected.
 * You either specify NONE of the id or type to simply get the available assets and asset groups or specify BOTH to get the selected field populated.
 * 
 * @param int $id the id of the item the function should return the selected state of the assets for
 * @param string $type the type of the id
 * @param bool $selected_only whether we want the function to return only the selected assets(not verified assets will be returned too if they're selected)
 * @return array The list of all verified assets and asset groups. If the id and type are provided then sets the selected state for those that are selected for that item
 */
function get_assets_and_asset_groups_of_type($id = null, $type = null, $selected_only = false) {

    // Having this variable here so the code is easier to read later
    $has_id = $id !== null;

    // If the function got an id as a parameter then the type is required too
    if ($has_id && $type === null) {
        return [];
    }

    $junction_config_type = null;
    $assets_junction_name = null;
    $asset_groups_junction_name = null;
    $asset_junction_id_name = null;
    $asset_group_junction_id_name = null;

    // If no type and id provided then we don't need this setup step
    if ($type !== null) {

        if (!in_array($type, ['risk', 'assessment_answer', 'questionnaire_answer', 'questionnaire_risk', 'incident'])) {
            return [];
        }

        global $junction_config;
        // set the names of the junction fields and fields required for the query for the type provided
        switch($type) {
            case 'risk':
                if (!check_permission("riskmanagement")) {
                    return [];
                }
                $id = $has_id ? $id - 1000 : null;
                $junction_config_type = 'risks';
                $assets_junction_name = 'risks_to_assets';
                $asset_groups_junction_name = 'risks_to_asset_groups';
                break;
            case 'assessment_answer':
                if (!check_permission("assessments")) {
                    return [];
                }
                $junction_config_type = 'assessment_answers';
                $assets_junction_name = 'assessment_answers_to_assets';
                $asset_groups_junction_name = 'assessment_answers_to_asset_groups';
                break;
            case 'questionnaire_answer':
                if(!assessments_extra() || !check_permission("assessments") || !table_exists("questionnaire_answers_to_assets") || !table_exists("questionnaire_answers_to_asset_groups")) {
                    return [];
                }
                $junction_config_type = 'questionnaire_answers';
                $assets_junction_name = 'questionnaire_answers_to_assets';
                $asset_groups_junction_name = 'questionnaire_answers_to_asset_groups';
                break;
            case 'questionnaire_risk':
                if(!assessments_extra() || !check_permission("assessments")) {
                    return [];
                }
                $junction_config_type = 'questionnaire_risk_details';
                $assets_junction_name = 'questionnaire_risk_to_assets';
                $asset_groups_junction_name = 'questionnaire_risk_to_asset_groups';
                break;
            case 'incident':
                if(!incident_management_extra() || !check_permission("im_incidents")) {
                    return [];
                }
                $junction_config_type = 'incident_management_incidents';
                $assets_junction_name = 'incident_management_incident_to_assets';
                $asset_groups_junction_name = 'incident_management_incident_to_asset_groups';
                break;
        }

        // Use the data setup in the 
        $asset_junction_id_name = $junction_config[$junction_config_type]['junctions'][$assets_junction_name];
        $asset_group_junction_id_name = $junction_config[$junction_config_type]['junctions'][$asset_groups_junction_name];
    }

    $db = db_open();
    $encryption = encryption_extra();

    if ($encryption) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }

    if (team_separation_extra() && isset($_SESSION['uid'])) {
        require_once(realpath(__DIR__ . '/../extras/separation/index.php'));
        $team_based_separation_where_condition = " AND " . get_user_teams_query_for_assets('', false);
    } else {
        $team_based_separation_where_condition = '';
    }

    // If only have to return the selected items then an inner join is needed
    $join_type = $selected_only ? 'INNER' : 'LEFT OUTER';

    // So the things that are going on in this query:
    // If encryption is enabled the order is dictated by the order_by_name field instead of the name
    // If an id and type are provided then have to flag assets that are asigned to that item as selected
    // If team separation is enabled then have to add the query part for that
    $stmt = $db->prepare("
        SELECT
            *
        FROM (
            SELECT
                `a`.`id`,
                `a`.`name`,
                'asset' AS class,
                " . ($encryption ? "`a`.`order_by_name`" : "`a`.`name`") . " AS ordr,
                " . ($has_id ? "`aj`.`asset_id` IS NOT NULL" : '0') . " AS selected,
                `a`.`verified`
            FROM
                `assets` a
                " . ($has_id ? "{$join_type} JOIN `$assets_junction_name` aj ON `aj`.`asset_id` = `a`.`id` AND `aj`.`$asset_junction_id_name` = :id" : '') . "
            WHERE
                (`a`.`verified` = 1" . ($has_id ? " OR `aj`.`asset_id` IS NOT NULL" : '') . "){$team_based_separation_where_condition}
        UNION ALL
            SELECT
                `ag`.`id`,
                `ag`.`name`,
                'group' AS class,
                " . ($encryption ? "@rownum := @rownum + 1" : "`ag`.`name`") . " AS ordr,
                " . ($has_id ? "`agj`.`asset_group_id` IS NOT NULL" : '0') . " AS selected,
                '1' AS verified
            FROM
                `asset_groups` ag
                " . ($has_id ? "{$join_type} JOIN `$asset_groups_junction_name` agj ON `agj`.`asset_group_id` = `ag`.`id` AND `agj`.`$asset_group_junction_id_name` = :id" : '') . "
                " . ($encryption ? "JOIN (SELECT @rownum := 0) rn" : "") . "
        ) u
        GROUP BY
            `u`.`class`, `u`.`id`
        ORDER BY
            `u`.`class` ASC, `u`.`ordr` ASC;
    ");

    if ($has_id) {
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    }

    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);

    if ($encryption) {
        foreach ($data as &$item) {
            if ($item['class'] === 'asset') {
                $item['name'] = try_decrypt($item['name']);
            }
        }
    }

    return $data;

}

function get_assets_and_asset_groups_by_control_for_dropdown($control_id = false, $control_maturity = false) {

    $db = db_open();

    if (encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }
    if(team_separation_extra()){
        require_once(realpath(__DIR__ . '/../extras/separation/index.php'));
        $team_based_separation_where_condition = " AND " . get_user_teams_query_for_assets('', false);
    } else {
        $team_based_separation_where_condition = '';
    }

    // ONE flag drives both the SQL and the bind, because they used to be able
    // to disagree. The `:control_maturity` token is only ever emitted inside
    // the `$control_id ? ... : ""` branches below -- there is no maturity
    // filter to apply without a control to filter against -- but the bind at
    // the bottom was guarded on `$control_maturity !== false` alone. Any
    // caller that sent a maturity WITHOUT a control therefore bound a
    // parameter the prepared statement had no token for and got
    // "SQLSTATE[HY093] ... number of bound variables does not match number of
    // tokens" back as a 500 instead of the asset list.
    //
    // That is not a hypothetical caller: it is every freshly added "Mapped
    // Assets" row in the control modal. The widget sends both values for a
    // row that has no control yet, and jQuery serializes an undefined value
    // as an empty string -- so the endpoint reads control_id='' (falsy, no
    // token emitted) but control_maturity='' -> (int)'' -> 0, which is
    // !== false and bound anyway.
    $filter_by_maturity = $control_id && $control_maturity !== false;

    $sql = "
        SELECT
            *
        FROM (
            SELECT
                `a`.`id`,
                `a`.`name`,
                'asset' as class,
                " . (encryption_extra() ? "`a`.`order_by_name`" : "`a`.`name`") . " as ordr" .
    ($control_id ? ",`cta`.`asset_id` IS NOT NULL as selected" : "") . "
            FROM
                `assets` a " .
    ($control_id ? "LEFT OUTER JOIN `control_to_assets` cta ON `cta`.`asset_id` = `a`.`id` and `cta`.`control_id` = :control_id" . ($filter_by_maturity ? " and cta.control_maturity = :control_maturity " : "") : "") . "
            WHERE
                (`a`.`verified` = 1" . ($control_id ? " or `cta`.`asset_id` IS NOT NULL" : "") . ")" . " {$team_based_separation_where_condition}
        UNION ALL
            SELECT
                `ag`.`id`,
                `ag`.`name`,
                'group' as class,
                " . (encryption_extra() ? "@rownum := @rownum + 1" : "`ag`.`name`") . " as ordr" .
    ($control_id ? ",`ctag`.`asset_group_id` IS NOT NULL as selected" : "") . "
            FROM
                `asset_groups` ag " .
    ($control_id ? "LEFT OUTER JOIN `control_to_asset_groups` ctag ON `ctag`.`asset_group_id` = `ag`.`id` and `ctag`.`control_id` = :control_id " . ($filter_by_maturity ? " and ctag.control_maturity = :control_maturity " : "") : "") . 
    (encryption_extra() ? "JOIN (SELECT @rownum := 0) rn" : "") . "
        ) u
        ORDER BY
            `u`.`class`, `u`.`ordr`
        ;
    ";
    /*
        We have to play with the values in the ordr column as the type have to match so it works properly when ordering.
        If some are int and some are string, even the ints will be sorted as strings.
    
    */

    $stmt = $db->prepare($sql);

    if ($control_id)
        $stmt->bindParam(":control_id", $control_id, PDO::PARAM_INT);
    if ($filter_by_maturity)
        $stmt->bindParam(":control_maturity", $control_maturity, PDO::PARAM_INT);

    $stmt->execute();

    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);

    foreach($data as &$item)
        if ($item['class'] === 'asset')
            $item['name'] = try_decrypt($item['name']);

    return $data;
}

function get_assets_and_asset_groups_of_type_as_string($id, $type) {

    $data = get_assets_and_asset_groups_of_type($id, $type, true);
    if ($data) {
        $affected_assets = [];
        foreach($data as $item) {
            $affected_assets[] = $item['class'] === 'asset' ? $item['name'] : "[{$item['name']}]";
        }
        return implode(',', $affected_assets);
    }

    return "";
}

function get_list_of_asset_and_asset_group_names($risk_id, $formatted = false) {
    global $escaper;

    return array_map(function($item) use ($escaper, $formatted) {
        if ($formatted) {
            return "<span class='{$item['class']}'>" . $escaper->escapeHtml($item['name']) . "</span>";
        }
        return $escaper->escapeHtml($item['name']);
    }, get_assets_and_asset_groups_of_type($risk_id, 'risk', true));
}

/****************************************
 * FUNCTION : ASSETS FOR RISK ID        *
 * THIS FUNCTION IS OBSOLETE!!          *
 * No usage found as of v20190331-001   *
 ****************************************/
function assets_for_risk_id($risk_id)
{
    // Open the database connection
    $db = db_open();

    // Update the default asset valuation
    $stmt = $db->prepare("
        SELECT
            a.id,
            a.ip,
            a.name,
            a.value,
            a.location,
            a.teams,
            a.created,
            a.verified
        FROM
            `assets` a
        LEFT JOIN `risks_to_assets` b ON a.id = b.asset_id
        WHERE
            b.risk_id=:risk_id;
    ");
    $stmt->bindParam(":risk_id", $risk_id, PDO::PARAM_INT, 11);
    $stmt->execute();

    $assets = $stmt->fetchAll();

    // Close the database connection
    db_close($db);

    // Return the assets array
    return $assets;
}

/****************************************
 * FUNCTION: GET ASSETS FOR RISK        *
 * THIS FUNCTION IS OBSOLETE!!          *
 * No usage found as of v20190331-001   *
 ****************************************/
function get_assets_for_risk($risk_id)
{
    // Open the database connection
    $db = db_open();

    // Get the assets
    $stmt = $db->prepare("SELECT b.name as asset FROM `risks_to_assets` a JOIN `assets` b ON a.asset_id = b.id WHERE risk_id = :risk_id ORDER BY b.name");
    $stmt->bindParam(":risk_id", $risk_id, PDO::PARAM_INT);
    $stmt->execute();

    // Store the list in the assets array
    $assets = $stmt->fetchAll();

    // Close the database connection
    db_close($db);

    // Return the assets array
    return $assets;
}

/*******************************************
 * FUNCTION: GET ASSET GROUPS FROM ASSET   *
 *******************************************/
function get_asset_groups_from_asset($asset_id)
{
    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("
        SELECT ag.*
        FROM `assets_asset_groups` aag
        LEFT JOIN `asset_groups` ag ON ag.id = aag.asset_group_id
        WHERE `asset_id` = :asset_id
    ");
    $stmt->bindParam(":asset_id", $asset_id, PDO::PARAM_INT);
    $stmt->execute();

    $groups = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);
    
    return $groups;   
}
/*******************************************
 * FUNCTION: GET ASSETS FROM ASSET GROUP   *
 *******************************************/
function get_assets_from_group($group_id)
{
    // Open the database connection
    $db = db_open();

    $stmt = $db->prepare("
        SELECT *
        FROM `assets_asset_groups` 
        WHERE asset_group_id = :group_id
    ");
    $stmt->bindParam(":group_id", $group_id, PDO::PARAM_INT);
    $stmt->execute();

    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    db_close($db);
    
    return $assets;   
}
/*******************************************
 * FUNCTION: GET ASSET IDS FROM GROUPS     *
 *******************************************/
function get_asset_ids_from_groups($group_ids)
{
    $asset_ids = [];
    foreach($group_ids as $group){
        $assets = get_assets_from_group($group);
//      $singleArray = array();
//      foreach ($asserts as $key => $value){
//          $singleArray[$key] = $value['asset_id'];
//      }
        $asset_ids = array_unique(array_merge($asset_ids,array_column($assets,"asset_id")));
    }
    return $asset_ids;

}

/**
 * The entries of an asset's `associated_risks` select part (the JSON array
 * of {value: internal risk id, name: stored subject} built by the
 * field_settings join) that the caller may see (SR-2313): none without the
 * Risk Management permission, and otherwise each risk must pass
 * check_access_for_risk() through filter_accessible_risk_ids(), so under Team
 * Separation another team's risk is neither named nor counted. Without the
 * Extra every entry is kept for a Risk Management user. Names stay as stored
 * (the caller decrypts and escapes).
 *
 * @param mixed $json the select part's value
 * @return array<int,array{value:int,name:string}>
 */
function assets_visible_associated_risk_entries($json): array
{
    if (!is_string($json) || $json === '' || $json === '[]' || !assets_caller_can_see_associated_risks()) {
        return [];
    }
    $entries = json_decode($json, true);
    if (!is_array($entries)) {
        return [];
    }
    $entries = array_values(array_filter($entries, fn($e) => is_array($e) && isset($e['value'])));
    $visible = array_flip(filter_accessible_risk_ids(array_column($entries, 'value')));

    $out = [];
    foreach ($entries as $entry) {
        if (isset($visible[(int)$entry['value']])) {
            $out[] = ['value' => (int)$entry['value'], 'name' => (string)($entry['name'] ?? '')];
        }
    }
    return $out;
}

function get_assets_data_for_view_v2($view, $selected_fields, $verified = null, $start = 0, $length = 10, $orderColumn = 'id', $orderDir = 'ASC', $column_filters = []) {

    global $field_settings_views, $field_settings, $escaper, $lang;
    $customization = customization_extra();
    
    // If there's an edit section setup in the view settings then the view is editable
    $view_editable = !empty($field_settings_views[$view]['edit']);
    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $view_edit_type_popup = $view_editable && $field_settings_views[$view]['edit']['type'] === 'popup';
    
    // Open the database connection
    $db = db_open();
    
    $params = [];
    $encryption = encryption_extra();
    
    $actions_tooltips = [];
    $actions_column_info = !empty($field_settings_views[$view]['actions_column']) ? $field_settings_views[$view]['actions_column'] : false;
    if ($actions_column_info) {
        // Create an array of escaped localized strings so it doesn't have to be done for every assets
        $actions_tooltips = [
            'edit' => $escaper->escapeHtml($lang['Edit']),
            'verify' => $escaper->escapeHtml($lang['Verify']),
            'discard' => $escaper->escapeHtml($lang['Discard']),
            'delete' => $escaper->escapeHtml($lang['Delete']),
        ];
    }

    $sql_order_column = null;
    if (str_starts_with($orderColumn, 'custom_field_')) {
        $sql_orderable = false;
    } else {
        // Can only order fields in the sql if they're not a custom field and encryption isn't enabled or they're not encrypted or if it's specifically stated that it's sql orderable
        // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
        $sql_orderable =
        // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
        (!$encryption || !$field_settings['asset'][$orderColumn]['encrypted']) &&
        // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
        (!array_key_exists('force_php_ordering', $field_settings['asset'][$orderColumn]) || !$field_settings['asset'][$orderColumn]['force_php_ordering']);

        if ($sql_orderable) {
            // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
            $sql_order_column = $field_settings['asset'][$orderColumn]['order_column'];
        } else {
            // If encryption is turned on and there's an encrypted order column specified then use that column for ordering and mark it as sql orderable
            // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
            if ($encryption && $field_settings['asset'][$orderColumn]['encrypted'] && !empty($field_settings['asset'][$orderColumn]['encrypted_order_column'])) {
                // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
                $sql_order_column = $field_settings['asset'][$orderColumn]['encrypted_order_column'];
                $sql_orderable = true;
            // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
            } elseif(array_key_exists('force_php_ordering', $field_settings['asset'][$orderColumn]) && $field_settings['asset'][$orderColumn]['force_php_ordering']) {
                // technically it would be possible to order in sql, but the result would be wrong, have to order in PHP by the display string
                // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
                $orderColumn = $field_settings['asset'][$orderColumn]['order_column'];
            }
        }
    }
    
    if ($verified !== null) {
        $where = "WHERE `a`.`verified` = :verified";
        $params['verified'] = $verified;
    } else {
        $where = "WHERE 1";
    }

    $where .= call_extra_function(
        'team_separation_extra',
        __DIR__ . '/../extras/separation/index.php',
        'get_user_teams_query_for_assets',
        ['a', false, true],
        ''
    );
    
    // At this point it's safe to add the column directly into the sql as it was validated
    $order_by = $sql_orderable ?  "ORDER BY {$sql_order_column} {$orderDir}, `a`.`id` ASC" : "";
    
    // We can do the paging through sql if there's no filtering and we can do the ordering through sql as well
    $sql_paging = empty($column_filters) && $sql_orderable;
    if ($sql_paging) {
        // When requesting every results the $length is -1 so we only limit the results if $length is greater than 0
        if ($length > 0) {
            $paging = "LIMIT {$start}, {$length}";
        } else {
            // In this case the $sql_paging = true to not try doing the paging using php code
            // but we're not limiting the number of returned results as we want all of them
            $paging = '';
        }
    } else {
        // paging will be done using php code
        $paging = '';
    }

    list($select_parts, $join_parts) = field_settings_get_join_parts($view, $selected_fields);

    $sql = "
        SELECT SQL_CALC_FOUND_ROWS t1.*
        FROM (
            SELECT
                " . implode(',', $select_parts) . "
            FROM
                `assets` a
                " . implode(' ', $join_parts) . "
            {$where}
            GROUP BY
                `a`.`id`
            {$order_by}
        ) t1
        {$paging};
    ";
    // error_log("SQL: $sql");
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $assets = $stmt->fetchAll();
    // error_log("ASSETS: " . json_encode($assets));
    $stmt = $db->prepare("SELECT FOUND_ROWS();");
    $stmt->execute();
    $recordsTotal = $stmt->fetch()[0];

    // Close the database connection
    db_close($db);

    $columns_with_filters = array_keys($column_filters);

    // Get and store the currency here and not every time in the loop
    // also, only do it if the value column is selected
    $currency_sign = null;
    if (in_array('value', $selected_fields)) {
        $currency_sign = get_setting("currency");
    }

    $rows = [];
    $filtered = false;
    foreach($assets as &$asset) {

        $drop_row = false;
        // If customization data for the asset is present
        if ($customization && !empty($asset['field_data']) && $asset['field_data'] !== '[]') {
            // extract it as normal fields
            foreach (json_decode($asset['field_data'], true) as $field_data) {
                
                if (empty($asset["custom_field_{$field_data['field_id']}_display"])) {
                    // only the rest needs formatting and only those fields that are selected. In this case they're escaped as well
                    if (in_array("custom_field_{$field_data['field_id']}", $selected_fields)) {
                        $asset["custom_field_{$field_data['field_id']}"] = get_custom_field_name_by_value($field_data['field_id'], $field_data['type'], $field_data['encryption'], $field_data['value']);
                    }
                } else {
                    // select/multi-select fields are already on the asset, returned by the sql
                    // so the custom fields already in the data needs to be escaped
                    $asset["custom_field_{$field_data['field_id']}_display"] = $escaper->escapeHtml($asset["custom_field_{$field_data['field_id']}_display"]);
                    $asset["custom_field_{$field_data['field_id']}"] = explode(',', (string)$field_data['value']);
                }
            }

            // Custom fields are ordered by their display strings
            if (!$sql_orderable && str_starts_with($orderColumn, 'custom_field_') && array_key_exists("{$orderColumn}_display", $asset)) {
                $orderColumn = "{$orderColumn}_display";
            }
        }

        $row = ['id' => $asset['id']];

        foreach ($selected_fields as $selected_field_name) {
            $field_setting = !empty($field_settings['asset'][$selected_field_name]) ? $field_settings['asset'][$selected_field_name] : false;
            $value = '';
            $display = false;
            if (!empty($asset[$selected_field_name])) {
                // if it's not defined in the settings it's probably a custom field
                if ($customization && empty($field_settings['asset'][$selected_field_name]) && str_starts_with($selected_field_name, 'custom_field_')) {
                    // as of now with how the custom field's actual values' getting goes they're already encrypted and escaped at this point
                    $value = !empty($asset[$selected_field_name]) ? $asset[$selected_field_name] : '';
                    $display = isset($asset["{$selected_field_name}_display"]) ? $asset["{$selected_field_name}_display"] : false;
                } else {
                    $value = $asset[$selected_field_name];
                    $display = isset($asset["{$selected_field_name}_display"]) ? $asset["{$selected_field_name}_display"] : false;
                    if ($value && $encryption && !empty($field_setting['encrypted']) && $field_setting['encrypted']) {
                        $value = try_decrypt($value);
                    }

                    // For fields that need custom formatting
                    switch($selected_field_name) {
                        case "teams":
                        case "location":
                            $value = explode(',', $value);
                            break;
                        case "details":
                            $value = $escaper->purifyHtml($value);
                            break;
                        case 'tags':
                            if ($value) {
                                $tags = [];
                                foreach(explode("|", $value) as $tag) {
                                    $tags []= $escaper->escapeHtml($tag);
                                }
                                $value = $tags;
                            }
                            break;
                        case 'value':
                            $display = $escaper->escapeHtml(str_replace('{currency}', $currency_sign, $display));
                            break;
                        case 'created':
                            $display = $escaper->escapeHtml(format_datetime($value));
                            break;
                        case 'verified':
                            $display = $escaper->escapeHtml(localized_yes_no($value));
                            break;
                        case 'mapped_controls':
                            if (!empty($value) && $value !== '[]') {
                                $mapped_controls = [];
                                foreach (json_decode($value, true) as $mapping) {
                                    $mapped_controls = [...$mapped_controls, ...explode('|', $mapping['control_names'])];
                                }
                                
                                sort($mapped_controls);
                                // Escape each control name — the value is rendered raw
                                // by the datatable column (no client renderer). Mirrors
                                // the associated_risks case below.
                                $value = implode(', ', array_map(fn($n) => $escaper->escapeHtml($n), $mapped_controls));
                            } else {
                                $value = '';
                            }
                            break;
                        case 'associated_risks':
                            // Only the risks the caller may see (Team Separation).
                            $associated_risks = [];
                            foreach (assets_visible_associated_risk_entries($value) as $associated_risk) {
                                $associated_risk_id = 1000 + $associated_risk['value'];
                                $associated_risks []= $escaper->escapeHtml("[{$associated_risk_id}]" . try_decrypt($associated_risk['name']));
                            }
                            $value = implode(', ', $associated_risks);
                            break;
                        default:
                            // Only have to escape non-custom fields as those are already escaped
                            $value = $escaper->escapeHtml($value);
                    }
                }
            } elseif(array_key_exists("{$selected_field_name}_display", $asset)) {
                // To make sure that even empty values are properly sent back
                $display = '';
            }

            $row[$selected_field_name] = $value;
            if ($display !== false) {
                $row["{$selected_field_name}_display"] = $display;
            }

            // Do the filtering.
            // stripos(is_array($value) ? implode('|', $value) : $value, $column_filters[$selected_field_name]) === false
            // The above line is used to be able to filter within both arrays and primitive values by making the array a single string separated by something that's not likely to be searched on
            if (!empty($columns_with_filters) && in_array($selected_field_name, $columns_with_filters)) {
                $filter_value = $display !== false ? $display : $value;
                if(stripos(is_array($filter_value) ? implode('|', $filter_value) : $filter_value, $column_filters[$selected_field_name]) === false) {
                    $drop_row = true;
                    $filtered = true;
                    // If the row is getting filtered out we can stop processing it
                    break;
                }
            }
        }

        // Add the row only if it's not filtered out
        if (!$drop_row) {

            // Only if the action column info is set for the view
            if ($actions_column_info) {

                // Only show the edit button if the view's edit type is popup, no need for the button for inline editing
                // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                $asset_actions = $view_edit_type_popup ? ["<button type='button' class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='edit' title='{$actions_tooltips['edit']}'><i class='fa fa-edit'></i></button>"] : [];

                // Different actions are available based on whether we want the verified/unverified/all assets
                if ($verified === 1) {
                    // When we display the verified assets the delete button is available
                    // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                    $asset_actions []= "<button class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='delete' title='{$actions_tooltips['delete']}'><i class='fa fa-trash'></i></button>";
                } elseif ($verified === 0) {
                    // When we display the not verified assets both the verify and discard buttons are available
                    // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                    $asset_actions []= "<button class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='discard' title='{$actions_tooltips['discard']}'><i class='fa fa-trash'></i></button>";
                    // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                    $asset_actions []= "<button class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='verify' title='{$actions_tooltips['verify']}'><i class='fa fa-check'></i></button>";
                } else {

                    // in case of displaying all assets the presence of the verify button is decided on a per row basis
                    if (!$asset['verified']) {
                        // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                        $asset_actions []= "<button class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='discard' title='{$actions_tooltips['discard']}'><i class='fa fa-trash'></i></button>";
                        // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                        $asset_actions []= "<button class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='verify' title='{$actions_tooltips['verify']}'><i class='fa fa-check'></i></button>";
                    } else {
                        // @phan-suppress-next-line PhanTypePossiblyInvalidDimOffset -- $actions_tooltips populated upstream when $actions_column_info is set
                        $asset_actions []= "<button class='btn btn-secondary btn-sm asset-row-action' style='margin:1px; padding: 4px 12px;' role='button' data-action='delete' title='{$actions_tooltips['delete']}'><i class='fa fa-trash'></i></button>";
                    }
                }
                $row[$actions_column_info['field_name']] = "<span data-id='{$asset['id']}'>" . implode('', $asset_actions) . "</span>";
            }
            $rows []= $row;
        }
    }

    $recordsFiltered = $filtered ? count($rows) : $recordsTotal;

    if (!$sql_orderable) {
        usort($rows, function($a, $b) use ($orderDir, $orderColumn){
            // For identical custom fields we're sorting on the id, so the results' order is not changing randomly
            if ($a[$orderColumn] === $b[$orderColumn]) {
                return (int)$a['id'] - (int)$b['id'];
            }
            
            return strcasecmp($a[$orderColumn], $b[$orderColumn]) * ($orderDir === "ASC" ? 1 : -1);
        });
    }

    if (!$sql_paging) {
        // Requesting all results is marked by $length's value being -1. In that case we're not applying the below logic
        // only when $length is greater than 0
        if($length > 0) {
            $page_rows = [];
            $row_count = count($rows);
            for($i = $start; $i < $row_count && $i < $start + $length; $i++){
                $page_rows[] = $rows[$i];
            }
            $rows = $page_rows;
        }
    }

    $data = [
        'rows' => $rows,
        'recordsTotal' => $recordsTotal,
        'recordsFiltered' => $recordsFiltered,
    ];

    return $data;
}


// Used to update the asset through the API call
function update_asset_API_v2($view) {

    global $field_settings_views, $field_settings, $lang, $escaper;

    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $view_type = $field_settings_views[$view]['view_type'];
    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $id_field = $field_settings_views[$view]['id_field'];
    $id = (int)$_POST[$id_field];

    // The name is trimmed before the checks below and before it is stored
    // (SR-37), so a blank one fails the required check; if it is already
    // taken, but not by this asset, the edit is refused.
    if ($view_type === 'asset' && isset($_POST['name']) && is_scalar($_POST['name'])) {
        $_POST['name'] = trim((string)$_POST['name']);
        if ($_POST['name'] !== '') {
            $stored_name = asset_name_for_edit($_POST['name'], $id);
            if ($stored_name === null) {
                set_alert(true, "bad", _lang_raw('EditFailed_FieldMustBeUnique', ['field' => 'name']));
                api_v2_json_result(400, get_alert(true), NULL);
            }
            $_POST['name'] = $stored_name;
        }
    }
    
    $mapped_custom_field_settings = [];
    $custom_field_data = [];
    $asset_name = null;

    // If customization is enabled then gather information about the custom fields
    if ($customization = customization_extra()) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $active_fields = get_active_fields($view_type);
        foreach ($active_fields as $active_field) {
            // Skip this step for basic fields
            if ($active_field['is_basic']) {
                continue;
            }

            $mapped_custom_field_settings["custom_field_{$active_field['id']}"] = [
                'field_id' => $active_field['id'],
                'required' => $active_field['required'],
                'editable' => true, // Custom fields are always editable for now
            ];
        }
    }

    $original = get_asset_for_change_checking($id);

    if ($encryption = encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }
    
    if ($notification = notification_extra()) {
        require_once(realpath(__DIR__ . '/../extras/notification/index.php'));
    }

    $tags = [];
    $mapped_controls = [];
    $associated_risks_new = [];

    $update_parts = [];
    $params = [":$id_field" => $id];

    // Do the field validation(like required fields not having a value) and collect the data for the update
    foreach (field_settings_get_localization($view, false, false) as $field_name => $field_text) {

        // Skipping checks for the ID field here
        if ($field_name === $id_field) {
            continue;
        }
        
        // Check if the field is required and if it is, then whether it has a proper value set
        if (empty($_POST[$field_name]) && ((!empty($field_settings[$view_type][$field_name]) && $field_settings[$view_type][$field_name]['required'])
            || ($customization && !empty($mapped_custom_field_settings[$field_name]) && $mapped_custom_field_settings[$field_name]['required']))) {
            set_alert(true, "bad", _lang('EditFailed_RequiredFieldEmpty', ['field' => $field_text]));
            api_v2_json_result(400, get_alert(true), NULL);
        }
        
        // check if the field is editable
        if (((!empty($field_settings[$view_type][$field_name]) && !$field_settings[$view_type][$field_name]['editable']) || ($customization && !empty($mapped_custom_field_settings[$field_name]) && !$mapped_custom_field_settings[$field_name]['editable']))) {
            // If not editable but it's sent somehow then this is an error
            if (isset($_POST[$field_name])) {
                set_alert(true, "bad", _lang('EditFailed_FieldNotEditable', ['field' => $field_text]));
                api_v2_json_result(400, get_alert(true), NULL);
            } else {
                // otherwise we're just skipping the processing of this field
                continue;
            }
        }

        $field_value = $_POST[$field_name] ?? null;
        // Storing values after validation to update the asset
        if ($customization && str_starts_with($field_name, 'custom_field_')) {
            // Storing the field's value so we can save that after the asset is updated
            // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
            $custom_field_data[$mapped_custom_field_settings[$field_name]['field_id']] = $field_value;
        } else {
            // These fields are still comma selected ids, need to remove this part once they're properly converted to use junction tables
            // and have a separate section for them like for the tags
            if (($field_name === "location" || $field_name === "teams") && is_array($field_value)) {
                $field_value = implode(",", $field_value);
            }

            switch ($field_name) {
                case 'tags':
                    // If it's empty, we need an empty array, rather than null that's the default behavior for missing data
                    $tags = $field_value ? $field_value : [];

                    foreach($tags as $tag){
                        if (strlen($tag) > 255) {
                            set_alert(true, "bad", $lang['MaxTagLengthWarning']);
                            api_v2_json_result(400, get_alert(true), NULL);
                        }
                    }
                    break;
                case 'mapped_controls':
                    $mapped_controls = empty($_POST['mapped_controls']) ? [] : $_POST['mapped_controls'];
                    break;
                case 'associated_risks':
                    // An absent key keeps the links (see below), so there is nothing to notify about.
                    if (!array_key_exists('associated_risks', $_POST)) {
                        break;
                    }
                    // Storing the list of associated risks so we can update it once the asset itself is updated
                    // If it's empty, we need an empty array, rather than null that's the default behavior for missing data
                    $associated_risks_new = $field_value ? $field_value : [];

                    if ($notification) {
                        // Also, storing the current list of associated risks so we can calculate the list of risk changes for the risk update notification
                        $associated_risks_current = get_associated_risks_for_asset($id);

                        // Get what risks were removed or added, for the notification we can ignore those that weren't changed
                        $associated_risks_need_notified = array_unique(array_merge(array_diff($associated_risks_new, $associated_risks_current), array_diff($associated_risks_current, $associated_risks_new)));
                    }
                    break;
                default:
                    // Store the asset name for the audit log before the encryption
                    if ($view_type === 'asset' && $field_name === 'name') {
                        $asset_name = $field_value;
                    }

                    // Encrypt the field if needed
                    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
                    if ($encryption && $field_settings[$view_type][$field_name]['encrypted']) {
                        $field_value = try_encrypt($field_value);
                    }

                    // build the parts that'll be used to construct the update
                    $update_parts [] = "`{$field_name}` = :{$field_name}";
                    $params[":{$field_name}"] = $field_value;
                    break;
            }
        }
    }

    // A verified asset whose name or IP is changed by a user without
    // asset_verify goes back to unverified (spec section 10), same rule as
    // PATCH /assets/{id}. `verified` itself is not an editable field here.
    $unverified_by_identity_edit = false;
    if ($view_type === 'asset' && asset_edit_demotes_verification(
        $id,
        isset($_POST['name']) && is_scalar($_POST['name']) ? (string)$_POST['name'] : null,
        isset($_POST['ip']) && is_scalar($_POST['ip']) ? (string)$_POST['ip'] : null
    )) {
        $update_parts[] = "`verified` = :verified_demoted";
        $params[':verified_demoted'] = 0;
        $unverified_by_identity_edit = true;
    }

    $db = db_open();

    $stmt = $db->prepare("UPDATE `assets` SET " . implode(',', $update_parts) . " WHERE {$id_field} = :{$id_field};");
    $stmt->execute($params);

    db_close($db);

    // Save control mappings
    save_asset_to_controls($id, $mapped_controls);
    // Update tags even when they didn't change as the time we'd win on not saving them is lost on the checks
    // so if we check and then still have to save we'd basically just wasted time on checking
    updateTagsOfType($id, $view_type, $tags);

    // Only a body that names associated_risks changes the links (SR-2313): an
    // absent key keeps them, so a save never silently drops an asset's risks.
    if (array_key_exists('associated_risks', $_POST)) {
        update_asset_risks_associations($id, $associated_risks_new);
    }

    if ($notification && !empty($associated_risks_need_notified)) {
        // Only send the notification about the updated risks that were changed on the asset
        foreach ($associated_risks_need_notified as $risk_id) {
            notify_risk_update($risk_id);
        }
    }

    if ($customization && !save_custom_field_values($id, $view_type, $custom_field_data)) {
        // It will basically never happen as we're checking values before even getting to the saving part to make sure we're not saving only half of the data
        api_v2_json_result(400, get_alert(true), NULL);
    }

    // Only when the name changed. get_asset_for_change_checking() returns the
    // name decrypted; try_decrypt() keeps the comparison plaintext-to-plaintext
    // should that ever change.
    if ($encryption && $asset_name !== null && (string)try_decrypt($original['name'] ?? '') !== (string)$asset_name) {
        update_name_order_for_asset($id, $asset_name);
    }

    $updated = get_asset_for_change_checking($id);

    $changes = get_changes_in_asset($original, $updated);

    if (!empty($changes)) {
        write_log($id, $_SESSION['uid'] ?? 0, _lang_raw('AssetAuditLogUpdate', array('asset_name' => $asset_name, 'user' => $_SESSION['user'], 'changes' => implode(', ', $changes))), 'asset');

        trigger_workflow_event('asset.updated', [
            'asset_id' => $id,
            'name'     => $asset_name,
        ]);
    }

    if ($unverified_by_identity_edit) {
        asset_write_unverified_by_edit_log($id, $asset_name);
    }

    set_alert(true, "good", $escaper->escapeHtml($lang['AssetWasUpdatedSuccessfully']));
    api_v2_json_result(200, get_alert(true), NULL);

}


function create_asset_API_v2($view) {

    global $field_settings_views, $field_settings, $lang, $escaper;

    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $view_type = $field_settings_views[$view]['view_type'];
    
    // Stored trimmed, the way add_asset() stores it (SR-37); asset_exists()
    // already compares trimmed names.
    if ($view_type === 'asset' && isset($_POST['name']) && is_scalar($_POST['name'])) {
        $_POST['name'] = trim((string)$_POST['name']);
    }

    // If the asset name is alread taken, but not on this asset
    if (!empty($_POST['name']) && asset_exists($_POST['name'])) {
        set_alert(true, "bad", _lang_raw('EditFailed_FieldMustBeUnique', ['field' => 'name']));
        api_v2_json_result(400, get_alert(true), NULL);
    }

    $mapped_custom_field_settings = [];
    $custom_field_data = [];
    $asset_name = null;

    // Which admin-defined template group this record was created under.
    // Read from the request (the create modal renders one <form> per
    // template-group tab, each carrying its own hidden template_group_id --
    // see render_create_modal()) and validated against the caller's actual
    // fgroup/business-unit assignment by resolve_template_group_id() below.
    $template_group_id = get_param("POST", "template_group_id", null);
    $template_group_id = $template_group_id !== null ? (int)$template_group_id : null;
    // Same Core guard add_asset() uses: resolves/validates through the Extra
    // when it is active, otherwise stores the value as submitted or the
    // schema's own Default of 1 -- without ever bare-requiring the Extra.
    $template_group_id = resolve_template_group_id_from_core($view_type, $template_group_id);

    // If customization is enabled then gather information about the custom fields
    if ($customization = customization_extra()) {
        require_once(realpath(__DIR__ . '/../extras/customization/index.php'));

        $active_fields = get_active_fields($view_type, $template_group_id);
        foreach ($active_fields as $active_field) {
            // Skip this step for basic fields
            if ($active_field['is_basic']) {
                continue;
            }

            $mapped_custom_field_settings["custom_field_{$active_field['id']}"] = [
                'field_id' => $active_field['id'],
                'required' => $active_field['required'],
                'editable' => true, // Custom fields are always editable for now
            ];
        }
    }

    if ($encryption = encryption_extra()) {
        require_once(realpath(__DIR__ . '/../extras/encryption/index.php'));
    }

    if ($notification = notification_extra()) {
        require_once(realpath(__DIR__ . '/../extras/notification/index.php'));
    }

    $tags = [];
    $mapped_controls = [];
    $associated_risks = [];
    
    $insert_parts = ["`verified` = :verified", "`template_group_id` = :template_group_id"];
    // Verified iff the creator holds asset_verify or auto_verify_new_assets is
    // on (spec D8/10); this legacy create-modal route used to always set true.
    // (int): execute($params) binds as strings, and false would bind as ''.
    $params = ["verified" => (int)asset_new_verified_for_current_user(), "template_group_id" => $template_group_id];
    // Do the field validation(like required fields not having a value) and collect the data for the update
    foreach (field_settings_get_localization($view, false, false, true, $customization ? $template_group_id : null) as $field_name => $field_text) {

        // Skipping checks for the verified field here
        if ($field_name === 'verified') {
            continue;
        }

        // Check if the field is required and if it is, then whether it has a proper value set
        if (empty($_POST[$field_name]) && ((!empty($field_settings[$view_type][$field_name]) && $field_settings[$view_type][$field_name]['required'])
            || ($customization && !empty($mapped_custom_field_settings[$field_name]) && $mapped_custom_field_settings[$field_name]['required']))) {
            set_alert(true, "bad", _lang('EditFailed_RequiredFieldEmpty', ['field' => $field_text]));
            api_v2_json_result(400, get_alert(true), NULL);
        }

        $field_value = $_POST[$field_name] ?? null;
        // Storing values after validation to update the asset
        if ($customization && str_starts_with($field_name, 'custom_field_')) {
            // Storing the field's value so we can save that after the asset is updated
            // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
            $custom_field_data[$mapped_custom_field_settings[$field_name]['field_id']] = $field_value;
        } else {
            // These fields are still comma selected ids, need to remove this part once they're properly converted to use junction tables
            // and have a separate section for them like for the tags
            if (($field_name === "location" || $field_name === "teams") && is_array($field_value)) {
                $field_value = implode(",", $field_value);
            }

            switch ($field_name) {
                case 'tags':
                    // If it's empty, we need an empty array, rather than null that's the default behavior for missing data
                    $tags = $field_value ? $field_value : [];
                    
                    foreach($tags as $tag){
                        if (strlen($tag) > 255) {
                            set_alert(true, "bad", $lang['MaxTagLengthWarning']);
                            api_v2_json_result(400, get_alert(true), NULL);
                        }
                    }
                    break;
                case 'mapped_controls':
                    $mapped_controls = empty($_POST['mapped_controls']) ? [] : $_POST['mapped_controls'];
                    
                    /*foreach($mapped_controls as $mapped_control){
                        if($control_id[$index]) $mapped_controls[] = array($maturity, $control_id[$index]);
                    }*/
                    
                    
                    /*$control_maturity   = empty($_POST['control_maturity']) ? [] : $_POST['control_maturity'];
                    $control_id         = empty($_POST['control_id']) ? [] : $_POST['control_id'];
                    foreach($control_maturity as $index=>$maturity){
                        if($control_id[$index]) $mapped_controls[] = array($maturity, $control_id[$index]);
                    }*/
                    break;
                case 'associated_risks':
                    // Storing the list of associated risks so we can set it once the asset itself is created
                    // If it's empty, we need an empty array, rather than null that's the default behavior for missing data                    
                    if ($notification) {
                        $associated_risks = $field_value ? $field_value : [];
                    } else {
                        $associated_risks = [];
                    }
                    break;
                default:
                    // Store the asset name for the audit log before the encryption
                    if ($view_type === 'asset' && $field_name === 'name') {
                        $asset_name = $field_value;
                    }
                    
                    // Encrypt the field if needed
                    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
                    if ($encryption && $field_settings[$view_type][$field_name]['encrypted']) {
                        $field_value = try_encrypt($field_value);
                    }

                    // build the parts that'll be used to construct the insert
                    $insert_parts [] = "`{$field_name}` = :{$field_name}";
                    $params[":{$field_name}"] = $field_value;
                    break;
            }
        }
    }
    
    $db = db_open();
    
    $stmt = $db->prepare("INSERT INTO `assets` SET " . implode(',', $insert_parts) . ";");
    $stmt->execute($params);

    $id = $db->lastInsertId();

    db_close($db);
    
    // Save control mappings
    save_asset_to_controls($id, $mapped_controls);

    // Update tags even when they didn't change as the time we'd win on not saving them is lost on the checks
    // so if we check and then still have to save we'd basically just wasted time on checking
    updateTagsOfType($id, $view_type, $tags);
    
    update_asset_risks_associations($id, $associated_risks);
    
    if ($notification && !empty($associated_risks)) {
        // Only send the notification about the updated risks that were changed on the asset
        foreach ($associated_risks as $risk_id) {
            notify_risk_update($risk_id);
        }
    }
    
    if ($customization && !save_custom_field_values($id, $view_type, $custom_field_data)) {
        // It will basically never happen as we're checking values before even getting to the saving part to make sure we're not saving only half of the data
        api_v2_json_result(400, get_alert(true), NULL);
    }
    
    if ($encryption) {
        update_name_order_for_asset($id, $asset_name);
    }

    $message = _lang("CreateSuccess_{$view_type}", ['name' => $asset_name, 'user' => $_SESSION['user']]);
    write_log($id, $_SESSION['uid'] ?? 0, $message, "asset");

    trigger_workflow_event('asset.created', [
        'asset_id' => $id,
        'name'     => $asset_name,
    ]);

    set_alert(true, "good", $escaper->escapeHtml($lang['SavedSuccess']));
    api_v2_json_result(200, get_alert(true), NULL);
    
}

/**
 * Processes the control mapping coming from the UI in the format of [['control_maturity' => maturity_id, 'control_id' => [control_id1, control_id2, ...]], ...]
 *
 * Returns it in the format of [maturity_id => [control_id1, control_id2, ...], ...]
 *
 * It groups by maturity id, merging the control id arrays associated to the same maturity.
 *
 * @param array $raw_mapped_controls
 * @return array
 */
function process_asset_control_mapping($raw_mapped_controls) {

    $temp_mapping = empty($raw_mapped_controls) ? [] : array_map(fn($mapped_control) => json_decode($mapped_control, true), $raw_mapped_controls);

    // merging individual rows, grouped by maturity
    $mapped_controls = [];
    foreach ($temp_mapping as $mapped_control) {
        // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
        $maturity_id = (int)$mapped_control['control_maturity'];
        // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
        $control_ids = array_map(fn($control_id) => (int)$control_id, $mapped_control['control_id']);
        if (isset($mapped_controls[$maturity_id])) {
            $mapped_controls[$maturity_id] = array_values(array_unique([...$mapped_controls[$maturity_id], ...$control_ids]));
        } else {
            $mapped_controls[$maturity_id] = $control_ids;
        }
    }

    return $mapped_controls;
}

/**
 * Validate the asset control mapping to prevent having the same control mapped to multiple maturities
 *
 * It assumes that the mapping is already preprocessed and in the format of [maturity_id => [control_id1, control_id2, ...], ...]
 *
 * @param array $mapped_controls an array in the format of [maturity_id => [control_id1, control_id2, ...], ...]
 * @return boolean whether the mapping is valid
 */
function validate_asset_control_mapping($mapped_controls) {
    
    if (empty($mapped_controls)) {
        return true;
    }
    
    $used_control_ids = [];
    foreach ($mapped_controls as $_ => $control_ids) {
        if (!empty(array_intersect($used_control_ids, $control_ids))) {
            return false;
        }
        $used_control_ids = array_values(array_unique([...$used_control_ids, ...$control_ids]));
    }
    return true;
}

function get_asset_for_change_checking($id) {
    
    // it's ok to use either the asset_verified view or the asset_unverified view here 
    // as the view_type and the group of the asset_verified view and the asset_unverified view are the same
    $view = 'asset_verified';

    $where = "
    WHERE `a`.`id` = :id";

    $where .= call_extra_function(
        'team_separation_extra',
        __DIR__ . '/../extras/separation/index.php',
        'get_user_teams_query_for_assets',
        ['a', false, true],
        ''
    );

    $encryption = encryption_extra();
    $customization = customization_extra();

    $active_field_names = display_settings_get_valid_field_keys($view);

    // We have to get the join parts for all the active fields and not just for the selected ones
    list($select_parts, $join_parts) = field_settings_get_join_parts($view, $active_field_names);

    $db = db_open();

    $sql = "
        SELECT
            " . implode(',', $select_parts) . "
        FROM
            `assets` a
            " . implode(' ', $join_parts) . "
        {$where}
        GROUP BY
            `a`.`id`;
    ";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    $stmt->execute();
    $asset = $stmt->fetch(PDO::FETCH_ASSOC);

    db_close($db);

    global $field_settings, $field_settings_views, $escaper;
    // @phan-suppress-next-line PhanTypeArraySuspiciousNullable
    $id_field = $field_settings_views[$view]['id_field'];

    $data = [];
    foreach ($asset as $field_name => $value) {
        $field_setting = !empty($field_settings['asset'][$field_name]) ? $field_settings['asset'][$field_name] : false;
        
        // Only run this logic if it's not a custom field(has a valid field setting)
        if ($field_setting && !empty($value) && ($field_setting['editable'] || $id_field === $field_name)) {
            
            if ($value && $encryption && !empty($field_setting['encrypted']) && $field_setting['encrypted']) {
                $value = try_decrypt($value);
            }
            //asdasdasd
            // For fields that need custom formatting
            switch($field_name) {
                case "teams":
                case "location":
                    $data[$field_name] = array_map('intval', explode(',', (string)$value));
                    break;
                case "details":
                    $data[$field_name] = $escaper->purifyHtml($value);
                    break;
                case 'tags':
                    if ($value) {
                        $tags = [];
                        foreach(explode("|", $value) as $tag) {
                            // We're not escaping the tags here on purpose as the way it's used on the UI needs no escaping
                            $tags []= $tag;
                        }
                        $data[$field_name] = $tags;
                    }
                    break;
                case 'associated_risks':
                    $data[$field_name] = [];
                    // If the data returned isn't empty
                    if (!empty($value) && $value !== '[]') {
                        // Decode the json list, iterate through it and gather the ids
                        foreach (json_decode($value, true) as $associated_risk) {
                            $data[$field_name] []= (int)$associated_risk['value'];
                        }
                    }
                    break;
                case "mapped_controls":
                    if (!empty($value) && $value !== '[]') {
                        $data[$field_name] = array_map(function($mapping) {
                            return array(
                                'control_maturity' => (int)$mapping['control_maturity'],
                                'control_id' => explode(',', $mapping['control_id']),
                            );
                        }, json_decode($value, true));
                    } else {
                        $data[$field_name] = [];
                    }
                    break;
                default:
                    // Only have to escape non-custom fields as those are already escaped
                    $data[$field_name] = $escaper->escapeHtml($value);
            }
        }
    }
    
    if ($customization && !empty($asset['field_data']) && $asset['field_data'] !== '[]') {
             // extract it as normal fields, but only the values, we don't need the _display fields here
        foreach (json_decode($asset['field_data'], true) as $field_data) {
            if (in_array($field_data['type'], ["multidropdown", "user_multidropdown"])) {
                $data["custom_field_{$field_data['field_id']}"] = array_map('intval', explode(',', (string)$field_data['value']));
            } elseif ((int)$field_data['encryption']) {
                $data["custom_field_{$field_data['field_id']}"] = $escaper->escapeHtml(try_decrypt($field_data['value']));
            } elseif($field_data['type'] === 'date') {
                $data["custom_field_{$field_data['field_id']}"] = format_date($field_data['value']);
            } else {
                $data["custom_field_{$field_data['field_id']}"] = $escaper->escapeHtml($field_data['value']);
            }
        }
    }

    return $data ? $data : [];

}

// This function is used to get the changes in the asset for the audit log
function get_changes_in_asset($original, $updated) {
    $changes = [];

    // it's ok to use either the asset_verified view or the asset_unverified view here 
    // as the view_type and the group of the asset_verified view and the asset_unverified view are the same
    $active_field_names = display_settings_get_valid_field_keys('asset_verified');

    foreach($active_field_names as $key) {
        if (is_array($original[$key] ?? [])) {
            $original[$key] = json_encode($original[$key] ?? []);
        }
        if (is_array($updated[$key] ?? [])) {
            $updated[$key] = json_encode($updated[$key] ?? []);
        }
        if ($original[$key] !== $updated[$key]) {
            $value = $original[$key];
            $new_value = $updated[$key];
            // The asset "details" field is WYSIWYG (rich-text); emit it as plain
            // text so the audit message doesn't carry literal "<p>"/"&nbsp;".
            // The comparison above ran on the raw values.
            if ($key === 'details') {
                $value = html_to_plain_text($value);
                $new_value = html_to_plain_text($new_value);
            }
            $changes[] = _lang_raw('AssetAuditLogUpdateChange', array('key' => $key, 'value' => $value, 'new_value' => $new_value));
        }
    }
    return $changes;
}

?>