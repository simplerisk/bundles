<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// run_timestamped_queue_check() — no-op when loaded via the worker, which
// requires queues.php before loading job definitions.
require_once(realpath(__DIR__ . '/../queues.php'));
// format_setting_timestamp() — keeps a settings string out of date()'s int
// parameter, where a TypeError would abort this task_check every cron tick.
require_once(realpath(__DIR__ . '/../setting_values.php'));
// run_version_check_fetches() lives in functions.php. queues.php requires it
// too, but a direct consumer declares its own.
require_once(realpath(__DIR__ . '/../functions.php'));

return [
    'type' => 'core_version_check',
    // One task of this type at a time across all queue workers (periodic: rewrites shared version settings).
    'concurrency' => 'serial',

    /************************************************************
     * FUNCTION: task_check
     * Ensures only one version check task runs at a time.
     ************************************************************/
    'task_check' => function(PDO $db) {
        write_debug_log("Version Check: Checking for existing version check tasks.", "debug");

        // Get the timestamp of the last version check
        $last_check = get_setting('queue_timestamp_last_version_check', false, false, db: $db);
        $now = time();
        write_debug_log("Version Check: Last checked at " . format_setting_timestamp($last_check), "debug");

        // The truthiness guard below already covered '' and false, but a
        // non-numeric non-empty value would still reach the subtraction and
        // raise. Normalize once so neither the log nor the arithmetic can throw.
        $last_check = coerce_setting_timestamp($last_check);

        // Check at most once per 24 hours
        if (!$last_check || ($now - $last_check) >= 24 * 60 * 60)
        {
            // Check if one is already queued or in progress
            $existing = get_queue_items($db, 'core_version_check', ['pending', 'in_progress']);

            // If there is not an existing check queued
            if (empty($existing))
            {
                $queue_task_payload = [
                    'triggered_at' => time(),
                ];
                $success = queue_task($db, 'core_version_check', $queue_task_payload, 50, 5, 3600);

                if ($success)
                {
                    write_debug_log("Version Check: Scheduled queue task.", "info");
                    return true;
                }
                else
                {
                    write_debug_log("Version Check: Failed to queue task.", "error");
                    return false;
                }
            }
            else
            {
                write_debug_log("Version Check: Version check task already queued or running.", "debug");
                return false;
            }
        }

        return false;
    },

    /************************************************************
     * FUNCTION: queue_check
     * Fetches the latest version data and caches it in the DB.
     * Failure handling (gate stamping, retries, 'failed' status)
     * is owned by run_timestamped_queue_check() and the worker.
     ************************************************************/
    'queue_check' => function(array $task, PDO $db) {
        // The work itself lives in run_version_check_fetches() (functions.php) so
        // the combining rule -- BOTH feeds must land, and the compatibility fetch
        // is never skipped when the release feed fails -- is reachable by a test.
        // Inside this closure it could only be exercised by two real outbound
        // requests. The Extra compatibility cache it writes is what keeps a
        // transient feed outage from refusing every Extra install, since
        // download_extra() consults it on an operator's click and fails CLOSED
        // when it is absent.
        return run_timestamped_queue_check($task, $db, 'queue_timestamp_last_version_check', 'Version Check', function() use ($db) {
            return run_version_check_fetches($db);
        });
    }
];

?>
