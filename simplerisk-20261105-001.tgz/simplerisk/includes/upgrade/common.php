<?php

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/*******************************************************************************
 * UPGRADE-ONLY SHARED HELPERS                                                  *
 *******************************************************************************
 * ADMISSION RULE: a function belongs in this file only if EVERY call site is
 * part of the upgrade process — a release `upgrade_from_*` function, one of the
 * two upgrade drivers in includes/upgrade.php, or another helper in this file.
 *
 * Anything a runtime page, API endpoint, or cron job ALSO calls belongs in
 * includes/functions.php instead. `table_exists()`, `field_exists_in_table()`,
 * and `index_exists_on_table()` are the standing example: they look like
 * migration plumbing, but they have roughly 277 call sites outside the upgrade
 * process — `table_exists()` in particular is the guard CLAUDE.md mandates for
 * the Core/Extra database boundary. Moving those here would make hundreds of
 * runtime paths depend on an upgrade file.
 *
 * This file exists because includes/upgrade.php passed 11,000 lines and the
 * practice of extracting named, directly-testable helpers out of the release
 * functions had nowhere to put them.
 *
 * It also holds the standing integrity checks both upgrade drivers call once
 * the database reaches the application version -- see
 * run_upgrade_integrity_checks() below -- so a reader who lands there first
 * has a file-level cue for what else is in scope here.
 *
 * LOAD ORDER: includes/upgrade.php requires this file AFTER functions.php. The
 * requires below are belt-and-suspenders per CLAUDE.md's function-reachability
 * rule — require_once makes a duplicate include a no-op.
 *******************************************************************************/

require_once(realpath(__DIR__ . '/../functions.php'));
require_once(realpath(__DIR__ . '/../authenticate.php'));
require_once(realpath(__DIR__ . '/../licensing.php'));



/**
 * Does a named constraint, or any constraint of a given type, exist on a table?
 *
 * table_exists() / field_exists_in_table() / index_exists_on_table() in
 * includes/functions.php cover tables, columns and indexes; a migration that adds
 * a PRIMARY KEY or a FOREIGN KEY has to introspect TABLE_CONSTRAINTS instead, and
 * that query was written out inline at each site until it appeared twice.
 *
 * This one lives here rather than beside those siblings because every call site is
 * part of the upgrade process -- the admission rule at the top of this file.
 *
 * Unlike those siblings this takes the caller's $db rather than opening its own.
 * Both callers are mid-migration with a connection already in hand, and a
 * migration that opens a second connection per guard is the kind of detail that
 * only shows up as a connection-limit failure on a large upgrade.
 *
 * @param PDO         $db              An open connection.
 * @param string      $table           Table to inspect. Not user input — every
 *                                     caller passes a literal — but it is bound
 *                                     rather than interpolated regardless.
 * @param string      $constraint_type 'PRIMARY KEY', 'FOREIGN KEY', 'UNIQUE'.
 * @param string|null $constraint_name Restrict to this constraint name; null
 *                                     matches any constraint of the type, which
 *                                     is what a PRIMARY KEY check wants (its
 *                                     name is always 'PRIMARY').
 */
function constraint_exists_on_table($db, $table, $constraint_type, $constraint_name = null) {

    $sql = "
        SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = :table
           AND CONSTRAINT_TYPE = :constraint_type
    ";

    if ($constraint_name !== null) {
        $sql .= " AND CONSTRAINT_NAME = :constraint_name";
    }

    $sql .= " LIMIT 1";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(":table", $table, PDO::PARAM_STR);
    $stmt->bindParam(":constraint_type", $constraint_type, PDO::PARAM_STR);

    if ($constraint_name !== null) {
        $stmt->bindParam(":constraint_name", $constraint_name, PDO::PARAM_STR);
    }

    $stmt->execute();

    return (bool)$stmt->fetchColumn();
}

/**
 * Read a column's actual definition, or null when the table/column is absent.
 *
 * `field_exists_in_table()` answers "is it there"; a migration that converges a
 * column's SHAPE needs to know what the shape currently is. That matters most
 * for the case this file exists to serve: an instance arriving from an unknown
 * release. Guarding on the real definition means a migration can be a no-op on
 * the instances that already match -- which is the difference between "safe to
 * re-run" and "rebuilds a table holding document blobs on every upgrade".
 *
 * Returns the raw information_schema row: DATA_TYPE, IS_NULLABLE ('YES'/'NO'),
 * COLUMN_DEFAULT (null when there is none), CHARACTER_MAXIMUM_LENGTH, EXTRA.
 *
 * @return array<string,mixed>|null
 */
function column_attributes($db, $table, $column)
{
    $database = DB_DATABASE;

    $stmt = $db->prepare(
        "SELECT `DATA_TYPE`, `IS_NULLABLE`, `COLUMN_DEFAULT`, `CHARACTER_MAXIMUM_LENGTH`, `EXTRA`
           FROM `information_schema`.`COLUMNS`
          WHERE `TABLE_SCHEMA` = :database
            AND `TABLE_NAME`   = :table
            AND `COLUMN_NAME`  = :column
          LIMIT 1;"
    );
    $stmt->bindParam(":database", $database, PDO::PARAM_STR);
    $stmt->bindParam(":table", $table, PDO::PARAM_STR);
    $stmt->bindParam(":column", $column, PDO::PARAM_STR);
    $stmt->execute();

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row === false ? null : $row;
}

/*******************************************************************************
 * UPGRADE DISPATCH PREDICATES                                                  *
 *******************************************************************************
 * The four functions below decide what the upgrade drivers do, rather than
 * performing a migration themselves. They are pure -- no DB, no globals, no
 * output -- which is the point: the drivers that consume them open a database,
 * echo HTML and self-recurse, so the decisions are only testable once they are
 * lifted out.
 *
 * They satisfy the admission rule at the top of this file: every call site is
 * includes/upgrade.php's two drivers, update_database_version(), the Upgrade
 * Extra's dispatch loop (via the upgrade_chain_did_advance() shim in
 * extras/upgrade/backwards_compatibility.php), or a test. No runtime page, API
 * endpoint, or cron job calls any of them.
 *
 * Watch that boundary if is_release_version_string() ever picks up a caller
 * outside the upgrade process -- api/v2/includes/simplerisk.php still validates
 * an admin-POSTed version with its own inline copy of the pattern, and switching
 * it to this helper would give this function a runtime caller and move it to
 * includes/functions.php under the same rule.
 *******************************************************************************/

/***************************************
 * FUNCTION: IS RELEASE VERSION STRING *
 ***************************************/
/**
 * True only for a real release version, YYYYMMDD-VVV -- one of the strings that
 * actually appears in $releases. The unreleased placeholder every in-flight
 * upgrade function targets ('2026XXXX-001') is deliberately NOT one: it names no
 * release, so a db_version carrying it matches nothing in $releases afterwards.
 *
 * Pure -- no DB, no globals, no output -- so the decision is testable without
 * touching a real db_version row.
 *
 * Anchored with \z rather than $, because PCRE's `$` also matches immediately
 * before a trailing newline and "20260709-001\n" would satisfy it.
 *
 * @param mixed $version
 * @return bool
 */
function is_release_version_string($version)
{
    return is_string($version) && preg_match("/^\d{8}-\d{3}\z/", $version) === 1;
}

/************************************
 * FUNCTION: UPGRADE CHAIN ADVANCED *
 ************************************/
/**
 * Did an upgrade function actually move the database forward?
 *
 * Only a real release version counts. update_database_version() refuses to write
 * anything else, so an unchanged version, the unreleased placeholder, and a
 * degenerate read (current_version("db") returns null when the db_version row is
 * missing -- functions.php reads $array[0]['value'] unguarded) all mean nothing
 * moved. False therefore means "stop", never "dispatch again": re-resolving from
 * an unchanged version yields the same function forever.
 *
 * Pure, and shared -- each of the three drivers that dispatch upgrade functions
 * used to carry its own copy of this comparison.
 *
 * @param mixed $db_version_before Version dispatched on.
 * @param mixed $db_version_after  Version read back after the function ran.
 * @return bool
 */
function upgrade_chain_advanced($db_version_before, $db_version_after)
{
    if (!is_release_version_string($db_version_after))
    {
        return false;
    }

    return (string)$db_version_before !== $db_version_after;
}

/*************************************
 * FUNCTION: IS NEWEST KNOWN RELEASE *
 *************************************/
/**
 * True when $version is the last entry in $releases -- the newest release this
 * copy of the code carries a migration path to, so there is nothing further to
 * apply regardless of what APP_VERSION says.
 *
 * Takes the array rather than reaching for the global so the decision stays pure.
 *
 * @param mixed $version
 * @param array $releases
 * @return bool
 */
function is_newest_known_release($version, array $releases)
{
    if ($releases === [])
    {
        return false;
    }

    return $version === $releases[array_key_last($releases)];
}

/************************************************************
 * FUNCTION: NAMED RELEASE HAS NOTHING TO APPLY             *
 ************************************************************/
/**
 * Pure: is a caller-named release the newest one, with the database already on
 * it?
 *
 * A release-cut branch has no upgrade_from_<newest>() -- the release process
 * finalizes the previous function's placeholder target and does not open a new
 * one -- so POST /admin/upgrade/db naming the newest release finds no function.
 * With the database already at that release that is "already current", not a
 * bad request, and the API documents 200 for it (its `version` example is the
 * current release). A database BEHIND the named release is different: nothing
 * can advance it, so that stays an error.
 *
 * @param mixed $version    The release the caller named.
 * @param mixed $db_version The database's current version.
 * @param array $releases   The ordered release list.
 */
function named_release_has_nothing_to_apply($version, $db_version, array $releases)
{
    return is_newest_known_release($version, $releases) && $version === $db_version;
}

/********************************************
 * FUNCTION: DECIDE DATABASE UPGRADE ACTION *
 ********************************************/
/**
 * What upgrade_database() should do for a given pair of versions. Pure -- no DB,
 * no globals, no output -- so the whole decision matrix is testable directly.
 *
 * Returns one of:
 *
 *   'run_chain'          The database is behind the application and an upgrade
 *                        function exists for it. Ordinary case: run it, then
 *                        continue up the chain.
 *
 *   'run_in_flight'      The versions already match, but an upgrade function
 *                        exists FOR the current version. Two different situations
 *                        arrive here, and they are told apart afterwards by
 *                        upgrade_chain_advanced() rather than in advance:
 *
 *                        (a) Development. The function for the current version is
 *                            the one still being written this cycle. It targets
 *                            the '2026XXXX-001' placeholder, which
 *                            update_database_version() refuses to write, so
 *                            db_version does not move. Running it is how a
 *                            developer applies in-flight changes and re-applies
 *                            them for validation.
 *
 *                        (b) A one-click upgrade on a customer instance.
 *                            APP_VERSION is a PHP constant, and both one-click
 *                            drivers resolve it BEFORE the file swap
 *                            (extras/upgrade/index.php, includes/api.php), so it
 *                            still names the OLD release while the upgrade.php on
 *                            disk belongs to the NEW bundle. $app_version does not
 *                            describe the code that is running: the versions only
 *                            appear to match, and the resolved function is an
 *                            ordinary released migration that DOES advance
 *                            db_version.
 *
 *                        Earlier revisions of this docblock claimed (b) could not
 *                        happen -- that a shipped bundle never carries an
 *                        upgrade_from_<APP_VERSION>. That is true of the bundle
 *                        and irrelevant here, because the APP_VERSION being
 *                        compared is the previous release's. Do not restore the
 *                        claim; nothing gates this branch to development.
 *
 *                        Both are safe to run: every upgrade function is required
 *                        to be idempotent. The caller halts for (a) and continues
 *                        up the chain for (b).
 *
 *   'up_to_date'         Nothing further to apply -- either the versions match and
 *                        no function exists for the current one, or the database
 *                        is already at the newest release in $releases and only a
 *                        stale in-memory $app_version makes the two look different
 *                        (the tail of case (b) above).
 *
 *   'no_upgrade_function' The database version is behind but names no release we
 *                        have a function for -- a hand-edited row, a partially
 *                        restored backup, or an instance stranded by the guard
 *                        bug this change fixes. Deliberately NOT repaired here:
 *                        we cannot tell which schema is actually behind such a
 *                        value, and writing a guessed version would assert a
 *                        state nobody has checked. The one narrow exception, a
 *                        well-formed ID of a REMOVED release, is handled before
 *                        this is consulted (rebase_removed_release_database_version()),
 *                        so this function only ever sees the known release it
 *                        was moved to.
 *
 * @param mixed $app_version
 * @param mixed $db_version
 * @param bool  $upgrade_function_exists Whether a callable upgrade function was
 *                                       resolved for $db_version.
 * @param bool  $db_is_newest_release    Whether $db_version is the last entry in
 *                                       $releases -- see is_newest_known_release().
 * @return string
 */
function decide_database_upgrade_action($app_version, $db_version, $upgrade_function_exists, $db_is_newest_release = false)
{
    if ($app_version != $db_version)
    {
        if ($upgrade_function_exists)
        {
            return 'run_chain';
        }

        // The database is at the newest release we know how to reach, so there is
        // nothing left to apply and this is not a fault to report. Reached at the
        // end of a one-click upgrade, where $app_version is the pre-swap constant.
        if ($db_is_newest_release)
        {
            return 'up_to_date';
        }

        return 'no_upgrade_function';
    }

    return $upgrade_function_exists ? 'run_in_flight' : 'up_to_date';
}

/********************************************
 * FUNCTION: RESOLVE DATABASE UPGRADE START *
 ********************************************/
/**
 * The release the upgrade chain should start from for a given db_version. Pure.
 *
 * A known release (one in $releases) is returned unchanged. That is every
 * instance whose version came from a release that shipped, so the chain behaves
 * exactly as it did before this function existed.
 *
 * The one case it changes is a REMOVED release. A release candidate is published
 * on updates-test only, and an RC with a bug is removed and replaced by a later
 * one. An instance on the Release Candidate channel can therefore have a
 * db_version that names a release no feed lists and whose upgrade_from_<id> no
 * bundle carries. The chain cannot start from that value, so before this the
 * instance had no upgrade path at all.
 *
 * For that case it returns the newest known release strictly earlier than
 * db_version. The RC was cut on top of that release, so its schema is the one
 * this database is guaranteed to contain. Every migration after it is
 * idempotent by project rule (writing-db-migrations), so replaying the ones the
 * RC already applied is safe.
 *
 * Returns null, meaning "do not move it", for:
 *   - a db_version that is not a well-formed release ID: the '2026XXXX-001'
 *     placeholder, an empty or missing row, anything hand-edited. Nothing about
 *     such a value says which schema is behind it;
 *   - an application version that is not a well-formed release ID;
 *   - a db_version that is not strictly earlier than the application version.
 *     A database later than the code is a downgrade. One equal to it is an
 *     instance sitting on its own release, which is not behind anything;
 *   - a db_version with no known release earlier than it;
 *   - a db_version with no known release later than it. Rebasing would then
 *     lower the recorded version with nothing to carry it back up.
 *
 * Release IDs are fixed-width and date-numbered, so they order as strings.
 *
 * @param mixed $db_version
 * @param mixed $app_version
 * @param array $releases
 * @return string|null
 */
function resolve_database_upgrade_start($db_version, $app_version, array $releases)
{
    if (!is_release_version_string($db_version))
    {
        return null;
    }

    if (in_array($db_version, $releases, true))
    {
        return $db_version;
    }

    if (!is_release_version_string($app_version) || strcmp($db_version, $app_version) >= 0)
    {
        return null;
    }

    $earlier = null;
    $has_later = false;

    foreach ($releases as $release)
    {
        if (!is_release_version_string($release))
        {
            continue;
        }

        if (strcmp($release, $db_version) < 0)
        {
            if ($earlier === null || strcmp($release, $earlier) > 0)
            {
                $earlier = $release;
            }
        }
        elseif (strcmp($release, $db_version) > 0)
        {
            $has_later = true;
        }
    }

    return $has_later ? $earlier : null;
}

/*****************************************************
 * FUNCTION: REBASE REMOVED RELEASE DATABASE VERSION *
 *****************************************************/
/**
 * Moves a db_version that names a removed release back to the release the chain
 * should start from (see resolve_database_upgrade_start()), so the drivers can
 * then walk the chain as usual.
 *
 * This has to be a WRITE, not only a choice of starting function. Each
 * upgrade_from_*() advances the row through update_database_version(), whose
 * UPDATE matches only when the row holds that function's own starting version.
 * Run upgrade_from_<earlier> against a row that still names the removed release
 * and the migrations run but the version never moves, so the driver stops on
 * "did not advance".
 *
 * The write goes through update_database_version(): it refuses anything that
 * is not a real release, and it is conditional on the row still holding the
 * removed release, so a concurrent change is never overwritten. If the chain
 * then fails, the row names a known release, so the next attempt runs the
 * ordinary chain from there.
 *
 * Writes nothing, and returns null, when there is nothing to rebase or when no
 * upgrade function exists for the starting release. The write's own echoed
 * line is swallowed: the structured driver's callers expect JSON, and each
 * driver reports the rebase in its own way.
 *
 * @param PDO|object    $db
 * @param mixed         $db_version
 * @param mixed         $app_version
 * @param array         $releases
 * @param callable|null $log fn(string $message, string $level). Defaults to
 *                           write_debug_log; a parameter so tests stay pure.
 * @return string|null The release the row was moved to, or null when nothing was written.
 */
function rebase_removed_release_database_version($db, $db_version, $app_version, array $releases, ?callable $log = null)
{
    $log = $log ?? 'write_debug_log';

    $start = resolve_database_upgrade_start($db_version, $app_version, $releases);
    if ($start === null || $start === $db_version)
    {
        return null;
    }

    $function_name = 'upgrade_from_' . str_replace('-', '', $start);
    if (!function_exists($function_name))
    {
        $log("The database version '{$db_version}' names no known release, and the release before it ('{$start}') has no upgrade function. The database version was left unchanged.", 'warning');
        return null;
    }

    $log("The database version '{$db_version}' names no known release (a release that was removed, such as a replaced release candidate). Restarting the upgrade from '{$start}', the newest known release before it. Migrations are idempotent, so those the removed release already applied are re-run safely.", 'notice');

    ob_start();
    try
    {
        update_database_version($db, $db_version, $start);
    }
    finally
    {
        ob_end_clean();
    }

    return $start;
}

/**********************************************************
 * FUNCTION: MIGRATE CONTROL STATUS TO NOT NULL           *
 **********************************************************
 * Makes framework_controls.control_status NOT NULL DEFAULT 2 ("Not Tested"),
 * backfilling any pre-existing NULLs to 2 first.
 *
 * Extracted from upgrade_from_20260709001() so the migration can be exercised
 * directly by tests rather than by a copy of its SQL — a copy would keep passing
 * if this were changed or deleted.
 *
 * WHY: NULL was never a modeled state. No UI offers an "unknown" choice, and the
 * column has defaulted to 2 since earlier in this same upgrade — NULL is reachable
 * only through an explicit `INSERT ... control_status = NULL`. But a NULL row was
 * actively harmful, because the two halves of the controls table disagree about it:
 *
 *   - DISPLAY folds NULL into "Not Tested" (governance.php's
 *     `CASE control_status WHEN 1 ... ELSE 'Not Tested' END`, mirrored by the v2
 *     API row shaper's `?? 2`), so the row renders as Not Tested; while
 *   - FILTERING and the status COUNT chips both match on `control_status = 2` in
 *     SQL, which is never true for NULL.
 *
 * So a NULL row was visible in the unfiltered table and vanished the moment the
 * user filtered by the very status it displayed, and the chips under-reported.
 * Collapsing NULL into 2 at the schema level removes the ambiguity at its source,
 * rather than teaching every filter and count to special-case NULL.
 *
 * ORDERING IS LOAD-BEARING: the backfill must run BEFORE the ALTER. This instance
 * has no NULL rows, but a customer upgrading from older data may — and the ALTER
 * would fail outright on their database if the NULLs were still there.
 *
 * Idempotent: the UPDATE matches no rows on a re-run, and the ALTER is skipped once
 * INFORMATION_SCHEMA reports the column is already NOT NULL with a default of 2.
 * The backfill is deliberately left unguarded (it is a no-op UPDATE on a re-run) so
 * a run that died between the UPDATE and the ALTER still backfills on the retry.
 */
function migrate_control_status_not_null($db) {

    // The column is added by a much earlier upgrade function; guard so this is a
    // no-op rather than an error on a chain that has not reached that point.
    if (!field_exists_in_table('control_status', 'framework_controls')) return;

    // Step 1 — backfill. NULL and "Not Tested" are the same thing.
    $db->query("UPDATE `framework_controls` SET `control_status` = 2 WHERE `control_status` IS NULL;");

    // Step 2 — only ALTER when the column is not already in the target shape.
    $stmt = $db->prepare("
        SELECT `IS_NULLABLE`, `COLUMN_DEFAULT`
        FROM `information_schema`.`COLUMNS`
        WHERE `TABLE_SCHEMA` = :database
            AND `TABLE_NAME` = 'framework_controls'
            AND `COLUMN_NAME` = 'control_status';
    ");
    $database = DB_DATABASE; // a variable, because bindParam takes it by reference
    $stmt->bindParam(":database", $database, PDO::PARAM_STR);
    $stmt->execute();
    $column = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($column && $column['IS_NULLABLE'] === 'NO' && (string)$column['COLUMN_DEFAULT'] === '2') return;

    $db->query("ALTER TABLE `framework_controls` MODIFY `control_status` tinyint(1) NOT NULL DEFAULT 2;");
    echo "Set framework_controls.control_status to NOT NULL DEFAULT 2 (Not Tested)<br />\n";
}

/**********************************************************
 * FUNCTION: MIGRATE CONTROL APPLICABILITY SCHEMA         *
 **********************************************************
 * Creates the per-framework control applicability schema behind the Statement of
 * Applicability: the decision table, the customer-extendable reason list, and the
 * two framework-level SoA fields.
 *
 * Extracted from upgrade_from_20260709001() so the migration can be exercised
 * directly by tests rather than by a copy of its SQL — a copy would keep passing
 * if this were changed or deleted.
 *
 * WHY A SEPARATE TABLE, KEYED ON (framework, control_id):
 *
 * Applicability must NOT live on `framework_control_mappings`. Those rows are
 * derived data owned by the SCF importer, with an auto-increment `id` that changes
 * whenever they are rebuilt — and three separate paths delete and recreate them:
 *
 *   - remove_framework_from_controls()   (includes/governance.php)  — framework removal
 *   - the SCF Extra's forced-reuse path  (extras/complianceforgescf/index.php)
 *   - every SCF version upgrade          (extras/complianceforgescf/upgrade.php)
 *
 * An exclusion justification is the opposite of derived data: it is a deliberate,
 * audited human decision a customer may have to defend to an auditor years later.
 * Hanging it off a mapping row would mean a routine SCF upgrade silently destroyed
 * it — a compliance incident with no error message anywhere. Keyed on the stable
 * business key instead, a mapping rebuild is a non-event, and a control that stops
 * being mapped into a framework goes DORMANT rather than deleted (an auditor may
 * still ask about last year's exclusion).
 *
 * APPLICABLE IS STILL THE DEFAULT AND IS STILL NEVER MATERIALISED. There is
 * deliberately no backfill here: no 1,535-row materialisation per framework,
 * exclusion is always an explicit audited act, and there is nothing for a rebuild
 * to lose. Absence of a row still means applicable, and DELETE still means "reset
 * to the framework default".
 *
 * WHY `state` NOW CARRIES 'applicable' AS WELL AS THE TWO DEVIATIONS (spec §4).
 * An applicable control may now carry its OWN justification and inclusion
 * reason(s) instead of printing the framework's boilerplate 90 times over, and
 * storing that needs a row. The storage contract is therefore:
 *
 *   no row                  applicable, framework-default justification
 *   state = 'applicable'    applicable, with THIS narrative and/or reason(s)
 *   state = 'not_applicable'/'inherited'   excluded / inherited, as before
 *   DELETE the row          reset to the framework default
 *
 * `narrative` becomes NULLABLE for the same reason: a justification is OPTIONAL
 * for an applicable control (a taxonomy reason alone is a complete answer), while
 * assert_applicability_narrative() continues to refuse a deviation without one.
 * Storing '' instead would make "no narrative" and "deliberately blank narrative"
 * indistinguishable — the absent-vs-empty confusion that produced nine data-loss
 * bugs on this branch.
 *
 * REASONS ARE MULTI-SELECT, via `framework_control_applicability_reasons`. A
 * control is commonly included for more than one reason (legal AND results of
 * risk assessment), and forcing a single choice would make the document less
 * truthful. The composite PRIMARY KEY makes a duplicate reason impossible by
 * construction rather than by convention, and ON DELETE CASCADE means the
 * existing delete-to-reset semantics clear the reasons too.
 *
 * The scalar `framework_control_applicability`.`reason_id` is GONE (Task 4). It
 * never shipped, so nothing is migrated for a customer; what the drop is guarded
 * for is the development and testing instances that already ran this branch's
 * schema and hold values in it. Those values are folded into the join table
 * first — see the note at the DROP — and then the column goes, because the
 * writer, the reader and the v2 API now read the join table exclusively.
 *
 * Idempotent: every CREATE is table_exists()-guarded, every ADD COLUMN is
 * field_exists_in_table()-guarded, every MODIFY is skipped once INFORMATION_SCHEMA
 * reports the column already in its target shape, and the reason seed is
 * existence-checked row by row. The seed deliberately does NOT use INSERT IGNORE —
 * `name` carries no UNIQUE key (the list is customer-extendable), so there would be
 * no duplicate-key error for IGNORE to swallow and every re-run would insert
 * another full copy.
 */
function migrate_control_applicability_schema($db) {

    // The column's CURRENT shape, straight from INFORMATION_SCHEMA, so each
    // MODIFY below can be skipped once it has already been applied. Returns null
    // when the column does not exist, which lets a caller no-op rather than error
    // on a chain that has not created the table yet.
    //
    // The comparison is against the WHOLE target definition rather than a
    // substring search for the new member: `enum('not_applicable','inherited')`
    // already contains the text "applicable", so a naive strpos() would report the
    // migration as already done on an unmigrated column and silently skip it.
    $column_shape = static function ($table, $column) use ($db) {

        $stmt = $db->prepare("
            SELECT `COLUMN_TYPE`, `IS_NULLABLE`, `COLUMN_DEFAULT`
            FROM `information_schema`.`COLUMNS`
            WHERE `TABLE_SCHEMA` = :database
                AND `TABLE_NAME` = :table
                AND `COLUMN_NAME` = :column;
        ");
        $database = DB_DATABASE; // a variable, because bindParam takes it by reference
        $stmt->bindParam(":database", $database, PDO::PARAM_STR);
        $stmt->bindParam(":table", $table, PDO::PARAM_STR);
        $stmt->bindParam(":column", $column, PDO::PARAM_STR);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    };

    // Configurable exclusion/inheritance/inclusion reasons, following the existing
    // `control_class` option-table pattern (value INT PK, name MEDIUMTEXT) so
    // customers can extend the list. `applies_to` says which state offers a
    // reason: a third party performing the control is an "inherited" reason,
    // not an exclusion, and "Contractual obligation" is a reason a control is IN
    // scope rather than out of it.
    if (!table_exists('control_applicability_reason')) {
        $db->prepare("
            CREATE TABLE IF NOT EXISTS `control_applicability_reason` (
                `value` INT NOT NULL AUTO_INCREMENT,
                `name` MEDIUMTEXT NOT NULL,
                `applies_to` ENUM('applicable','not_applicable','inherited') NOT NULL DEFAULT 'not_applicable',
                PRIMARY KEY (`value`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ")->execute();
        echo "Created the control_applicability_reason table.<br />\n";
    }

    // Instances already carrying this branch have the two-member enum. Widen it
    // BEFORE the seed below runs, or the four inclusion reasons are rejected as
    // out-of-range values by strict SQL mode.
    //
    // DEFAULT 'not_applicable' is restated deliberately: a bare MODIFY drops the
    // column default, and the reason list is customer-extendable through a form
    // that may not send `applies_to` at all.
    $applies_to = $column_shape('control_applicability_reason', 'applies_to');
    if ($applies_to !== null
        && strtolower((string)$applies_to['COLUMN_TYPE']) !== "enum('applicable','not_applicable','inherited')") {

        $db->prepare("
            ALTER TABLE `control_applicability_reason`
            MODIFY `applies_to` ENUM('applicable','not_applicable','inherited') NOT NULL DEFAULT 'not_applicable';
        ")->execute();
        echo "Extended control_applicability_reason.applies_to to offer inclusion reasons.<br />\n";
    }

    // Existence-checked seed — see the INSERT IGNORE note in the docblock.
    //
    // The four 'applicable' rows are the standard SoA inclusion drivers (ISO/IEC
    // 27001 6.1.3(d)). "Results of risk assessment" is already implemented in
    // substance by the existing risk linkage; naming it makes the reasoning
    // explicit and consistent with the other three.
    //
    // Seeded as literals, NOT through $lang, because this is a customer-extendable
    // option table: `name` is customer-authored free text that every reader
    // (get_applicability_reasons(), the API, the modal picklist) renders straight
    // from the row, exactly as `control_class` does. A key would render as a key
    // for the customer rows that will never have one.
    $seed = [
        ['Not applicable to the defined scope',            'not_applicable'],
        ['No such asset or technology',                    'not_applicable'],
        ['Function not performed by the organization',     'not_applicable'],
        ['Legal or regulatory requirement does not apply', 'not_applicable'],
        ['Risk accepted',                                  'not_applicable'],
        ['Covered by another control',                     'not_applicable'],
        ['Performed by a third party',                     'inherited'],
        ['Legal or regulatory requirement',                'applicable'],
        ['Contractual obligation',                         'applicable'],
        ['Business requirement or best practice',          'applicable'],
        ['Results of risk assessment',                     'applicable'],
    ];
    $check = $db->prepare("SELECT COUNT(*) FROM `control_applicability_reason` WHERE `name` = :n");
    $ins   = $db->prepare("INSERT INTO `control_applicability_reason` (`name`, `applies_to`) VALUES (:n, :a)");
    foreach ($seed as list($name, $applies_to_value)) {
        $check->execute([':n' => $name]);
        if ((int)$check->fetchColumn() === 0) {
            $ins->execute([':n' => $name, ':a' => $applies_to_value]);
        }
    }

    if (!table_exists('framework_control_applicability')) {
        $db->prepare("
            CREATE TABLE IF NOT EXISTS `framework_control_applicability` (
                `id` INT NOT NULL AUTO_INCREMENT,
                `framework` INT NOT NULL,
                `control_id` INT NOT NULL,
                `state` ENUM('applicable','not_applicable','inherited') NOT NULL,
                `narrative` TEXT NULL,
                `provider` VARCHAR(200) NOT NULL DEFAULT '',
                `decided_by` INT NOT NULL,
                `decided_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_framework_control` (`framework`, `control_id`),
                KEY `control_id` (`control_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ")->execute();
        echo "Created the framework_control_applicability table.<br />\n";
    }

    // Instances already carrying this branch have the pre-§4 shape: a two-member
    // `state` enum and a NOT NULL `narrative`. Both MODIFYs are guarded by the
    // column's own current definition, so a re-run is a no-op.
    $state = $column_shape('framework_control_applicability', 'state');
    if ($state !== null
        && strtolower((string)$state['COLUMN_TYPE']) !== "enum('applicable','not_applicable','inherited')") {

        $db->prepare("
            ALTER TABLE `framework_control_applicability`
            MODIFY `state` ENUM('applicable','not_applicable','inherited') NOT NULL;
        ")->execute();
        echo "Extended framework_control_applicability.state to store the applicable state.<br />\n";
    }

    $narrative = $column_shape('framework_control_applicability', 'narrative');
    if ($narrative !== null && strtoupper((string)$narrative['IS_NULLABLE']) !== 'YES') {

        $db->prepare("ALTER TABLE `framework_control_applicability` MODIFY `narrative` TEXT NULL;")->execute();
        echo "Made framework_control_applicability.narrative nullable.<br />\n";
    }

    // Inclusion/exclusion reasons are MULTI-select, so they hang off a join table
    // rather than the scalar `reason_id`. The composite PRIMARY KEY makes a
    // duplicate reason impossible by construction — worth stating explicitly,
    // because a sibling table on this branch relied on INSERT IGNORE without a
    // unique key and silently failed to dedupe.
    //
    // ON DELETE CASCADE is what keeps delete-to-reset honest: resetting a control
    // to the framework default deletes the applicability row, and the reasons that
    // justified the old decision must not outlive it.
    //
    // The reason side gets a foreign key too, and RESTRICT rather than CASCADE.
    // The two directions are not symmetric:
    //   - applicability_id CASCADEs because the decision owning the reason is
    //     gone, so the reason has nothing left to justify.
    //   - reason_id RESTRICTs because the taxonomy row is shared. CASCADE there
    //     would let removing one entry from the picklist silently strip the
    //     justification off every control citing it -- in an SoA, an auditable
    //     document, that is the worst available outcome. RESTRICT makes such a
    //     delete fail loudly while the reason is still in use, which is the
    //     correct prompt: retire it from the controls first.
    // RESTRICT is InnoDB's default, but it is spelled out because the choice is
    // deliberate and sits one line under a CASCADE.
    if (!table_exists('framework_control_applicability_reasons')) {
        $db->prepare("
            CREATE TABLE IF NOT EXISTS `framework_control_applicability_reasons` (
                `applicability_id` INT NOT NULL,
                `reason_id` INT NOT NULL,
                PRIMARY KEY (`applicability_id`, `reason_id`),
                KEY `reason_id` (`reason_id`),
                CONSTRAINT `fk_fcar_applicability` FOREIGN KEY (`applicability_id`)
                    REFERENCES `framework_control_applicability` (`id`) ON DELETE CASCADE,
                CONSTRAINT `fk_fcar_reason` FOREIGN KEY (`reason_id`)
                    REFERENCES `control_applicability_reason` (`value`) ON DELETE RESTRICT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ")->execute();
        echo "Created the framework_control_applicability_reasons table.<br />\n";
    }

    // Instances already carrying this branch built the table with only the
    // applicability-side key, so `reason_id` had an index but nothing enforcing
    // that it names a real row -- an orphan was reachable by any direct DB edit.
    // Add the missing constraint after the fact. Guarded on the constraint's own
    // presence, so a re-run is a no-op.
    //
    // Orphans have to go first or the ALTER cannot succeed. Deleting them is
    // hygiene, not data loss: applicability_reason_rows() LEFT JOINs the taxonomy
    // so a dangling id renders as an id with an EMPTY NAME, which shows an
    // auditor a justification entry that says nothing. Once the constraint is in
    // place that state is unreachable, and the LEFT JOIN stays as defence for
    // rows predating it. Neither table has reached a customer -- both are created
    // in this same unreleased upgrade -- so this can only touch development and
    // testing instances.
    //
    // Best-effort, matching the audit_log primary-key migration above: a failure
    // here must not fatal the rest of the upgrade.
    try {
        $reason_fk_exists = constraint_exists_on_table(
            $db,
            'framework_control_applicability_reasons',
            'FOREIGN KEY',
            'fk_fcar_reason'
        );

        if (!$reason_fk_exists) {

            $delete_orphans = $db->prepare("
                DELETE ar FROM `framework_control_applicability_reasons` ar
                LEFT JOIN `control_applicability_reason` r ON ar.`reason_id` = r.`value`
                WHERE r.`value` IS NULL;
            ");
            $delete_orphans->execute();

            if ($delete_orphans->rowCount() > 0) {
                echo "Removed " . (int)$delete_orphans->rowCount() . " applicability reason row(s) pointing at a reason that no longer exists.<br />\n";
            }

            $db->prepare("
                ALTER TABLE `framework_control_applicability_reasons`
                ADD CONSTRAINT `fk_fcar_reason` FOREIGN KEY (`reason_id`)
                    REFERENCES `control_applicability_reason` (`value`) ON DELETE RESTRICT;
            ")->execute();
            echo "Added the missing foreign key from framework_control_applicability_reasons.reason_id to control_applicability_reason.<br />\n";
        }
    } catch (Exception $e) {
        write_debug_log("Upgrade failed to add fk_fcar_reason to framework_control_applicability_reasons: " . $e->getMessage() . ". Applicability reasons remain unconstrained against the reason taxonomy.", 'warning');
        echo "Warning: failed to add the applicability reason foreign key (" . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . ").<br />\n";
    }

    // THE SCALAR `reason_id` GOES, now that the writer, the reader and the v2 API
    // all read the join table instead (Task 4). It has never reached a customer —
    // both tables are new on this branch — so this is a schema DEFINITION change
    // rather than a migration, and the CREATE above no longer names the column at
    // all.
    //
    // The one-row copy is nevertheless done first. The spec called for no data
    // copy because nothing has shipped, and strictly that is true; but every
    // development and testing instance carrying this branch holds real exclusion
    // reasons in that column, and those reasons are rendered into an SoA. Three
    // lines that turn "your existing exclusions silently lose their reason" into
    // "they keep it" are worth more than the purity of dropping outright.
    //
    // INSERT IGNORE genuinely dedupes here — unlike the reason seed above, this
    // target HAS a (composite) PRIMARY KEY for the duplicate to collide with —
    // so a re-run before the DROP is a no-op.
    if (field_exists_in_table('reason_id', 'framework_control_applicability')) {

        $db->prepare("
            INSERT IGNORE INTO `framework_control_applicability_reasons` (`applicability_id`, `reason_id`)
            SELECT `id`, `reason_id` FROM `framework_control_applicability` WHERE `reason_id` IS NOT NULL;
        ")->execute();

        $db->prepare("ALTER TABLE `framework_control_applicability` DROP COLUMN `reason_id`;")->execute();
        echo "Moved framework_control_applicability.reason_id into the reasons join table and dropped it.<br />\n";
    }

    // Framework-level SoA fields. Both are deliberately left NULL on existing
    // frameworks: the SoA *export* prompts for them when they are missing, which
    // is the only moment they matter. Seeding boilerplate here would suppress that
    // prompt and ship an auditor a scope and an inclusion driver nobody reviewed.
    if (!field_exists_in_table('scope_statement', 'frameworks')) {
        $db->prepare("ALTER TABLE `frameworks` ADD `scope_statement` TEXT;")->execute();
        echo "Added scope_statement to the frameworks table.<br />\n";
    }
    if (!field_exists_in_table('default_inclusion_justification', 'frameworks')) {
        $db->prepare("ALTER TABLE `frameworks` ADD `default_inclusion_justification` TEXT;")->execute();
        echo "Added default_inclusion_justification to the frameworks table.<br />\n";
    }

    // The scope statement became a rich-text field after the two columns above
    // were added, so anything already in it is plain text. Same release, so
    // there is nothing to convert on a customer's upgrade path — see the
    // function's own note for why it is written and called anyway.
    migrate_framework_scope_statement_rich_text($db);
}

/**********************************************************
 * FUNCTION: MIGRATE FRAMEWORK SCOPE STATEMENT RICH TEXT  *
 **********************************************************
 * Converts any PLAIN-TEXT value already sitting in `frameworks`.`scope_statement`
 * into the rich text that column now holds.
 *
 * Extracted from upgrade_from_20260709001() so the conversion can be exercised
 * directly by tests rather than by a copy of its logic — a copy would keep
 * passing if this were changed or deleted.
 *
 * WHY IT EXISTS AT ALL, GIVEN IT CANNOT RUN FOR A CUSTOMER. `scope_statement` is
 * ADDED by the same (still unreleased) upgrade function that now calls this, so
 * on every real upgrade path the column is created empty three statements above
 * and there is nothing here to convert. What DOES hold plain-text statements is
 * every development and testing instance that has been carrying this branch —
 * and a plain-text row rendered as HTML silently loses every newline its author
 * typed, which on a scope statement means a list of sites collapsing into one
 * sentence. This is the callable that repairs those, and it is the honest place
 * for the rule to live if the column's release ever splits from this change's.
 *
 * IDEMPOTENT BY DETECTION rather than by a flag: plain_text_to_rich_text()
 * (includes/functions.php) returns an already-tagged value untouched, so a
 * re-run is a no-op. Its detection is a tag-shaped regex and NOT
 * `strip_tags($v) !== $v`, because strip_tags() discards everything after an
 * unterminated "<" — so a scope statement reading "R&D < 500 users" would be
 * misread as markup and skipped, and that is precisely the row most in need of
 * escaping before something renders it.
 *
 * NULL IS LEFT NULL. It is the "never asked" state that makes the SoA prompt;
 * writing '' would silently answer the question.
 **********************************************************/
function migrate_framework_scope_statement_rich_text($db) {

    if (!field_exists_in_table('scope_statement', 'frameworks')) {
        return;
    }

    $rows = $db->query(
        "SELECT `value`, `scope_statement` FROM `frameworks`
         WHERE `scope_statement` IS NOT NULL AND `scope_statement` <> '';"
    )->fetchAll(PDO::FETCH_ASSOC);

    $update    = $db->prepare("UPDATE `frameworks` SET `scope_statement` = :s WHERE `value` = :v;");
    $converted = 0;

    foreach ($rows as $row) {

        $before = (string)$row['scope_statement'];
        $after  = plain_text_to_rich_text($before);

        if ($after === $before) {
            continue;
        }

        $update->execute([':s' => $after, ':v' => (int)$row['value']]);
        $converted++;
    }

    if ($converted > 0) {
        echo "Converted " . (int)$converted . " plain-text framework scope statement(s) to rich text.<br />\n";
    }
}

/**********************************************************
 * FUNCTION: MIGRATE FRAMEWORK CONTROL MAPPING SUBJECT    *
 **********************************************************
 * Adds `framework_control_mappings`.`reference_subject` — the FRAMEWORK's own
 * title for the control it cites, per mapping row.
 *
 * Extracted from upgrade_from_20260709001() so the migration can be exercised
 * directly by tests rather than by a copy of its SQL — a copy would keep passing
 * if this were changed or deleted.
 *
 * WHY A THIRD COLUMN RATHER THAN REUSING `reference_text`:
 *
 * The mapping row already carries two per-framework facts. `reference_name` is
 * the CODE the framework cites the control by ("5.1", "GV.OC-01"), and it is
 * what the Statement of Applicability's Reference column prints. `reference_text`
 * was designed to hold the framework's full CONTROL STATEMENT — normative
 * paragraph-length prose, which is what the AI enhancement job
 * (extras/artificial_intelligence/jobs/ai_control_reference_enhance.php) writes
 * into it as `control_text`.
 *
 * Neither is the control's SUBJECT: the short title an SoA prints beside the
 * clause number ("Policies for information security"). Without it the Name
 * column has nothing to show but the SimpleRisk control's `short_name`, which on
 * an SCF-derived catalogue reads "GOV-01: Security, Compliance & Resilience
 * Program (SCRP)" — the SCF's name for its own control, in a document that is
 * supposed to be about ISO's. Overloading `reference_text` instead would mean
 * the same column held a title on one row and three paragraphs on the next, with
 * no way for a reader to tell which, and would silently redefine what the AI job
 * has already been writing.
 *
 * NULLABLE AND NOT BACKFILLED. There is nothing truthful to backfill it with:
 * `short_name` is the other catalogue's title, which is exactly the substitution
 * this column exists to stop. NULL means "this framework has not told us its
 * title for this control", and build_soa_rows() (includes/soa.php) falls back to
 * `short_name` for that row — the pre-existing behaviour — rather than printing
 * a blank Name cell.
 *
 * VARCHAR(1000), matching the width `reference_name` carried before it was
 * reduced to 255. A control title is short; the headroom costs nothing on a
 * nullable column and avoids a second migration for a verbose framework.
 *
 * Idempotent: guarded by field_exists_in_table(), so a re-run is a clean no-op.
 * Fresh installs need no separate change — generate_database_sql.yml builds the
 * installer SQL by replaying this same upgrade chain and dumping the result.
 */
function migrate_framework_control_mapping_subject($db) {

    if (!table_exists('framework_control_mappings')) {
        return;
    }

    if (!field_exists_in_table('reference_subject', 'framework_control_mappings')) {
        $db->query("
            ALTER TABLE `framework_control_mappings`
            ADD `reference_subject` VARCHAR(1000) DEFAULT NULL
            COMMENT \"The framework's own title for this control, as the Statement of Applicability prints it.\"
            AFTER `reference_name`;
        ");
        echo "Added framework_control_mappings.reference_subject for the framework's own control title.<br />\n";
    }
}

/**********************************************************
 * FUNCTION: BACKFILL FRAMEWORK INCLUSION JUSTIFICATION   *
 **********************************************************
 * Gives every framework that has never had one a default inclusion
 * justification, so the Statement of Applicability's Justification column stops
 * printing blank cells for the majority of frameworks.
 *
 * Extracted from upgrade_from_20260709001() so the migration can be exercised
 * directly by tests rather than by a copy of its SQL — a copy would keep passing
 * if this were changed or deleted.
 *
 * WHY THERE IS ANYTHING TO BACKFILL. The column arrived earlier in this same
 * upgrade (migrate_control_applicability_schema()) as a nullable TEXT that
 * nothing seeded and nothing required — the framework form offered the sentence
 * as a PLACEHOLDER, on the reasoning that an unreviewed default must not reach a
 * customer's SoA by inaction. The result was measured on the development
 * instance: 19 of 20 frameworks NULL, and therefore a blank Justification cell
 * on every applicable control with no linked risks — 1,500 of them on SCF. A
 * blank cell is not a more honest document than a boilerplate one; it is the
 * single most common finding against a hand-maintained SoA, produced here by the
 * tool that exists to prevent it. So the sentence is now the default answer in
 * all three places: seeded on the create form, backfilled here, and substituted
 * at read time by soa_framework_default_justification() (includes/soa.php).
 *
 * `IS NULL` ONLY, and that is the whole care this migration needs. The column
 * carries THREE states, and Task 16 made the difference load-bearing:
 *
 *     NULL   never asked for      -> backfilled here
 *     ''     deliberately cleared -> LEFT ALONE
 *     text   answered             -> LEFT ALONE
 *
 * A customer who emptied the box made a decision, and overwriting it with
 * boilerplate on upgrade would be the migration answering a question on their
 * behalf that they had already answered. They lose nothing by being skipped: the
 * read-time fallback fills the column for them too, without touching their row.
 *
 * LOCALIZED FROM $lang, not an English literal — upgrade.php loads the language
 * file at the top, so this writes the sentence in the language the upgrading
 * administrator is running, which is the same string the create form would have
 * seeded. If the key is missing (a customer maintaining their own lang file that
 * predates it) the backfill is SKIPPED rather than writing the key name or
 * English into an audit document; those rows stay NULL and the read-time
 * fallback covers them.
 *
 * Idempotent: after one run no framework matches `IS NULL`, so a re-run updates
 * zero rows. Fresh installs need no separate change — generate_database_sql.yml
 * builds the installer SQL by replaying this same upgrade chain and dumping the
 * result, and a fresh install's own frameworks are created through the form.
 */
function migrate_framework_default_inclusion_justification($db) {

    global $lang;

    if (!table_exists('frameworks') || !field_exists_in_table('default_inclusion_justification', 'frameworks')) {
        return;
    }

    $sentence = trim((string)($lang['DefaultInclusionJustificationPlaceholder'] ?? ''));

    if ($sentence === '') {
        return;
    }

    $stmt = $db->prepare(
        "UPDATE `frameworks`
         SET `default_inclusion_justification` = :sentence
         WHERE `default_inclusion_justification` IS NULL;"
    );
    $stmt->execute([':sentence' => $sentence]);

    if ($stmt->rowCount() > 0) {
        echo "Backfilled the default inclusion justification on " . (int)$stmt->rowCount() . " framework(s).<br />\n";
    }
}

/**
 * Configurable document categories (replaces the hardcoded Policies/Guidelines/
 * Standards/Procedures tab set). Follows the exact precedent already set on this
 * table: documents.status (free enum) -> documents.document_status (INT FK), at
 * upgrade.php ~line 5817-5831.
 *
 * Seeded INDEPENDENTLY of the CREATE TABLE: nesting the seed inside a
 * !table_exists() branch means an interruption between the two statements
 * leaves the table permanently empty on every re-run (table_exists() is true
 * by then, so the whole block is skipped) -- and with an empty lookup, the
 * document_type_id backfill has nothing to match and every document falls out
 * of every category tab. Per-name existence checks, so re-running is a no-op
 * and an admin who deliberately renamed a seeded category doesn't get the old
 * slug silently re-added.
 *
 * The caller is still responsible for running backfill_document_type_ids()
 * (includes/governance.php) afterward -- it lives outside upgrade.php /
 * upgrade/common.php, so it is not part of the wiring graph these
 * table/column changes are.
 */
function migrate_document_types_schema($db) {

    if (!table_exists('document_types')) {
        echo "Creating `document_types` table.<br />\n";
        $stmt = $db->prepare("CREATE TABLE IF NOT EXISTS `document_types` (`value` INT NOT NULL AUTO_INCREMENT, `name` varchar(100) NOT NULL, PRIMARY KEY (`value`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        $stmt->execute();
    }

    $stmt = $db->prepare("SELECT COUNT(*) FROM `document_types`");
    $stmt->execute();
    if ((int)$stmt->fetchColumn() === 0) {
        echo "Seeding `document_types` with the existing four categories.<br />\n";
        $stmt = $db->prepare("INSERT INTO `document_types` (`name`) VALUES ('policies'), ('guidelines'), ('standards'), ('procedures');");
        $stmt->execute();
    }

    // Any OTHER distinct `documents.document_type` value already on this
    // instance also needs a lookup row, otherwise those documents end up with a
    // NULL document_type_id and disappear from the (now FK-keyed) category
    // filter. Idempotent: the NOT EXISTS arm makes a re-run a no-op.
    echo "Seeding `document_types` with any remaining in-use document categories.<br />\n";
    $stmt = $db->prepare("
        INSERT INTO `document_types` (`name`)
        SELECT DISTINCT d.`document_type`
        FROM `documents` d
        WHERE d.`document_type` IS NOT NULL
          AND d.`document_type` <> ''
          AND NOT EXISTS (SELECT 1 FROM `document_types` dt WHERE dt.`name` = d.`document_type`)
    ");
    $stmt->execute();

    if (!field_exists_in_table('document_type_id', 'documents')) {
        echo "Adding `document_type_id` to `documents`.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `documents` ADD `document_type_id` INT NULL DEFAULT NULL AFTER `document_type`;");
        $stmt->execute();
    }
}

/**
 * Ensures `document_team_mappings` exists, and migrates+drops the legacy
 * `documents.team_ids` column when it is still present.
 *
 * upgrade_from_20260422001() only created this table INSIDE
 * `if (field_exists_in_table('team_ids', 'documents'))` -- so any instance
 * that reached that migration with `team_ids` already absent (the
 * fresh-install-schema-drift pattern -- see the equivalent gap already fixed
 * for `document_additional_stakeholder_mappings` in
 * upgrade_from_20260519001()) skipped table creation entirely and every
 * runtime read against it (governance.php, workflows.php, functions.php, the
 * Notification/Team-Separation/AI Extras) fatally errors with "Base table or
 * view not found". Discovered on simplerisk-dev: db_version had already
 * advanced to 20260828-001 while `documents.team_ids` was STILL present and
 * `document_team_mappings` did not exist -- a state only reachable if this
 * instance's db_version marker got out of sync with its actual schema (e.g.
 * a restored snapshot whose settings row was newer than its table
 * definitions), not something a normal sequential upgrade produces.
 *
 * Called from upgrade_from_20260519001() (mirroring the sibling
 * document_additional_stakeholder_mappings ensure-block immediately above
 * its call site, for the instance that is genuinely walking the chain
 * step-by-step) AND from run_upgrade_integrity_checks() as a standing
 * self-heal -- because an instance whose db_version has already advanced
 * PAST 20260519-001 (exactly the drift found on simplerisk-dev) never runs
 * either upgrade_from_*() function again; only the standing check, which
 * runs regardless of chain position, can reach it. Unlike the sibling's
 * table-only ensure, this also recovers any team_ids data still sitting on
 * the instance rather than silently orphaning it once the table exists.
 *
 * Idempotent: table creation is guarded by table_exists(), the migration
 * INSERT is deduped by document_team_mappings' own composite PRIMARY KEY,
 * and the DROP COLUMN can only run once (field_exists_in_table() is false
 * on every call after the first).
 *
 * @param PDO $db Open connection from the calling driver.
 */
function migrate_document_team_mappings_schema($db) {
    if (!table_exists('document_team_mappings')) {
        echo "Creating `document_team_mappings` table.<br />\n";
        $stmt = $db->prepare("
            CREATE TABLE IF NOT EXISTS `document_team_mappings` (
                `document_id` INT NOT NULL,
                `team_id` INT NOT NULL,
                PRIMARY KEY(`document_id`, `team_id`),
                INDEX(`team_id`, `document_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
        ");
        $stmt->execute();
    }

    if (field_exists_in_table('team_ids', 'documents')) {
        echo "Migrating team_ids field in documents table to new table.<br />\n";
        // Single INSERT...SELECT rather than a fetch-then-loop-INSERT: the
        // per-row PHP loop left document_team_mappings observably empty for
        // every already-restricted document between table creation and the
        // last INSERT, during which extras/separation/index.php treats a
        // missing mapping row as "visible to everyone" whenever
        // allow_all_to_document_noassign_team is enabled (the Team
        // Separation Extra's default). One atomic statement closes that
        // window instead of narrowing it.
        $stmt = $db->prepare("
            INSERT IGNORE INTO `document_team_mappings` (document_id, team_id)
            SELECT DISTINCT t1.id, t2.value FROM `documents` t1, `team` t2 WHERE FIND_IN_SET(t2.value, t1.team_ids);
        ");
        $stmt->execute();

        echo "Deleting `team_ids` field from the `documents` table.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `documents` DROP `team_ids`;");
        $stmt->execute();
    }
}

/**
 * Schema and one-time data prep for the governance_review_due queue job
 * (SR-189): the gate columns the job's queue_check stamps at the start of
 * every attempt (writing-queue-jobs' anti-requeue-storm rule), plus the
 * kill-switch setting and two idempotent backfills that keep the job's
 * first run from mass-notifying on records that predate the feature.
 *
 * Extracted from upgrade_from_20260828001() (same reasoning as
 * migrate_document_types_schema() above) so UpgradeMigrationWiringTest can
 * verify it stays wired into whichever upgrade_from_*() is the current
 * unreleased bucket — this exact class of placement bug (a migration parked
 * in an already-shipped upgrade function) recurred three times across this
 * feature's development before the helpers existed to catch it statically.
 *
 * WATERMARKING: without stamping `queue_timestamp_last_review_due` on
 * already-overdue records, every document/exception past its
 * next_review_date on the day this feature lands would be swept up by the
 * job's very first task_check pass — a mass-email event on upgrade, on an
 * instance that has never had this notification before. Idempotent: only
 * rows whose gate is still NULL are touched.
 *
 * NO-CADENCE STAMP CLEANUP: before this release, approve_document()/
 * approve_exception() unconditionally computed
 * next_review_date = approval_date + review_frequency days, so a no-cadence
 * (review_frequency <= 0) record approved under the old code was stamped
 * with next_review_date == approval_date — the treegrids classify that as
 * permanently overdue. The current code no longer produces this stamp (a
 * no-cadence approval now keeps the record's existing date, or writes
 * '0000-00-00' when it has none), but records approved BEFORE
 * this release keep their stale date until someone re-approves them.
 * next_review_date = approval_date is the old bug's exact signature, so this
 * only touches records that match it. Idempotent: once corrected to
 * '0000-00-00', a row can never match that signature again.
 *
 * @param PDO $db Open connection from the calling driver.
 */
function migrate_governance_review_due_schema($db) {

    if (!field_exists_in_table('queue_timestamp_last_review_due', 'documents')) {
        echo "Adding `queue_timestamp_last_review_due` to `documents`.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `documents` ADD `queue_timestamp_last_review_due` DATETIME NULL DEFAULT NULL");
        $stmt->execute();
    }
    if (!field_exists_in_table('queue_timestamp_last_review_due', 'document_exceptions')) {
        echo "Adding `queue_timestamp_last_review_due` to `document_exceptions`.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `document_exceptions` ADD `queue_timestamp_last_review_due` DATETIME NULL DEFAULT NULL");
        $stmt->execute();
    }

    // Admin kill-switch for the governance_review_due notification job,
    // mirroring NOTIFICATIONS_REMOTE_FEED_ENABLED. INSERT IGNORE, so a re-run
    // never resets an admin's chosen value back to 'true'.
    echo "Inserting the Governance Review Due notification setting.<br />\n";
    $stmt = $db->prepare("INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('GOVERNANCE_REVIEW_DUE_ENABLED', 'true');");
    $stmt->execute();

    echo "Watermarking already-overdue documents and exceptions so the first review-due run doesn't mass-notify.<br />\n";
    $stmt = $db->prepare("
        UPDATE `documents`
        SET `queue_timestamp_last_review_due` = NOW()
        WHERE `queue_timestamp_last_review_due` IS NULL
          AND `next_review_date` IS NOT NULL
          AND `next_review_date` != '0000-00-00'
          AND `next_review_date` <= CURDATE()
    ");
    $stmt->execute();
    $stmt = $db->prepare("
        UPDATE `document_exceptions`
        SET `queue_timestamp_last_review_due` = NOW()
        WHERE `queue_timestamp_last_review_due` IS NULL
          AND `next_review_date` IS NOT NULL
          AND `next_review_date` != '0000-00-00'
          AND `next_review_date` <= CURDATE()
    ");
    $stmt->execute();

    echo "Clearing the pre-fix no-cadence overdue stamp on already-approved documents and exceptions.<br />\n";
    $stmt = $db->prepare("
        UPDATE `documents`
        SET `next_review_date` = '0000-00-00'
        WHERE `document_status` = 3
          AND `review_frequency` <= 0
          AND `next_review_date` = `approval_date`
    ");
    $stmt->execute();
    $stmt = $db->prepare("
        UPDATE `document_exceptions`
        SET `next_review_date` = '0000-00-00'
        WHERE `approved` = 1
          AND `review_frequency` <= 0
          AND `next_review_date` = `approval_date`
    ");
    $stmt->execute();
}

/****************************************************************************
 * FUNCTION: BACKFILL SESSIONS USER ID                                      *
 * One-time (per row) migration helper: populates `sessions`.`user_id` for  *
 * every row still NULL, by parsing the uid out of its existing `data` with *
 * extract_session_data_uid() (authenticate.php) — so a session already     *
 * open when the SD-828 / SR-2133 fix ships is matched by                   *
 * kill_sessions_of_user() and refresh_permissions_in_sessions_of_user()    *
 * immediately, not only after its next write. Called from                  *
 * migrate_sessions_user_id_schema() below, its sole caller.                *
 *                                                                          *
 * Idempotent: only rows where `user_id IS NULL` are read, and a row whose  *
 * `data` has no uid (a pre-auth session) is left NULL — correctly, since   *
 * that is not a user's session yet. Re-running only ever re-processes      *
 * that same NULL set, which converges to the same result.                 *
 *                                                                          *
 * Paged in bounded batches keyed on `id` (the primary key) rather than     *
 * fetched in one SELECT. A `sessions` table can carry millions of rows on  *
 * an install with heavy anonymous/bot traffic (each unauthenticated       *
 * request that never returns with its cookie mints a fresh row) — an      *
 * unpaged `fetchAll()` there tries to buffer the entire multi-hundred-MB   *
 * result set into PHP's memory_limit in one shot and fatals with          *
 * "Allowed memory size exhausted" before a single row is processed.       *
 ****************************************************************************/
function backfill_sessions_user_id($db) {

    $batch_size = 2000;
    $last_id = '';
    $total_backfilled = 0;

    $select = $db->prepare(
        "SELECT `id`, `data` FROM sessions " .
        "WHERE `user_id` IS NULL AND `data` IS NOT NULL AND `data` != '' AND `id` > :last_id " .
        "ORDER BY `id` ASC LIMIT " . $batch_size
    );
    $update = $db->prepare("UPDATE sessions SET `user_id` = :user_id WHERE `id` = :id");

    while (true) {
        $select->bindValue(':last_id', $last_id, PDO::PARAM_STR);
        $select->execute();
        $rows = $select->fetchAll(PDO::FETCH_ASSOC);
        $fetched = count($rows);

        foreach ($rows as $row) {
            // Advance the keyset regardless of whether this row has a uid,
            // so a run of pre-auth rows can't stall forward progress.
            $last_id = $row['id'];

            $uid = extract_session_data_uid($row['data']);
            if ($uid === null) {
                // No uid in this row's data yet (e.g. a pre-auth session) — leave NULL.
                continue;
            }
            $update->bindValue(':user_id', $uid, PDO::PARAM_INT);
            $update->bindValue(':id', $row['id'], PDO::PARAM_STR);
            $update->execute();
            $total_backfilled++;
        }

        if ($fetched < $batch_size) {
            break;
        }
    }

    if ($total_backfilled > 0) {
        echo "Backfilled `user_id` on " . $total_backfilled . " existing session row(s).<br />\n";
    }
}

/**********************************************************
 * FUNCTION: MIGRATE SESSIONS USER ID SCHEMA               *
 **********************************************************
 * SD-828 / SR-2133: kill_sessions_of_user() used to filter the `sessions`
 * table with an unindexed `data REGEXP :uid_pattern` predicate -- a
 * full-table scan that could take next-key locks broadly enough to hit
 * MySQL's innodb_lock_wait_timeout under concurrent writes, throwing an
 * uncaught PDOException on logout/password-reset. This adds a maintained,
 * indexed `user_id` column so that query becomes a plain equality lookup.
 *
 * `user_id` is nullable, maintained going forward on every session write
 * (see SimpleRiskSessionHandler::write() and sess_write() in
 * authenticate.php), and backfilled here for every session already open
 * at upgrade time -- see backfill_sessions_user_id() above.
 * The only rows that stay NULL after this migration are ones whose `data`
 * genuinely has no uid yet (a pre-auth session, e.g. mid-MFA) -- those are
 * correctly excluded from kill_sessions_of_user() and refresh_permissions_
 * in_sessions_of_user(), which is the same behavior the old REGEXP had.
 **********************************************************/
function migrate_sessions_user_id_schema($db) {

    if (!field_exists_in_table('user_id', 'sessions')) {
        echo "Adding `user_id` to `sessions`.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `sessions` ADD `user_id` INT NULL DEFAULT NULL");
        $stmt->execute();
    }

    // Backfill before indexing: every currently open session gets its
    // user_id populated from its existing `data` in one pass, so the index
    // built next is populated from the start instead of maintained
    // incrementally row-by-row during the backfill UPDATEs.
    backfill_sessions_user_id($db);

    if (!index_exists_on_table('sessions_user_id_idx', 'sessions')) {
        echo "Adding the `sessions_user_id_idx` index on `sessions`.`user_id`.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `sessions` ADD INDEX `sessions_user_id_idx` (`user_id`)");
        $stmt->execute();
    }
}

/**********************************************************
 * FUNCTION: UPGRADE ADD SESSIONS ACCESS INDEX            *
 **********************************************************
 * Index `sessions`.`access` so session garbage collection is an index range
 * delete instead of a table scan.
 *
 * sess_gc() runs `DELETE FROM sessions WHERE access < :old ORDER BY access
 * ASC LIMIT 500`, and index.php calls it on every login-page request. With no
 * index on `access`, InnoDB scans the whole table and locks every row it
 * visits, so a concurrent session write (REPLACE INTO sessions in sess_write())
 * waits behind it and, under load, times out with SQLSTATE HY000 / 1205
 * ("Lock wait timeout exceeded"). Bots that hit the login page create a
 * session each, so the table (and the scan) grows with scanner traffic.
 *
 * `sessions` is the hottest table in the application and the session handler
 * holds a SELECT ... FOR UPDATE transaction for the whole request, so a plain
 * ALTER could queue behind those transactions for its metadata lock -- and every
 * session read/write arriving after it would queue behind the ALTER. The index
 * is therefore added online (ALGORITHM=INPLACE, LOCK=NONE, which makes MySQL
 * refuse rather than silently fall back to a table copy) under a short
 * lock_wait_timeout that is restored afterwards. If it cannot be taken in that
 * window the failure is logged and the upgrade carries on: the instance simply
 * keeps today's behaviour, and the statement is safe to re-run in a quieter
 * window. Idempotent: a no-op once the index exists.
 **********************************************************/
function upgrade_add_sessions_access_index($db) {

    if (index_exists_on_table('sessions_access_idx', 'sessions')) {
        return;
    }

    echo "Adding the `sessions_access_idx` index on `sessions`.`access`.<br />\n";

    $previous_timeout = null;
    try {
        $previous_timeout = (int)$db->query("SELECT @@SESSION.lock_wait_timeout")->fetchColumn();
        $db->exec("SET SESSION lock_wait_timeout = 10");
        $db->exec("ALTER TABLE `sessions` ADD INDEX `sessions_access_idx` (`access`), ALGORITHM=INPLACE, LOCK=NONE");
    } catch (\Throwable $e) {
        write_debug_log("upgrade_add_sessions_access_index: could not add sessions_access_idx (" . $e->getMessage() . "); continuing without it -- re-run `ALTER TABLE sessions ADD INDEX sessions_access_idx (access)` during a quiet period", 'warning');
        echo "Could not add the `sessions_access_idx` index right now (the sessions table is busy); the upgrade will continue without it.<br />\n";
    } finally {
        if ($previous_timeout !== null && $previous_timeout > 0) {
            try {
                $db->exec("SET SESSION lock_wait_timeout = " . $previous_timeout);
            } catch (\Throwable $e) {
                write_debug_log("upgrade_add_sessions_access_index: could not restore lock_wait_timeout: " . $e->getMessage(), 'warning');
            }
        }
    }
}

/**********************************************************
 * FUNCTION: DUPLICATE INSTANCE IDS                       *
 **********************************************************
 * The instance_id values confirmed to be shared by many unrelated organizations.
 *
 * HOW THEY HAPPENED: two delivery vectors shipped an already-populated
 * `settings` row for instance_id — a pre-seeded database file, and a VM image
 * with a pre-populated database. create_simplerisk_instance_id() returns the
 * existing value when one is present, so every instance built from those
 * artifacts kept the seeded id, and the registration path of the day sent that
 * id to the licensing service instead of minting a fresh one. One id ended up
 * shared by 30 organizations.
 *
 * MAINTENANCE OBLIGATION: this list is load-bearing indefinitely.
 * repair_duplicate_instance_id() is a STANDING check, not a one-time release
 * migration — it runs on every upgrade, on every admin/upgrade.php upgrade
 * attempt (pressing Continue, not merely opening the page), and on every call
 * into the management API's structured upgrade driver, including a no-op one.
 * If a ninth carrier is ever identified and is not added here, the check will
 * run, find nothing, and report clean. There is no mechanism that detects a
 * stale list; keeping it current is a human responsibility.
 *
 * Each value is a generate_token(50) string. Transcribe exactly.
 *
 * THIS LIST IS MIRRORED in DuplicateInstanceIdRepairTest::EXPECTED_IDS, which
 * transcribes it independently so a typo here fails loudly rather than silently
 * disabling a carrier. Adding an entry to one list without the other turns that
 * test red immediately, in either direction — that is the intent, not a defect.
 * Update both.
 *
 * @return list<string>
 **********************************************************/
function duplicate_instance_ids()
{
    return [
        'buQDR9yTTlqUXGoPmUQjq7OBJJZQzSovc4tAaPj6jyeaM4y4G9',
        'QIpmS4gO8l2ryKX4JeHdMxMGv5L5OFyqVdqxeWMvT9oSkUDZYY',
        'NvkrFq8rfVWA0wt0PKMMBHUQOjmPOZ63OwOrcVjKjVUm0Qc2ux',
        '36ODqYyyd8vthw2715KV3st85j7qCRlK9OlGn07PZa3VgtRLZ6',
        'p5AxaccLa3noBJK69mVPIBXh06DGVb5EDbp6RInhyUY9ObUc2f',
        'iJBZlvb5pGOHKXqoxbh8br39EJkAPl2e0WPd7fsPjMnpKs7qQ6',
        'CG2IPndnJBm4GL141AFJQnx7Wsl6gT3JGGW02uGjZQOzhE6RVK',
        'C2zedFBTA6QmJmIGVAE4yzrwYcQ3jCQ9q4RZQynHS4ljEh7Yx0',
    ];
}

/**********************************************************
 * FUNCTION: REPAIR DUPLICATE INSTANCE ID                 *
 **********************************************************
 * Give this instance a unique identity if it is carrying one of the ids in
 * duplicate_instance_ids().
 *
 * ORDER IS THE WHOLE POINT: register FIRST, overwrite the local settings only
 * once a 200 comes back. The obvious reading of "clear the id and key, then
 * re-register" leaves the instance UNREGISTERED whenever the licensing service
 * is unreachable -- a real possibility mid-upgrade on a customer network -- which
 * is strictly worse than the duplication it was meant to fix.
 * licensing_register_with_retry() mints the new id itself and retries on 409, so
 * the old values can simply stay in place until it succeeds.
 *
 * An unregistered carrier is repaired locally with no /register call: there is
 * no registration to preserve and no credential to rotate, and calling /register
 * would create a registration the customer never initiated. (The default
 * $cache_warm still fires and reaches /license/check -- that call is unrelated
 * to registration and safe to make either way.)
 *
 * IDEMPOTENT BOTH WAYS. After a success the id is no longer in the list, so a
 * re-run is a no-op. After a failure nothing was written, so the next upgrade
 * retries. Two instances sharing an id and upgrading at the same moment each
 * mint their own.
 *
 * NEVER THROWS. A licensing outage must not stop the database version from
 * advancing.
 *
 * Settings are written through update_or_insert_setting() rather than raw SQL
 * because it refreshes $GLOBALS['setting_<name>'], which get_setting() reads.
 * A raw REPLACE INTO would leave license_check_daily() reporting the new
 * registration under the OLD id for the rest of the request.
 *
 * @param PDO           $db         Open connection, reused for the settings reads/writes.
 * @param callable|null $transport  Test seam forwarded to licensing_register_with_retry().
 * @param callable|null $cache_warm Test seam; defaults to license_check_daily().
 **********************************************************/
function repair_duplicate_instance_id($db, ?callable $transport = null, ?callable $cache_warm = null): void
{
    $current = get_setting('instance_id', false, true, $db);

    // The path essentially every instance takes: one cached read and an
    // in_array over eight strings. Stay silent.
    if (!is_string($current) || !in_array($current, duplicate_instance_ids(), true)) {
        return;
    }

    if ($cache_warm === null) {
        $cache_warm = 'license_check_daily';
    }

    echo "Detected an instance_id that was distributed with a pre-populated database and is shared by other organizations. Repairing.<br />\n";
    write_debug_log(
        "repair_duplicate_instance_id: instance_id '{$current}' is a known shared value; repairing.",
        'notice'
    );

    // Forensic record of the entitlement state BEFORE anything is written. D6
    // below warms the licensing cache after a successful rotation on the
    // premise that a shared id resolves to no valid licensing, so there is
    // nothing good to lose -- but that premise is about server-side state and
    // is not verifiable from this code. If it is wrong for even one of the
    // eight carriers, this line is what survives to reconstruct what the
    // instance had. get_cached_license_entries() rows carry only extra_name,
    // effective/is_free booleans, license status/start/end dates,
    // current_version and download_sha256 -- no credential-shaped field -- so
    // logging the whole decoded array does not risk the never-log-secrets rule.
    write_debug_log(
        'repair_duplicate_instance_id: pre-rotation entitlement state — enforcement='
        . get_cached_enforcement_level() . ', entries=' . json_encode(get_cached_license_entries()),
        'notice'
    );

    $services_api_key = get_setting('services_api_key', false, true, $db);
    $registered = (get_setting('registration_registered', false, true, $db) == 1)
        && is_string($services_api_key)
        && $services_api_key !== '';

    if ($registered) {
        try {
            $result = licensing_register_with_retry([
                'fname'   => (string)get_setting('registration_fname',   '', true, $db),
                'lname'   => (string)get_setting('registration_lname',   '', true, $db),
                'company' => (string)get_setting('registration_company', '', true, $db),
                'title'   => (string)get_setting('registration_title',   '', true, $db),
                'phone'   => (string)get_setting('registration_phone',   '', true, $db),
                'email'   => (string)get_setting('registration_email',   '', true, $db),
            ], $transport);
        } catch (\Throwable $e) {
            write_debug_log(
                'repair_duplicate_instance_id: re-registration threw (' . $e->getMessage()
                . '); leaving the existing identity in place.',
                'error'
            );
            echo "Could not reach the licensing service; the existing registration was left in place and this will be retried on the next upgrade.<br />\n";
            return;
        }

        // A genuine transport-level failure (non-200, or the 409 retries
        // exhausted): the service was NOT usefully reached, so this is the one
        // remaining path where "could not reach the licensing service" is an
        // accurate thing to tell the console.
        if (empty($result['ok'])) {
            write_debug_log(
                'repair_duplicate_instance_id: re-registration failed ('
                . (isset($result['error']) ? $result['error'] : 'unknown')
                . '); instance_id and services_api_key left unchanged. The next upgrade will retry.',
                'warning'
            );
            echo "Could not reach the licensing service; the existing registration was left in place and this will be retried on the next upgrade.<br />\n";
            return;
        }

        // The service DID answer with a 200 here -- everything below this point
        // is a different failure class, and must not be described as
        // unreachable. Two things are checked and both are treated as a
        // failure, not a partial success:
        //
        //   - A missing services_api_key: writing the new instance_id without a
        //     matching key would pair a brand-new identity with the OLD
        //     carrier's key -- a combination that authenticates as nothing and
        //     is permanent, because the new id is no longer in
        //     duplicate_instance_ids() and the standing check never revisits it.
        //
        //   - A malformed instance_id: LICENSING_URL is overridable in
        //     config.php, so a spoofed or compromised endpoint could return any
        //     non-empty string. Nothing downstream is injectable -- every write
        //     is a bound parameter and every render site escapes -- but a
        //     malformed id would still be written PERMANENTLY for the same
        //     reason as above. The regex also keeps a hostile response from
        //     putting a newline into the notice/critical log lines below.
        $valid_instance_id = !empty($result['instance_id'])
            && preg_match('/^[A-Za-z0-9]{50}$/', (string)$result['instance_id']);

        if (!$valid_instance_id || empty($result['services_api_key'])) {
            $error = !$valid_instance_id
                ? 'registration returned a malformed or empty instance_id'
                : 'registration returned no services_api_key';
            write_debug_log(
                "repair_duplicate_instance_id: re-registration succeeded but the response was "
                . "unusable ({$error}); instance_id and services_api_key left unchanged. The next "
                . 'upgrade will retry.',
                'warning'
            );
            echo "The licensing service responded, but its answer could not be used to update this instance's identity. Nothing was changed; this will be retried on the next upgrade.<br />\n";
            return;
        }

        // Only now is it safe to overwrite the local identity. Check the
        // instance_id write before attempting the key write: update_or_insert_setting()
        // returns false rather than throwing on a caught DB error, and writing the
        // key against a still-stale instance_id would produce the mirror-image
        // broken pair -- the OLD id with the NEW key.
        if (!update_or_insert_setting('instance_id', $result['instance_id'], $db)) {
            write_debug_log(
                "repair_duplicate_instance_id: failed to write the new instance_id; leaving the "
                . 'existing identity in place. The next upgrade will retry.',
                'error'
            );
            echo "The licensing service responded, but this instance's identity could not be saved locally. Nothing was changed; this will be retried on the next upgrade.<br />\n";
            return;
        }

        // The instance_id write succeeded; the key write is checked the same way.
        // If it fails here, the instance is left with the NEW instance_id paired
        // with the OLD carrier's key -- the same permanent broken pair the guard
        // above exists to prevent (the new id is no longer in
        // duplicate_instance_ids(), so the standing check never revisits it).
        // Compensate by writing $current back onto instance_id rather than using
        // a DB transaction: a rollBack() would restore the row but leave
        // $GLOBALS['setting_instance_id'] holding the new id, reintroducing the
        // exact cache-incoherence bug the coherence test guards. A second
        // update_or_insert_setting() call fixes the row and the memo together.
        if (!update_or_insert_setting('services_api_key', $result['services_api_key'], $db)) {
            if (!update_or_insert_setting('instance_id', $current, $db)) {
                // Both writes failed: the instance is now stuck with the NEW
                // instance_id and the OLD services_api_key, and cannot be
                // rolled back automatically. Log both ids (never the key) so
                // support can reconcile by hand.
                write_debug_log(
                    'repair_duplicate_instance_id: CRITICAL -- the services_api_key write failed '
                    . "and the compensating instance_id rollback ALSO failed. The instance is left "
                    . "with instance_id '{$result['instance_id']}' paired with the OLD services_api_key "
                    . "from '{$current}'. This pair will not authenticate and requires manual "
                    . 'reconciliation.',
                    'critical'
                );
                echo "This instance's identity could not be fully updated and needs manual attention. Please contact support.<br />\n";
                return;
            }

            write_debug_log(
                "repair_duplicate_instance_id: the licensing service issued a new registration "
                . "('{$result['instance_id']}') but the services_api_key write failed; rolled "
                . "instance_id back to '{$current}'. The next upgrade will retry, which will "
                . 'register again.',
                'error'
            );
            echo "The licensing service issued a new registration, but this instance's identity could not be saved locally; the change was rolled back to the previous identity. This will be retried on the next upgrade.<br />\n";
            return;
        }

        // The key is deliberately absent from this line.
        write_debug_log(
            "repair_duplicate_instance_id: re-registered; instance_id '{$current}' -> "
            . "'{$result['instance_id']}'.",
            'notice'
        );
        echo "Re-registered this instance under a unique instance_id.<br />\n";
    } else {
        $new_id = generate_token(50);
        if (!update_or_insert_setting('instance_id', $new_id, $db)) {
            write_debug_log(
                "repair_duplicate_instance_id: failed to write the new instance_id; leaving the "
                . "existing identity '{$current}' in place. The next upgrade will retry.",
                'error'
            );
            echo "Could not update the local instance identity; this will be retried on the next upgrade.<br />\n";
            return;
        }
        write_debug_log(
            "repair_duplicate_instance_id: instance is not registered; instance_id '{$current}' -> "
            . "'{$new_id}' with no licensing call.",
            'notice'
        );
        echo "Replaced the shared instance_id with a unique value.<br />\n";
    }

    // Push the new identity into the licensing records now rather than waiting
    // up to 24h for the daily cron. The duplicates resolve to no valid
    // licensing, so there is no good cached entitlement set at risk here.
    try {
        call_user_func($cache_warm);
    } catch (\Throwable $e) {
        write_debug_log(
            'repair_duplicate_instance_id: the identity was rotated successfully but the licensing '
            . 'cache warm failed (' . $e->getMessage() . '). The daily check will catch up.',
            'warning'
        );
    }
}

/**********************************************************
 * FUNCTION: BACKFILL DOCUMENTATION PERMISSIONS           *
 **********************************************************
 * Grants the two Document Program permissions added in this release to the
 * existing users who should already have them:
 *
 *   view_documentation    -> every existing `governance` holder. SR-2071:
 *                            add_new_permissions() grants a new permission to
 *                            admins only, never to existing holders of a
 *                            related coarse permission, so the read access
 *                            those users already had has to be re-granted
 *                            explicitly or the upgrade takes it away.
 *   approve_documentation -> every user who already holds BOTH
 *                            add_documentation and modify_documentation --
 *                            the closest existing proxy for "this user already
 *                            manages documents end to end". A join of the two
 *                            single-permission holder sets rather than
 *                            INTERSECT, for MySQL/MariaDB portability.
 *
 * Extracted from upgrade_from_20260828001() so a test can invoke the real
 * backfill against users it has just seeded, rather than asserting against a
 * grant that ran once at DB-upgrade time -- long before any test fixture user
 * existed. (tests/unit/DocumentationPermissionUpgradeTest.php asserted exactly
 * that and could never pass.) A copy of the SQL in the test would be worse than
 * no test: it would keep passing if this were changed or deleted.
 *
 * Idempotent: INSERT IGNORE against permission_to_user's (permission_id,
 * user_id) key, and both statements are pure INSERT ... SELECT, so re-running
 * grants nothing new.
 *
 * @param PDO $db Open connection from the calling driver.
 **********************************************************/
function backfill_documentation_permissions($db)
{
    $stmt = $db->prepare("
        INSERT IGNORE INTO `permission_to_user` (`permission_id`, `user_id`)
        SELECT (SELECT `id` FROM `permissions` WHERE `key` = 'view_documentation'), p2u.`user_id`
        FROM `permission_to_user` p2u
        INNER JOIN `permissions` p ON p.`id` = p2u.`permission_id`
        WHERE p.`key` = 'governance';
    ");
    $stmt->execute();

    $stmt = $db->prepare("
        INSERT IGNORE INTO `permission_to_user` (`permission_id`, `user_id`)
        SELECT (SELECT `id` FROM `permissions` WHERE `key` = 'approve_documentation'), t1.`user_id`
        FROM (
            SELECT p2u.`user_id` FROM `permission_to_user` p2u
            INNER JOIN `permissions` p ON p.`id` = p2u.`permission_id` WHERE p.`key` = 'add_documentation'
        ) t1
        INNER JOIN (
            SELECT p2u.`user_id` FROM `permission_to_user` p2u
            INNER JOIN `permissions` p ON p.`id` = p2u.`permission_id` WHERE p.`key` = 'modify_documentation'
        ) t2 ON t1.`user_id` = t2.`user_id`;
    ");
    $stmt->execute();
}

/**********************************************************
 * FUNCTION: BACKFILL DOCUMENT AUDIT LOG IDS               *
 **********************************************************
 * Historical `audit_log` rows with log_type='document' predate write_log()'s
 * `+1000` convention being applied consistently across every document
 * call site (see the write_log(..., 'document') calls in
 * includes/governance.php's add_document()/update_document()/
 * delete_document()/approve_document()/unapprove_document() and
 * includes/compliance.php's download-log addition). Their stored `risk_id`
 * is therefore either 0 (the historical hardcoded `1000` bug) or offset by
 * -1000 from the real document id (the pre-fix calls that passed the id
 * without +1000). This reparses each row's decrypted message to recover the
 * real document id and rewrites `risk_id` to match, so the audit trail's
 * structured Document column/filter (which joins audit_log.risk_id directly
 * to documents.id) resolves these entries too, not only ones logged after
 * the fix.
 *
 * Only rows whose message matches one of the known document-audit message
 * shapes are touched. The file-upload log line ("File \"x\" was uploaded by
 * username \"y\".", written via a pre-existing call at functions.php:22606
 * that already used +1000 correctly) carries no document id or name at all,
 * matches nothing here, and is left as-is -- it was already correct.
 *
 * Idempotent: re-running recomputes the same risk_id for a row already
 * fixed, and a row that can't be resolved (its document has since been
 * renamed/deleted, or its name matches more than one document) is skipped
 * the same way on every run rather than guessed at.
 **********************************************************/
function backfill_document_audit_log_ids($db)
{
    $stmt = $db->prepare("SELECT `id`, `message` FROM `audit_log` WHERE `log_type` = 'document';");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $update_stmt = $db->prepare("UPDATE `audit_log` SET `risk_id` = :risk_id WHERE `id` = :id;");
    $lookup_stmt = $db->prepare("SELECT `id` FROM `documents` WHERE `document_name` = :document_name;");

    foreach ($rows as $row) {
        $message = try_decrypt($row['message']);
        $document_id = null;

        if (preg_match('/\(ID:\s*(\d+)\)/', $message, $matches)) {
            // "Document \"x\"(ID: N) was updated by ..."
            $document_id = (int)$matches[1];
        } elseif (preg_match('/document ID "(\d+)"/i', $message, $matches)) {
            // "The existing document ID \"N\" was deleted by ..."
            $document_id = (int)$matches[1];
        } elseif (preg_match('/^(?:A new document named|Document) "(.*?)" was (?:created by user|approved by|unapproved by|downloaded by)/', $message, $matches)) {
            // Create/Approve/Unapprove/Download messages carry only the
            // document name -- resolve it, but only when it names exactly
            // one document.
            $lookup_stmt->bindParam(":document_name", $matches[1], PDO::PARAM_STR);
            $lookup_stmt->execute();
            $matching_documents = $lookup_stmt->fetchAll(PDO::FETCH_COLUMN);
            if (count($matching_documents) === 1) {
                $document_id = (int)$matching_documents[0];
            }
        }

        if ($document_id !== null) {
            $update_stmt->bindParam(":risk_id", $document_id, PDO::PARAM_INT);
            $update_stmt->bindParam(":id", $row['id'], PDO::PARAM_INT);
            $update_stmt->execute();
        }
    }
}

/*******************************************************************************
 * FUNCTION: UPGRADE NOTIFICATION WANTED                                        *
 *******************************************************************************
 * Whether finishing an upgrade should tell users. True only when the database
 * version actually moved: a no-op visit to the upgrade page, and the in-flight
 * function that deliberately leaves the version alone, must stay silent.
 * Pure (no I/O).
 ******************************************************************************/
function upgrade_notification_wanted(string $from_version, string $to_version): bool
{
    return $to_version !== '' && $from_version !== $to_version;
}

/*******************************************************************************
 * FUNCTION: NOTIFY UPGRADE COMPLETE                                            *
 *******************************************************************************
 * Tells every user, in-app, that SimpleRisk was upgraded and links the release
 * notes. Called by each upgrade driver once the chain has arrived, with the
 * database version from BEFORE the run -- so one notification covers however
 * many releases the run crossed.
 *
 * Idempotent: external_guid is per target version, so a retry or a second driver
 * reaching the same version inserts nothing. Title and body are stored as
 * language keys (see resolve_notification_text()) so each user reads them in
 * their own language. Must not throw: a failed notification must never fail an
 * upgrade. A no-op when the notifications tables do not exist.
 ******************************************************************************/
function notify_upgrade_complete(string $from_version, string $to_version): void
{
    if (!upgrade_notification_wanted($from_version, $to_version)) {
        return;
    }

    try {
        require_once(realpath(__DIR__ . '/../notifications.php'));

        if (!table_exists('notifications') || !table_exists('notification_recipients')) {
            return;
        }

        $result = create_notification(
            source:        'upgrade',
            title:         notification_lang_ref('UpgradeNotificationTitle'),
            body:          notification_lang_ref('UpgradeNotificationBody', $to_version),
            link:          NOTIFICATION_RELEASE_NOTES_URL,
            audience_type: 'all_user',
            audience_id:   null,
            created_by:    null,
            expires_at:    null,
            external_guid: 'upgrade-' . $to_version
        );

        // 'duplicate' is the expected answer for a second driver or a retry; a
        // rejection means the source or link validator changed under us.
        if (!in_array($result['status'], ['inserted', 'duplicate'], true)) {
            write_debug_log('notify_upgrade_complete() was rejected: ' . $result['status'], 'warning');
        }
    } catch (\Throwable $e) {
        write_debug_log('notify_upgrade_complete() failed: ' . $e->getMessage(), 'warning');
    }
}

/**********************************************************
 * FUNCTION: RUN UPGRADE INTEGRITY CHECKS                 *
 **********************************************************
 * Standing data-integrity checks, run by BOTH upgrade drivers at the point
 * where the database has reached the application version.
 *
 * WHY STANDING RATHER THAN RELEASE-BOUND: a check parked in one
 * upgrade_from_*() only ever fires for instances crossing that single version
 * boundary. An instance already past it -- including one restored next year from
 * a template database -- is never examined. The duplicate-instance_id problem
 * recurred from 2018 to 2026, so a one-shot check would miss the next
 * occurrence. Running here also means a carrier that is already fully upgraded
 * is repaired the next time an admin deliberately presses Continue on an
 * already-current admin/upgrade.php -- merely opening the page only renders
 * display_upgrade_info() and never reaches this -- or, with no admin visit at
 * all, the next time the management API's run_database_upgrade_structured() is
 * called, including a no-op call. That second path is what lets a HOSTED
 * instance heal passively.
 *
 * The cost on the path essentially every instance takes is one cached
 * get_setting() and an in_array over eight strings.
 *
 * Must not throw: a failed check must never stop the database version from
 * advancing.
 *
 * ADDING A CHECK: it belongs here only if it is safe to run on every upgrade
 * and on every no-op call from either driver -- meaning idempotent, cheap when
 * there is nothing to do, and harmless when it fails. Anything that is a
 * one-time schema or data change belongs in the current release's
 * upgrade_from_*() instead.
 *
 * The two seams are forwarded, not consumed, and both drivers call this with
 * neither -- so production behaviour is exactly `repair_duplicate_instance_id($db)`.
 * They exist because the branch a caller most needs covered is the one where a
 * check REPORTS something, and reaching it with the real defaults would make a
 * test rotate an identity against the live licensing service. Without a seam
 * here the only reachable test case is the silent no-op.
 *
 * @param PDO           $db         Open connection from the calling driver.
 * @param callable|null $transport  Test seam forwarded to repair_duplicate_instance_id().
 * @param callable|null $cache_warm Test seam forwarded to repair_duplicate_instance_id().
 **********************************************************/
function run_upgrade_integrity_checks($db, ?callable $transport = null, ?callable $cache_warm = null)
{
    try {
        repair_duplicate_instance_id($db, $transport, $cache_warm);
    } catch (\Throwable $e) {
        write_debug_log(
            'run_upgrade_integrity_checks: repair_duplicate_instance_id() failed: '
            . $e->getMessage(),
            'error'
        );
    }

    try {
        migrate_document_team_mappings_schema($db);
    } catch (\Throwable $e) {
        write_debug_log(
            'run_upgrade_integrity_checks: migrate_document_team_mappings_schema() failed: '
            . $e->getMessage(),
            'error'
        );
    }

    // asset_discovery_runs.probe_method / tcp_ports joined the discovery-runs
    // helper after some databases had already run it; its guarded steps are a
    // no-op (two column lookups) once everything is there.
    try {
        upgrade_add_asset_discovery_runs($db);
    } catch (\Throwable $e) {
        write_debug_log(
            'run_upgrade_integrity_checks: upgrade_add_asset_discovery_runs() failed: '
            . $e->getMessage(),
            'error'
        );
    }

    // The latest-version cache is only refreshed daily, so it names the previous
    // release as "latest" right after an upgrade. Discard it if it is behind.
    try {
        refresh_stale_latest_version_cache($db);
    } catch (\Throwable $e) {
        write_debug_log(
            'run_upgrade_integrity_checks: refresh_stale_latest_version_cache() failed: '
            . $e->getMessage(),
            'error'
        );
    }
}

/*******************************************************************************
 * FUNCTION: LATEST VERSION CACHE IS STALE                                      *
 *******************************************************************************
 * Pure decision: is the cached "latest" release older than the one installed?
 *
 * settings.latest_version_data is refreshed by the core_version_check job at
 * most once every 24 hours, so an instance upgraded after the cache was written
 * still holds the previous release as "latest" -- which the registration page
 * rendered as an available update. Only STRICTLY behind counts: a dev or RC
 * build is ahead of the feed and a cache that agrees with it is fine.
 * Identifiers are fixed-width YYYYMMDD-NNN, so strcmp() is chronological.
 *
 * @param string $cached_app The 'app' value from the cached feed entry ('' if none).
 * @param string $installed  The release now installed.
 **********************************************************/
function latest_version_cache_is_stale(string $cached_app, string $installed): bool
{
    if ($cached_app === '' || $installed === '') {
        return false;
    }
    return strcmp($cached_app, $installed) < 0;
}

/*******************************************************************************
 * FUNCTION: REFRESH STALE LATEST VERSION CACHE                                 *
 *******************************************************************************
 * After an upgrade, drop a latest-version cache that is behind the installed
 * release and reset the version-check gate, so the core_version_check job
 * refetches the real feed entry on its next tick.
 *
 * Deliberately a discard, not a write of the installed version: the cache
 * mirrors a releases.xml entry (md5, release date, notes, schema URLs) and
 * stamping only the version into it would leave the rest describing the old
 * release. Until the job runs the cache is empty, which readers treat as
 * "unknown" -- no badge -- rather than showing a wrong one.
 *
 * Cheap and idempotent: a current, absent or unparseable cache is left alone.
 *
 * @param PDO         $db        Open connection from the calling driver.
 * @param string|null $installed Test seam; defaults to APP_VERSION.
 * @return bool True when the cache was discarded.
 **********************************************************/
function refresh_stale_latest_version_cache($db, ?string $installed = null): bool
{
    $installed ??= defined('APP_VERSION') ? (string)APP_VERSION : '';

    $cached = json_decode((string)get_setting('latest_version_data', false, false, db: $db), true);
    $cached_app = (is_array($cached) && isset($cached['app']) && is_string($cached['app'])) ? $cached['app'] : '';

    if (!latest_version_cache_is_stale($cached_app, $installed)) {
        return false;
    }

    delete_setting('latest_version_data', $db);
    delete_setting('queue_timestamp_last_version_check', $db);
    unset($GLOBALS['latest_versions_cached']);

    write_debug_log(
        "Upgrade: discarded stale latest-version cache ({$cached_app}, installed {$installed}); the version check will refetch it.",
        'info'
    );
    return true;
}

/*******************************************************************************
 * FUNCTION: APPLY DATABASE RELEASE                                             *
 *******************************************************************************
 * Apply ONE release's upgrade function and report what happened.
 *
 * The shared step for the two JSON-facing drivers:
 * run_database_upgrade_structured() (the management extra's /upgrade) and
 * api_v2_admin_upgrade_db() (POST /admin/upgrade/db). The second used to
 * hand-roll its own and was missing most of what the first does -- no grants
 * check, no captured exception, no advancement check -- so an instance upgraded
 * through that endpoint could be told "Upgrade successful" by a release
 * function that threw or that moved nothing.
 *
 * NOT used by upgrade_database(), and that is deliberate rather than an
 * oversight to tidy up later. That driver echoes to the operator's page as it
 * goes (admin/upgrade.php reads it live); this function buffers a release
 * function's output and returns it as an array, which would replace a running
 * commentary with a single lump at the end. The two therefore keep separate
 * dispatch, and share the part that actually caused divergence --
 * upgrade_chain_advanced() and finalize_database_upgrade().
 *
 * So a change HERE does not automatically reach upgrade_database(). Check it
 * too, or the drift this function was written to end starts over.
 *
 * What it deliberately does NOT do is decide anything: no chain walking, no
 * status code, no output. Those differ per channel and belong to the caller.
 * This returns facts and lets each channel report them in its own shape.
 *
 * @param object $db      An open database handle.
 * @param string $version The release whose upgrade function should run.
 *
 * @return array {
 *     @var string $from     Database version before the call.
 *     @var string $to       Database version after it.
 *     @var bool   $ran      Whether an upgrade function was found and called.
 *     @var bool   $advanced Whether the database version actually moved.
 *     @var bool   $success  $ran && no error && $advanced.
 *     @var string $error    Internal error text, for the log -- never for a caller.
 *     @var array  $messages The function's echoed progress, as lines.
 * }
 */
function apply_database_release($db, $version)
{
    // The baseline is READ, never taken from $version. They are the same value
    // for the chain drivers, which dispatch on the version they just read -- but
    // the v2 endpoint takes the version from its caller, and trusting it there
    // would compute "did the database move?" against a number the database was
    // never on, reporting advancement for a migration that did nothing.
    $before = current_version("db");

    $result = array(
        'from'     => (string)$before,
        'to'       => (string)$before,
        'ran'      => false,
        'advanced' => false,
        'success'  => false,
        'error'    => '',
        'messages' => array(),
    );

    $function_name = get_database_upgrade_function_for_release($version);
    if ($function_name === false || !function_exists($function_name)) {
        return $result;
    }

    // The release functions narrate themselves with echo. Capture that here so
    // a caller answering in JSON does not emit HTML into its own response --
    // which is what forced api_v2_admin_upgrade_db() to run the function bare,
    // and is why an exception from it escaped uncaught.
    $outer = ob_get_level();
    ob_start();
    try {
        call_user_func($function_name, $db);
    } catch (\Throwable $e) {
        // Kept out of the return value's message list on purpose: exception text
        // carries table and column names, file paths and MySQL error strings.
        // A caller gets "something failed"; the detail goes to the log.
        $result['error'] = $e->getMessage();
    } finally {
        // Bounded rather than while-true: a release function that opened a
        // buffer and did not close it must not let this unwind past the
        // caller's own.
        $guard = 0;
        while (ob_get_level() > $outer && $guard++ < 32) {
            $result['messages'] = array_merge(upgrade_output_to_messages(ob_get_clean()), $result['messages']);
        }
    }

    $result['ran']      = true;
    $result['to']       = current_version("db");
    $result['advanced'] = upgrade_chain_advanced($before, $result['to']);
    $result['success']  = ($result['error'] === '' && $result['advanced']);

    return $result;
}

/**
 * Run something while holding the instance-wide upgrade lock.
 *
 * Two upgrade chains running at once on one database is the worst concurrency
 * bug this subsystem can have. Both drivers read the same db_version, both
 * dispatch the same upgrade_from_* function, and the migrations are written to
 * be idempotent against a RE-RUN, not against a simultaneous run: two
 * interleaved ALTERs on the same table, two seed inserts racing the same
 * existence check, two update_database_version() writes deciding what the
 * version is now.
 *
 * It is not hypothetical. The Upgrade Extra took a lock for its own start-once
 * check and nothing else did, so the hosted fleet's automation calling the
 * management /upgrade endpoint could walk the chain underneath an administrator
 * who had just clicked Upgrade in the UI -- two entirely different channels,
 * neither aware of the other.
 *
 * A MySQL advisory lock rather than a file: it is named (so it excludes across
 * web workers, which a per-process flag cannot) and it lives in the database
 * (so it excludes across NODES sharing one database, which a lock on local disk
 * cannot). Same lock name the Upgrade Extra uses, so the channels exclude each
 * other and not merely themselves.
 *
 * Non-blocking by default. A caller who cannot get the lock has an upgrade
 * already in progress, and queueing behind it would run a second chain the
 * moment the first finished -- the caller wants to be told "not now", not to
 * wait and then do the wrong thing.
 *
 * @param callable $work    Runs while the lock is held.
 * @param int      $wait    Seconds to wait for the lock. 0 = do not wait.
 * @param mixed    $refused Returned when the lock could not be taken.
 * @return mixed The work's return value, or $refused.
 */
function with_upgrade_lock(callable $work, $wait = 0, $refused = false)
{
    // db_open() returns a shared singleton and db_close() is a no-op, so this
    // is the same MySQL session the work itself will use. That is what makes
    // the lock re-entrant for a nested caller in the same request (MySQL grants
    // the same session the lock again and counts it, and the matching
    // RELEASE_LOCK decrements) while still excluding a different request.
    $db = db_open();
    if (!$db) {
        // Refuse rather than proceed unserialised. An upgrade that cannot prove
        // it is alone is exactly the one not to start.
        write_debug_log('Could not open a connection to take the upgrade lock; refusing to upgrade.', 'error');
        return $refused;
    }

    $acquired = false;

    // ONLY the acquisition is guarded. An exception from $work() propagates.
    //
    // Catching it here and returning $refused would tell the caller "an upgrade
    // is already running" when what actually happened is that the upgrade ran
    // and failed -- reporting one outcome for a completely different one, which
    // is the single most common defect this subsystem has had. The callers
    // already handle migration failures properly; the lock has no business
    // rewriting them.
    try {
        $stmt = $db->prepare("SELECT GET_LOCK('simplerisk_upgrade', :wait) AS acquired");
        $stmt->bindParam(":wait", $wait, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // GET_LOCK returns 1 (taken), 0 (timed out) or NULL (error). Only 1 is
        // permission to proceed.
        $acquired = ((int)($row['acquired'] ?? 0) === 1);
    } catch (Throwable $e) {
        write_debug_log('Taking the upgrade lock failed: ' . $e->getMessage(), 'error');
        $acquired = false;
    }

    if (!$acquired) {
        write_debug_log('An upgrade is already running on this instance, or the lock could not be taken; refusing to start a second one.', 'warning');
        db_close($db);
        return $refused;
    }

    try {
        return $work();
    } finally {
        // Must run, and cannot be left to the connection closing: db_close() is
        // a no-op here, so a lock left held would stay held for the rest of the
        // request -- and on a persistent connection, beyond it.
        try { $db->query("SELECT RELEASE_LOCK('simplerisk_upgrade')"); } catch (Throwable $e) {}
        db_close($db);
    }
}

/**
 * Recompute the file_encoding_issues_count_{compliance,risk,questionnaire}
 * settings by counting rows whose stored `size` doesn't match the actual
 * byte-length of `content` -- a mismatch left behind by a charset-conversion
 * bug in an old upload path.
 *
 * Moved here from includes/functions.php when the legacy admin checker
 * (admin/fix_upload_encoding_issues.php and its supporting functions) was
 * retired in favor of the Data Integrity framework's file_content_mismatch
 * detector. Its only remaining caller is upgrade_from_20230106001() in
 * includes/upgrade.php (shipped 2023-03-31) -- an already-released historical
 * upgrade function that must keep working for anyone upgrading from a
 * pre-2023-03-31 database -- so per this file's admission rule ("a function
 * belongs here only if EVERY call site is part of the upgrade process") it
 * moves here rather than being deleted alongside the rest of the legacy
 * checker.
 *
 * @param string $type 'all', 'compliance', 'risk', or 'questionnaire'.
 * @return void
 */
// Refresh the number of files having an issue, update the settings or delete if there're no file with encoding issue left
function refresh_file_encoding_issue_counts($type = 'all') {

    $db = db_open();

    // Only query the database if it's really necessary
    $questionnaire_table_exists = (($type === 'questionnaire' || $type === 'all') ? table_exists('questionnaire_files') : false);

    if (($type === 'questionnaire' || $type === 'all') && !$questionnaire_table_exists) {
        // Make sure there's no leftover data left in the settings table
        delete_setting("file_encoding_issues_count_questionnaire");

        // If it's only for the questionnaire then there's nothing else to do here
        if ($type === 'questionnaire') {
            return;
        }
    }

    if ($type === 'all') {
        $types = ['compliance', 'risk'];
        if ($questionnaire_table_exists) {
            $types []= 'questionnaire';
        }
    } else {
        $types = [$type];
    }

    foreach ($types as $type) {
        $setting_name = "file_encoding_issues_count_{$type}";
        $log_type = $type;
        $sql = '';
        switch($type) {
            case 'compliance':
                $log_type = 'test_audit';
                $sql = "SELECT count(1) AS cnt FROM `compliance_files` WHERE `size` <> LENGTH(`content`);";
                break;
            case 'risk':
                $log_type = 'risk';
                $sql = "SELECT count(1) AS cnt FROM `files` WHERE `size` <> LENGTH(`content`);";
                break;
            case 'questionnaire':
                $log_type = 'questionnaire';
                $sql = "SELECT count(1) AS cnt FROM `questionnaire_files` WHERE `size` <> LENGTH(`content`);";
                break;
        }
        if (!$sql) continue;

        $stmt = $db->prepare($sql);
        $stmt->execute();

        $count = (int)$stmt->fetch(PDO::FETCH_COLUMN);

        // Refresh the numbers in the database
        if ($count) {
            $old_count = (int)get_setting($setting_name);
            if ($old_count !== $count) {
                update_or_insert_setting($setting_name, $count);
                write_log(0, $_SESSION['uid'] ?? 0, _lang('EncodingIssueCountUpdated', ['type' => $type, 'old_count' => $old_count, 'count' => $count]), $log_type);
            }
        } else {
            // Or delete the setting if the issues were cleaned up
            delete_setting($setting_name);
            write_log(0, $_SESSION['uid'] ?? 0, _lang('EncodingIssueCleanedUp', ['type' => $type]), $log_type);
        }
    }

    db_close($db);
}

/**
 * Seeds the seven granular asset-management permissions (asset_edit,
 * asset_delete, asset_verify, asset_discovery, asset_group_create,
 * asset_group_edit, asset_group_delete) into the existing "Asset Management"
 * permission group and grants them to every user and role that already holds
 * the parent `asset` permission, so upgrading customers keep today's behavior.
 *
 * The grant happens once per key, recorded in the
 * `asset_granular_permissions_granted` setting (a JSON list of the keys whose
 * grant completed), which is written only AFTER both grant statements. A
 * re-run (the in-flight release is re-applied by every CI/dev upgrade, a
 * retried upgrade, the upgrade API) grants only keys not recorded yet, so it
 * never hands the permissions back to a user or role an admin has since
 * narrowed to `asset` alone: before, every re-run re-granted all seven to
 * every `asset` holder, which also escalated test users created with `asset`
 * only (asset-record-modal SCENARIO-14's viewer saw Edit asset). And a run
 * that died between the seed and the grants is finished by the retry: gating
 * on "the key already exists" instead stranded every existing holder without
 * the new keys for good.
 *
 * Idempotent: `permissions.key`, `permission_groups.name` and the junction
 * tables' composite primary keys are all UNIQUE, so the INSERT IGNOREs dedupe,
 * and a run whose keys are all recorded grants nothing. $after_seed is a test
 * seam (a crash between the seed and the grants). add_new_permissions() also
 * grants the new keys to admin users. Permission names are stored as English
 * literals (the roles UI renders them raw), the same as every other seeded
 * permission.
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_add_asset_granular_permissions($db, ?callable $after_seed = null)
{
    require_once(realpath(__DIR__ . '/../permissions.php'));

    $keys = ['asset_edit', 'asset_delete', 'asset_verify', 'asset_discovery', 'asset_group_create', 'asset_group_edit', 'asset_group_delete'];

    add_new_permissions([
        'asset_management' => [
            'name' => 'Asset Management',
            'description' => '',
            'order' => 4,
            'permissions' => [
                'asset_edit' => [
                    'name' => 'Able to Edit Assets',
                    'description' => 'This permission allows a user to edit assets.',
                    'order' => 2,
                ],
                'asset_delete' => [
                    'name' => 'Able to Delete Assets',
                    'description' => 'This permission allows a user to delete assets.',
                    'order' => 3,
                ],
                'asset_verify' => [
                    'name' => 'Able to Verify Assets',
                    'description' => 'This permission allows a user to verify assets.',
                    'order' => 4,
                ],
                'asset_discovery' => [
                    'name' => 'Able to Run Asset Discovery',
                    'description' => 'This permission allows a user to run asset discovery.',
                    'order' => 5,
                ],
                'asset_group_create' => [
                    'name' => 'Able to Create Asset Groups',
                    'description' => 'This permission allows a user to create asset groups.',
                    'order' => 6,
                ],
                'asset_group_edit' => [
                    'name' => 'Able to Edit Asset Groups',
                    'description' => 'This permission allows a user to edit asset groups.',
                    'order' => 7,
                ],
                'asset_group_delete' => [
                    'name' => 'Able to Delete Asset Groups',
                    'description' => 'This permission allows a user to delete asset groups.',
                    'order' => 8,
                ],
            ],
        ],
    ]);

    if ($after_seed) {
        $after_seed();
    }

    // Read uncached: the grant decision must see the stored state.
    $marker = 'asset_granular_permissions_granted';
    $stmt = $db->prepare("SELECT `value` FROM `settings` WHERE `name` = :name");
    $stmt->execute([':name' => $marker]);
    $new_keys = upgrade_asset_permission_keys_to_grant($keys, $stmt->fetchColumn());
    if (!$new_keys) {
        write_debug_log('Asset permissions: the granular asset permissions were already granted to asset holders; nothing to grant on this run.', 'debug');
        return; // granted once already: an admin's later choices stand
    }

    // Grant the not-yet-granted keys to every current holder of `asset`
    // (direct user grants and role grants).
    $in = implode(',', array_fill(0, count($new_keys), '?'));

    $stmt = $db->prepare("
        INSERT IGNORE INTO `permission_to_user` (`permission_id`, `user_id`)
        SELECT `np`.`id`, `p2u`.`user_id`
        FROM `permission_to_user` `p2u`
            INNER JOIN `permissions` `ap` ON `ap`.`id` = `p2u`.`permission_id` AND `ap`.`key` = 'asset'
            INNER JOIN `permissions` `np` ON `np`.`key` IN ({$in})
    ");
    $stmt->execute($new_keys);

    $stmt = $db->prepare("
        INSERT IGNORE INTO `role_responsibilities` (`role_id`, `permission_id`)
        SELECT `rr`.`role_id`, `np`.`id`
        FROM `role_responsibilities` `rr`
            INNER JOIN `permissions` `ap` ON `ap`.`id` = `rr`.`permission_id` AND `ap`.`key` = 'asset'
            INNER JOIN `permissions` `np` ON `np`.`key` IN ({$in})
    ");
    $stmt->execute($new_keys);

    // Recorded only now, after both grants: a run that dies before this line
    // is finished by the next one.
    $db->prepare("INSERT INTO `settings` (`name`, `value`) VALUES (:name, :value) ON DUPLICATE KEY UPDATE `value` = :value_update")
        ->execute([':name' => $marker, ':value' => json_encode($keys), ':value_update' => json_encode($keys)]);
    unset($GLOBALS['setting_' . $marker]);

    // add_new_permissions() refreshed the open sessions of the admins it
    // granted; the non-admin holders granted just above need the same, or
    // anyone logged in across the upgrade keeps a session without the new
    // keys (no Edit, Verify, Add group, Discover assets...) until they log
    // out and back in.
    foreach (upgrade_asset_permission_session_holders($db, $new_keys) as $uid) {
        refresh_permissions_in_sessions_of_user($uid);
    }
}

/**
 * The granular asset permission keys upgrade_add_asset_granular_permissions()
 * still has to grant: every key of $keys not listed in the stored completion
 * marker ($stored: the setting's raw value, false when absent). A missing or
 * unreadable marker means nothing was granted yet. Pure.
 *
 * @param string[] $keys
 * @param string|false|null $stored
 * @return string[]
 */
function upgrade_asset_permission_keys_to_grant(array $keys, $stored): array
{
    $granted = is_string($stored) && $stored !== '' ? json_decode($stored, true) : [];
    if (!is_array($granted)) {
        $granted = [];
    }
    return array_values(array_diff($keys, array_filter($granted, 'is_string')));
}

/**
 * Non-admin users who hold any of $keys directly and have an open session:
 * the sessions upgrade_add_asset_granular_permissions() must refresh after
 * granting (admins are refreshed by add_new_permissions() itself). Empty
 * before sessions.user_id exists (refresh_permissions_in_sessions_of_user()
 * skips those sessions anyway).
 *
 * @param string[] $keys
 * @return int[]
 */
function upgrade_asset_permission_session_holders($db, array $keys): array
{
    if (!$keys || !field_exists_in_table('user_id', 'sessions')) {
        return [];
    }
    $in = implode(',', array_fill(0, count($keys), '?'));
    $stmt = $db->prepare("
        SELECT DISTINCT `u`.`value`
        FROM `sessions` `s`
            INNER JOIN `user` `u` ON `u`.`value` = `s`.`user_id` AND `u`.`admin` = 0
            INNER JOIN `permission_to_user` `p2u` ON `p2u`.`user_id` = `u`.`value`
            INNER JOIN `permissions` `p` ON `p`.`id` = `p2u`.`permission_id` AND `p`.`key` IN ({$in})
        ORDER BY `u`.`value`
    ");
    $stmt->execute(array_values($keys));
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * Asset management redesign: per-user column visibility / order for the
 * Manage assets grid. Same JSON shape family as
 * custom_plan_projects_display_settings ({"columns": [[key,"1"|"0"],...],
 * "order": [key,...]}); NULL means "defaults". Idempotent.
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_add_asset_column_settings($db)
{
    if (!field_exists_in_table('custom_manage_assets_display_settings', 'user')) {
        echo "Adding a custom_manage_assets_display_settings field to user table.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `user` ADD COLUMN `custom_manage_assets_display_settings` TEXT NULL");
        $stmt->execute();
    }
}

/**
 * Asset management redesign: per-user column visibility / order for the
 * Manage assets page's Asset groups table -- its own column, so the two
 * tables' layouts never collide. Same JSON shape as
 * custom_manage_assets_display_settings; NULL means "defaults". Idempotent.
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_add_asset_group_column_settings($db)
{
    if (!field_exists_in_table('custom_manage_asset_groups_display_settings', 'user')) {
        echo "Adding a custom_manage_asset_groups_display_settings field to user table.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `user` ADD COLUMN `custom_manage_asset_groups_display_settings` TEXT NULL");
        $stmt->execute();
    }
}

/**
 * Asset management redesign: background asset discovery runs (spec section
 * 7). One row per run a user starts from Manage assets; the
 * core_asset_discovery queue job records its progress here. A Core table.
 * Idempotent (table_exists guard + CREATE TABLE IF NOT EXISTS, and
 * field_exists_in_table guards on the columns added later).
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_add_asset_discovery_runs($db)
{
    if (!table_exists('asset_discovery_runs')) {
        echo "Creating the asset_discovery_runs table.<br />\n";
        $stmt = $db->prepare("
            CREATE TABLE IF NOT EXISTS `asset_discovery_runs` (
                `id` INT NOT NULL AUTO_INCREMENT,
                `range_text` VARCHAR(100) NOT NULL,
                `resolve_names` TINYINT(1) NOT NULL DEFAULT 1,
                `add_as_verified` TINYINT(1) NOT NULL DEFAULT 0,
                `team_ids` VARCHAR(4000) NOT NULL DEFAULT '',
                `created_by` INT NOT NULL,
                `status` VARCHAR(20) NOT NULL DEFAULT 'queued',
                `total_hosts` INT NOT NULL DEFAULT 0,
                `hosts_scanned` INT NOT NULL DEFAULT 0,
                `live_hosts` INT NOT NULL DEFAULT 0,
                `new_assets` INT NOT NULL DEFAULT 0,
                `error_text` VARCHAR(1000) NULL,
                `probe_method` VARCHAR(20) NULL,
                `tcp_ports` VARCHAR(200) NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `started_at` DATETIME NULL,
                `finished_at` DATETIME NULL,
                PRIMARY KEY (`id`),
                INDEX `idx_asset_discovery_runs_user_status` (`created_by`, `status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        $stmt->execute();
    }

    // The probe method a run used and its TCP ports (discovery probe
    // methods). The CREATE above has them; a table created before they
    // existed gets them here.
    if (!field_exists_in_table('probe_method', 'asset_discovery_runs')) {
        echo "Adding the probe_method column to the asset_discovery_runs table.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `asset_discovery_runs` ADD COLUMN `probe_method` VARCHAR(20) NULL AFTER `error_text`");
        $stmt->execute();
    }
    if (!field_exists_in_table('tcp_ports', 'asset_discovery_runs')) {
        echo "Adding the tcp_ports column to the asset_discovery_runs table.<br />\n";
        $stmt = $db->prepare("ALTER TABLE `asset_discovery_runs` ADD COLUMN `tcp_ports` VARCHAR(200) NULL AFTER `probe_method`");
        $stmt->execute();
    }
}

/**
 * Asset Scoring (spec 2026-09-30-asset-scoring-design.md §4): the asset's
 * FIPS 199 potential impact per security objective. NULL = not set; only
 * confidentiality accepts not_applicable. Scores are computed on read
 * (includes/asset_scoring.php) and never stored. Idempotent
 * (field_exists_in_table guard per column).
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_add_asset_scoring_columns($db)
{
    $columns = [
        'confidentiality' => "ENUM('low','moderate','high','not_applicable') NULL DEFAULT NULL",
        'integrity' => "ENUM('low','moderate','high') NULL DEFAULT NULL",
        'availability' => "ENUM('low','moderate','high') NULL DEFAULT NULL",
    ];
    foreach ($columns as $column => $definition) {
        if (!field_exists_in_table($column, 'assets')) {
            echo "Adding a {$column} field to the assets table.<br />\n";
            $stmt = $db->prepare("ALTER TABLE `assets` ADD COLUMN `{$column}` {$definition}");
            $stmt->execute();
        }
    }
}

/**
 * SR-2040: rewrite the inaccurate comment_risk_management description on
 * existing installs. Idempotent: only a row whose text differs is touched, and
 * no other permission is affected. Stored as an English literal in the
 * permissions table, like every other seeded permission description.
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_reword_comment_risk_management_description($db)
{
    $description = 'This permission allows a user to add comments to risks. Reading a risk or its existing comments requires the Allow Access to "Risk Management" Menu permission, and when the Team Separation Extra is active, comments are limited to risks within the user\'s teams.';
    $stmt = $db->prepare("UPDATE `permissions` SET `description` = :description WHERE `key` = 'comment_risk_management' AND `description` <> :description2");
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':description2', $description, PDO::PARAM_STR);
    $stmt->execute();
}

/**
 * Update channel: seed the update_channel setting ('production' or 'rc').
 * Idempotent: the row is added only when absent, so a second run adds no
 * duplicate and an existing 'rc' (or any other) value is never overwritten.
 * The resolver in includes/update_channel.php treats an absent row as
 * production, so this is belt-and-suspenders for a visible default.
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 */
function upgrade_add_update_channel_setting($db)
{
    if (!setting_exists('update_channel', $db)) {
        add_setting('update_channel', 'production', $db);
    }
}

/**********************************************************
 * FUNCTION: UPGRADE REMOVE COUNTRIES REFRESH
 *
 * The org_location country list is now static (includes/countries.php); the
 * restcountries.com API it was refreshed from is deprecated and not licensed
 * for commercial use. Removes what the retired refresh left behind:
 *
 *  - every `core_countries_update` queue task. The job definition is gone, so
 *    a task left in the queue (pending, or already failed) would never run and
 *    the worker would keep failing it with "No job definition found",
 *    re-raising the "could not be completed after repeated attempts"
 *    notification.
 *  - the `countries_cache` and `countries_cache_last_failed_at` settings.
 *  - the job file and the old includes/countries_fallback.php (renamed to
 *    countries.php). An upgrade overlays new code but never deletes removed
 *    files, and a stale jobs/ file would otherwise sit in load_all_jobs()'s
 *    directory.
 *
 * Idempotent: every statement is a no-op once its target is gone.
 *
 * @param PDO         $db           Open database connection.
 * @param string|null $includes_dir Directory holding includes/ (test seam only;
 *                                  production callers pass nothing).
 *
 * Upgrade-only: called from the current unreleased upgrade_from_*().
 **********************************************************/
function upgrade_remove_countries_refresh($db, ?string $includes_dir = null)
{
    $includes_dir ??= dirname(__DIR__);

    $stmt = $db->prepare("DELETE FROM `queue_tasks` WHERE `task_type` = :task_type");
    $stmt->execute([':task_type' => 'core_countries_update']);
    if ($stmt->rowCount() > 0) {
        echo "Removed " . (int)$stmt->rowCount() . " retired core_countries_update queue task(s).<br />\n";
    }

    foreach (['countries_cache', 'countries_cache_last_failed_at'] as $setting_name) {
        if (setting_exists($setting_name, $db)) {
            echo "Removing the retired " . $setting_name . " setting.<br />\n";
            delete_setting($setting_name, $db);
        }
    }

    foreach (['jobs/core_countries_update.php', 'countries_fallback.php'] as $retired_file) {
        $path = $includes_dir . '/' . $retired_file;
        if (file_exists($path)) {
            echo "Deleting the retired includes/" . $retired_file . " file.<br />\n";
            if (!unlink($path)) {
                write_debug_log("upgrade_remove_countries_refresh: could not delete " . $path, 'warning');
            }
        }
    }
}

/**
 * Normalizes duplicate (number, name) rows in `risk_catalog`, repointing
 * `risk_catalog_mappings` off the duplicate before adding a unique index on
 * (number, name). Extracted out of the already-shipped
 * upgrade_from_20251118001() for SR-2414 so the fix below is directly
 * testable without needing a database already sitting at that exact
 * pre-upgrade version.
 *
 * SR-2414: the historical seed-on-upgrade behavior (stopped for NEW
 * duplication by SR-2084, but not retroactively) left some instances with
 * duplicate risk_catalog rows where a risk is ALREADY mapped to both the
 * duplicate row and the one being kept. Step 2's repoint would then try to
 * create a (risk_id, risk_catalog_id) pair that risk_catalog_mappings'
 * composite PRIMARY KEY already holds, aborting the whole upgrade chain with
 * a duplicate-key PDOException. Step 1 removes exactly those
 * already-redundant mapping rows first, so Step 2 never collides.
 *
 * Idempotent: the index_exists_on_table() guard makes every step a no-op
 * once the unique index is in place.
 */
function upgrade_normalize_duplicate_risk_catalog_entries($db)
{
    if (index_exists_on_table('uniq_risk_catalog_number_name', 'risk_catalog')) {
        return;
    }

    echo "Normalizing duplicate risks in risk_catalog table.<br />\n";

    // Step 1: Remove risk_catalog_mappings rows that would collide with the
    // Step 2 repoint -- a risk already mapped to BOTH the duplicate and the
    // kept risk_catalog row already holds the (risk_id, risk_catalog_id)
    // pair the repoint would otherwise try to create.
    $stmt = $db->prepare("
        DELETE rcm1
        FROM risk_catalog_mappings rcm1
        INNER JOIN risk_catalog rc1 ON rcm1.risk_catalog_id = rc1.id
        INNER JOIN risk_catalog rc2
            ON rc1.number = rc2.number
            AND rc1.name = rc2.name
            AND rc1.id > rc2.id
        INNER JOIN risk_catalog_mappings rcm2
            ON rcm2.risk_id = rcm1.risk_id
            AND rcm2.risk_catalog_id = rc2.id;
    ");
    $stmt->execute();

    // Step 2: Update risk_catalog_mappings to point to the kept risk_catalog.id
    $stmt = $db->prepare("
        UPDATE risk_catalog_mappings rcm
        INNER JOIN risk_catalog rc1 ON rcm.risk_catalog_id = rc1.id
        INNER JOIN risk_catalog rc2
            ON rc1.number = rc2.number
            AND rc1.name = rc2.name
            AND rc1.id > rc2.id
        SET rcm.risk_catalog_id = rc2.id;
    ");
    $stmt->execute();

    // Step 3: Delete duplicate risk_catalog rows (keep smallest id)
    $stmt = $db->prepare("
        DELETE rc1
        FROM risk_catalog rc1
        INNER JOIN risk_catalog rc2
            ON rc1.number = rc2.number
            AND rc1.name = rc2.name
            AND rc1.id > rc2.id;
    ");
    $stmt->execute();

    // Step 4: Add unique index on (number, name)
    echo "Making (number, name) unique in risk_catalog.<br />\n";
    $stmt = $db->prepare("
        ALTER TABLE `risk_catalog`
        ADD UNIQUE INDEX `uniq_risk_catalog_number_name` (`number`, `name`(191));
    ");
    $stmt->execute();
}

/**********************************************************
 * FUNCTION: UPGRADE REMOVE COMPLIANCEFORGE PAGE          *
 * admin/complianceforge.php was a shell page for the     *
 * never-built ComplianceForge Extra, deleted from the    *
 * source in 5da881b531. An upgrade overlays new code but *
 * never deletes removed files, and no upgrade function   *
 * unlinked this one, so it still sits on every install   *
 * that ever shipped it. Its address now redirects to     *
 * admin/securecontrolsframework.php (admin/.htaccess),   *
 * but a server that ignores .htaccess would keep serving *
 * the stale page, and a POST to it calls                 *
 * enable_complianceforge_extra(), which no longer exists.*
 *                                                        *
 * Idempotent: a no-op once the file is gone.             *
 *                                                        *
 * @param string|null $admin_dir Directory holding the    *
 *                               admin pages (test seam    *
 *                               only; production callers  *
 *                               pass nothing).            *
 *                                                        *
 * Upgrade-only: called from the current unreleased       *
 * upgrade_from_*().                                      *
 **********************************************************/
function upgrade_remove_complianceforge_page(?string $admin_dir = null)
{
    $admin_dir ??= dirname(__DIR__, 2) . '/admin';
    $path = $admin_dir . '/complianceforge.php';

    if (file_exists($path)) {
        echo "Deleting the retired admin/complianceforge.php page.<br />\n";
        if (!unlink($path)) {
            write_debug_log("upgrade_remove_complianceforge_page: could not delete " . $path, 'warning');
        }
    }
}

/**********************************************************
 * FUNCTION: UPGRADE REMOVE UCF EXTRA                     *
 * The Unified Compliance Framework (UCF) Extra is        *
 * retired. Removes everything it left on an instance:    *
 *                                                        *
 *  - its four tables (ucf_ad_lists,                      *
 *    ucf_authority_documents,                            *
 *    ucf_authority_document_controls, ucf_audit_items).  *
 *    Only these UCF mapping tables go: frameworks,       *
 *    controls and tests that were installed from UCF     *
 *    are ordinary Core records and are kept.             *
 *  - its settings: the `ucf` activation flag, the        *
 *    `ucf_extra_version` migration counter and the four  *
 *    connection/scheduling settings (UCFAPIKey,          *
 *    UCFDefaultTester, UCFTestFrequency,                 *
 *    UCFApproximateTime).                                *
 *  - the extras/ucf/ directory and admin/ucf.php. An     *
 *    upgrade overlays new code but never deletes removed *
 *    files, so both would otherwise stay on disk.        *
 *                                                        *
 * Idempotent: every step is a no-op once its target is   *
 * gone.                                                  *
 *                                                        *
 * @param PDO         $db            Open database          *
 *                                   connection.            *
 * @param string|null $simplerisk_dir The simplerisk/ root  *
 *                                   (test seam only;       *
 *                                   production callers     *
 *                                   pass nothing).         *
 *                                                        *
 * Upgrade-only: called from the current unreleased       *
 * upgrade_from_*().                                      *
 **********************************************************/
function upgrade_remove_ucf_extra($db, ?string $simplerisk_dir = null)
{
    $simplerisk_dir ??= dirname(__DIR__, 2);

    // These are the Extra's own tables, hardcoded and never built from input.
    foreach (['ucf_ad_lists', 'ucf_authority_documents', 'ucf_authority_document_controls', 'ucf_audit_items'] as $table) {
        $stmt = $db->prepare("SHOW TABLES LIKE :table");
        $stmt->execute([':table' => $table]);
        if ($stmt->fetchColumn() !== false) {
            echo "Dropping the retired " . $table . " table.<br />\n";
            $db->exec("DROP TABLE IF EXISTS `" . $table . "`");
        }
    }

    foreach (['ucf', 'ucf_extra_version', 'UCFAPIKey', 'UCFDefaultTester', 'UCFTestFrequency', 'UCFApproximateTime'] as $setting_name) {
        if (setting_exists($setting_name, $db)) {
            echo "Removing the retired " . $setting_name . " setting.<br />\n";
            delete_setting($setting_name, $db);
        }
    }

    $retired_page = $simplerisk_dir . '/admin/ucf.php';
    if (file_exists($retired_page)) {
        echo "Deleting the retired admin/ucf.php page.<br />\n";
        if (!unlink($retired_page)) {
            write_debug_log("upgrade_remove_ucf_extra: could not delete " . $retired_page, 'warning');
        }
    }

    $retired_extra = $simplerisk_dir . '/extras/ucf';
    if (is_dir($retired_extra)) {
        echo "Deleting the retired extras/ucf directory.<br />\n";
        $entries = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($retired_extra, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($entries as $entry) {
            // A symlink is unlinked, never followed into.
            $ok = ($entry->isDir() && !$entry->isLink()) ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
            if (!$ok) {
                write_debug_log("upgrade_remove_ucf_extra: could not delete " . $entry->getPathname(), 'warning');
            }
        }
        if (!rmdir($retired_extra)) {
            write_debug_log("upgrade_remove_ucf_extra: could not delete " . $retired_extra, 'warning');
        }
    }
}
